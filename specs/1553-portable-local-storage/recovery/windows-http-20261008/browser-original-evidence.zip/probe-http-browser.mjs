import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';

const root = String.raw`C:\Temp\boe-win-6381a950-20261008T030647Z`;
const url = process.argv[2];
if (!/^http:\/\/127\.0\.0\.1:\d+$/.test(url ?? '')) throw new Error('An owned loopback URL is required');
const out = path.join(root, 'evidence', 'http-browser-final');
fs.mkdirSync(out, {recursive:false});
const profile = path.join(root, 'data', 'chrome-http-final-' + Date.now());
fs.mkdirSync(profile, {recursive:false});
const events = [];
const record = (label, value) => {
  events.push({utc:new Date().toISOString(), label, value});
  fs.writeFileSync(path.join(out, 'events.json'), JSON.stringify(events,null,2));
};
const delay = ms => new Promise(resolve => setTimeout(resolve,ms));
const chrome = spawn(String.raw`C:\Program Files\Google\Chrome\Application\chrome.exe`,
  ['--headless','--remote-debugging-port=0',`--user-data-dir=${profile}`,
   '--no-first-run','--no-default-browser-check','--disable-background-networking',
   '--window-size=1280,900','about:blank'],
  {windowsHide:true,stdio:['ignore',fs.openSync(path.join(out,'chrome.stdout.txt'),'wx'),fs.openSync(path.join(out,'chrome.stderr.txt'),'wx')]});
const exited = new Promise(resolve => chrome.once('exit',(code,signal) => resolve({code,signal})));
record('owned-chrome-start',{pid:chrome.pid,profile,url});
const pending = new Map();
let socket, sessionId, counter=0, failed=false, browserExit;
const exceptions=[], responses=[], loadingFailures=[];
function send(method,params={},session) {
  const id=++counter;
  return new Promise((resolve,reject) => {
    const timer=setTimeout(() => {pending.delete(id);reject(new Error(method+' timed out'));},15000);
    pending.set(id,{resolve,reject,timer});
    socket.send(JSON.stringify({id,method,params,...(session?{sessionId:session}:{})}));
  });
}
try {
  const portFile=path.join(profile,'DevToolsActivePort');
  for(let i=0;i<100&&!fs.existsSync(portFile);i++) await delay(100);
  const [port,endpoint]=fs.readFileSync(portFile,'utf8').trim().split(/\r?\n/);
  const schema=await (await fetch(`http://127.0.0.1:${port}/json/protocol`,{signal:AbortSignal.timeout(10000)})).json();
  record('owned-cdp-schema',{version:schema.version,domains:schema.domains.filter(d=>['Browser','Target','Runtime','Page','Network'].includes(d.domain)).map(d=>({domain:d.domain,commands:d.commands.map(c=>c.name)}))});
  socket=new WebSocket(`ws://127.0.0.1:${port}${endpoint}`);
  await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
  socket.addEventListener('message',event=>{
    const m=JSON.parse(event.data);
    if(m.id) {
      const p=pending.get(m.id);
      if(p) {clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(new Error(JSON.stringify(m.error))):p.resolve(m.result);}
    } else if(m.method==='Runtime.exceptionThrown') exceptions.push(m.params.exceptionDetails);
    else if(m.method==='Network.loadingFailed') loadingFailures.push(m.params);
    else if(m.method==='Network.responseReceived'&&m.params.response.url.startsWith(url))
      responses.push({url:m.params.response.url,status:m.params.response.status,mimeType:m.params.response.mimeType});
  });
  record('browser-version',await send('Browser.getVersion'));
  const targets=await send('Target.getTargets');
  record('owned-target-inventory',targets);
  const target=targets.targetInfos.find(t=>t.type==='page'&&t.url==='about:blank');
  if(!target) throw new Error('Owned blank page missing');
  ({sessionId}=await send('Target.attachToTarget',{targetId:target.targetId,flatten:true}));
  for(const method of ['Runtime.enable','Page.enable','Network.enable']) await send(method,{},sessionId);
  const evaluate=async expression=>{
    const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessionId);
    if(r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
    return r.result.value;
  };
  await send('Page.navigate',{url},sessionId);
  let dom;
  for(let i=0;i<450;i++) {
    dom=await evaluate('({title:document.title,text:document.body.innerText,buttons:[...document.querySelectorAll("button")].map(x=>x.innerText)})');
    if(dom.buttons.length>2&&!/Открываем книгу|Загружаем книгу/.test(dom.text)) break;
    await delay(200);
  }
  if(dom.buttons.length<3||/Открываем книгу|Загружаем книгу/.test(dom.text)) throw new Error('Initial browser data did not finish loading');
  await evaluate('(()=>{const b=[...document.querySelectorAll("button")].find(x=>x.innerText.trim()==="Главное меню");if(b)b.click()})()');
  await delay(1200);
  dom=await evaluate('({title:document.title,text:document.body.innerText,launcher:!!document.querySelector(".game-launcher"),buttons:[...document.querySelectorAll("button")].map(x=>x.innerText)})');
  record('main-menu-rendered',dom);
  if(!dom.launcher) throw new Error('Actual game launcher is absent');
  fs.writeFileSync(path.join(out,'main-menu.png'),Buffer.from((await send('Page.captureScreenshot',{format:'png'},sessionId)).data,'base64'));
  const clicked=await evaluate('(()=>{const b=[...document.querySelectorAll("button")].find(x=>/Опции|Настройки/i.test(x.innerText));if(!b)return false;b.click();return true})()');
  let settings;
  for(let i=0;i<450;i++) {
    settings=await evaluate('({text:document.body.innerText,view:!!document.querySelector(".settings-view"),inputs:[...document.querySelectorAll(".settings-view input,.settings-view select")].map(x=>({tag:x.tagName,type:x.type,value:x.value,checked:x.checked}))})');
    if(settings.inputs.length&&!/Загрузка настроек/.test(settings.text)) break;
    await delay(200);
  }
  record('settings-rendered',{clicked,settings});
  if(!clicked||!settings.view||!settings.inputs.length||/Загрузка настроек/.test(settings.text)) throw new Error('Settings controls did not load');
  await delay(1000);
  fs.writeFileSync(path.join(out,'settings.png'),Buffer.from((await send('Page.captureScreenshot',{format:'png'},sessionId)).data,'base64'));
  record('javascript-exceptions',exceptions);
  record('owned-http-responses',responses);
  record('network-loading-failures',loadingFailures);
  for(const route of ['/api/main-menu','/api/session','/api/game-screen','/api/audio/settings','/api/client/settings'])
    if(!responses.some(r=>new URL(r.url).pathname===route&&r.status===200)) throw new Error('Missing successful browser response: '+route);
  if(exceptions.length||loadingFailures.length||responses.some(r=>r.status>=400)) throw new Error('Browser observed a JavaScript, transport or HTTP error');
} catch(error) {
  failed=true;record('failure',String(error));
} finally {
  if(socket?.readyState===WebSocket.OPEN) {
    try {await send('Browser.close');} catch(error) {record('browser-close-response',String(error));}
    socket.close();
  }
  browserExit=await Promise.race([exited,delay(5000).then(()=>null)]);
  if(!browserExit) {
    failed=true;record('owned-chrome-abnormal-stop',{pid:chrome.pid});
    chrome.kill();
    browserExit=await Promise.race([exited,delay(5000).then(()=>null)]);
  }
  record('owned-chrome-exit',browserExit);
  if(!browserExit||browserExit.code!==0||browserExit.signal!==null) failed=true;
  for(const p of pending.values()) {clearTimeout(p.timer);p.reject(new Error('Closed'));}
  pending.clear();
}
console.log(JSON.stringify({passed:!failed,report:out,browserExit,httpResponses:responses.length,javascriptExceptions:exceptions.length}));
process.exitCode=failed?1:0;
