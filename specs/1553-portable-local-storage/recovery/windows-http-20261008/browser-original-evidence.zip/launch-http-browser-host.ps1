$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$root = 'C:\Temp\boe-win-6381a950-20261008T030647Z'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_CLI_HOME = Join-Path $root 'dotnet-home'
$env:DOTNET_PROCESSOR_COUNT = '2'
$env:TEMP = Join-Path $root 'tmp'
$env:TMP = $env:TEMP
Set-Location -LiteralPath (Join-Path $root 'repo')
Start-Transcript -LiteralPath (Join-Path $root 'evidence/http-browser-host-transcript.txt') -NoClobber | Out-Null
try {
    & dotnet (Join-Path $root 'http-worktree/BookOfEternityClient/bin/Debug/net8.0/BookOfEternityClient.dll') (Join-Path $root 'data/http-ordinary-new-game') --web --web-url 'http://127.0.0.1:0'
    $code = $LASTEXITCODE
    [pscustomobject]@{ExitCode=$code;FinishedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
}
finally { Stop-Transcript | Out-Null }
exit $code
