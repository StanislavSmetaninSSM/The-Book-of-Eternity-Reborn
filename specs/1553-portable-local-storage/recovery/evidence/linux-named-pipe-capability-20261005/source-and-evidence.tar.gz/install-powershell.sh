#!/usr/bin/env bash
set -euo pipefail
source /workspace/linux-1553-artifacts/env.sh
curl --fail --show-error --location --max-time 180 https://github.com/PowerShell/PowerShell/releases/download/v7.6.6/powershell-7.6.6-linux-x64.tar.gz -o "$BOE_TOOLCHAIN/powershell.tar.gz"
printf 'ddbc4a2d113bbd46d283cfedcbcd117a70caefd7673f41f2b4e0000badf103bc  %s\n' "$BOE_TOOLCHAIN/powershell.tar.gz" | sha256sum -c -
mkdir -p "$BOE_TOOLCHAIN/powershell"
tar -xzf "$BOE_TOOLCHAIN/powershell.tar.gz" -C "$BOE_TOOLCHAIN/powershell"
chmod u+x "$BOE_TOOLCHAIN/powershell/pwsh"
pwsh -NoLogo -NoProfile -Command '$PSVersionTable | ConvertTo-Json'
