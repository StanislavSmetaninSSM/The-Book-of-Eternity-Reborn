using System.IO.Pipes;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text.Json;

var stage = "initialization";
var suffix = Guid.NewGuid().ToString("N")[..12];
var controlName = "boe-cap-c-" + suffix;
var statusName = "boe-cap-s-" + suffix;
NamedPipeServerStream? control = null, status = null;
NamedPipeClientStream? controlPeer = null, statusPeer = null;
var result = new Dictionary<string, object?>
{
    ["runtime"] = RuntimeInformation.FrameworkDescription,
    ["os"] = RuntimeInformation.OSDescription,
    ["pid"] = Environment.ProcessId,
    ["tempPath"] = Path.GetTempPath(),
    ["controlPipeName"] = controlName,
    ["statusPipeName"] = statusName,
    ["options"] = "Byte, Asynchronous|CurrentUserOnly, maxInstances=1; control Out/status In",
    ["ordinaryPermissions"] = true,
    ["peerAuthenticationQualification"] = false
};
var passed = false;
try
{
    stage = "control NamedPipeServerStream constructor";
    control = new(controlName, PipeDirection.Out, 1, PipeTransmissionMode.Byte,
        PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
    stage = "status NamedPipeServerStream constructor";
    status = new(statusName, PipeDirection.In, 1, PipeTransmissionMode.Byte,
        PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
    result["constructorsPassed"] = true;
    result["socketPathsObserved"] = Directory.EnumerateFileSystemEntries(Path.GetTempPath(), "*" + suffix + "*").ToArray();
    controlPeer = new(".", controlName, PipeDirection.In, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
    statusPeer = new(".", statusName, PipeDirection.Out, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
    using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(5));
    stage = "connect both local peers";
    await Task.WhenAll(control.WaitForConnectionAsync(deadline.Token), status.WaitForConnectionAsync(deadline.Token),
        controlPeer.ConnectAsync(deadline.Token), statusPeer.ConnectAsync(deadline.Token));
    stage = "control byte transfer";
    await control.WriteAsync(new byte[] { 0x43 }, deadline.Token);
    var buffer = new byte[1];
    await controlPeer.ReadExactlyAsync(buffer, deadline.Token);
    if (buffer[0] != 0x43) throw new InvalidDataException("Control byte mismatch.");
    stage = "status byte transfer";
    await statusPeer.WriteAsync(new byte[] { 0x53 }, deadline.Token);
    await status.ReadExactlyAsync(buffer, deadline.Token);
    if (buffer[0] != 0x53) throw new InvalidDataException("Status byte mismatch.");
    passed = true;
    result["status"] = "PASS transport capability only";
}
catch (Exception ex)
{
    result["status"] = "FAIL capability";
    result["failureStage"] = stage;
    result["exception"] = ex.ToString();
    var errors = new List<object>();
    for (Exception? current = ex; current is not null; current = current.InnerException)
    {
        errors.Add(new {
            type = current.GetType().FullName, current.Message, current.HResult,
            nativeErrorCode = current is SocketException socket ? (int?)socket.NativeErrorCode : null,
            socketErrorCode = current is SocketException socketError ? socketError.SocketErrorCode.ToString() : null
        });
    }
    result["exceptionChain"] = errors;
}
finally
{
    controlPeer?.Dispose();
    statusPeer?.Dispose();
    control?.Dispose();
    status?.Dispose();
    var remaining = Directory.EnumerateFileSystemEntries(Path.GetTempPath(), "*" + suffix + "*").ToArray();
    result["ownedSocketPathsRemaining"] = remaining;
    result["cleanupComplete"] = remaining.Length == 0;
    if (remaining.Length != 0) passed = false;
}
Console.WriteLine(JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
return passed ? 0 : 1;
