#!/usr/bin/env bash
set -euo pipefail
source /workspace/linux-1553-artifacts/env.sh
printf '082f7685e156738a1b2e2ed8381a621870d4ce8e8c59278034556f05c186eb2e  %s\n' "$BOE_TOOLCHAIN/dotnet-install.sh" | sha256sum -c -
bash "$BOE_TOOLCHAIN/dotnet-install.sh" --version 10.0.401 --install-dir "$BOE_TOOLCHAIN/dotnet" --no-path
bash "$BOE_TOOLCHAIN/dotnet-install.sh" --version 8.0.31 --runtime aspnetcore --install-dir "$BOE_TOOLCHAIN/dotnet" --no-path
dotnet --info
dotnet --list-runtimes
