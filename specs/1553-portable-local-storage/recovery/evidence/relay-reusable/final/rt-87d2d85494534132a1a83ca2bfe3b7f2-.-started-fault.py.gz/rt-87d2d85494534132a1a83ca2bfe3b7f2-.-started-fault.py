import sys
sys.path.insert(0,sys.argv.pop(1))
import relay_cli
original=relay_cli.save
def save(path,value):
    if path.name=='started.json':raise OSError('Controlled started metadata publication failure')
    original(path,value)
relay_cli.save=save
sys.exit(relay_cli.main())
