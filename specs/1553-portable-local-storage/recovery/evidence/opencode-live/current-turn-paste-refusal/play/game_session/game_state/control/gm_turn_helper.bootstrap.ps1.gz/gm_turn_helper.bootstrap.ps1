. '/workspace/og9/play/game_session/_runtime/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/workspace/og9/play/game_session'

