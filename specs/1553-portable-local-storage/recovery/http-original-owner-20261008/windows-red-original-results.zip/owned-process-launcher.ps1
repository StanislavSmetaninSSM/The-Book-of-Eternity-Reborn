[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$LaunchGateName,

    [Parameter(Mandatory)]
    [string]$PayloadPath
)

$ErrorActionPreference = "Stop"
$launchGate =
    [System.Threading.EventWaitHandle]::OpenExisting($LaunchGateName)
try {
    if (-not $launchGate.WaitOne(30000)) {
        throw "Owned process launch gate timed out."
    }

    $payload = Get-Content -LiteralPath $PayloadPath -Raw | ConvertFrom-Json
    & ([string]$payload.FileName) @($payload.Arguments)
    $targetExitCode = if ($null -eq $LASTEXITCODE) {
        0
    }
    else {
        [int]$LASTEXITCODE
    }
    exit $targetExitCode
}
catch {
    [Console]::Error.WriteLine($_.Exception.ToString())
    exit 1
}
finally {
    $launchGate.Dispose()
}
