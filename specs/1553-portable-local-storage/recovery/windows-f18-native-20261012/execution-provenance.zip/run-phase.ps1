[CmdletBinding()]
param([Parameter(Mandatory)][ValidateSet('Prepare','Actual')][string]$Phase)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$taskRoot='C:\Temp\boe-win-8c2ecdfa-20261011T234246Z'
$repo=Join-Path $taskRoot 'repo'
$phaseDir=Join-Path $taskRoot ('evidence\' + $Phase.ToLowerInvariant())
if (Test-Path -LiteralPath $phaseDir) { throw 'Phase already reserved: inspect its PID, exit and evidence; no automatic repeat.' }
New-Item -ItemType Directory -Path $phaseDir | Out-Null
$statePath=Join-Path $phaseDir 'process-state.json'
$state=[ordered]@{Phase=$Phase;State='Reserved';WrapperPid=$PID;WrapperStartedUtc=(Get-Process -Id $PID).StartTime.ToUniversalTime().ToString('o');RunnerPid=$null;RunnerStartedUtc=$null;ExitCode=$null;StartedUtc=[DateTime]::UtcNow.ToString('o');CompletedUtc=$null;Source='8c2ecdfaa1003e49bf15ba83693788e9b19dd10f';Category='legacy-physical-publication-windows';CategoryBudgetMinutes=3;RunnerDefaultBudgetMinutes=8;Stdout=(Join-Path $phaseDir 'stdout.log');Stderr=(Join-Path $phaseDir 'stderr.log')}
function Save-State { $state | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $statePath -Encoding utf8NoBOM }
Save-State
try {
    Set-Location -LiteralPath $repo
    $head=(git -c core.longpaths=true -c core.autocrlf=false rev-parse HEAD).Trim()
    if ($LASTEXITCODE -ne 0 -or $head -ne $state.Source) { throw 'Exact accepted source moved before phase launch.' }
    $status=@(git -c core.longpaths=true -c core.autocrlf=false status --porcelain=v1)
    if ($LASTEXITCODE -ne 0 -or $status.Count -ne 0) { throw 'Source checkout is not clean before launch.' }
    $state['Branch']=(git -c core.longpaths=true -c core.autocrlf=false branch --show-current).Trim()
    $envMap=[ordered]@{
        DOTNET_CLI_HOME=(Join-Path $taskRoot 'dotnet-home');
        NUGET_PACKAGES=(Join-Path $taskRoot 'nuget-packages');
        NUGET_HTTP_CACHE_PATH=(Join-Path $taskRoot 'nuget-http');
        NUGET_SCRATCH=(Join-Path $taskRoot 'nuget-scratch');
        NUGET_PLUGINS_CACHE_PATH=(Join-Path $taskRoot 'nuget-plugins');
        APPDATA=(Join-Path $taskRoot 'appdata');LOCALAPPDATA=(Join-Path $taskRoot 'localappdata');
        TEMP=(Join-Path $taskRoot 'tmp');TMP=(Join-Path $taskRoot 'tmp');
        DOTNET_CLI_TELEMETRY_OPTOUT='1';DOTNET_SKIP_FIRST_TIME_EXPERIENCE='1';
        DOTNET_GENERATE_ASPNET_CERTIFICATE='false';MSBUILDDISABLENODEREUSE='1';DOTNET_CLI_USE_MSBUILD_SERVER='0'
    }
    foreach ($entry in $envMap.GetEnumerator()) {
        [Environment]::SetEnvironmentVariable($entry.Key,$entry.Value,'Process')
        if ($entry.Value.StartsWith($taskRoot + '\',[StringComparison]::OrdinalIgnoreCase)) { New-Item -ItemType Directory -Path $entry.Value -Force | Out-Null }
    }
    $state['Environment']=$envMap
    $state['SdkVersion']=(& dotnet --version | Out-String).Trim()
    $state['OperatingSystem']=[Environment]::OSVersion.VersionString
    $state['PowerShellVersion']=$PSVersionTable.PSVersion.ToString()
    $state['IsWindows']=$IsWindows
    $runnerArgs=@('-NoLogo','-NoProfile','-File',(Join-Path $repo 'scripts\test-csharp.ps1'),'-Category',$state.Category)
    if ($Phase -eq 'Prepare') { $runnerArgs+='-PlanOnly' }
    else {
        $gatePath=Join-Path $taskRoot 'evidence\prepare-gate.json'
        if (-not (Test-Path -LiteralPath $gatePath)) { throw 'Matching fresh build/discovery/source/DLL gate is absent.' }
        $gate=Get-Content -LiteralPath $gatePath -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not $gate.Accepted -or $gate.Head -ne $head -or $gate.PlannedCases -ne 6) { throw 'Matching preparation gate is not accepted.' }
        $runnerArgs+='-NoBuild'
    }
    $state['Executable']=(Get-Command pwsh).Source
    $state['Arguments']=$runnerArgs
    $state['Command']='pwsh -NoLogo -NoProfile -File ./scripts/test-csharp.ps1 -Category legacy-physical-publication-windows ' + $(if ($Phase -eq 'Prepare') {'-PlanOnly'} else {'-NoBuild'})
    $state['State']='Launching'
    Save-State
    $runner=Start-Process -FilePath $state.Executable -ArgumentList $runnerArgs -WorkingDirectory $repo -WindowStyle Hidden -RedirectStandardOutput $state.Stdout -RedirectStandardError $state.Stderr -PassThru
    $state.RunnerPid=$runner.Id
    $state.RunnerStartedUtc=$runner.StartTime.ToUniversalTime().ToString('o')
    $state.State='Running'
    Save-State
    Write-Output ($state | ConvertTo-Json -Compress -Depth 8)
    $runner.WaitForExit()
    $state.ExitCode=$runner.ExitCode
    $state.State='Exited'
    $state.CompletedUtc=[DateTime]::UtcNow.ToString('o')
    $state['ResultDirectories']=@(Get-ChildItem -LiteralPath (Join-Path $repo 'TestResults\test-categories') -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match ('-' + $runner.Id + '-') } | ForEach-Object FullName)
    Save-State
    Write-Output ($state | ConvertTo-Json -Compress -Depth 8)
    exit $state.ExitCode
} catch {
    $state.State='WrapperFailure'
    $state['Failure']=$_.Exception.ToString()
    $state.CompletedUtc=[DateTime]::UtcNow.ToString('o')
    Save-State
    throw
}
