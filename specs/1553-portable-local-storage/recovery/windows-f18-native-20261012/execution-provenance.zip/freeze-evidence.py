import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone

root = pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z')
repo = root / 'repo'
target = repo / 'specs/1553-portable-local-storage/recovery/windows-f18-native-20261012'
assert not target.exists(), 'Evidence carrier exists; inspect rather than overwrite'
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
gate = read(root / 'evidence/prepare-gate.json')
actual = read(root / 'evidence/actual/process-state.json')
prepare = read(root / 'evidence/prepare/process-state.json')
assert actual['State'] == 'Exited' and actual['ExitCode'] == 0
assert len(actual['ResultDirectories']) == 1
result_dir = pathlib.Path(actual['ResultDirectories'][0])
summary = read(result_dir / 'summary.json')
assert summary['Revision']['Head'] == gate['Head'] and summary['Revision']['ChangedFiles'] == 0
assert summary['Selection']['Complete'] and summary['Selection']['CompletedCases'] == 6
assert summary['Tests']['Executed'] == 6 and summary['Tests']['Passed'] == 6 and summary['Tests']['Failed'] == 0
assert not summary['PlanOnly'] and summary['TimeoutMinutes'] == 8
assert not summary['TimedOut'] and not summary['DuplicateTests']
assert summary['OwnedTreeCleanupSucceeded'] and summary['RuntimeCleanupSucceeded']
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
trx = ET.parse(result_dir / 'legacy-physical-publication-windows-integration-001.trx')
cases = []
for case in trx.findall('.//t:UnitTestResult', ns):
    assert case.get('outcome') == 'Passed'
    output = case.find('t:Output/t:StdOut', ns).text
    rows = [json.loads(line) for line in output.splitlines() if line.startswith('{')]
    routes = [row for row in rows if row.get('kind') == 'native-legacy-publication-route']
    cleanups = [row for row in rows if 'CleanupOwnedRoot' in row]
    assert len(routes) == 1 and routes[0]['entered'] and routes[0]['flagRestored']
    assert len(cleanups) == 1 and cleanups[0]['OwnedFixtureRemoved'] and cleanups[0]['CleanupFailure'] is None
    owned = pathlib.Path(cleanups[0]['CleanupOwnedRoot'])
    assert owned.is_relative_to(root / 'tmp') and not owned.exists()
    cases.append({'Name': case.get('testName'), 'Outcome': case.get('outcome'),
                  'Duration': case.get('duration'), 'OriginalRouteReceipt': routes[0],
                  'OriginalCleanupReceipt': cleanups[0], 'OwnedRootAbsentAfterRun': True})
assert len(cases) == 6 and sorted(x['Name'] for x in cases) == sorted(gate['ExpectedMethods'])
counters = trx.find('.//t:ResultSummary/t:Counters', ns).attrib
assert counters['total'] == '6' and counters['executed'] == '6' and counters['passed'] == '6'
assert counters['failed'] == '0' and counters['notExecuted'] == '0'
for pin in gate['SourcePins'] + gate['DllPins']:
    path = repo / pin['Path']
    assert path.stat().st_size == pin['Bytes'] and sha(path) == pin['SHA256'], pin['Path']
git = ['git', '-c', 'core.longpaths=true', '-c', 'core.autocrlf=false']
assert not subprocess.check_output(git + ['status', '--porcelain=v1', '-z'], cwd=repo)
assert not list((root / 'tmp').glob('boe-filesystem-manager-*'))
assert not list((root / 'tmp').glob('boe-test-worker-runtime-*'))
target.mkdir(parents=True)
def archive(name, entries):
    output = target / name
    records = []
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipper:
        for path, arcname in entries:
            zipper.write(path, arcname)
            records.append({'Path': arcname, 'Bytes': path.stat().st_size, 'SHA256': sha(path)})
    with zipfile.ZipFile(output) as zipper:
        assert sorted(zipper.namelist()) == sorted(x['Path'] for x in records)
        for item in records:
            raw = zipper.read(item['Path'])
            assert len(raw) == item['Bytes'] and hashlib.sha256(raw).hexdigest() == item['SHA256']
    return {'Path': name, 'Bytes': output.stat().st_size, 'SHA256': sha(output), 'Entries': records}
archives = []
for phase, state in [('prepare', prepare), ('actual', actual)]:
    directory = pathlib.Path(state['ResultDirectories'][0])
    entries = [(p, 'runner/' + p.relative_to(directory).as_posix()) for p in sorted(directory.rglob('*')) if p.is_file()]
    entries += [(p, 'process/' + p.name) for p in sorted((root / 'evidence' / phase).iterdir()) if p.is_file()]
    archives.append(archive(f'{phase}-original.zip', entries))
metadata_paths = [root / 'preflight-state.json', root / 'working-branch.json',
                  root / 'run-phase.ps1', root / 'pin-source.py', root / 'prepare-gate.py',
                  root / 'freeze-evidence.py', root / 'evidence/source-pin-initial-failure.json',
                  root / 'evidence/source-before-prepare.json',
                  root / 'evidence/source-linked-closure-supplement.json', root / 'evidence/prepare-gate.json']
archives.append(archive('execution-provenance.zip', [(p, p.relative_to(root).as_posix()) for p in metadata_paths]))
manifest = {'SchemaVersion': 1, 'RecordedUtc': datetime.now(timezone.utc).isoformat(),
    'TrackedTask': '#1553 / T064-STORAGE-CUTS / F18 native physical publication6',
    'State': 'FirstWindowsGreenFrozen_IndependentEvidenceReviewPending',
    'Source': gate['Head'], 'WorkingBranch': read(root / 'working-branch.json')['Branch'],
    'Windows': read(root / 'preflight-state.json'), 'Category': gate['Category'],
    'PrepareCommand': prepare['Command'], 'ActualCommand': actual['Command'],
    'PrepareWallTime': gate['PreparationWallTime'], 'FreshBuildSeconds': gate['BuildWallSeconds'],
    'ActualWallTime': summary['WallTime'], 'CategorySeconds': summary['CategoryResults'][0]['Seconds'],
    'CategoryBudgetMinutes': 3, 'RunnerBudgetMinutes': 8, 'ActualAttempts': 1,
    'PreparationPlannedCases': 6, 'PreparationExecutedCases': 0,
    'ActualPlannedCases': 6, 'ActualCompletedCases': 6, 'ActualPassedCases': 6,
    'SkippedCases': 0, 'DuplicateTests': 0, 'TimedOut': False,
    'SourcePinsVerifiedBeforeAndAfterActual': len(gate['SourcePins']),
    'DllPdbPinsVerifiedBeforeAndAfterActual': len(gate['DllPins']),
    'FreshSelectedProjectOutputs': gate['FreshProjectOutputs'],
    'OwnedTreeCleanupSucceeded': True, 'RuntimeCleanupSucceeded': True,
    'OriginalRouteReceipts': 6, 'OriginalStrictCleanupReceipts': 6,
    'ObservedFixtureAndRuntimeRootsAbsent': True, 'Cases': cases, 'TrxCounters': counters,
    'Archives': archives,
    'NativeQualification': 'Six unchanged Windows-only Facts executed their explicit legacy write lease route; original positive hooks and native hard-link/file-ID/reparse checks are asserted by pinned source and passing original TRX.',
    'RecoveryScope': 'Original committed-cleanup test performs the public recovery read after the legacy write helper has disposed its write lease, preserves published bytes and file identity and empties quarantine/journal. No additional fresh-process cold restart was executed.',
    'Limits': ['Legacy physical recorder/recovery component only, not ordinary trusted-local publication',
               'No new process cold restart, active GM/full turn or whole storage recoverability qualification',
               'No Windows qualification of the six other handoff categories',
               'No B2-B5, provider calls, timer increases or architectural optimization',
               'Initial Unicode pin-list metadata failure occurred before build/test and is not a product RED',
               'Original runner logs, including pre-existing localized SDK decoding, are immutable'],
    'ProductSourceChanged': False, 'TestSourceChanged': False}
(target / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'Target': str(target), 'Cases': 6, 'OriginalRouteReceipts': 6, 'CleanupReceipts': 6,
                  'SourcePins': len(gate['SourcePins']), 'DllPins': len(gate['DllPins']),
                  'Archives': [{'Path': x['Path'], 'Bytes': x['Bytes'], 'Entries': len(x['Entries'])} for x in archives]}))
