import hashlib
import json
import pathlib
import subprocess
from datetime import datetime, timezone

root = pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z')
repo = root / 'repo'
expected = '8c2ecdfaa1003e49bf15ba83693788e9b19dd10f'
git = ['git', '-c', 'core.longpaths=true', '-c', 'core.autocrlf=false']
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
state = read(root / 'evidence/prepare/process-state.json')
assert state['State'] == 'Exited' and state['ExitCode'] == 0
assert len(state['ResultDirectories']) == 1
results = pathlib.Path(state['ResultDirectories'][0])
summary, plan = read(results / 'summary.json'), read(results / 'plan.json')
assert summary['PlanOnly'] and summary['ExitCode'] == 0
assert summary['Tests']['Executed'] == 0
assert summary['TimeoutMinutes'] == 8 and not summary['TimedOut']
assert summary['OwnedTreeCleanupSucceeded'] and summary['RuntimeCleanupSucceeded']
assert summary['Revision']['Head'] == expected and summary['Revision']['ChangedFiles'] == 0
assert summary['Selection']['PlannedCases'] == 6 and summary['Selection']['PlannedDescriptors'] == 1
assert any(p['Name'] == 'Build-integration' and p['Completed'] for p in summary['PhaseResults'])
catalog = read(repo / 'tests/categories.json')
category = [x for x in catalog['categories'] if x['id'] == 'legacy-physical-publication-windows']
assert len(category) == 1 and category[0]['timeoutMinutes'] == 3
expected_methods = category[0]['selectors'][0]['tests']
assert len(expected_methods) == 6
assert len(plan['Descriptors']) == 1
descriptor = plan['Descriptors'][0]
assert descriptor['BudgetMinutes'] == 3 and descriptor['EstimatedCases'] == 6
assert not descriptor['FrontendBuild'] and descriptor['Exclusive']
assert sorted(x['Name'] for x in descriptor['ExpectedMethodCounts']) == sorted(expected_methods)
assert all(x['Cases'] == 1 for x in descriptor['ExpectedMethodCounts'])
assert subprocess.check_output(git + ['rev-parse', 'HEAD'], cwd=repo, text=True).strip() == expected
assert not subprocess.check_output(git + ['status', '--porcelain=v1', '-z'], cwd=repo)
pins = read(root / 'evidence/source-before-prepare.json')['SourcePins']
pins += read(root / 'evidence/source-linked-closure-supplement.json')['SourcePins']
assert len({x['Path'] for x in pins}) == len(pins)
for pin in pins:
    path = repo / pin['Path']
    assert path.stat().st_size == pin['Bytes'] and sha(path) == pin['SHA256'], pin['Path']
dll_pins = []
projects = ['BookOfEternityClient', 'BookOfEternityClient.TestSupport', 'BookOfEternityClient.IntegrationTests']
for project in projects:
    output = repo / project / 'bin/Debug/net8.0'
    assert output.is_dir(), str(output)
    for path in sorted(output.rglob('*')):
        if path.is_file() and path.suffix.lower() in ['.dll', '.pdb']:
            dll_pins.append({'Path': path.relative_to(repo).as_posix(), 'Bytes': path.stat().st_size,
                             'SHA256': sha(path), 'LastWriteUtc': datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()})
fresh_outputs = []
started = datetime.fromisoformat(state['RunnerStartedUtc'].replace('Z', '+00:00'))
for project in projects:
    for suffix in ['.dll', '.pdb']:
        name = f'{project}/bin/Debug/net8.0/{project}{suffix}'
        pin = next(x for x in dll_pins if x['Path'] == name)
        assert datetime.fromisoformat(pin['LastWriteUtc']) >= started, name
        fresh_outputs.append(pin)
target = root / 'evidence/prepare-gate.json'
assert not target.exists(), 'Gate already exists; inspect without overwrite'
gate = {'Accepted': True, 'Head': expected, 'RecordedUtc': datetime.now(timezone.utc).isoformat(),
        'Category': category[0]['id'], 'PlannedCases': 6, 'PlannedDescriptors': 1, 'ExecutedCases': 0,
        'CategoryBudgetMinutes': 3, 'RunnerBudgetMinutes': 8, 'ResultDirectory': str(results),
        'BuildWallSeconds': next(p['Seconds'] for p in summary['PhaseResults'] if p['Name'] == 'Build-integration'),
        'PreparationWallTime': summary['WallTime'], 'SourcePins': pins, 'DllPins': dll_pins,
        'FreshProjectOutputs': fresh_outputs, 'ExpectedMethods': expected_methods,
        'OwnedTreeCleanupSucceeded': True, 'RuntimeCleanupSucceeded': True}
target.write_text(json.dumps(gate, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'Accepted': True, 'Head': expected, 'PlannedCases': 6, 'Executed': 0,
                  'SourcePins': len(pins), 'DllPins': len(dll_pins), 'FreshProjectOutputs': len(fresh_outputs),
                  'PreparationWallTime': summary['WallTime'], 'Gate': str(target)}))
