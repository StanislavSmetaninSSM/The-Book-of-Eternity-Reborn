import hashlib
import json
import pathlib
import subprocess
from datetime import datetime, timezone

root = pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z')
repo = root / 'repo'
git = ['git', '-c', 'core.longpaths=true', '-c', 'core.autocrlf=false']
head = subprocess.check_output(git + ['rev-parse', 'HEAD'], cwd=repo, text=True).strip()
if head != '8c2ecdfaa1003e49bf15ba83693788e9b19dd10f':
    raise SystemExit('Accepted source moved before pinning')
paths = subprocess.check_output(git + ['ls-files', '-z', '--',
    'BookOfEternityClient', 'BookOfEternityClient.IntegrationTests',
    'BookOfEternityClient.TestSupport',
    'BookOfEternityClient.Tests/MortalItemConsumptionPlannerTests.Helpers.cs',
    'scripts/test-csharp.ps1', 'scripts/testing', 'tests/categories.json',
    'AGENTS.md', 'docs/testing.md', 'docs/development-workflow.md',
    'specs/1553-portable-local-storage/plan.md',
    'specs/1553-portable-local-storage/tasks.md'], cwd=repo).decode('utf-8').split('\0')
pins = []
for name in paths:
    if not name:
        continue
    path = repo / name
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    pins.append({'Path': name, 'Bytes': path.stat().st_size, 'SHA256': digest})
target = root / 'evidence/source-before-prepare.json'
if target.exists():
    raise SystemExit('Source pin receipt already exists; inspect rather than overwrite')
target.write_text(json.dumps({'Head': head, 'RecordedUtc': datetime.now(timezone.utc).isoformat(),
                             'SourcePins': pins}, ensure_ascii=False, indent=2) + '\n',
                  encoding='utf-8', newline='\n')
print(json.dumps({'Head': head, 'SourcePins': len(pins), 'Path': str(target)}))
