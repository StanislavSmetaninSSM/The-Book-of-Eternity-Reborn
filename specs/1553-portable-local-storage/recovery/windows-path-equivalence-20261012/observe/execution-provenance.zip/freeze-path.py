import hashlib,json,pathlib,sys,xml.etree.ElementTree as ET,zipfile
from datetime import datetime,timezone
from collections import Counter
root=pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z');repo=root/'repo'
stage=sys.argv[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
cfg=read(root/f'evidence/path-{stage}-config.json')
prepare=read(root/f'evidence/path-{stage}-prepare/process-state.json');actual=read(root/f'evidence/path-{stage}-actual/process-state.json')
inputs=read(root/f'evidence/path-{stage}-inputs-after-actual.json');gate=read(root/f'evidence/path-{stage}-prepare-gate.json')
process=read(root/f'evidence/path-{stage}-post-run.json')
assert actual['State']=='Exited' and actual['ExitCode'] is not None and len(actual['ResultDirectories'])==1
assert not process['ActiveOwnedOperations'] and not process['TaskOwnedRootRemainders']
result=pathlib.Path(actual['ResultDirectories'][0]);summary=read(result/'summary.json')
assert summary['Revision']['Head']==cfg['Head'] and summary['Revision']['ChangedFiles']==0
assert summary['Selection']['Complete'] and summary['Selection']['CompletedCases']==cfg['Cases']
assert summary['OwnedTreeCleanupSucceeded'] and summary['RuntimeCleanupSucceeded'] and not summary['TimedOut'] and not summary['DuplicateTests'] and summary['TimeoutMinutes']==8
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};cases=[]
for trx in sorted(result.glob('*.trx')):
 tree=ET.parse(trx)
 for row in tree.findall('.//t:UnitTestResult',ns):
  stdout=row.findtext('t:Output/t:StdOut',default='',namespaces=ns) or '';error=row.find('t:Output/t:ErrorInfo',ns)
  cases.append({'Name':row.get('testName'),'Outcome':row.get('outcome'),'Duration':row.get('duration'),'OriginalStdOut':stdout,
   'ErrorMessage':error.findtext('t:Message',default='',namespaces=ns) if error is not None else '',
   'ErrorStackTrace':error.findtext('t:StackTrace',default='',namespaces=ns) if error is not None else ''})
assert len(cases)==cfg['Cases'] and len({x['Name'] for x in cases})==len(cases)
counts=Counter(x['Outcome'] for x in cases)
operands=[]
for case in cases:
 for line in case['OriginalStdOut'].splitlines():
  if line.startswith('NativeRollbackPathOperands='):
   data=json.loads(line.split('=',1)[1]);assert all(data[k] for k in ['OpenedPath','ComparedPath','IntentDestinationPath','IntentSourcePath','IntentFailedSourcePath'])
   operands.append(data)
if stage=='observe':
 assert counts=={'Passed':1,'Failed':1} and len(operands)==1 and operands[0]['Extended']
 assert operands[0]['OpenedPath']==operands[0]['IntentDestinationPath']
 assert operands[0]['OpenedPath'].startswith('\\\\?\\') and operands[0]['OpenedPath'][4:]==operands[0]['ComparedPath']
assert all('OwnedFixtureRemoved=True' in x['OriginalStdOut'] for x in cases if 'BrowserProtocolCutoverTests.' in x['Name'])
carrier=repo/'specs/1553-portable-local-storage/recovery/windows-path-equivalence-20261012';d=carrier/stage
assert not d.exists(),'Stage carrier exists; inspect before any retry'
d.mkdir(parents=True)
def archive(name,entries):
 path=d/name;records=[]
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for source,key in entries:z.write(source,key);records.append({'Path':key,'Bytes':source.stat().st_size,'SHA256':sha(source)})
 with zipfile.ZipFile(path) as z:
  assert sorted(z.namelist())==sorted(x['Path'] for x in records)
  for item in records:
   raw=z.read(item['Path']);assert len(raw)==item['Bytes'] and hashlib.sha256(raw).hexdigest()==item['SHA256']
 return {'Path':stage+'/'+name,'Bytes':path.stat().st_size,'SHA256':sha(path),'Entries':records}
archives=[]
for phase,state in [('prepare',prepare),('actual',actual)]:
 results=pathlib.Path(state['ResultDirectories'][0]);entries=[(p,'runner/'+p.relative_to(results).as_posix()) for p in sorted(results.rglob('*')) if p.is_file()]
 entries.extend((p,'process/'+p.name) for p in sorted((root/f'evidence/path-{stage}-{phase}').iterdir()) if p.is_file())
 archives.append(archive(phase+'-original.zip',entries))
names=['path-inputs.py','freeze-path.py',f'run-path-{stage}-phase.ps1',f'evidence/path-{stage}-config.json',f'evidence/path-{stage}-source-review.json',
 f'evidence/path-{stage}-inputs-before-prepare.json',f'evidence/path-{stage}-inputs-before-actual.json',f'evidence/path-{stage}-inputs-after-actual.json',f'evidence/path-{stage}-prepare-gate.json',f'evidence/path-{stage}-post-run.json','evidence/post-reboot-recovery-20261012T0151.json']
entries=[(root/n,n) for n in names]
for name in ['BookOfEternityClient/Core/ReversibleFilePublication.cs','BookOfEternityClient/Core/TrustedLocalFileScope.cs','BookOfEternityClient.IntegrationTests/BrowserProtocolCutoverTests.cs','BookOfEternityClient.IntegrationTests/BrowserProtocolCutoverTests.Windows.cs','tests/categories.json']:
 entries.append((repo/name,'repo/'+name))
archives.append(archive('execution-provenance.zip',entries))
m={'SchemaVersion':1,'RecordedUtc':datetime.now(timezone.utc).isoformat(),'Stage':stage,'CompiledSource':cfg['Head'],'Categories':cfg['Categories'],
 'BuildSeconds':gate['BuildSeconds'],'PreparationWallTime':gate['PreparationWallTime'],'PreparationPlanned':cfg['Cases'],'PreparationExecuted':0,
 'ActualAttemptsInStage':1,'ActualWallTime':summary['WallTime'],'CategoryResults':summary['CategoryResults'],'Planned':cfg['Cases'],'Executed':len(cases),'Passed':counts.get('Passed',0),'Failed':counts.get('Failed',0),
 'ExitCode':summary['ExitCode'],'SelectionComplete':True,'CategoryBudgetMinutes':3,'RunnerBudgetMinutes':8,'NoSkipsDuplicatesTimeouts':True,
 'OwnedTreeCleanupSucceeded':True,'RuntimeCleanupSucceeded':True,'SourcePins':len(inputs['SourcePins']),'DllPdbPins':len(inputs['DllPins']),
 'ActualOperandTraces':operands,'Cases':cases,'Archives':archives,'State':'EvidenceReviewPending','Limits':['No fresh-process cold restart','UNC/device source controls do not qualify UNC filesystem/nativedevice access','Prior failure carriers and F18 history preserved']}
(d/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
rootmanifest={'SchemaVersion':1,'TrackedTask':'#1553/T068 Windows path equivalence','WorkingBranch':'1553-storage-migration-windows-f18-20261011T235650Z','State':'WIP','Stages':[],'Archives':[],'FreshProcessColdRestartQualified':False,'PreviousHistory':'../windows-browser-protocol-bom-20261012/manifest.json'}
for sub in ['observe','controls-red','green']:
 p=carrier/sub/'manifest.json'
 if p.exists():
  x=read(p);rootmanifest['Stages'].append({'Stage':sub,'Manifest':sub+'/manifest.json','CompiledSource':x['CompiledSource'],'Passed':x['Passed'],'Failed':x['Failed']});rootmanifest['Archives'].extend(x['Archives'])
(carrier/'manifest.json').write_text(json.dumps(rootmanifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'Stage':stage,'Passed':m['Passed'],'Failed':m['Failed'],'ActualWall':m['ActualWallTime'],'Entries':sum(len(x['Entries']) for x in archives),'Operands':operands}))
