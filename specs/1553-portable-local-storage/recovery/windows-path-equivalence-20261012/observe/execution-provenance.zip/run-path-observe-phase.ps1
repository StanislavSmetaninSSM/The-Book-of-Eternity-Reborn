[CmdletBinding()]
param([Parameter(Mandatory)][ValidateSet('Prepare','Actual')][string]$Phase)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$root='C:\Temp\boe-win-8c2ecdfa-20261011T234246Z'
$repo=Join-Path $root 'repo'
$phaseDir=Join-Path $root ('evidence\path-observe-' + $Phase.ToLowerInvariant())
if (Test-Path -LiteralPath $phaseDir) { throw 'Browser phase already reserved: inspect PID/exit/evidence; do not duplicate.' }
New-Item -ItemType Directory -Path $phaseDir | Out-Null
$statePath=Join-Path $phaseDir 'process-state.json'
$state=[ordered]@{Phase=$Phase;State='Reserved';WrapperPid=$PID;WrapperStartedUtc=(Get-Process -Id $PID).StartTime.ToUniversalTime().ToString('o');RunnerPid=$null;RunnerStartedUtc=$null;ExitCode=$null;StartedUtc=[DateTime]::UtcNow.ToString('o');CompletedUtc=$null;CheckoutHead='00764cf90bdc96c93c1c4c922a3bc25a918ee4d0';CompiledSource='00764cf90bdc96c93c1c4c922a3bc25a918ee4d0';Category='native-original-six-path-causal-windows';CategoryBudgetMinutes=3;RunnerDefaultBudgetMinutes=8;Stdout=(Join-Path $phaseDir 'stdout.log');Stderr=(Join-Path $phaseDir 'stderr.log')}
function Save-State { $state | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $statePath -Encoding utf8NoBOM }
Save-State
try {
 Set-Location -LiteralPath $repo
 if ((git -c core.longpaths=true -c core.autocrlf=false rev-parse HEAD).Trim() -ne $state.CheckoutHead) { throw 'Reviewed checkout moved before launch' }
 if (@(git -c core.longpaths=true -c core.autocrlf=false status --porcelain=v1).Count -ne 0) { throw 'Source checkout dirty before launch' }
 $old=Get-Content -LiteralPath (Join-Path $root 'evidence\prepare\process-state.json') -Raw -Encoding UTF8 | ConvertFrom-Json
 $review=Get-Content -LiteralPath (Join-Path $root 'evidence\path-observe-source-review.json') -Raw -Encoding UTF8 | ConvertFrom-Json
 if ($review.Verdict -ne 'SOURCE PASS' -or $review.ReviewedSha -ne $state.CheckoutHead) { throw 'Independent source review required before build/runtime' }
 $state['Environment']=$old.Environment
 foreach ($entry in $old.Environment.PSObject.Properties) { [Environment]::SetEnvironmentVariable($entry.Name,[string]$entry.Value,'Process') }
 $state['BootUtc']=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o')
 $state['SdkVersion']=(& dotnet --version | Out-String).Trim()
 if ($state.SdkVersion -ne '10.0.401') { throw 'SDK changed from qualified fresh preparation' }
 $state['IsWindows']=$IsWindows
 if (-not $IsWindows) { throw 'Actual Windows environment is required' }
 if ($Phase -eq 'Actual') {
  $gate=Get-Content -LiteralPath (Join-Path $root 'evidence\path-observe-prepare-gate.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  if (-not $gate.Accepted -or $gate.Head -ne $state.CheckoutHead -or $gate.CompiledSource -ne $state.CompiledSource -or $gate.PlannedCases -ne 2 -or $gate.Methods -ne 1) { throw 'Exact browser discovery/input gate is absent' }
 }
 $args=@('-NoLogo','-NoProfile','-File',(Join-Path $repo 'scripts\test-csharp.ps1'),'-Category',$state.Category)
 if ($Phase -eq 'Prepare') { $args+='-PlanOnly' } else { $args+='-NoBuild' }
 $state['Executable']=(Get-Command pwsh).Source
 $state['Arguments']=$args
 $state['Command']='pwsh -NoLogo -NoProfile -File ./scripts/test-csharp.ps1 -Category native-original-six-path-causal-windows' + $(if($Phase -eq 'Prepare'){' -PlanOnly'}else{' -NoBuild'})
 $state.State='Launching';Save-State
 $runner=Start-Process -FilePath $state.Executable -ArgumentList $args -WorkingDirectory $repo -WindowStyle Hidden -RedirectStandardOutput $state.Stdout -RedirectStandardError $state.Stderr -PassThru
 $state.RunnerPid=$runner.Id;$state.RunnerStartedUtc=$runner.StartTime.ToUniversalTime().ToString('o');$state.State='Running';Save-State
 Write-Output ($state | ConvertTo-Json -Compress -Depth 8)
 $runner.WaitForExit()
 $state.ExitCode=$runner.ExitCode;$state.State='Exited';$state.CompletedUtc=[DateTime]::UtcNow.ToString('o')
 $state['ResultDirectories']=@(Get-ChildItem -LiteralPath (Join-Path $repo 'TestResults\test-categories') -Directory | Where-Object {$_.Name -match ('-' + $runner.Id + '-')} | ForEach-Object FullName)
 Save-State;Write-Output ($state | ConvertTo-Json -Compress -Depth 8)
 exit $state.ExitCode
} catch {
 $state.State='WrapperFailure';$state['Failure']=$_.Exception.ToString();$state.CompletedUtc=[DateTime]::UtcNow.ToString('o');Save-State;throw
}
