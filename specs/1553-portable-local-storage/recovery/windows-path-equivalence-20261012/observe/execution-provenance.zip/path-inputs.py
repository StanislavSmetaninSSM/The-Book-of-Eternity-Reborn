import hashlib,json,pathlib,subprocess,sys
from datetime import datetime,timezone

root=pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z')
repo=root/'repo'
stage,mode=sys.argv[1:3]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
cfg=read(root/f'evidence/path-{stage}-config.json')
git=['git','-c','core.longpaths=true','-c','core.autocrlf=false']
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p):return {'Path':p.relative_to(repo).as_posix(),'Bytes':p.stat().st_size,'SHA256':sha(p),'LastWriteUtc':datetime.fromtimestamp(p.stat().st_mtime,timezone.utc).isoformat()}
def valid(pins):
 for x in pins:
  p=repo/x['Path'];assert p.stat().st_size==x['Bytes'] and sha(p)==x['SHA256'],x['Path']
assert subprocess.check_output(git+['rev-parse','HEAD'],cwd=repo,text=True).strip()==cfg['Head']
assert not subprocess.check_output(git+['status','--porcelain=v1','-z'],cwd=repo)
target=root/f'evidence/path-{stage}-inputs-{mode}.json'
assert not target.exists(),'Receipt already exists; inspect before retry'
record={'CheckedUtc':datetime.now(timezone.utc).isoformat(),'Head':cfg['Head'],'CompiledSource':cfg['Head'],'Stage':stage,'Categories':cfg['Categories']}
if mode=='before-prepare':
 old=read(root/cfg['BaselineInputs'])
 sources=[pin(repo/x['Path']) for x in old['SourcePins']]
 changed={x['Path'] for x,y in zip(sources,old['SourcePins']) if x['SHA256']!=y['SHA256']}
 assert changed==set(cfg['ExpectedChangedSourcePins']),changed
 valid(old['DllPins'])
 record.update({'SourcePins':sources,'PreviousDllPins':old['DllPins'],'ChangedSourcePins':sorted(changed),'UnchangedSourcePins':len(sources)-len(changed),'InputBytesEqual':True,'FreshBuildRequired':True})
elif mode=='before-actual':
 before=read(root/f'evidence/path-{stage}-inputs-before-prepare.json');valid(before['SourcePins'])
 state=read(root/f'evidence/path-{stage}-prepare/process-state.json')
 assert state['State']=='Exited' and state['ExitCode']==0 and len(state['ResultDirectories'])==1
 d=pathlib.Path(state['ResultDirectories'][0]);s=read(d/'summary.json');plan=read(d/'plan.json')
 assert s['PlanOnly'] and s['Tests']['Executed']==0 and s['ExitCode']==0 and not s['TimedOut']
 assert s['Revision']['Head']==cfg['Head'] and s['Revision']['ChangedFiles']==0
 assert s['OwnedTreeCleanupSucceeded'] and s['RuntimeCleanupSucceeded'] and s['TimeoutMinutes']==8
 assert s['Selection']['PlannedCases']==cfg['Cases'] and len(plan['Descriptors'])==cfg['Descriptors']
 build=[p for p in s['PhaseResults'] if p['Name']=='Build-integration'];assert len(build)==1 and build[0]['Completed']
 methods={x['Name']:x['Cases'] for desc in plan['Descriptors'] for x in desc['ExpectedMethodCounts']}
 assert methods==cfg['ExpectedMethodCounts'],methods
 assert all(x['BudgetMinutes']==3 and x['Exclusive'] and not x['FrontendBuild'] for x in plan['Descriptors'])
 dlls=[]
 for project in ['BookOfEternityClient','BookOfEternityClient.TestSupport','BookOfEternityClient.IntegrationTests']:
  dlls.extend(pin(p) for p in sorted((repo/project/'bin/Debug/net8.0').rglob('*')) if p.is_file() and p.suffix.lower() in ['.dll','.pdb'])
 assert len(dlls)==157
 fresh=[];started=datetime.fromisoformat(state['RunnerStartedUtc'].replace('Z','+00:00'))
 for project in ['BookOfEternityClient','BookOfEternityClient.IntegrationTests']:
  for suffix in ['.dll','.pdb']:
   name=f'{project}/bin/Debug/net8.0/{project}{suffix}';x=next(x for x in dlls if x['Path']==name)
   assert datetime.fromisoformat(x['LastWriteUtc'])>=started and x['SHA256']!=next(y['SHA256'] for y in before['PreviousDllPins'] if y['Path']==name),name
   fresh.append(x)
 record.update({'SourcePins':before['SourcePins'],'DllPins':dlls,'InputBytesEqual':True,'FreshProjectOutputs':fresh,'BuildSeconds':build[0]['Seconds'],'PreparationWallTime':s['WallTime'],'ResultDirectory':str(d),'ExpectedMethodCounts':methods})
 gate={'Accepted':True,'Head':cfg['Head'],'CompiledSource':cfg['Head'],'Categories':cfg['Categories'],'PlannedCases':cfg['Cases'],'Methods':len(methods),'ExecutedCases':0,'CategoryBudgetMinutes':3,'RunnerBudgetMinutes':8,'ResultDirectory':str(d),'BuildSeconds':build[0]['Seconds'],'PreparationWallTime':s['WallTime'],'ExpectedMethodCounts':methods}
 gatepath=root/f'evidence/path-{stage}-prepare-gate.json';assert not gatepath.exists();gatepath.write_text(json.dumps(gate,indent=2)+'\n',encoding='utf-8',newline='\n')
elif mode=='after-actual':
 before=read(root/f'evidence/path-{stage}-inputs-before-actual.json');valid(before['SourcePins']+before['DllPins'])
 record.update({'SourcePins':before['SourcePins'],'DllPins':before['DllPins'],'InputBytesEqual':True,'FreshProjectOutputs':before['FreshProjectOutputs'],'NoAdditionalBuild':True})
else:raise AssertionError(mode)
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'Stage':stage,'Mode':mode,'Head':cfg['Head'],'SourcePins':len(record['SourcePins']),'DllPdbPins':len(record.get('DllPins',record.get('PreviousDllPins',[]))),'BuildSeconds':record.get('BuildSeconds'),'PlanWallTime':record.get('PreparationWallTime'),'BytesEqual':True}))
