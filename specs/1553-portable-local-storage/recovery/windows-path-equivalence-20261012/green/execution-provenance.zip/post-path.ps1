param([Parameter(Mandatory)][string]$Stage)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$taskRoot='C:\Temp\boe-win-8c2ecdfa-20261011T234246Z'
$boot=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime()
$checks=@()
foreach ($phase in @('prepare','actual')) {
 $s=Get-Content -LiteralPath (Join-Path $taskRoot ('evidence\path-'+$Stage+'-'+$phase+'\process-state.json')) -Raw -Encoding utf8 | ConvertFrom-Json
 if ($s.State -ne 'Exited' -or $null -eq $s.ExitCode -or [datetime]$s.RunnerStartedUtc -lt $boot) { throw 'Phase did not complete in current boot' }
 foreach ($kind in @('Wrapper','Runner')) {
  $ownedId=[int]$s.($kind+'Pid');$started=[datetime]$s.($kind+'StartedUtc');$live=Get-Process -Id $ownedId -ErrorAction SilentlyContinue
  if ($live -and [Math]::Abs(($live.StartTime.ToUniversalTime()-$started.ToUniversalTime()).TotalSeconds) -lt 2) { throw 'Owned phase process still running' }
  $checks += [pscustomobject]@{Phase=$phase;Kind=$kind;Pid=$ownedId;StartUtc=$started.ToUniversalTime().ToString('o');Exited=$true;PidReused=[bool]$live}
 }
}
$ops=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(dotnet|testhost|git|python|MSBuild)(\.exe)?$' -and $_.CommandLine -and $_.CommandLine.Contains($taskRoot) } | Select-Object ProcessId,Name,CreationDate)
$roots=@(Get-ChildItem -LiteralPath (Join-Path $taskRoot 'tmp') -Directory | Where-Object { $_.Name -like 'boe-browser-protocol-*' -or $_.Name -like 'boe-test-worker-runtime-*' } | Select-Object -ExpandProperty FullName)
if ($ops.Count -or $roots.Count) { throw 'Task-owned operations/roots remain' }
$record=[ordered]@{RecordedUtc=[datetime]::UtcNow.ToString('o');BootUtc=$boot.ToString('o');Stage=$Stage;State='OneActualExited';ProcessChecks=$checks;ActiveOwnedOperations=$ops;TaskOwnedRootRemainders=$roots}
$path=Join-Path $taskRoot ('evidence\path-'+$Stage+'-post-run.json')
if (Test-Path -LiteralPath $path) { throw 'Post-run receipt exists; inspect before retry' }
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $path -Encoding utf8NoBOM
$record | ConvertTo-Json -Depth 6 -Compress
