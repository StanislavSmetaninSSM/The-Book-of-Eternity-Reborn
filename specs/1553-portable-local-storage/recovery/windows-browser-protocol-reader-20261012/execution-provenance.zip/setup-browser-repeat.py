import json
from pathlib import Path

root = Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z')
head = 'be02e0f998cf440ff5c14a6218d6dcb8cedc9113'
script = root / 'run-browser-repeat-phase.ps1'
assert not script.exists()
raw = (root / 'run-browser-phase.ps1').read_text(encoding='utf-8')
raw = raw.replace("'evidence\\browser-'", "'evidence\\browser-repeat-'")
raw = raw.replace('5d9f822195a2d4788dadcf483eee742e3ae7e766', head)
raw = raw.replace('8c2ecdfaa1003e49bf15ba83693788e9b19dd10f', head)
raw = raw.replace('browser-prepare-gate.json', 'browser-repeat-prepare-gate.json')
raw = raw.replace(",'-Category',$state.Category,'-NoBuild')", ",'-Category',$state.Category)")
raw = raw.replace("if ($Phase -eq 'Prepare') { $args+='-PlanOnly' }", "if ($Phase -eq 'Prepare') { $args+='-PlanOnly' } else { $args+='-NoBuild' }")
raw = raw.replace("-native-windows -NoBuild' +", "-native-windows' +")
raw = raw.replace("{' -PlanOnly'}else{''}", "{' -PlanOnly'}else{' -NoBuild'}")
raw = raw.replace(" $state['Environment']=$old.Environment", " $review=Get-Content -LiteralPath (Join-Path $root 'evidence\\browser-repeat-source-review.json') -Raw -Encoding UTF8 | ConvertFrom-Json\n if ($review.Verdict -ne 'SOURCE PASS' -or $review.ReviewedSha -ne $state.CheckoutHead) { throw 'Independent source review required before build/runtime' }\n $state['Environment']=$old.Environment")
script.write_text(raw, encoding='utf-8', newline='\n')
review = {'Verdict': 'SOURCE PASS', 'ReviewedSha': head, 'Base': '9bb4e646e379363684ea9d741ebae837f354e8df',
          'Reviewer': 'gpt-6-astra', 'Effort': 'xhigh', 'Findings': [],
          'PhysicalReadRetained': True, 'DisposeInsideSameLease': True, 'LaterAssertionsUnchanged': True,
          'ProductSharingUnchanged': True, 'Category': 'portable-browser-protocol-native-windows',
          'Methods': 7, 'Cases': 30, 'CategoryBudgetMinutes': 3, 'RunnerBudgetMinutes': 8,
          'RuntimeQualifiedByThisReview': False}
(root / 'evidence/browser-repeat-source-review.json').write_text(json.dumps(review, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'Created': str(script), 'SourceReview': review['Verdict'], 'Head': head}))
