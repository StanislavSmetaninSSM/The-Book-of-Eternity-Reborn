import hashlib
import json
import pathlib
import subprocess
import sys
from datetime import datetime, timezone

root = pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z')
repo = root / 'repo'
head = 'be02e0f998cf440ff5c14a6218d6dcb8cedc9113'
git = ['git', '-c', 'core.longpaths=true', '-c', 'core.autocrlf=false']
changed_source = 'BookOfEternityClient.IntegrationTests/BrowserProtocolCutoverTests.Windows.cs'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def pin(path):
    return {'Path': path.relative_to(repo).as_posix(), 'Bytes': path.stat().st_size,
            'SHA256': sha(path), 'LastWriteUtc': datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()}

def validate(pins):
    for item in pins:
        path = repo / item['Path']
        assert path.stat().st_size == item['Bytes'] and sha(path) == item['SHA256'], item['Path']

assert subprocess.check_output(git + ['rev-parse', 'HEAD'], cwd=repo, text=True).strip() == head
assert not subprocess.check_output(git + ['status', '--porcelain=v1', '-z'], cwd=repo)
changed = subprocess.check_output(git + ['diff', '--name-only', '-z', '9bb4e646e379363684ea9d741ebae837f354e8df', head], cwd=repo).decode('utf-8').split('\0')
assert set(x for x in changed if x) == {changed_source, 'specs/1553-portable-local-storage/plan.md', 'specs/1553-portable-local-storage/tasks.md'}
mode = sys.argv[1]
target = root / f'evidence/browser-repeat-inputs-{mode}.json'
assert not target.exists(), 'Receipt exists; inspect instead of overwrite/retry'
original = read(root / 'evidence/browser-inputs-after-actual.json')
record = {'CheckedUtc': datetime.now(timezone.utc).isoformat(), 'Head': head, 'CompiledSource': head,
          'OriginalProductSource': original['CompiledSource'], 'Category': 'portable-browser-protocol-native-windows',
          'MetadataOnlyExclusions': original['MetadataOnlyExclusions'], 'TestOnlyChangedSource': changed_source}

if mode == 'before-prepare':
    unchanged = [x for x in original['SourcePins'] if x['Path'] != changed_source]
    assert len(unchanged) == 1628
    validate(unchanged + original['DllPins'])
    updated = pin(repo / changed_source)
    assert updated['SHA256'] != next(x['SHA256'] for x in original['SourcePins'] if x['Path'] == changed_source)
    record.update({'SourcePins': unchanged + [updated], 'PreviousDllPins': original['DllPins'],
                   'UnchangedSourcePins': 1628, 'ChangedSourcePins': 1, 'PreviousDllBytesEqual': True,
                   'FreshBuildRequired': True, 'InputBytesEqual': True})
elif mode == 'before-actual':
    before = read(root / 'evidence/browser-repeat-inputs-before-prepare.json')
    validate(before['SourcePins'])
    state = read(root / 'evidence/browser-repeat-prepare/process-state.json')
    assert state['State'] == 'Exited' and state['ExitCode'] == 0 and len(state['ResultDirectories']) == 1
    directory = pathlib.Path(state['ResultDirectories'][0])
    summary, plan = read(directory / 'summary.json'), read(directory / 'plan.json')
    assert summary['PlanOnly'] and summary['Tests']['Executed'] == 0 and summary['ExitCode'] == 0
    assert summary['Revision']['Head'] == head and summary['Revision']['ChangedFiles'] == 0
    assert summary['OwnedTreeCleanupSucceeded'] and summary['RuntimeCleanupSucceeded'] and not summary['TimedOut']
    assert summary['TimeoutMinutes'] == 8 and summary['Selection']['PlannedCases'] == 30
    assert summary['Selection']['PlannedDescriptors'] == 1 and len(plan['Descriptors']) == 1
    build = [x for x in summary['PhaseResults'] if x['Name'] == 'Build-integration']
    assert len(build) == 1 and build[0]['Completed']
    descriptor = plan['Descriptors'][0]
    original_gate = read(root / 'evidence/browser-prepare-gate.json')
    assert descriptor['ExpectedMethodCounts'] == original_gate['MethodCounts']
    assert descriptor['BudgetMinutes'] == 3 and descriptor['EstimatedCases'] == 30
    assert descriptor['Exclusive'] and not descriptor['FrontendBuild']
    dlls = []
    for project in ['BookOfEternityClient', 'BookOfEternityClient.TestSupport', 'BookOfEternityClient.IntegrationTests']:
        dlls += [pin(p) for p in sorted((repo / project / 'bin/Debug/net8.0').rglob('*')) if p.is_file() and p.suffix.lower() in ['.dll', '.pdb']]
    assert len(dlls) == 157
    started = datetime.fromisoformat(state['RunnerStartedUtc'].replace('Z', '+00:00'))
    fresh = []
    for suffix in ['.dll', '.pdb']:
        name = f'BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.IntegrationTests{suffix}'
        item = next(x for x in dlls if x['Path'] == name)
        assert datetime.fromisoformat(item['LastWriteUtc']) >= started
        assert item['SHA256'] != next(x['SHA256'] for x in before['PreviousDllPins'] if x['Path'] == name)
        fresh.append(item)
    record.update({'SourcePins': before['SourcePins'], 'DllPins': dlls, 'InputBytesEqual': True,
                   'FreshIntegrationOutputs': fresh, 'SuccessfulSelectedBuild': True,
                   'BuildWallSeconds': build[0]['Seconds'], 'PreparationWallTime': summary['WallTime']})
    gate = {'Accepted': True, 'Head': head, 'CompiledSource': head, 'Category': record['Category'],
            'PlannedCases': 30, 'Methods': 7, 'ExecutedCases': 0, 'CategoryBudgetMinutes': 3, 'RunnerBudgetMinutes': 8,
            'ResultDirectory': str(directory), 'MethodCounts': descriptor['ExpectedMethodCounts'],
            'PreparationWallTime': summary['WallTime'], 'BuildWallSeconds': build[0]['Seconds'],
            'NewBuildExecuted': True, 'InputsReceipt': target.name}
    gate_path = root / 'evidence/browser-repeat-prepare-gate.json'
    assert not gate_path.exists()
    gate_path.write_text(json.dumps(gate, indent=2)+'\n', encoding='utf-8', newline='\n')
elif mode == 'after-actual':
    before = read(root / 'evidence/browser-repeat-inputs-before-actual.json')
    validate(before['SourcePins'] + before['DllPins'])
    record.update({'SourcePins': before['SourcePins'], 'DllPins': before['DllPins'],
                   'InputBytesEqual': True, 'FreshIntegrationOutputs': before['FreshIntegrationOutputs'],
                   'SuccessfulSelectedBuild': True, 'NoRepeatBuild': True})
else:
    raise AssertionError(mode)
target.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'Mode': mode, 'Head': head, 'SourcePins': len(record['SourcePins']),
                  'DllPdbPins': len(record.get('DllPins', record.get('PreviousDllPins', []))),
                  'InputBytesEqual': True, 'Receipt': str(target),
                  'BuildSeconds': record.get('BuildWallSeconds'), 'PlanWallTime': record.get('PreparationWallTime')}))
