from pathlib import Path
import json

root=Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z')
head='6473dda217717b1d37500e215d701292ae5a77a6'
for source,target in [('run-browser-repeat-phase.ps1','run-browser-bom-phase.ps1'),
                      ('browser-repeat-inputs.py','browser-bom-inputs.py'),
                      ('readback-browser-repeat.ps1','readback-browser-bom.ps1'),
                      ('freeze-browser-repeat.py','freeze-browser-bom.py')]:
    path=root/target
    assert not path.exists()
    text=(root/source).read_text(encoding='utf-8').replace('browser-repeat','browser-bom').replace('be02e0f998cf440ff5c14a6218d6dcb8cedc9113',head)
    if target=='browser-bom-inputs.py':
        text=text.replace('9bb4e646e379363684ea9d741ebae837f354e8df','bb485e1112355402fa119a24b2178bcfbf83667c')
        text=text.replace("'evidence/browser-inputs-after-actual.json'","'evidence/browser-repeat-inputs-after-actual.json'")
        text=text.replace("original['CompiledSource']","original['OriginalProductSource']")
    if target=='readback-browser-bom.ps1':
        text=text.replace('HistoricalActualInvocations=2','HistoricalActualInvocations=3')
    if target=='freeze-browser-bom.py':
        text=text.replace('windows-browser-protocol-reader-20261012','windows-browser-protocol-bom-20261012')
        text=text.replace("'HistoricalActualAttemptsIncludingFirst': 2","'HistoricalActualAttemptsIncludingFirst': 3")
        text=text.replace("(directory / 'manifest.json').write_text", "manifest['TestOnlyExactBomParserApplied']=True\nmanifest['StrictUtf8Controls']='BOM/noBOM/malformedUTF8withandwithoutBOM/doubleBOM; physical bytes unchanged; inside2authentic6rows'\nmanifest['PreviousBomFailureEvidence']='../windows-browser-protocol-reader-20261012/manifest.json'\nmanifest['PreviousBomFailureSha']='bb485e1112355402fa119a24b2178bcfbf83667c'\nmanifest['ControlWitnesses']=[x for x in authentic if 'ManifestParserControls=True' in x['OriginalStdOut']]\nassert len(manifest['ControlWitnesses'])==2\n(directory / 'manifest.json').write_text")
    path.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({'Head':head,'HelpersCreated':4,'SourceReviewRequired':True}))
