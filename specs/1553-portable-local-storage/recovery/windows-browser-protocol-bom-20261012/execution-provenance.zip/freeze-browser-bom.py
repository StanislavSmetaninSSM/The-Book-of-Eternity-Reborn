import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from datetime import datetime, timezone

root = pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z')
repo = root / 'repo'
directory = repo / 'specs/1553-portable-local-storage/recovery/windows-browser-protocol-bom-20261012'
assert not directory.exists(), 'Carrier exists; inspect before any retry'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

prepare = read(root / 'evidence/browser-bom-prepare/process-state.json')
actual = read(root / 'evidence/browser-bom-actual/process-state.json')
gate = read(root / 'evidence/browser-bom-prepare-gate.json')
inputs = read(root / 'evidence/browser-bom-inputs-after-actual.json')
process = read(root / 'evidence/browser-bom-post-run-process-readback.json')
assert actual['State'] == 'Exited' and actual['ExitCode'] is not None and len(actual['ResultDirectories']) == 1
assert not process['ActiveOwnedOperations'] and not process['BrowserRootRemainders'] and not process['WorkerRuntimeRemainders']
results = pathlib.Path(actual['ResultDirectories'][0])
summary = read(results / 'summary.json')
assert summary['Revision']['Head'] == inputs['Head'] and summary['Revision']['ChangedFiles'] == 0
assert inputs['InputBytesEqual'] and len(inputs['SourcePins']) == 1629 and len(inputs['DllPins']) == 157
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
trx = ET.parse(results / 'portable-browser-protocol-native-windows-integration-001.trx')
cases = []
for result in trx.findall('.//t:UnitTestResult', ns):
    stdout = result.findtext('t:Output/t:StdOut', default='', namespaces=ns) or ''
    error = result.find('t:Output/t:ErrorInfo', ns)
    cases.append({'Name': result.get('testName'), 'Outcome': result.get('outcome'),
                  'Duration': result.get('duration'), 'OriginalStdOut': stdout,
                  'OwnedFixtureRemovedReceipt': 'OwnedFixtureRemoved=True' in stdout,
                  'ErrorMessage': error.findtext('t:Message', default='', namespaces=ns) if error is not None else '',
                  'ErrorStackTrace': error.findtext('t:StackTrace', default='', namespaces=ns) if error is not None else ''})
assert len(cases) == 30 and len({x['Name'] for x in cases}) == 30
assert all(x['OwnedFixtureRemovedReceipt'] for x in cases)
counts = Counter(x['Outcome'] for x in cases)
assert summary['Selection']['Complete'] and summary['Selection']['CompletedCases'] == 30
assert summary['OwnedTreeCleanupSucceeded'] and summary['RuntimeCleanupSucceeded']
assert not summary['TimedOut'] and not summary['DuplicateTests'] and summary['TimeoutMinutes'] == 8
authentic = [x for x in cases if 'WindowsAuthenticOriginalSix_' in x['Name']]
assert len(authentic) == 2
green = counts == {'Passed': 30} and summary['ExitCode'] == 0 and summary['CategoryResults'][0]['Completed']
assert len([x for x in cases if 'extended: True' in x['Name']]) == 15
assert len([x for x in cases if 'extended: False' in x['Name']]) == 15
first_directory = repo / 'specs/1553-portable-local-storage/recovery/windows-browser-protocol-20261012'
first_manifest = read(first_directory / 'manifest.json')
assert (first_manifest['Passed'], first_manifest['Failed'], first_manifest['Executed']) == (28, 2, 30)
for item in first_manifest['Archives']:
    assert sha(first_directory / item['Path']) == item['SHA256']
directory.mkdir(parents=True)

def archive(name, entries):
    path = directory / name
    records = []
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipper:
        for source, key in entries:
            zipper.write(source, key)
            records.append({'Path': key, 'Bytes': source.stat().st_size, 'SHA256': sha(source)})
    with zipfile.ZipFile(path) as zipper:
        assert sorted(zipper.namelist()) == sorted(x['Path'] for x in records)
        for item in records:
            raw = zipper.read(item['Path'])
            assert len(raw) == item['Bytes'] and hashlib.sha256(raw).hexdigest() == item['SHA256']
    return {'Path': name, 'Bytes': path.stat().st_size, 'SHA256': sha(path), 'Entries': records}

archives = []
for phase, state in [('prepare', prepare), ('actual', actual)]:
    result = pathlib.Path(state['ResultDirectories'][0])
    entries = [(p, 'runner/' + p.relative_to(result).as_posix()) for p in sorted(result.rglob('*')) if p.is_file()]
    entries += [(p, 'process/' + p.name) for p in sorted((root / 'evidence' / ('browser-bom-' + phase)).iterdir()) if p.is_file()]
    archives.append(archive(phase + '-original.zip', entries))
provenance = [root / name for name in ['browser-bom-inputs.py', 'run-browser-bom-phase.ps1', 'freeze-browser-bom.py',
    'setup-browser-bom.py', 'evidence/browser-bom-source-review.json', 'evidence/browser-bom-inputs-before-prepare.json',
    'evidence/browser-bom-inputs-before-actual.json', 'evidence/browser-bom-inputs-after-actual.json',
    'evidence/browser-bom-prepare-gate.json', 'evidence/browser-bom-post-run-process-readback.json']]
provenance += [repo / 'BookOfEternityClient.IntegrationTests/BrowserProtocolCutoverTests.Windows.cs',
               repo / 'BookOfEternityClient.IntegrationTests/BrowserProtocolCutoverTests.cs']
archives.append(archive('execution-provenance.zip', [(p, p.relative_to(root).as_posix()) for p in provenance]))
manifest = {'SchemaVersion': 1, 'RecordedUtc': datetime.now(timezone.utc).isoformat(),
    'State': 'OneApprovedRepeat30PASS_EvidenceReviewPending' if green else 'OneApprovedRepeatFailure_EvidenceReviewPending_HOLD',
    'TrackedTask': '#1553 / F04-F05 Windows protocol30 test-reader correction',
    'CheckoutHead': inputs['Head'], 'CompiledSource': inputs['Head'], 'OriginalProductSource': inputs['OriginalProductSource'],
    'WorkingBranch': '1553-storage-migration-windows-f18-20261011T235650Z', 'Category': gate['Category'],
    'PreparationCommand': prepare['Command'], 'ActualCommand': actual['Command'],
    'NewBuildExecuted': True, 'BuildWallSeconds': gate['BuildWallSeconds'], 'PreparationWallTime': gate['PreparationWallTime'],
    'PreparationPlannedCases': 30, 'PreparationExecutedCases': 0, 'Methods': 7, 'MethodCounts': gate['MethodCounts'],
    'ActualAttemptsInThisBlock': 1, 'HistoricalActualAttemptsIncludingFirst': 3,
    'ActualWallTime': summary['WallTime'], 'CategorySeconds': summary['CategoryResults'][0]['Seconds'],
    'CategoryCompletedFlag': summary['CategoryResults'][0]['Completed'], 'SelectionComplete': summary['Selection']['Complete'],
    'CategoryBudgetMinutes': 3, 'RunnerBudgetMinutes': 8, 'Planned': 30, 'Executed': 30,
    'Passed': counts.get('Passed', 0), 'Failed': counts.get('Failed', 0), 'Skipped': 0,
    'TimedOut': False, 'DuplicateTests': 0, 'ExitCode': summary['ExitCode'],
    'OwnedTreeCleanupSucceeded': True, 'RuntimeCleanupSucceeded': True, 'StrictCleanupReceipts': 30,
    'BrowserRootRemainders': 0, 'WorkerRuntimeRemainders': 0, 'ActiveOwnedOperations': 0,
    'SourcePinsVerifiedBeforePrepareBeforeActualAfterActual': 1629,
    'UnchangedSourcePinsFromFirst': 1628, 'TestOnlyChangedSourcePins': 1,
    'DllPdbPinsVerifiedBeforeActualAfterActual': 157, 'FreshIntegrationOutputs': inputs['FreshIntegrationOutputs'],
    'TestReaderCorrectionApplied': True, 'ProductSourceChanged': False, 'ProductSharingChanged': False,
    'SourceReview': read(root / 'evidence/browser-bom-source-review.json'),
    'FirstResult': '28 PASS / 2 fixture FAIL', 'FirstEvidenceSha': '9bb4e646e379363684ea9d741ebae837f354e8df',
    'FirstEvidence': '../windows-browser-protocol-20261012/manifest.json', 'FirstRawUnchanged': True,
    'AuthenticSixRecoveryRows': authentic,
    'AuthenticSixQualification': '2 PASS through all unchanged After/receipt/identity/neutral/byte/recovery assertions' if all(x['Outcome'] == 'Passed' for x in authentic) else 'UNQUALIFIED; first causal result retained, no automatic product fix',
    'QualificationBasis': 'TRX outcomes of complete pinned unchanged assertion bodies; no separately serialized native values claimed',
    'Cases': cases, 'Archives': archives,
    'Limits': ['Fresh() is same-process new FileSystemManager; no fresh-process cold restart',
               'Protocol component category only; no browser DOM/UI/full game/whole migration',
               'F18 prior6PASS and historical ordinary40FAIL/performanceUNQUALIFIED/B2-B5paused unchanged',
               'No further runtime or product change authorized by this result']}
manifest['TestOnlyExactBomParserApplied']=True
manifest['StrictUtf8Controls']='BOM/noBOM/malformedUTF8withandwithoutBOM/doubleBOM; physical bytes unchanged; inside2authentic6rows'
manifest['PreviousBomFailureEvidence']='../windows-browser-protocol-reader-20261012/manifest.json'
manifest['PreviousBomFailureSha']='bb485e1112355402fa119a24b2178bcfbf83667c'
manifest['ControlWitnesses']=[x for x in authentic if 'ManifestParserControls=True' in x['OriginalStdOut']]
assert len(manifest['ControlWitnesses'])==2
(directory / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'Target': str(directory), 'Executed': 30, 'Passed': manifest['Passed'], 'Failed': manifest['Failed'],
                  'CleanupReceipts': 30, 'ArchiveEntries': sum(len(x['Entries']) for x in archives),
                  'ArchiveBytes': sum(x['Bytes'] for x in archives), 'CategorySeconds': manifest['CategorySeconds'],
                  'RunnerWallTime': manifest['ActualWallTime'], 'Green': green}))
