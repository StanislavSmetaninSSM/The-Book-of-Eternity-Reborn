import hashlib,json,pathlib,sys,xml.etree.ElementTree as ET,zipfile
from datetime import datetime,timezone
from collections import Counter
root=pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z');repo=root/'repo';key=sys.argv[1];attempt=sys.argv[2] if len(sys.argv)>2 else 'a1';prefix=f'owner-{key}-{attempt}'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
cfg=read(root/f'evidence/{prefix}-config.json');prepare=read(root/f'evidence/{prefix}-prepare/process-state.json');actual=read(root/f'evidence/{prefix}-actual/process-state.json')
assert prepare['State']=='Exited' and actual['State']=='Exited' and actual['ExitCode'] is not None
assert len(actual['ResultDirectories'])==1 and len(prepare['ResultDirectories'])==1
d=pathlib.Path(actual['ResultDirectories'][0]);s=read(d/'summary.json');gate=read(root/f'evidence/{prefix}-prepare-gate.json')
pins=read(root/f'evidence/{prefix}-inputs-after-actual.json');health=read(root/f'evidence/{prefix}-post-run.json')
assert s['Revision']['Head']==cfg['CheckoutHead'] and s['Revision']['ChangedFiles']==0 and s['TimeoutMinutes']==cfg['RunnerBudgetMinutes']
assert not s['PlanOnly'];assert s['Selection']['PlannedCases']==cfg['ExpectedCases']
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};cases=[]
for path in sorted(d.glob('*.trx')):
 for row in ET.parse(path).findall('.//t:UnitTestResult',ns):
  error=row.find('t:Output/t:ErrorInfo',ns)
  cases.append({'Name':row.get('testName'),'Outcome':row.get('outcome'),'Duration':row.get('duration'),'OriginalStdOut':row.findtext('t:Output/t:StdOut',default='',namespaces=ns) or '',
   'ErrorMessage':error.findtext('t:Message',default='',namespaces=ns) if error is not None else '',
   'ErrorStackTrace':error.findtext('t:StackTrace',default='',namespaces=ns) if error is not None else ''})
assert len(cases)<=cfg['ExpectedCases'] and len({x['Name'] for x in cases})==len(cases)
counts=Counter(x['Outcome'] for x in cases);witnesses=[]
for case in cases:
 for line in case['OriginalStdOut'].splitlines():
  if line.startswith('{'):
   try:item=json.loads(line)
   except json.JSONDecodeError:continue
   if item.get('kind')=='f18-native-runtime-contention' or 'CleanupOwnedRoot' in item:witnesses.append(item)
passed=counts.get('Passed',0)==cfg['ExpectedCases'] and len(cases)==cfg['ExpectedCases'] and s['ExitCode']==0 and s['Selection']['Complete'] and s['OwnedTreeCleanupSucceeded'] and s['RuntimeCleanupSucceeded'] and not s['TimedOut'] and not s['DuplicateTests'] and not health['ActiveOwnedOperations'] and not health['TaskOwnedRootRemainders'] and all(x['Exited'] for x in health['ProcessChecks'])
if key=='contention' and passed:
 traces=[x for x in witnesses if x.get('kind')=='f18-native-runtime-contention'];clean=[x for x in witnesses if 'CleanupOwnedRoot' in x]
 assert len(traces)==3 and len(clean)==3
 assert all(x['paused']==1 and x['mainContentions']>0 and x['canonicalContentions']==0 and x['publicationStarted'] and x['publicationSettled'] and x['readerStarted'] and x['readerSettled'] for x in traces)
 assert all(x['OwnedFixtureRemoved'] and not pathlib.Path(x['CleanupOwnedRoot']).exists() for x in clean)
carrier=repo/'specs/1553-portable-local-storage/recovery/windows-owner-recipes-20261012';stage=carrier/key/attempt;assert not stage.exists(),'Carrier already frozen: inspect before retry';stage.mkdir(parents=True)
def archive(name,entries):
 path=stage/name;records=[]
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for source,path_in_zip in entries:z.write(source,path_in_zip);records.append({'Path':path_in_zip,'Bytes':source.stat().st_size,'SHA256':sha(source)})
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and sorted(z.namelist())==sorted(x['Path'] for x in records)
  for item in records:
   raw=z.read(item['Path']);assert len(raw)==item['Bytes'] and hashlib.sha256(raw).hexdigest()==item['SHA256']
 return {'Path':f'{key}/{attempt}/{name}','Bytes':path.stat().st_size,'SHA256':sha(path),'Entries':records}
archives=[]
for phase,state in [('prepare',prepare),('actual',actual)]:
 result=pathlib.Path(state['ResultDirectories'][0]);entries=[(p,'runner/'+p.relative_to(result).as_posix()) for p in sorted(result.rglob('*')) if p.is_file()]
 entries.extend((p,'process/'+p.name) for p in sorted((root/f'evidence/{prefix}-{phase}').iterdir()) if p.is_file());archives.append(archive(phase+'-original.zip',entries))
names=['owner-inputs.py','run-owner-phase.ps1','post-owner.ps1','freeze-owner.py','evidence/owner-recipes-inventory.json','evidence/owner-recipes-source-review.json','evidence/owner-recipes-output-cohorts.json','evidence/owner-recipes-extended-source-snapshot.json',
 f'evidence/{prefix}-config.json',f'evidence/{prefix}-inputs-before-prepare.json',f'evidence/{prefix}-inputs-gate.json',f'evidence/{prefix}-inputs-before-actual.json',f'evidence/{prefix}-inputs-after-actual.json',f'evidence/{prefix}-prepare-gate.json',f'evidence/{prefix}-post-run.json']
entries=[(root/n,n) for n in names]
for name in cfg['RelevantSources']+['tests/categories.json','BookOfEternityClient/Core/ReversibleFilePublication.cs','BookOfEternityClient/Core/TrustedLocalFileScope.cs']:
 entries.append((repo/name,'repo/'+name))
archives.append(archive('execution-provenance.zip',entries))
m={'SchemaVersion':1,'RecordedUtc':datetime.now(timezone.utc).isoformat(),'Recipe':key,'Attempt':attempt,'Category':cfg['Category'],'CheckoutHead':cfg['CheckoutHead'],'SemanticSourceEquals':cfg['SemanticSourceEquals'],
 'CompiledProjectOrigins':pins['QualifiedProjects'],'Qualification':'Native Windows required bodies' if cfg['NativeQualification'] else 'Portable component executed on Windows; native Windows qualification expressly excluded',
 'Planned':cfg['ExpectedCases'],'ExpectedMethodCounts':cfg['ExpectedMethodCounts'],'Executed':len(cases),'Passed':counts.get('Passed',0),'Failed':counts.get('Failed',0),'OtherOutcomes':dict(counts),
 'CompleteGreen':passed,'State':'EvidenceReviewPending' if passed else 'FailureEvidencePreservedReviewPending','ActualAttemptsInStage':1,
 'PlanOnlyWallTime':gate['PlanOnlyWallTime'],'PlanOnlyExecuted':0,'BuildPhases':gate['BuildPhases'],'ActualWallTime':s['WallTime'],'CategoryResults':s['CategoryResults'],
 'ExitCode':s['ExitCode'],'SelectionComplete':s['Selection']['Complete'],'CategoryBudgetMinutes':cfg['CategoryBudgetMinutes'],'RunnerBudgetMinutes':cfg['RunnerBudgetMinutes'],
 'TimedOut':s['TimedOut'],'Duplicates':s['DuplicateTests'],'OwnedTreeCleanupSucceeded':s['OwnedTreeCleanupSucceeded'],'RuntimeCleanupSucceeded':s['RuntimeCleanupSucceeded'],
 'Health':health,'SourcePins':len(pins['SourcePins']),'OriginalClientIntegrationTestSupportSourcePins':1629,'ExtraUnitBridgeCrashHostSourcePins':len(pins['SourcePins'])-1629,'DllPdbPins':len(pins['DllPins']),'ExactSourceAndDllBytesEqual':pins['ExactSourceAndDllBytesEqual'],'Cases':cases,'Witnesses':witnesses,'Archives':archives,
 'Excludes':cfg['Excludes'],'NoNewColdUncCaseSensitiveFullGamePerformanceTask':True,'ParentIssueClosed':False}
save(stage/'manifest.json',m)
global_manifest=read(carrier/'manifest.json');entry=next(x for x in global_manifest['Recipes'] if x['Key']==key)
entry['State']=m['State'];entry.setdefault('Attempts',[]).append({'Manifest':f'{key}/{attempt}/manifest.json','Passed':m['Passed'],'Failed':m['Failed'],'CompleteGreen':passed,'CheckoutHead':cfg['CheckoutHead']})
global_manifest.setdefault('Archives',[]).extend(archives);global_manifest['State']='WIPSequentialRecipeEvidence';save(carrier/'manifest.json',global_manifest)
print(json.dumps({'Category':cfg['Category'],'Passed':m['Passed'],'Failed':m['Failed'],'CompleteGreen':passed,'ActualWallTime':m['ActualWallTime'],'CategoryResults':m['CategoryResults'],'ArchiveEntries':sum(len(x['Entries']) for x in archives),'Witnesses':witnesses}))
