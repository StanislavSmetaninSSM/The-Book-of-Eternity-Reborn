param([Parameter(Mandatory)][string]$Recipe,[string]$Attempt='a1')
$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$root='C:\Temp\boe-win-8c2ecdfa-20261011T234246Z';$prefix='owner-'+$Recipe+'-'+$Attempt
$cfg=Get-Content -LiteralPath (Join-Path $root ('evidence\'+$prefix+'-config.json')) -Raw -Encoding UTF8 | ConvertFrom-Json
$boot=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime();$checks=@()
foreach ($phase in @('prepare','actual')) {
 $s=Get-Content -LiteralPath (Join-Path $root ('evidence\'+$prefix+'-'+$phase+'\process-state.json')) -Raw -Encoding UTF8 | ConvertFrom-Json
 if ($s.State -ne 'Exited' -or $null -eq $s.ExitCode -or [datetime]$s.RunnerStartedUtc -lt $boot) { throw 'Phase not completed in this boot; recovery first' }
 foreach ($kind in @('Wrapper','Runner')) {
  $ownedId=[int]$s.($kind+'Pid');$started=[datetime]$s.($kind+'StartedUtc');$live=Get-Process -Id $ownedId -ErrorAction SilentlyContinue
  $same=[bool]($live -and [Math]::Abs(($live.StartTime.ToUniversalTime()-$started.ToUniversalTime()).TotalSeconds) -lt 2)
  $checks += [pscustomobject]@{Phase=$phase;Kind=$kind;Pid=$ownedId;StartUtc=$started.ToUniversalTime().ToString('o');Exited=(-not $same);PidReused=[bool]($live -and -not $same)}
 }
}
$ops=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(dotnet|testhost|git|python|MSBuild)(\.exe)?$' -and $_.CommandLine -and $_.CommandLine.Contains($root) } | Select-Object ProcessId,Name,CreationDate)
$roots=@(Get-ChildItem -LiteralPath (Join-Path $root 'tmp') -Directory | Where-Object {
 $candidate=$_.Name
 @($cfg.FixturePrefixes | Where-Object {$candidate.StartsWith($_,[StringComparison]::Ordinal)}).Count -gt 0 -or $candidate.StartsWith('boe-test-worker-runtime-',[StringComparison]::Ordinal)
} | Select-Object -ExpandProperty FullName)
$record=[ordered]@{RecordedUtc=[datetime]::UtcNow.ToString('o');BootUtc=$boot.ToString('o');Recipe=$Recipe;Attempt=$Attempt;ProcessChecks=$checks;ActiveOwnedOperations=$ops;TaskOwnedRootRemainders=$roots;NoKillOrDelete=$true}
$path=Join-Path $root ('evidence\'+$prefix+'-post-run.json');if(Test-Path -LiteralPath $path){throw 'Post receipt reserved: inspect before retry'}
$record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $path -Encoding utf8NoBOM
$record | ConvertTo-Json -Depth 8 -Compress
