import hashlib,json,pathlib,subprocess,sys
from datetime import datetime,timezone
root=pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z');repo=root/'repo'
key,mode=sys.argv[1:3];attempt=sys.argv[3] if len(sys.argv)>3 else 'a1'
prefix=f'owner-{key}-{attempt}';cfgpath=root/f'evidence/{prefix}-config.json'
git=['git','-c','core.longpaths=true','-c','core.autocrlf=false']
projects=['BookOfEternityClient','BookOfEternityClient.TestSupport','BookOfEternityClient.IntegrationTests','BookOfEternityClient.Tests','BookOfEternityGMBridge','tests/fixtures/PortableStorageCrashHost']
registry_path=root/'evidence/owner-recipes-output-cohorts.json'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p):return {'Path':p.relative_to(repo).as_posix(),'Bytes':p.stat().st_size,'SHA256':sha(p),'LastWriteUtc':datetime.fromtimestamp(p.stat().st_mtime,timezone.utc).isoformat()}
def valid(items):
 for x in items:
  p=repo/x['Path'];assert p.stat().st_size==x['Bytes'] and sha(p)==x['SHA256'],x['Path']
def dlls():return [pin(p) for name in projects for p in sorted((repo/name/'bin/Debug/net8.0').rglob('*')) if p.is_file() and p.suffix.lower() in ['.dll','.pdb']]
head=subprocess.check_output(git+['rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(git+['status','--porcelain=v1','-z'],cwd=repo),'Dirty checkout'
baseline=read(root/'evidence/path-green-inputs-after-actual.json');valid(baseline['SourcePins'])
extended=read(root/'evidence/owner-recipes-extended-source-snapshot.json');valid(extended['Pins'])
if mode=='setup':
 assert not cfgpath.exists(),'Config reserved: inspect before retry'
 recipe=next(x for x in read(root/'evidence/owner-recipes-inventory.json')['Recipes'] if x['Key']==key)
 if not registry_path.exists():
  valid(baseline['DllPins']);all_dll=dlls();qualified={'integration':'13e17a3eb446b02e3d136b0214b52b00e730e25c'}
  save(registry_path,{'QualifiedProjects':qualified,'DllPins':all_dll,'LastBuild':'path-green fresh successful integration prepare'})
 registry=read(registry_path);valid(registry['DllPins'])
 if not recipe['PrepareFreshBuild']:assert all(p in registry['QualifiedProjects'] for p in recipe['Projects'])
 selected_pins=baseline['SourcePins']
 if 'unit' in recipe['Projects']:
  original_names={x['Path'] for x in selected_pins}
  selected_pins=selected_pins+[x for x in extended['Pins'] if x['Path'] not in original_names]
 cfg={**recipe,'Attempt':attempt,'Prefix':prefix,'CheckoutHead':head,'SemanticSourceEquals':'13e17a3eb446b02e3d136b0214b52b00e730e25c','SourcePins':selected_pins,
  'OriginalIntegrationSourcePins':1629,'ExtraUnitBridgeCrashHostSourcePins':len(selected_pins)-1629,'UnitBridgeSourceSnapshotHead':extended['SnapshotCheckoutHead'],
  'PrepareNoBuild':not recipe['PrepareFreshBuild'],'PriorQualifiedProjects':registry['QualifiedProjects'],'SourceReviewReceipt':'evidence/owner-recipes-source-review.json'}
 save(cfgpath,cfg);print(json.dumps({'Mode':'setup','Head':head,'Category':cfg['Category'],'Cases':cfg['ExpectedCases'],'PrepareNoBuild':cfg['PrepareNoBuild'],'CompileOrigins':registry['QualifiedProjects']}));sys.exit()
cfg=read(cfgpath);assert head==cfg['CheckoutHead'];valid(cfg['SourcePins'])
receipt=root/f'evidence/{prefix}-inputs-{mode}.json';assert not receipt.exists(),'Receipt reserved: inspect before retry'
record={'CheckedUtc':datetime.now(timezone.utc).isoformat(),'CheckoutHead':head,'Category':cfg['Category'],'SourcePins':cfg['SourcePins'],'SemanticSourceEquals':cfg['SemanticSourceEquals']}
if mode=='before-prepare':
 registry=read(registry_path);valid(registry['DllPins'])
 record.update({'DllPins':dlls(),'QualifiedProjects':registry['QualifiedProjects'],'PrepareNoBuild':cfg['PrepareNoBuild']})
elif mode=='gate':
 before=read(root/f'evidence/{prefix}-inputs-before-prepare.json');valid(before['SourcePins'])
 state=read(root/f'evidence/{prefix}-prepare/process-state.json');assert state['State']=='Exited' and state['ExitCode']==0 and len(state['ResultDirectories'])==1
 d=pathlib.Path(state['ResultDirectories'][0]);s=read(d/'summary.json');plan=read(d/'plan.json')
 assert s['PlanOnly'] and s['Tests']['Executed']==0 and s['ExitCode']==0 and not s['TimedOut']
 assert s['Revision']['Head']==head and s['Revision']['ChangedFiles']==0
 assert s['OwnedTreeCleanupSucceeded'] and s['RuntimeCleanupSucceeded'] and s['TimeoutMinutes']==cfg['RunnerBudgetMinutes']
 assert s['Selection']['PlannedCases']==cfg['ExpectedCases'] and len(plan['Descriptors'])==cfg['ExpectedDescriptors']
 methods={x['Name']:x['Cases'] for desc in plan['Descriptors'] for x in desc['ExpectedMethodCounts']};assert methods==cfg['ExpectedMethodCounts'],methods
 assert all(x['BudgetMinutes']==cfg['CategoryBudgetMinutes'] and x['Exclusive']==cfg['Exclusive'] and not x['FrontendBuild'] for x in plan['Descriptors'])
 assert sorted({x['Adapter'] for x in plan['Descriptors']})==cfg['Projects']
 registry=read(registry_path);outputs=dlls();fresh=[];builds=[x for x in s['PhaseResults'] if x['Name'].startswith('Build-')]
 if cfg['PrepareNoBuild']:
  assert not builds;valid(before['DllPins']);assert outputs==before['DllPins']
 else:
  assert len(builds)==1 and builds[0]['Name']=='Build-unit' and builds[0]['Completed']
  valid([x for x in before['DllPins'] if x['Path'].startswith('BookOfEternityClient.IntegrationTests/')])
  started=datetime.fromisoformat(state['RunnerStartedUtc'].replace('Z','+00:00'))
  for project in ['BookOfEternityClient.Tests','BookOfEternityGMBridge']:
   for suffix in ['.dll','.pdb']:
    name=f'{project}/bin/Debug/net8.0/{project}{suffix}';x=next(x for x in outputs if x['Path']==name)
    assert datetime.fromisoformat(x['LastWriteUtc'])>=started,name
    old=next((v for v in before['DllPins'] if v['Path']==name),None)
    assert old is None or old['SHA256']!=x['SHA256'],name
    fresh.append(x)
  registry['QualifiedProjects'].update({'unit':head,'bridge':head});registry['LastBuild']=str(d)
 registry['DllPins']=outputs;save(registry_path,registry)
 record.update({'DllPins':outputs,'QualifiedProjects':registry['QualifiedProjects'],'FreshUnitAndBridgeOutputs':fresh,'BuildPhases':builds,'PlanOnlyWallTime':s['WallTime'],'ExpectedMethodCounts':methods,'ResultDirectory':str(d)})
 gate={'Accepted':True,'CheckoutHead':head,'Category':cfg['Category'],'PlannedCases':cfg['ExpectedCases'],'Methods':len(methods),'Descriptors':cfg['ExpectedDescriptors'],'PlanOnlyExecuted':0,
  'CategoryBudgetMinutes':cfg['CategoryBudgetMinutes'],'RunnerBudgetMinutes':cfg['RunnerBudgetMinutes'],'QualifiedProjects':registry['QualifiedProjects'],'InputsReceipt':str(receipt),'PlanOnlyWallTime':s['WallTime'],'BuildPhases':builds}
 gatepath=root/f'evidence/{prefix}-prepare-gate.json';assert not gatepath.exists();save(gatepath,gate)
elif mode=='before-actual':
 gate=read(root/f'evidence/{prefix}-prepare-gate.json');assert gate['Accepted'] and gate['CheckoutHead']==head
 previous=read(root/f'evidence/{prefix}-inputs-gate.json');valid(previous['SourcePins']+previous['DllPins'])
 review=read(root/cfg['SourceReviewReceipt']);assert review['Verdict']=='SOURCE PASS' and review['Reviewer']=='Actual gpt-6-astra/xhigh'
 assert not subprocess.check_output(git+['diff','--name-only',review['ReviewedHead'],head,'--','BookOfEternityClient','BookOfEternityClient.Tests','BookOfEternityClient.IntegrationTests','BookOfEternityGMBridge','BookOfEternityClient.TestSupport','tests','scripts'],cwd=repo)
 record.update({'DllPins':previous['DllPins'],'QualifiedProjects':previous['QualifiedProjects'],'ExactSourceAndDllBytesEqual':True,'IndependentSourceReview':review})
elif mode=='after-actual':
 previous=read(root/f'evidence/{prefix}-inputs-before-actual.json');valid(previous['SourcePins']+previous['DllPins']);assert dlls()==previous['DllPins']
 record.update({'DllPins':previous['DllPins'],'QualifiedProjects':previous['QualifiedProjects'],'ExactSourceAndDllBytesEqual':True,'NoAdditionalBuild':True})
else:raise AssertionError(mode)
save(receipt,record)
print(json.dumps({'Mode':mode,'Head':head,'Category':cfg['Category'],'SourcePins':len(record['SourcePins']),'DllPdbPins':len(record.get('DllPins',[])),
 'QualifiedProjects':record.get('QualifiedProjects'),'FreshOutputs':len(record.get('FreshUnitAndBridgeOutputs',[])),'PlanOnlyWallTime':record.get('PlanOnlyWallTime'),'BuildPhases':record.get('BuildPhases')}))
