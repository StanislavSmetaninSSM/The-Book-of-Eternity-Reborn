using System.Security.Cryptography;
using System.Collections;
using System.Collections.Concurrent;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using System.Reflection;
using BookOfEternityClient.AgentConsole;
using BookOfEternityClient.Configuration;
using BookOfEternityClient.Core;
using BookOfEternityClient.IO;
using BookOfEternityClient.Models;
using BookOfEternityClient.Services;
using BookOfEternityClient.Services.GmWorkers;
using BookOfEternityClient.UI;
using Microsoft.Extensions.Logging.Abstractions;
using Spectre.Console;
using Xunit;
using Xunit.Abstractions;

namespace BookOfEternityClient.Tests;

[CollectionDefinition(CollectionName, DisableParallelization = true)]
public sealed class GameEngineTurnLifecycleCollection
{
    public const string CollectionName = "Game engine turn lifecycle";
}

[Collection(GameEngineTurnLifecycleCollection.CollectionName)]
[Trait("Category", "LifecycleIntegration")]
public sealed partial class GameEngineTurnLifecycleTests : IDisposable
{
    private sealed class PendingTurnSnapshotManifestPayload
    {
        public string SessionId { get; set; } = "";
        public string RequestId { get; set; } = "";
        public int TurnNumber { get; set; }
        public string RequestTimestamp { get; set; } = "";
        public string PlayerAction { get; set; } = "";
        public int[]? PreGeneratedDices1d20 { get; set; }
        public JsonObject? GachaBaseResult { get; set; }
        public ProgressionControl? ProgressionControl { get; set; }
        public Dictionary<string, string> Files { get; set; } = new(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> SnapshotFileHashes { get; set; } = new(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> ClientOwnedValidationHashes { get; set; } = new(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> RollbackBackups { get; set; } = new(StringComparer.OrdinalIgnoreCase);
        public List<string> RollbackBaselineFiles { get; set; } = new();
        public string? SourceLabel { get; set; }
        public string ManifestPayloadHash { get; set; } = "";
    }

    private static readonly JsonSerializerOptions SnapshotHashJsonOpts = new()
    {
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    private readonly string _rootPath;
    private readonly FileSystemManager _fs;
    private Action<TrustedLocalPublicationPhase, int>? _consolePublicationObserver;
    private Action<string>? _consoleMutationObserver;
    private string? _armedCanonicalWriteFailurePath;
    private int _remainingCanonicalWriteFailureMatches;
    private readonly ITestOutputHelper? _directGachaOutput;

    public GameEngineTurnLifecycleTests(ITestOutputHelper? output = null)
    {
        _directGachaOutput = output;
        _rootPath = Path.Combine(Path.GetTempPath(), "boe-gameengine-turnlifecycle-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(_rootPath);
        _fs = new FileSystemManager(
            _rootPath,
            NullLogger<FileSystemManager>.Instance,
            PhysicalLoadTransactionOperations.Instance,
            new FileSystemManagerHooks
            {
                BeforeCanonicalMutationAsync = BeforeCanonicalMutationAsync,
                LocalPublicationObserver = (phase, index) => _consolePublicationObserver?.Invoke(phase, index)
            });
        _fs.EnsureDirectoryStructure();
        _fs.WriteFileAtomicAsync(
                MortalItemIdentityState.StatePath,
                MortalItemIdentityState.CreateEmptyRoot()
                    .ToJsonString(SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed))
            .GetAwaiter()
            .GetResult();
    }

    [Fact]
    public void TryDescribeInvalidTriggerLifeEndRuntimeContext_MortalPreTurnAndMortalCurrent_IsReadable()
    {
        var invalid = GameEngine.TryDescribeInvalidTriggerLifeEndRuntimeContext(
            "Mortal World",
            "Mortal World",
            out var failureDescription);

        Assert.False(invalid);
        Assert.Equal(string.Empty, failureDescription);
    }

    [Fact]
    public void TryDescribeInvalidTriggerLifeEndRuntimeContext_AfterlifeCurrentRealm_FailsClosed()
    {
        var invalid = GameEngine.TryDescribeInvalidTriggerLifeEndRuntimeContext(
            "Mortal World",
            "Chaos Sea",
            out var failureDescription);

        Assert.True(invalid);
        Assert.Contains("currentRealm", failureDescription, StringComparison.Ordinal);
    }

    [Fact]
    public void TryDescribeInvalidTriggerLifeEndRuntimeContext_UnreadablePreTurnRealm_FailsClosed()
    {
        var invalid = GameEngine.TryDescribeInvalidTriggerLifeEndRuntimeContext(
            null,
            "Mortal World",
            out var failureDescription);

        Assert.True(invalid);
        Assert.Contains("pre-turn mortal realm authority", failureDescription, StringComparison.Ordinal);
    }

    [Fact]
    [Trait("Category", "PreMergeSentinel")]
    public async Task CheckLevelUpAsync_DoesNotAwardAlreadyProcessedLevelAfterEngineRestart()
    {
        await WriteJsonAsync("game_state/player/experience.json", new
        {
            playerLevel = 2,
            level = 2,
            currentExperience = 49,
            experience = 49,
            totalExperience = 149,
            experienceForNextLevel = 150
        });
        await WriteJsonAsync("game_state/player/stat_points.json", new
        {
            unspentStatPoints = 0
        });
        await WriteJsonAsync("game_state/misc/characteristics.json", new
        {
            strength = 2,
            dexterity = 4,
            constitution = 2,
            intelligence = 4,
            wisdom = 1,
            faith = 1,
            attractiveness = 1,
            trade = 1,
            persuasion = 2,
            perception = 4,
            luck = 2,
            speed = 1
        });
        await WriteJsonAsync("game_state/player/computed_characteristics.json", new
        {
            playerLevel = 1,
            unspentStatPoints = 0,
            characteristics = new { strength = 2 }
        });

        var firstLevelUpInput = new QueuedConsoleInputSource(
            Enumerable.Repeat(Key(ConsoleKey.RightArrow), 5).Append(Key(ConsoleKey.Enter)));
        var firstEngine = CreateGameEngine(firstLevelUpInput);
        await InvokePrivateTaskAsync(firstEngine, "CheckLevelUpAsync");

        var afterFirstBaseStats = JsonNode.Parse((await _fs.ReadFileAsync("game_state/misc/characteristics.json"))!)!.AsObject();
        Assert.Equal(7, afterFirstBaseStats["strength"]!.GetValue<int>());
        var afterFirstComputed = JsonNode.Parse((await _fs.ReadFileAsync("game_state/player/computed_characteristics.json"))!)!.AsObject();
        Assert.Equal(7, afterFirstComputed["characteristics"]!["strength"]!.GetValue<int>());

        var restartedInput = new QueuedConsoleInputSource(
            Enumerable.Repeat(Key(ConsoleKey.RightArrow), 5).Append(Key(ConsoleKey.Enter)));
        var restartedEngine = CreateGameEngine(restartedInput);
        await InvokePrivateTaskAsync(restartedEngine, "CheckLevelUpAsync");

        var afterRestartBaseStats = JsonNode.Parse((await _fs.ReadFileAsync("game_state/misc/characteristics.json"))!)!.AsObject();
        Assert.Equal(7, afterRestartBaseStats["strength"]!.GetValue<int>());
        var statPoints = JsonNode.Parse((await _fs.ReadFileAsync("game_state/player/stat_points.json"))!)!.AsObject();
        Assert.Equal(0, statPoints["unspentStatPoints"]!.GetValue<int>());
        var afterRestartComputed = JsonNode.Parse((await _fs.ReadFileAsync("game_state/player/computed_characteristics.json"))!)!.AsObject();
        Assert.Equal(7, afterRestartComputed["characteristics"]!["strength"]!.GetValue<int>());
    }

    [Fact]
    public async Task HandleInvalidTriggerLifeEndRuntimeFailure_DeletesSignalAndWritesErrorLog()
    {
        await _fs.WriteFileAtomicAsync("game_state/control/life_transitions.json", """
        {
          "reason": "Death",
          "summary": "Смертная жизнь завершена."
        }
        """);

        var exception = new GameEngine.TriggerLifeEndRuntimeContextException(
            "Canonical TriggerLifeEnd runtime flow requires mortal pre-turn realm authority.");

        GameEngine.HandleInvalidTriggerLifeEndRuntimeFailure(_fs, exception);

        Assert.False(_fs.FileExists("game_state/control/life_transitions.json"));

        var logPath = Path.Combine(_fs.GameSessionPath, "error_log.txt");
        Assert.True(File.Exists(logPath));
        var log = File.ReadAllText(logPath, Encoding.UTF8);
        Assert.Contains("TriggerLifeEndRuntimeContextException", log, StringComparison.Ordinal);
        Assert.Contains("mortal pre-turn realm authority", log, StringComparison.Ordinal);
    }

    [Fact]
    public async Task ShowTurnErrorMessageAsync_PublishesPlayerSafeRecoveryScreen()
    {
        var store = new AgentConsoleStateStore();
        using var input = new AgentConsoleLiveInputSource(store, readTimeout: TimeSpan.FromSeconds(5));
        var engine = CreateGameEngine(input);
        await _fs.WriteFileAtomicAsync("ready/turn_error.json", """
        {
          "sessionId": "session-timeout",
          "requestId": "request-timeout",
          "turnNumber": 15,
          "timestamp": "2026-06-30T23:43:36Z",
          "status": "error",
          "error": "Timeout after 900s"
        }
        """);

        var method = typeof(GameEngine).GetMethod(
            "ShowTurnErrorMessageAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(engine, new object[] { "ready/turn_error.json" })!);

        var snapshot = await WaitForAgentConsoleSnapshotAsync(store, "world-turn-paused");

        Assert.Equal(AgentConsoleMode.Error, snapshot.Mode);
        Assert.True(snapshot.AwaitingInput);
        Assert.Equal(AgentConsoleInputKind.Key, snapshot.InputKind);
        Assert.Equal("Ход прервался", snapshot.Title);
        Assert.Contains("Действие не было применено", snapshot.PlainText, StringComparison.Ordinal);
        AssertPlayerAgentConsoleSnapshotIsPrivate(
            snapshot,
            store.GetEvents(),
            "Timeout after 900s",
            "session-timeout",
            "request-timeout");

        input.EnqueueKey(Key(ConsoleKey.Enter));
        await task.WaitAsync(TimeSpan.FromSeconds(5));
    }

    [Fact]
    [Trait("Category", "PreMergeSentinel")]
    public async Task CollectAcceptedTurnRawStateIssuesAsync_DirectNpcCoreMutation_IsRejectedBeforeNormalization()
    {
        const string npcCorePath = "game_state/npcs/npc_core.json";
        const string sessionId = "session-npc-core-raw-lifecycle";
        const string requestId = "request-npc-core-raw-lifecycle";
        const int turnNumber = 12;

        var preTurnRoot = new JsonObject
        {
            ["NPCsInScene"] = new JsonArray
            {
                new JsonObject
                {
                    ["NPCId"] = "npc_archive_mentor",
                    ["NPCName"] = "Смотритель архива",
                    ["worldview"] = "Знание требует осторожности."
                }
            }
        };
        var currentRoot = preTurnRoot.DeepClone().AsObject();
        var currentActor = Assert.Single(currentRoot["NPCsInScene"]!.AsArray().OfType<JsonObject>());
        currentActor["worldview"] = "Несанкционированная подмена убеждений.";
        await _fs.WriteFileAtomicAsync(npcCorePath, currentRoot.ToJsonString());
        await _fs.WriteFileAtomicAsync(
            $"game_state/control/pending_turn_snapshot/{npcCorePath}",
            preTurnRoot.ToJsonString());
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, npcCorePath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber,
            playerAction = "game-engine-turn-lifecycle-test"
        });
        var engine = CreateGameEngine();

        var issues = await InvokePrivateAsync<List<ValidationIssue>>(
            engine,
            "CollectAcceptedTurnRawStateIssuesAsync");

        Assert.Contains(issues, issue =>
            issue.Code == "npc_existing_core_direct_mutation_forbidden" &&
            issue.FilePath == $"{npcCorePath}.NPCsInScene[0]");
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_WithEnabledWorkerProfile_WritesWorkerTaskAndAudit()
    {
        const string sessionId = "session-worker-repair";
        const string requestId = "request-worker-repair";
        const int turnNumber = 3;
        const string trackedPath = "game_state/world/weather.json";

        await _fs.WriteFileAtomicAsync(trackedPath, "{\"before\":true}");
        await _fs.WriteFileAtomicAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", "{\"before\":true}");
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });
        await WriteJsonAsync("game_state/control/validation_repair_request.json", new { stale = true });
        await WriteJsonAsync("game_state/control/validation_repair_ready.json", new { stale = true });
        await WriteJsonAsync("game_state/control/gm_validation_repair_artifact_stall_report.json", new { stale = true });

        var scriptPath = Path.Combine(_rootPath, "fake-validation-repair-worker.ps1");
        await File.WriteAllTextAsync(scriptPath, """
            $control = Join-Path $env:BOE_WORKER_SESSION_PATH 'game_state/control'
            if (Test-Path (Join-Path $control 'validation_repair_request.json')) { exit 71 }
            if (Test-Path (Join-Path $control 'validation_repair_ready.json')) { exit 72 }
            if (Test-Path (Join-Path $control 'gm_validation_repair_artifact_stall_report.json')) { exit 73 }
            exit 7
            """, Encoding.UTF8);
        var engine = CreateGameEngine(configureSettings: settings =>
        {
            settings.GmWorkerBridgeProfiles.Add(GmWorkerBridgeTestFixtures.ValidationRepairCodexProfile() with
            {
                LaunchCommand = $"powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File \"{scriptPath}\"",
                TimeoutSeconds = 10
            });
        });
        var issue = new ValidationIssue(
            "game_state/world/weather.json",
            IssueSeverity.Error,
            "normalizedWeatherState.description is required.",
            code: "normalized_weather_missing_description");

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "state validation", new List<ValidationIssue> { issue }, 1 })!);

        await task;

        Assert.True(_fs.FileExists("game_state/control/validation_repair_request.json"));
        Assert.False(_fs.FileExists("game_state/control/validation_repair_ready.json"));
        Assert.False(_fs.FileExists("game_state/control/gm_validation_repair_artifact_stall_report.json"));
        var workerTaskJson = await _fs.ReadFileAsync("game_state/control/gm_worker_latest_validation_repair_task.json");
        Assert.False(string.IsNullOrWhiteSpace(workerTaskJson));
        var workerTask = GmWorkerJson.Deserialize<WorkerTaskPacket>(workerTaskJson!);
        Assert.NotNull(workerTask);
        Assert.Equal("validation_repair_codex", workerTask!.WorkerId);
        Assert.Equal(WorkerTaskType.ValidationRepair, workerTask.TaskType);
        Assert.Contains("game_state/world/weather.json", workerTask.AllowedProposalPaths);

        var audit = new GmWorkerAuditLog(_fs);
        var events = await audit.ReadEventsAsync();
        var dispatch = Assert.Single(events, evt => evt.EventType == "task-dispatched");
        Assert.Equal(workerTask.TaskId, dispatch.TaskId);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task WriteValidationRepairRequestAsync_WhenWorkerApplies_DoesNotExposeLegacyRepairRequest(
        bool auditPathWritable)
    {
        const string sessionId = "session-worker-repair-applied";
        const string requestId = "request-worker-repair-applied";
        const int turnNumber = 4;
        const string trackedPath = "game_state/world/weather.json";
        const string weatherJson = "{\"tendency\":\"NO_CHANGE\",\"description\":\"Погода не меняется.\"}";

        CopyDirectory(TestRepoPaths.BaseSessionRoot, _fs.GameSessionPath);
        _fs.DeleteFile("game_state/control/validation_repair_request.json");
        _fs.DeleteFile("game_state/control/validation_repair_ready.json");
        await _fs.WriteFileAtomicAsync(trackedPath, weatherJson);
        var snapshotRoot = _fs.ResolvePath("game_state/control/pending_turn_snapshot");
        if (Directory.Exists(snapshotRoot))
            Directory.Delete(snapshotRoot, recursive: true);
        var trackedPaths = Directory.GetFiles(_fs.GameSessionPath, "*.json", SearchOption.AllDirectories)
            .Select(path => Path.GetRelativePath(_fs.GameSessionPath, path).Replace('\\', '/'))
            .Where(path =>
                (path.StartsWith("game_state/", StringComparison.Ordinal) &&
                 !path.StartsWith("game_state/control/", StringComparison.Ordinal)) ||
                path.StartsWith("lore/", StringComparison.Ordinal))
            .Order(StringComparer.Ordinal)
            .ToArray();
        foreach (var path in trackedPaths)
        {
            var destination = _fs.ResolvePath($"game_state/control/pending_turn_snapshot/{path}");
            Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
            File.Copy(_fs.ResolvePath(path), destination, overwrite: true);
        }
        await WritePendingTurnSnapshotManifestAsync(
            sessionId,
            requestId,
            turnNumber,
            trackedPaths);
        await WriteJsonAsync("input/turn_request.json", new { sessionId, requestId, turnNumber });
        if (!auditPathWritable)
            Directory.CreateDirectory(_fs.ResolvePath(GmWorkerAuditLog.AuditLogPath));

        var scriptPath = Path.Combine(_rootPath, "fake-validation-repair-worker-applied.ps1");
        await File.WriteAllTextAsync(scriptPath, """
            $task = Get-Content -Raw -Path $env:BOE_WORKER_TASK_PATH | ConvertFrom-Json
            $weatherContext = @($task.contextFiles | Where-Object { $_.path -eq 'game_state/world/weather.json' })[0]
            $proposalId = 'worker_proposal_game_engine_applied'
            $contentRef = 'worker_proposals/' + $proposalId + '/game_state/world/weather.json'
            $contentPath = Join-Path $env:BOE_WORKER_SESSION_PATH $contentRef
            $canonicalPath = Join-Path $env:BOE_WORKER_SESSION_PATH 'game_state/world/weather.json'
            New-Item -ItemType Directory -Path (Split-Path $contentPath) -Force | Out-Null
            Copy-Item -Path $canonicalPath -Destination $contentPath -Force
            $sha = [System.Security.Cryptography.SHA256]::Create()
            try { $afterSha256 = ([BitConverter]::ToString($sha.ComputeHash([IO.File]::ReadAllBytes($contentPath)))).Replace('-', '').ToLowerInvariant() }
            finally { $sha.Dispose() }
            $proposal = [ordered]@{
                schemaVersion = 1
                proposalId = $proposalId
                taskId = $task.taskId
                workerId = $task.workerId
                status = 'completed'
                summary = 'No-op repair used to verify exclusive worker ownership.'
                changedFiles = @([ordered]@{
                    path = 'game_state/world/weather.json'
                    changeKind = 'replace'
                    beforeSha256 = $weatherContext.sha256
                    afterSha256 = $afterSha256
                    contentRef = $contentRef
                })
                findings = @()
                selfCheck = [ordered]@{
                    scopeReviewed = $true
                    validationExpectedToPass = $true
                    notes = @('exclusive repair flow')
                }
                createdAtUtc = '2026-06-20T01:00:05Z'
            }
            $proposal | ConvertTo-Json -Depth 20 | Set-Content -Path $env:BOE_WORKER_PROPOSAL_PATH -Encoding UTF8
            """, Encoding.UTF8);
        var engine = CreateGameEngine(configureSettings: settings =>
        {
            settings.GmWorkerBridgeProfiles.Add(GmWorkerBridgeTestFixtures.ValidationRepairCodexProfile() with
            {
                LaunchCommand = $"powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File \"{scriptPath}\"",
                TimeoutSeconds = 10
            });
        });
        var issue = new ValidationIssue(
            trackedPath,
            IssueSeverity.Error,
            "Synthetic repair request for worker ownership test.",
            code: "normalized_weather_missing_description");

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "state validation", new List<ValidationIssue> { issue }, 1 })!);

        await task;

        var dispatch = task.GetType().GetProperty("Result")?.GetValue(task);
        Assert.NotNull(dispatch);
        var workerResult = (GmWorkerValidationRepairDispatchResult?)dispatch!
            .GetType()
            .GetProperty("WorkerResult")!
            .GetValue(dispatch);
        var workerDiagnostic = workerResult == null
            ? "missing worker result"
            : $"{workerResult.Outcome}: {workerResult.FallbackReason}; " +
              string.Join(" | ", workerResult.ApplyDecision?.RejectionReasons ?? []);
        Assert.True(
            (bool)dispatch.GetType().GetProperty("WorkerApplyAccepted")!.GetValue(dispatch)!,
            workerDiagnostic);
        Assert.True((bool)dispatch.GetType().GetProperty("ReadySignalCreated")!.GetValue(dispatch)!);

        var auditDiagnostic = auditPathWritable
            ? await _fs.ReadFileAsync(GmWorkerAuditLog.AuditLogPath) ?? "<missing audit>"
            : "audit path intentionally unavailable";
        Assert.True(_fs.FileExists("game_state/control/validation_repair_ready.json"), auditDiagnostic);
        Assert.False(_fs.FileExists("game_state/control/validation_repair_request.json"));
    }

    [Fact]
    public async Task WaitForContractRepairAsync_WhenSessionIsReplaced_AbortsBeforeLegacyRepairOrRollback()
    {
        const string sessionId = "session-worker-repair-replaced";
        const string requestId = "request-worker-repair-replaced";
        const int turnNumber = 5;
        const string trackedPath = "game_state/world/weather.json";
        const string replacementWeather = "{\"replacementSession\":true}";

        await _fs.WriteFileAtomicAsync(trackedPath, "{\"before\":true}");
        await _fs.WriteFileAtomicAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", "{\"before\":true}");
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new { sessionId, requestId, turnNumber });
        string capturedGeneration;
        await using (var lease = await _fs.AcquireCanonicalWriteLeaseAsync())
            capturedGeneration = _fs.GetOrCreateSessionGeneration(lease);

        var canonicalGenerationPath = _fs.SessionGenerationPath.Replace("'", "''", StringComparison.Ordinal);
        var canonicalWeatherPath = _fs.ResolvePath(trackedPath).Replace("'", "''", StringComparison.Ordinal);
        var replacementGeneration = Guid.NewGuid().ToString("N");
        var scriptPath = Path.Combine(_rootPath, "fake-validation-repair-session-replaced.ps1");
        await File.WriteAllTextAsync(scriptPath, $$"""
            $task = Get-Content -Raw -Path $env:BOE_WORKER_TASK_PATH | ConvertFrom-Json
            Set-Content -Path '{{canonicalGenerationPath}}' -Value '{"schemaVersion":1,"generationId":"{{replacementGeneration}}"}' -Encoding UTF8 -NoNewline
            Set-Content -Path '{{canonicalWeatherPath}}' -Value '{{replacementWeather}}' -Encoding UTF8 -NoNewline
            $proposalId = 'worker_proposal_session_replaced'
            $contentRef = 'worker_proposals/' + $proposalId + '/game_state/world/weather.json'
            $contentPath = Join-Path $env:BOE_WORKER_SESSION_PATH $contentRef
            New-Item -ItemType Directory -Path (Split-Path $contentPath) -Force | Out-Null
            Set-Content -Path $contentPath -Value '{"description":"stale worker bytes"}' -Encoding UTF8 -NoNewline
            $sha = [System.Security.Cryptography.SHA256]::Create()
            try { $afterSha256 = ([BitConverter]::ToString($sha.ComputeHash([IO.File]::ReadAllBytes($contentPath)))).Replace('-', '').ToLowerInvariant() }
            finally { $sha.Dispose() }
            $proposal = [ordered]@{
                schemaVersion = 1
                proposalId = $proposalId
                taskId = $task.taskId
                workerId = $task.workerId
                status = 'completed'
                summary = 'Stale proposal after replacement session became current.'
                changedFiles = @([ordered]@{
                    path = 'game_state/world/weather.json'
                    changeKind = 'replace'
                    beforeSha256 = $task.contextFiles[0].sha256
                    afterSha256 = $afterSha256
                    contentRef = $contentRef
                })
                findings = @()
                selfCheck = [ordered]@{
                    scopeReviewed = $true
                    validationExpectedToPass = $true
                    notes = @('session replacement regression')
                }
                createdAtUtc = '2026-07-23T01:00:05Z'
            }
            $proposal | ConvertTo-Json -Depth 20 | Set-Content -Path $env:BOE_WORKER_PROPOSAL_PATH -Encoding UTF8
            """, Encoding.UTF8);
        var engine = CreateGameEngine(configureSettings: settings =>
        {
            settings.GmWorkerBridgeProfiles.Add(GmWorkerBridgeTestFixtures.ValidationRepairCodexProfile() with
            {
                LaunchCommand = $"powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File \"{scriptPath}\"",
                TimeoutSeconds = 10
            });
        });
        var issue = new ValidationIssue(
            trackedPath,
            IssueSeverity.Error,
            "Synthetic repair request for replacement-session ownership test.",
            code: "normalized_weather_missing_description");

        await Assert.ThrowsAsync<GmWorkerSessionReplacedException>(() =>
            InvokePrivateAsync<bool>(
                engine,
                "WaitForContractRepairAsync",
                "state validation",
                new List<ValidationIssue> { issue },
                1,
                null,
                capturedGeneration));
        Assert.False(_fs.FileExists("game_state/control/validation_repair_request.json"));
        Assert.Equal(replacementWeather, await _fs.ReadFileAsync(trackedPath));
    }

    [Fact]
    public async Task WaitForContractRepairAsync_StaleCapturedSession_AbortsBeforeDispatchAndRollback()
    {
        const string trackedPath = "game_state/world/weather.json";
        const string originalWeather = "{\"description\":\"old session\"}";
        const string replacementWeather = "{\"description\":\"replacement session\"}";
        await _fs.WriteFileAtomicAsync(trackedPath, originalWeather);
        var engine = CreateGameEngine(new QueuedConsoleInputSource([Key(ConsoleKey.Escape)]));
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(
            engine,
            "CreatePreTurnBackup",
            "stale_repair_generation");

        string capturedGeneration;
        await using (var lease = await _fs.AcquireCanonicalWriteLeaseAsync())
            capturedGeneration = _fs.GetOrCreateSessionGeneration(lease);
        await using (var lifecycleLease = await _fs.AcquireSessionLifecycleLeaseAsync())
        await using (var replacementLease =
                     await _fs.AcquireSessionReplacementWriteLeaseAsync(lifecycleLease))
        {
            _fs.RotateSessionGeneration(replacementLease);
            await _fs.WriteFileAtomicAsync(replacementLease, trackedPath, replacementWeather);
        }

        var issue = new ValidationIssue(
            trackedPath,
            IssueSeverity.Error,
            "Synthetic stale repair request.",
            code: "normalized_weather_missing_description");
        await Assert.ThrowsAsync<GmWorkerSessionReplacedException>(() =>
            InvokePrivateAsync<bool>(
                engine,
                "WaitForContractRepairAsync",
                "state validation",
                new List<ValidationIssue> { issue },
                1,
                rollbackSnapshot,
                capturedGeneration));
        Assert.Equal(replacementWeather, await _fs.ReadFileAsync(trackedPath));
        Assert.False(_fs.FileExists("game_state/control/validation_repair_request.json"));
    }

    [Fact]
    public async Task WaitForGmResponse_TerminalErrorDoesNotHoldSessionLifecycleLease()
    {
        const string sessionId = "session-cancel-lifecycle";
        const string requestId = "request-cancel-lifecycle";
        const int turnNumber = 4;
        const string trackedPath = "game_state/world/weather.json";

        await _fs.WriteFileAtomicAsync(trackedPath, "{\"description\":\"stable\"}");
        await _fs.WriteFileAtomicAsync(
            $"game_state/control/pending_turn_snapshot/{trackedPath}",
            "{\"description\":\"stable\"}");
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });
        await WriteJsonAsync("ready/turn_error.json", new
        {
            sessionId,
            requestId,
            turnNumber,
            status = "error",
            error = "synthetic terminal failure"
        });
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));

        var lifecycleLease = await _fs.AcquireSessionLifecycleLeaseAsync();
        try
        {
            var accepted = await InvokePrivateAsync<bool>(
                    engine,
                    "WaitForGmResponse")
                .WaitAsync(TimeSpan.FromSeconds(5));
            Assert.False(accepted);
            Assert.False(_fs.FileExists("input/turn_request.json"));
        }
        finally
        {
            await lifecycleLease.DisposeAsync();
        }
    }

    [Fact]
    public async Task WaitForGmResponse_SessionRotationDuringTerminalWait_ThrowsWithoutCleaningReplacement()
    {
        const string sessionId = "session-terminal-rotation";
        const string requestId = "request-terminal-rotation";
        const int turnNumber = 8;
        const string trackedPath = "game_state/world/weather.json";

        await _fs.WriteFileAtomicAsync(trackedPath, "{\"description\":\"old\"}");
        await _fs.WriteFileAtomicAsync(
            $"game_state/control/pending_turn_snapshot/{trackedPath}",
            "{\"description\":\"old\"}");
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });

        var terminalWaitStarted = new TaskCompletionSource(
            TaskCreationOptions.RunContinuationsAsynchronously);
        var engine = CreateGameEngine(
            new QueuedConsoleInputSource([]),
            finalizationHooks: new GameEngineSessionFinalizationHooks
            {
                AtCheckpointAsync = checkpoint =>
                {
                    if (checkpoint == SessionFinalizationCheckpoint.TerminalWaitStarted)
                        terminalWaitStarted.TrySetResult();
                    return Task.CompletedTask;
                }
            });

        var waitTask = InvokePrivateAsync<bool>(engine, "WaitForGmResponse");
        await terminalWaitStarted.Task.WaitAsync(TimeSpan.FromSeconds(5));

        await _fs.ClearGameStateAsync();
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId = "replacement-session",
            requestId = "replacement-request",
            turnNumber = 1
        });
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            sessionId = "replacement-session",
            requestId = "replacement-request",
            turnNumber = 1,
            status = "success"
        });

        await Assert.ThrowsAsync<SessionReplacedException>(
            () => waitTask.WaitAsync(TimeSpan.FromSeconds(5)));
        Assert.True(_fs.FileExists("input/turn_request.json"));
        Assert.True(_fs.FileExists("ready/turn_complete.json"));
        Assert.Contains(
            "replacement-session",
            await _fs.ReadFileAsync("input/turn_request.json"),
            StringComparison.Ordinal);
    }

    [Fact]
    public async Task WaitForGmResponse_GenerationChangesBeforeTerminalInspection_DoesNotConsumeReplacementSignal()
    {
        const string sessionId = "session-terminal-inspection-race";
        const string requestId = "request-terminal-inspection-race";
        const int turnNumber = 8;
        const string trackedPath = "game_state/world/weather.json";

        await _fs.WriteFileAtomicAsync(trackedPath, "{\"description\":\"old\"}");
        await _fs.WriteFileAtomicAsync(
            $"game_state/control/pending_turn_snapshot/{trackedPath}",
            "{\"description\":\"old\"}");
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });

        using var owned = new CleanupOwnedFixture(_rootPath, line => _directGachaOutput?.WriteLine(line));
        var probe = await SessionGenerationCheckpointFixture.CreateAsync(_rootPath, line => _directGachaOutput?.WriteLine(line));
        var engine = CreateGameEngine(
            probe.ObserveInput(new QueuedConsoleInputSource([])), configureSettings: InertRealmSettings,
            fileSystem: probe.Files,
            finalizationHooks: new GameEngineSessionFinalizationHooks
            {
                AtCheckpointAsync = async checkpoint =>
                {
                    if (checkpoint == SessionFinalizationCheckpoint.TerminalWaitStarted)
                        await probe.RotateAsync(checkpoint.ToString(), SessionGenerationCheckpointFixture.ReplacementTerminalSentinels());
                }
            });
        var failure = await Record.ExceptionAsync(() => InvokePrivateAsync<bool>(engine, "WaitForGmResponse"));
        probe.Verify(failure);
    }

    [Fact]
    public async Task WaitForGmResponse_GenerationChangesAfterTerminalSnapshot_DoesNotReadReplacementSignal()
    {
        const string sessionId = "session-terminal-snapshot-race";
        const string requestId = "request-terminal-snapshot-race";
        const int turnNumber = 9;
        const string trackedPath = "game_state/world/weather.json";

        await _fs.WriteFileAtomicAsync(trackedPath, "{\"description\":\"old\"}");
        await _fs.WriteFileAtomicAsync(
            $"game_state/control/pending_turn_snapshot/{trackedPath}",
            "{\"description\":\"old\"}");
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            sessionId,
            requestId,
            turnNumber,
            status = "success",
            timestamp = "2026-10-09T00:00:00Z",
            filesModified = new[] { trackedPath }
        });

        using var owned = new CleanupOwnedFixture(_rootPath, line => _directGachaOutput?.WriteLine(line));
        var probe = await SessionGenerationCheckpointFixture.CreateAsync(_rootPath, line => _directGachaOutput?.WriteLine(line));
        var engine = CreateGameEngine(
            probe.ObserveInput(new QueuedConsoleInputSource([])), configureSettings: InertRealmSettings,
            fileSystem: probe.Files,
            finalizationHooks: new GameEngineSessionFinalizationHooks
            {
                AtCheckpointAsync = async checkpoint =>
                {
                    if (checkpoint == SessionFinalizationCheckpoint.TerminalSignalSnapshotCapturedBeforeResolution)
                        await probe.RotateAsync(checkpoint.ToString(), SessionGenerationCheckpointFixture.ReplacementTerminalSentinels());
                }
            });
        var failure = await Record.ExceptionAsync(() => InvokePrivateAsync<bool>(engine, "WaitForGmResponse"));
        probe.Verify(failure);
    }

    [Fact]
    public async Task LateTerminalAndIdleFlow_SessionReplacementAfterBinding_DoesNotTouchReplacement()
    {
        using var owned = new CleanupOwnedFixture(_rootPath, line => _directGachaOutput?.WriteLine(line));
        var probe = await SessionGenerationCheckpointFixture.CreateAsync(_rootPath, line => _directGachaOutput?.WriteLine(line));
        const string replacementPath = "game_state/world/late-idle-replacement.json";
        var engine = CreateGameEngine(
            probe.ObserveInput(new QueuedConsoleInputSource([])), configureSettings: InertRealmSettings,
            fileSystem: probe.Files,
            finalizationHooks: new GameEngineSessionFinalizationHooks
            {
                AtCheckpointAsync = async checkpoint =>
                {
                    if (checkpoint == SessionFinalizationCheckpoint.LateTerminalAndIdleOperationBound)
                        await probe.RotateAsync(checkpoint.ToString(), new Dictionary<string, byte[]>
                        {
                            [replacementPath] = Encoding.UTF8.GetBytes("""{"owner":"replacement"}""")
                        }, ["game_state/control/pending_turn_snapshot.json"]);
                }
            });
        var failure = await Record.ExceptionAsync(() => InvokePrivateAsync<bool>(
            engine, "ProcessLateTerminalAndIdleTransitionsForCurrentSessionAsync"));
        probe.Verify(failure);
    }

    [Fact]
    public async Task HandleIncarnation_SessionReplacementAfterBinding_DoesNotReadOrMutateReplacement()
    {
        using var owned = new CleanupOwnedFixture(_rootPath, line => _directGachaOutput?.WriteLine(line));
        const string soulPath = "game_state/meta/soul_state.json";
        await _fs.WriteFileAtomicAsync(soulPath,
            """{ "soulName": "Старая душа", "currentRealm": "Chaos Sea" }""");
        var originalGeneration = await GetOrCreateSessionGenerationAsync();
        var rotated = false;
        var checkpoints = 0;
        var committedRotations = 0;
        var laterReads = new List<string>();
        var laterMutations = new List<string>();
        byte[]? rotationJournal = null;
        byte[]? committedGenerationImage = null;
        string? replacementGeneration = null;
        Dictionary<string, byte[]>? sentinels = null;
        var journalPath = Path.Combine(_fs.RuntimeRootPath, "trusted-local-publication-v1", "active.json");
        var files = new FileSystemManager(_rootPath, NullLogger<FileSystemManager>.Instance,
            PhysicalLoadTransactionOperations.Instance, new FileSystemManagerHooks
            {
                AfterCanonicalReadInitialValidationAsync = path =>
                { if (rotated) laterReads.Add(path); return Task.CompletedTask; },
                BeforeCanonicalMutationBoundaryAsync = path =>
                { if (rotated) laterMutations.Add(path); return Task.CompletedTask; },
                LocalPublicationObserver = (phase, _) =>
                {
                    if (phase != TrustedLocalPublicationPhase.Committed) return;
                    var bytes = File.ReadAllBytes(journalPath);
                    using var metadata = CleanupPublicationCut.Metadata(bytes);
                    var before = metadata.RootElement.GetProperty("GenerationBefore").GetProperty("Id").GetString();
                    var after = metadata.RootElement.GetProperty("GenerationAfter").GetProperty("Id").GetString();
                    if (before == after) return;
                    Assert.Equal(originalGeneration, before);
                    Assert.False(string.IsNullOrWhiteSpace(after));
                    committedRotations++;
                    rotationJournal = bytes;
                    committedGenerationImage = File.ReadAllBytes(_fs.SessionGenerationPath);
                }
            });
        var input = new LoreRealmInput([], 0);
        var engine = CreateGameEngine(input, fileSystem: files,
            finalizationHooks: new GameEngineSessionFinalizationHooks
            {
                AtCheckpointAsync = async checkpoint =>
                {
                    if (checkpoint != SessionFinalizationCheckpoint.IncarnationOperationBound) return;
                    checkpoints++;
                    // Original local admission is borrowed; no concurrent Clear or new binding is invented.
                    await using var lifecycle = await files.AcquireSessionLifecycleLeaseAsync();
                    await using var lease = await files.AcquireSessionReplacementWriteLeaseAsync(lifecycle);
                    await files.WriteFileAtomicAsync(lease, soulPath,
                        """{ "soulName": "Новая душа", "currentRealm": "Chaos Sea" }""");
                    await files.WriteFileAtomicAsync(lease, WorldDirectiveService.PendingSetupPath,
                        """{ "worldDescription": "replacement sentinel" }""");
                    sentinels = new[] { soulPath, WorldDirectiveService.PendingSetupPath }
                        .ToDictionary(path => path, path => File.ReadAllBytes(files.ResolvePath(path)));
                    replacementGeneration = files.RotateSessionGeneration(lease);
                    rotated = true;
                }
            });
        // Directly await the original operation: no blocked background actor or timeout proxy survives cleanup.
        var failure = await Record.ExceptionAsync(() => InvokePrivateTaskAsync(engine, "HandleIncarnation"));
        var afterSentinels = new[] { soulPath, WorldDirectiveService.PendingSetupPath }
            .ToDictionary(path => path, path => CleanupPublicationCut.ReadOptional(files.ResolvePath(path)));
        var generationAfter = File.ReadAllBytes(files.SessionGenerationPath);
        _directGachaOutput?.WriteLine(JsonSerializer.Serialize(new { originalGeneration, replacementGeneration,
            checkpoints, committedRotations, rotationJournal, committedGenerationImage, generationAfter,
            sentinels, afterSentinels, laterReads, laterMutations, input.KeyReads, input.LineReads,
            OriginalTaskJoined = true, Failure = failure?.ToString() }));
        Assert.Equal(1, checkpoints); Assert.Equal(1, committedRotations); Assert.NotNull(rotationJournal);
        Assert.True(rotated); Assert.NotEqual(originalGeneration, replacementGeneration);
        Assert.Equal(committedGenerationImage, generationAfter);
        var replaced = Assert.IsType<SessionReplacedException>(failure);
        Assert.Equal(originalGeneration, replaced.ExpectedGeneration);
        Assert.Equal(replacementGeneration, replaced.ActualGeneration);
        Assert.Empty(laterReads); Assert.Empty(laterMutations); input.AssertCompleted();
        foreach (var path in sentinels!.Keys) Assert.Equal(sentinels[path], afterSentinels[path]);
    }

    [Fact]
    [Trait("Category", "PreMergeSentinel")]
    public async Task RebindRuntimeAfterSessionReplacement_ActiveReplacementRebindsLoopAndClearsTransientState()
    {
        await _fs.ClearGameStateAsync();
        await _fs.WriteFileAtomicAsync(
            "game_state/meta/soul_state.json",
            """{ "soulName": "Новая душа", "currentRealm": "Chaos Sea", "currentIncarnation": 2 }""");
        await _fs.WriteFileAtomicAsync(
            "game_state/history/chat_log.json",
            """{ "sessionId": "replacement-session", "messages": [] }""");
        await _fs.WriteFileAtomicAsync(
            "stories/replacement.json",
            """{ "turn": 7, "response": "replacement" }""");

        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var gameLoop = GetPrivateField<GameLoop>(engine, "_gameLoop");
        var explorer = GetPrivateField<ExplorerMode>(engine, "_explorer");
        gameLoop.SetSession("old-session", 42);
        SetPrivateField(engine, "_lastResponse", new GameResponse { Response = "old response" });
        SetPrivateField(engine, "_pendingImagePrompt", "old image prompt");
        SetPrivateField(engine, "_pendingMemoryLegacyAwaitingConsumption", true);
        SetPrivateField(engine, "_mainMenuSessionWarning", "old warning");
        SetPrivateField(engine, "_lastConsoleWidth", 180);
        SetPrivateField(engine, "_lastKnownLevel", 9);
        SetPrivateField(engine, "_inGame", true);
        SetPrivateField(explorer, "_pendingGmAction", "old pending action");
        SetPrivateField(explorer, "_currentCommandInput", "/old");
        SetPrivateField(explorer, "_currentCommandRemainder", "old");
        SetPrivateField(explorer, "_diceRevealed", true);

        await InvokePrivateTaskAsync(engine, "RebindRuntimeAfterSessionReplacementAsync");

        Assert.Equal("replacement-session", gameLoop.SessionId);
        Assert.Equal(7, gameLoop.TurnNumber);
        Assert.True(GetPrivateFieldValue<bool>(engine, "_inGame"));
        Assert.Null(GetPrivateFieldValue<GameResponse?>(engine, "_lastResponse"));
        Assert.Null(GetPrivateFieldValue<string?>(engine, "_pendingImagePrompt"));
        Assert.False(GetPrivateFieldValue<bool>(engine, "_pendingMemoryLegacyAwaitingConsumption"));
        Assert.Null(GetPrivateFieldValue<string?>(engine, "_mainMenuSessionWarning"));
        Assert.Equal(0, GetPrivateFieldValue<int>(engine, "_lastConsoleWidth"));
        Assert.Equal(1, GetPrivateFieldValue<int>(engine, "_lastKnownLevel"));
        Assert.Null(GetPrivateFieldValue<string?>(explorer, "_pendingGmAction"));
        Assert.Equal(string.Empty, GetPrivateFieldValue<string>(explorer, "_currentCommandInput"));
        Assert.Equal(string.Empty, GetPrivateFieldValue<string>(explorer, "_currentCommandRemainder"));
        Assert.False(GetPrivateFieldValue<bool>(explorer, "_diceRevealed"));
    }

    [Fact]
    public async Task RebindRuntimeAfterSessionReplacement_EmptyReplacementReturnsToMenu()
    {
        await _fs.ClearGameStateAsync();
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var gameLoop = GetPrivateField<GameLoop>(engine, "_gameLoop");
        gameLoop.SetSession("old-session", 42);
        SetPrivateField(engine, "_inGame", true);

        await InvokePrivateTaskAsync(engine, "RebindRuntimeAfterSessionReplacementAsync");

        Assert.Equal(string.Empty, gameLoop.SessionId);
        Assert.Equal(0, gameLoop.TurnNumber);
        Assert.False(GetPrivateFieldValue<bool>(engine, "_inGame"));
    }

    [Fact]
    public async Task LoadSelectedSaveAndRebindRuntime_UsesLoadedCanonicalStateInsteadOfSaveListMetadata()
    {
        var loadedSoul = CreateLifecycleSoulState("Загруженная душа", "Chaos Sea");
        var loadedProfiles = CreatePlayerSoulProfiles("Загруженная душа", "Chaos Sea");
        var guardians = CreateEmptyGuardiansState();
        await CanonicalResourceQuartetTestFixture.CommitFreshBootstrapAsync(
            _fs,
            new AfterlifeOwnerResourceAcceptedState(
                Profiles: loadedProfiles,
                SpiritualConflict: AfterlifeSpiritualConflictState.CreateDefaultRoot(),
                SoulState: loadedSoul,
                ShiningAbode: ShiningAbodeState.CreateDefaultState(),
                Guardians: guardians));
        await WriteJsonAsync(
            "game_state/history/chat_log.json",
            new { sessionId = "loaded-session", messages = Array.Empty<object>() });
        await WriteJsonAsync(
            "stories/loaded-turn.json",
            new { turn = 7, response = "loaded" });
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var stateManager = GetPrivateField<StateManager>(engine, "_stateManager");
        await stateManager.RefreshGameStateAsync();
        var saveLoad = GetPrivateField<SaveLoadService>(engine, "_saveLoad");
        Assert.True(await saveLoad.SaveGameAsync(
            "runtime-rebind",
            "canonical runtime rebind regression",
            turnNumber: 7));
        var savePath = Assert.Single(
            Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip"));

        var oldSoul = CreateLifecycleSoulState("Старая душа", "Chaos Sea");
        var oldProfiles = JsonNode.Parse((await _fs.ReadFileAsync(
            AfterlifeEntityProfileState.StatePath))!)!.AsObject();
        Assert.Single(Assert.IsType<JsonArray>(
                oldProfiles[AfterlifeEntityProfileState.ProfilesProperty]))!
            ["displayName"] = "Старая душа";
        var livePlan = await AfterlifeOwnerResourceStateService.BuildAsync(
            _fs,
            new AfterlifeOwnerResourceAcceptedState(
                Profiles: oldProfiles,
                SoulState: oldSoul),
            turn: 8);
        Assert.True(livePlan.IsValid, string.Join(Environment.NewLine, livePlan.Issues));
        Assert.True(await AfterlifeOwnerResourceStateService.TryCommitAsync(_fs, livePlan));

        var gameLoop = GetPrivateField<GameLoop>(engine, "_gameLoop");
        gameLoop.SetSession("save-list-metadata-session", 99);
        var method = typeof(GameEngine).GetMethod(
            "LoadSelectedSaveAndRebindRuntimeAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);

        var loaded = Assert.IsType<LoadReplacementResult>(
            await InvokeConsoleLoadResultAsync(engine, savePath));

        Assert.Equal(LoadReplacementDisposition.Committed, loaded.Disposition);
        Assert.False(loaded.ContinuationBlocked);
        Assert.Equal("loaded-session", gameLoop.SessionId);
        Assert.Equal(7, gameLoop.TurnNumber);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_WithoutWorkerProfiles_PreservesSingleGmRepairFlow()
    {
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var issue = new ValidationIssue(
            "game_state/world/weather.json",
            IssueSeverity.Error,
            "normalizedWeatherState.description is required.",
            code: "normalized_weather_missing_description");

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "state validation", new List<ValidationIssue> { issue }, 1 })!);

        await task;

        Assert.True(_fs.FileExists("game_state/control/validation_repair_request.json"));
        Assert.False(_fs.FileExists("game_state/control/gm_worker_latest_validation_repair_task.json"));
        Assert.False(_fs.FileExists(GmWorkerAuditLog.AuditLogPath));
        Assert.False(Directory.Exists(_fs.ResolvePath(GmWorkerBridgePool.TaskRoot)));
        Assert.False(Directory.Exists(_fs.ResolvePath(GmWorkerBridgePool.ProposalInboxRoot)));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_WithAgentConsole_PublishesPlayerSafeWaitingSnapshot()
    {
        const string sessionId = "session-repair-console";
        const string requestId = "request-repair-console";
        const int turnNumber = 12;
        const string trackedPath = "game_state/world/current_location.json";

        await WriteJsonAsync(trackedPath, new
        {
            locationId = "loc_gate"
        });
        await WriteJsonAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", new
        {
            locationId = "loc_gate"
        });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });

        var store = new AgentConsoleStateStore();
        using var input = new AgentConsoleLiveInputSource(store, readTimeout: TimeSpan.FromSeconds(5));
        var engine = CreateGameEngine(input);
        var issue = new ValidationIssue(
            "game_state/world/current_location.json.locationId",
            IssueSeverity.Error,
            "Current location references an unknown location id.",
            code: "current_location_unknown_location_id",
            category: IssueCategory.StateConsistency,
            expected: "known location id",
            actual: "loc_gate");

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", new List<ValidationIssue> { issue }, 2 })!);

        await task;

        var snapshot = store.GetSnapshot();
        Assert.NotNull(snapshot);
        Assert.Equal("world-turn-paused", snapshot!.ScreenId);
        Assert.Equal(AgentConsoleMode.Loading, snapshot.Mode);
        Assert.False(snapshot.AwaitingInput);
        Assert.Equal("Течение мира приостановлено", snapshot.Title);
        AssertPlayerAgentConsoleSnapshotIsPrivate(
            snapshot,
            store.GetEvents(),
            "current_location_unknown_location_id",
            "game_state/world/current_location.json.locationId",
            requestId,
            "known location id",
            "loc_gate");
    }

    [Fact]
    public async Task NormalizePendingRepairArtifactsAsync_ValidationRepairArtifactStall_WritesTerminalError()
    {
        const string sessionId = "session-repair-stall";
        const string requestId = "request-repair-stall";
        const int turnNumber = 5;
        const string trackedPath = "game_state/world/current_location.json";

        await WriteJsonAsync(trackedPath, new { locationId = "loc_stable" });
        await WriteJsonAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", new { locationId = "loc_stable" });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            sessionId,
            requestId,
            turnNumber,
            status = "success",
            timestamp = "2026-07-05T02:00:00Z"
        });
        await WriteJsonAsync("game_state/control/validation_repair_request.json", new
        {
            sessionId,
            requestId,
            turnNumber,
            revalidationAttempt = 2
        });
        await WriteJsonAsync("game_state/control/gm_validation_repair_artifact_stall_report.json", new
        {
            isStalled = true,
            elapsedSeconds = 180,
            bridgeCleanup = new
            {
                reason = "gm_validation_repair_artifact_stall",
                status = "fallback-stopped",
                ok = true
            }
        });
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));

        await InvokePrivateTaskAsync(engine, "NormalizePendingRepairArtifactsAsync");

        Assert.True(_fs.FileExists("ready/turn_error.json"));
        var errorJson = await _fs.ReadFileAsync("ready/turn_error.json");
        Assert.NotNull(errorJson);
        using var errorDoc = JsonDocument.Parse(errorJson!);
        var root = errorDoc.RootElement;
        Assert.Equal(sessionId, root.GetProperty("sessionId").GetString());
        Assert.Equal(requestId, root.GetProperty("requestId").GetString());
        Assert.Equal(turnNumber, root.GetProperty("turnNumber").GetInt32());
        Assert.Equal("error", root.GetProperty("status").GetString());
        Assert.Equal("gm_validation_repair_artifact_stall", root.GetProperty("harnessSource").GetString());
        Assert.Contains("validation repair", root.GetProperty("error").GetString(), StringComparison.OrdinalIgnoreCase);
        Assert.False(_fs.FileExists("ready/turn_complete.json"));
    }

    [Fact]
    public async Task NormalizePendingRepairArtifactsAsync_ValidationRepairArtifactStallWithoutTurnComplete_WritesTerminalError()
    {
        const string sessionId = "session-repair-stall-no-complete";
        const string requestId = "request-repair-stall-no-complete";
        const int turnNumber = 15;
        const string trackedPath = "game_state/world/current_location.json";

        await WriteJsonAsync(trackedPath, new { locationId = "loc_stable" });
        await WriteJsonAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", new { locationId = "loc_stable" });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });
        await WriteJsonAsync("game_state/control/validation_repair_request.json", new
        {
            sessionId,
            requestId,
            turnNumber,
            revalidationAttempt = 3
        });
        await WriteJsonAsync("game_state/control/gm_validation_repair_artifact_stall_report.json", new
        {
            isStalled = true,
            elapsedSeconds = 180,
            bridgeCleanup = new
            {
                reason = "gm_validation_repair_artifact_stall",
                status = "graceful-stopped",
                ok = true
            }
        });
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));

        await InvokePrivateTaskAsync(engine, "NormalizePendingRepairArtifactsAsync");

        Assert.True(_fs.FileExists("ready/turn_error.json"));
        var errorJson = await _fs.ReadFileAsync("ready/turn_error.json");
        Assert.NotNull(errorJson);
        using var errorDoc = JsonDocument.Parse(errorJson!);
        var root = errorDoc.RootElement;
        Assert.Equal(sessionId, root.GetProperty("sessionId").GetString());
        Assert.Equal(requestId, root.GetProperty("requestId").GetString());
        Assert.Equal(turnNumber, root.GetProperty("turnNumber").GetInt32());
        Assert.Equal("gm_validation_repair_artifact_stall", root.GetProperty("harnessSource").GetString());
        Assert.False(_fs.FileExists("ready/turn_complete.json"));
    }

    [Fact]
    public async Task WaitForContractRepairAsync_ValidationRepairArtifactStall_ExitsWithTerminalError()
    {
        const string sessionId = "session-active-repair-stall";
        const string requestId = "request-active-repair-stall";
        const int turnNumber = 6;
        const string trackedPath = "game_state/meta/guardians.json";

        await WriteJsonAsync(trackedPath, new { guardians = Array.Empty<object>() });
        await WriteJsonAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", new { guardians = Array.Empty<object>() });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            sessionId,
            requestId,
            turnNumber,
            status = "success",
            timestamp = "2026-07-05T03:00:00Z"
        });

        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardians.json.guardians",
                IssueSeverity.Error,
                "Current guardians[] must match kernel authority.",
                code: "guardian_materialized_state_outside_authority",
                section: "Guardians")
        };
        var repairSessionGeneration = await GetOrCreateSessionGenerationAsync();

        var repairTask = InvokePrivateAsync<bool>(
            engine,
            "WaitForContractRepairAsync",
            "active validation repair stall test",
            issues,
            1,
            null,
            repairSessionGeneration);

        var deadline = DateTime.UtcNow.AddSeconds(5);
        while (!_fs.FileExists("game_state/control/validation_repair_request.json") && DateTime.UtcNow < deadline)
            await Task.Delay(100);

        Assert.True(_fs.FileExists("game_state/control/validation_repair_request.json"));
        await WriteJsonAsync("game_state/control/gm_validation_repair_artifact_stall_report.json", new
        {
            isStalled = true,
            elapsedSeconds = 180,
            bridgeCleanup = new
            {
                reason = "gm_validation_repair_artifact_stall",
                status = "fallback-stopped",
                ok = true
            }
        });

        var accepted = await repairTask.WaitAsync(TimeSpan.FromSeconds(5));

        Assert.False(accepted);
        Assert.True(_fs.FileExists("ready/turn_error.json"));
        var errorJson = await _fs.ReadFileAsync("ready/turn_error.json");
        Assert.NotNull(errorJson);
        using var errorDoc = JsonDocument.Parse(errorJson!);
        var root = errorDoc.RootElement;
        Assert.Equal(sessionId, root.GetProperty("sessionId").GetString());
        Assert.Equal(requestId, root.GetProperty("requestId").GetString());
        Assert.Equal(turnNumber, root.GetProperty("turnNumber").GetInt32());
        Assert.Equal("gm_validation_repair_artifact_stall", root.GetProperty("harnessSource").GetString());
        Assert.False(_fs.FileExists("ready/turn_complete.json"));
    }

    [Fact]
    public async Task WaitForContractRepairAsync_ValidationRepairArtifactStallWithoutTurnComplete_ExitsWithTerminalError()
    {
        const string sessionId = "session-active-repair-stall-no-complete";
        const string requestId = "request-active-repair-stall-no-complete";
        const int turnNumber = 16;
        const string trackedPath = "game_state/meta/guardians.json";

        await WriteJsonAsync(trackedPath, new { guardians = Array.Empty<object>() });
        await WriteJsonAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", new { guardians = Array.Empty<object>() });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });

        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardians.json.guardians",
                IssueSeverity.Error,
                "Current guardians[] must match kernel authority.",
                code: "guardian_materialized_state_outside_authority",
                section: "Guardians")
        };
        var repairSessionGeneration = await GetOrCreateSessionGenerationAsync();

        var repairTask = InvokePrivateAsync<bool>(
            engine,
            "WaitForContractRepairAsync",
            "active validation repair stall test without turn_complete",
            issues,
            1,
            null,
            repairSessionGeneration);

        var deadline = DateTime.UtcNow.AddSeconds(5);
        while (!_fs.FileExists("game_state/control/validation_repair_request.json") && DateTime.UtcNow < deadline)
            await Task.Delay(100);

        Assert.True(_fs.FileExists("game_state/control/validation_repair_request.json"));
        await WriteJsonAsync("game_state/control/gm_validation_repair_artifact_stall_report.json", new
        {
            isStalled = true,
            elapsedSeconds = 180,
            bridgeCleanup = new
            {
                reason = "gm_validation_repair_artifact_stall",
                status = "graceful-stopped",
                ok = true
            }
        });

        var accepted = await repairTask.WaitAsync(TimeSpan.FromSeconds(5));

        Assert.False(accepted);
        Assert.True(_fs.FileExists("ready/turn_error.json"));
        var errorJson = await _fs.ReadFileAsync("ready/turn_error.json");
        Assert.NotNull(errorJson);
        using var errorDoc = JsonDocument.Parse(errorJson!);
        var root = errorDoc.RootElement;
        Assert.Equal(sessionId, root.GetProperty("sessionId").GetString());
        Assert.Equal(requestId, root.GetProperty("requestId").GetString());
        Assert.Equal(turnNumber, root.GetProperty("turnNumber").GetInt32());
        Assert.Equal("gm_validation_repair_artifact_stall", root.GetProperty("harnessSource").GetString());
        Assert.False(_fs.FileExists("ready/turn_complete.json"));
    }

    [Fact]
    public async Task TryPromoteValidationRepairArtifactStallToTerminalErrorAsync_StaleSession_DoesNotReplaceReadySignal()
    {
        const string sessionId = "session-stale-stall";
        const string requestId = "request-stale-stall";
        const int turnNumber = 4;
        const string trackedPath = "game_state/meta/soul_state.json";
        await WriteJsonAsync(trackedPath, new { currentRealm = "Mortal World" });
        await WriteJsonAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", new { currentRealm = "Mortal World" });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("game_state/control/validation_repair_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });
        await WriteJsonAsync("game_state/control/gm_validation_repair_artifact_stall_report.json", new
        {
            isStalled = true
        });

        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var pendingResolution = await InvokePrivateTaskResultAsync(
            engine,
            "ResolveActivePendingTurnSnapshotContextAsync");
        var context = pendingResolution.GetType().GetProperty("Context")!.GetValue(pendingResolution);
        Assert.NotNull(context);
        var staleGeneration = await GetOrCreateSessionGenerationAsync();
        await SessionReplacementTestHarness.RotateGenerationAsync(_fs);
        const string replacementSignal = "{\"status\":\"replacement-session\"}";
        await _fs.WriteFileAtomicAsync("ready/turn_error.json", replacementSignal);

        await Assert.ThrowsAsync<GmWorkerSessionReplacedException>(() =>
            InvokePrivateAsync<bool>(
                engine,
                "TryPromoteValidationRepairArtifactStallToTerminalErrorAsync",
                context,
                staleGeneration));

        Assert.Equal(replacementSignal, await _fs.ReadFileAsync("ready/turn_error.json"));
    }

    [Fact]
    public async Task WaitForContractRepairAsync_AcceptedRepairReady_WritesAcceptedTrajectoryRecord()
    {
        const string sessionId = "session-repair-ledger";
        const string requestId = "request-repair-ledger";
        const int turnNumber = 7;
        const string trackedPath = "game_state/meta/soul_state.json";

        await WriteJsonAsync(trackedPath, new
        {
            currentRealm = "Mortal World",
            currentIncarnation = 2
        });
        await WriteJsonAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", new
        {
            currentRealm = "Mortal World",
            currentIncarnation = 2
        });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(
            engine,
            "CreatePreTurnBackup",
            "repair_ledger");
        var issue = new ValidationIssue(
            "game_state/world/current_location.json.currentLocationData.description",
            IssueSeverity.Error,
            "Current location creation is missing its description.",
            code: "mortal_location_materialization_governed_field_missing",
            actor: "mortal_location:new:locref_repair_ledger",
            section: "MortalLocationMaterialization",
            expected: "complete description",
            actual: "missing",
            repairTargetFiles: new[] { MortalLocationMaterializationContract.CurrentLocationPath });
        issue.MortalLocationRepairContext = new MortalLocationRepairContext(
            "currentLocationData",
            "mortal_location",
            "locref_repair_ledger",
            "mlocmat_repair_ledger",
            new[] { "description" });
        var repairSessionGeneration = await GetOrCreateSessionGenerationAsync();

        var gmRepair = Task.Run(async () =>
        {
            await WaitForValidationRepairRequestContainingAsync(
                "mortal_location_materialization_governed_field_missing",
                TimeSpan.FromSeconds(5));
            await WriteJsonAsync("game_state/control/validation_repair_ready.json", new
            {
                sessionId,
                requestId,
                turnNumber,
                updatedAtUtc = "2026-06-27T00:00:00Z",
                note = "Repair accepted by test."
            });
        });

        var accepted = await InvokePrivateAsync<bool>(
            engine,
            "WaitForContractRepairAsync",
            "обработки хода",
            new List<ValidationIssue> { issue },
            2,
            rollbackSnapshot,
            repairSessionGeneration);

        await gmRepair;

        Assert.True(accepted);
        Assert.False(_fs.FileExists("game_state/control/validation_repair_ready.json"));

        var ledgerJson = await _fs.ReadFileAsync("game_state/control/gm_trajectory_ledger.jsonl");
        Assert.False(string.IsNullOrWhiteSpace(ledgerJson));
        using var document = JsonDocument.Parse(ledgerJson!.Trim());
        var record = document.RootElement;
        Assert.Equal("repair", record.GetProperty("kind").GetString());
        Assert.Equal(sessionId, record.GetProperty("sessionId").GetString());
        Assert.Equal(requestId, record.GetProperty("requestId").GetString());
        Assert.Equal(turnNumber, record.GetProperty("turnNumber").GetInt32());
        Assert.Equal("validation_repair", record.GetProperty("mode").GetString());
        var validation = record.GetProperty("validation");
        Assert.Equal("accepted", validation.GetProperty("status").GetString());
        Assert.Equal("обработки хода", validation.GetProperty("source").GetString());
        Assert.Equal("correlated_repair_ready", validation.GetProperty("acceptanceScope").GetString());
        Assert.False(validation.GetProperty("fullCanonicalStateAccepted").GetBoolean());
        Assert.Contains(
            "mortal_location_materialization_governed_field_missing",
            validation.GetProperty("issueKinds")
                .EnumerateArray()
                .Select(item => item.GetString()));
        Assert.Contains(
            "mortal_location_materialization_repair",
            validation.GetProperty("repairPacketRefs")
                .EnumerateArray()
                .Select(item => item.GetString()));
        Assert.Equal(2, record.GetProperty("repair").GetProperty("attempts").GetInt32());
        Assert.Equal("accepted", record.GetProperty("repair").GetProperty("status").GetString());
        Assert.Equal("validation_repair_ready", record.GetProperty("terminal").GetProperty("kind").GetString());
        Assert.Equal(
            "game_state/control/validation_repair_ready.json",
            record.GetProperty("terminal").GetProperty("signalPath").GetString());
        Assert.True(record.GetProperty("rubric").GetProperty("validTurn").GetBoolean());
    }

    [Fact]
    public async Task AppendClearedValidationRepairTrajectoryAsync_StaleSession_AbortsRepairCycle()
    {
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var staleGeneration = await GetOrCreateSessionGenerationAsync();
        await SessionReplacementTestHarness.RotateGenerationAsync(_fs);

        var exception = await Assert.ThrowsAsync<GmWorkerSessionReplacedException>(() =>
            InvokePrivateTaskAsync(
                engine,
                "AppendClearedValidationRepairTrajectoryAsync",
                "state validation",
                Array.Empty<ValidationIssue>(),
                1,
                staleGeneration));

        Assert.Contains("session", exception.Message, StringComparison.OrdinalIgnoreCase);
        Assert.False(_fs.FileExists("game_state/control/gm_trajectory_ledger.jsonl"));
    }

    [Fact]
    public async Task RemoveGuardianQuestProgressUpdatesCommandSurfaceAsync_StaleSession_DoesNotRewriteReplacementState()
    {
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var staleGeneration = await GetOrCreateSessionGenerationAsync();
        await SessionReplacementTestHarness.RotateGenerationAsync(_fs);
        const string replacement = "{\"guardians\":[],\"questProgressUpdates\":[{\"questId\":\"new-session\"}]}";
        await _fs.WriteFileAtomicAsync("game_state/meta/guardians.json", replacement);

        await Assert.ThrowsAsync<GmWorkerSessionReplacedException>(() =>
            InvokePrivateTaskAsync(
                engine,
                "RemoveGuardianQuestProgressUpdatesCommandSurfaceAsync",
                staleGeneration));

        Assert.Equal(replacement, await _fs.ReadFileAsync("game_state/meta/guardians.json"));
    }

    [Fact]
    public async Task ReportRejectedRepairReadyAsync_ReturnsExclusiveDispatchStateToCaller()
    {
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var sessionGeneration = await GetOrCreateSessionGenerationAsync();
        var issue = new ValidationIssue(
            "game_state/control/validation_repair_ready.json",
            IssueSeverity.Error,
            "Synthetic rejected ready signal.",
            code: "invalid_repair_ready_json");
        var method = typeof(GameEngine).GetMethod(
            "ReportRejectedRepairReadyAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);

        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[]
            {
                "state validation",
                new List<ValidationIssue> { issue },
                1,
                "invalid_repair_ready_json",
                "Malformed ready signal.",
                "Valid correlated ready signal",
                "Malformed JSON",
                "Publish a fresh correlated ready signal.",
                sessionGeneration
            })!);

        await task;

        var result = task.GetType().GetProperty("Result")?.GetValue(task);
        Assert.NotNull(result);
        var dispatch = result!.GetType().GetField("Item1")?.GetValue(result);
        Assert.NotNull(dispatch);
        Assert.NotNull(dispatch!.GetType().GetProperty("WorkerApplyAccepted"));
        Assert.NotNull(dispatch.GetType().GetProperty("ReadySignalCreated"));
    }

    [Fact]
    public async Task WaitForContractRepairAsync_RejectedRepairReadyWithLostSnapshot_FailsClosedInsteadOfWaitingForever()
    {
        const string sessionId = "session-repair-lost-snapshot";
        const string requestId = "request-repair-lost-snapshot";
        const int turnNumber = 11;
        const string trackedPath = "game_state/meta/soul_state.json";

        await WriteJsonAsync(trackedPath, new
        {
            currentRealm = "Mortal World",
            currentIncarnation = 2
        });
        await WriteJsonAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", new
        {
            currentRealm = "Mortal World",
            currentIncarnation = 2
        });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, trackedPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });

        var gmRepair = Task.Run(async () =>
        {
            var deadline = DateTime.UtcNow.AddSeconds(5);
            while (!_fs.FileExists("game_state/control/validation_repair_request.json") &&
                   DateTime.UtcNow < deadline)
            {
                await Task.Delay(50);
            }

            Assert.True(_fs.FileExists("game_state/control/validation_repair_request.json"));
            await _fs.WriteFileAtomicAsync("game_state/control/pending_turn_snapshot.authority.json", "{}");
            await WriteJsonAsync("game_state/control/validation_repair_ready.json", new
            {
                sessionId,
                requestId,
                turnNumber,
                updatedAtUtc = "2026-06-27T00:00:00Z",
                note = "Repair ready becomes unusable because snapshot authority was lost."
            });
        });

        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var issue = new ValidationIssue(
            "game_state/world/current_location.json.locationId",
            IssueSeverity.Error,
            "Current location references an unknown location id.",
            code: "current_location_unknown_location_id");
        var repairSessionGeneration = await GetOrCreateSessionGenerationAsync();

        var repairTask = InvokePrivateAsync<bool>(
            engine,
            "WaitForContractRepairAsync",
            "обработки хода",
            new List<ValidationIssue> { issue },
            2,
            null,
            repairSessionGeneration);

        var completed = await Task.WhenAny(repairTask, Task.Delay(TimeSpan.FromSeconds(8)));

        await gmRepair;
        Assert.Same(repairTask, completed);
        Assert.False(await repairTask);
        Assert.False(_fs.FileExists("game_state/control/validation_repair_request.json"));
        Assert.False(_fs.FileExists("game_state/control/validation_repair_ready.json"));
        Assert.True(_fs.FileExists("game_state/control/validation_diagnostic_failure_report.json"));

        var reportJson = await _fs.ReadFileAsync("game_state/control/validation_diagnostic_failure_report.json");
        Assert.Contains("Diagnostic-only validation repair request cannot be completed by GM", reportJson);
        Assert.Contains("mismatched_repair_ready_context", reportJson);
    }

    [Fact]
    public async Task ValidateCurrentGameStateOrShowErrorsAsync_AfterRepairClearsValidation_WritesTerminalAcceptedTrajectoryRecord()
    {
        const string sessionId = "session-repair-cleared-ledger";
        const string requestId = "request-repair-cleared-ledger";
        const int turnNumber = 8;
        const string trackedPath = "game_state/meta/soul_state.json";

        await CanonicalResourceQuartetTestFixture.CommitFreshBootstrapAsync(
            _fs,
            new AfterlifeOwnerResourceAcceptedState(
                Profiles: AfterlifeEntityProfileState.CreateDefaultRoot()));
        await WriteJsonAsync(trackedPath, new
        {
            soulName = "Тихая Искра",
            currentRealm = "Chaos Sea",
            currentIncarnation = 0,
            soulFormDescription = new { invalid = true }
        });
        await WriteJsonAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", new
        {
            soulName = "Тихая Искра",
            currentRealm = "Chaos Sea",
            currentIncarnation = 0,
            soulFormDescription = new { invalid = true }
        });
        var profilesJson = await _fs.ReadFileAsync(AfterlifeEntityProfileState.StatePath);
        Assert.False(string.IsNullOrWhiteSpace(profilesJson));
        await _fs.WriteFileAtomicAsync(
            $"game_state/control/pending_turn_snapshot/{AfterlifeEntityProfileState.StatePath}",
            profilesJson!);
        await WritePendingTurnSnapshotManifestAsync(
            sessionId,
            requestId,
            turnNumber,
            trackedPath,
            AfterlifeEntityProfileState.StatePath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });

        var gmRepair = Task.Run(async () =>
        {
            var deadline = DateTime.UtcNow.AddSeconds(5);
            while (!_fs.FileExists("game_state/control/validation_repair_request.json") &&
                   DateTime.UtcNow < deadline)
            {
                await Task.Delay(50);
            }

            if (!_fs.FileExists("game_state/control/validation_repair_request.json"))
            {
                var diagnosticValidator = new ValidationService(
                    _fs,
                    NullLogger<ValidationService>.Instance);
                var diagnosticIssues = await diagnosticValidator.ValidateGameStateAsync(
                    IntegrationValidationProfiles.SoulIdentity);
                Assert.Fail(string.Join(
                    " | ",
                    diagnosticIssues
                        .Where(issue => issue.Severity == IssueSeverity.Error)
                        .Select(issue => $"{issue.Code}:{issue.FilePath}:{issue.Actor}")));
            }
            var repairRequestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
            var repairRequestNode = JsonNode.Parse(repairRequestJson!)!.AsObject();
            repairRequestNode["harnessRepairPackets"] = new JsonArray
            {
                new JsonObject
                {
                    ["kind"] = "soul_form_shape_repair"
                }
            };
            await _fs.WriteFileAtomicAsync(
                "game_state/control/validation_repair_request.json",
                repairRequestNode.ToJsonString(SnapshotHashJsonOpts));

            await WriteJsonAsync(trackedPath, new
            {
                soulName = "Тихая Искра",
                currentRealm = "Chaos Sea",
                currentIncarnation = 0,
                soulFormDescription = "Женский силуэт из серебристого пепла."
            });
            await WriteJsonAsync("game_state/control/validation_repair_ready.json", new
            {
                sessionId,
                requestId,
                turnNumber,
                updatedAtUtc = "2026-06-27T00:00:00Z",
                note = "Repair cleared by test."
            });
        });

        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var accepted = await InvokePrivateAsync<bool>(
            engine,
            "ValidateCurrentGameStateOrShowErrorsAsync",
            "state validation",
            null,
            null,
            true);

        await gmRepair;

        Assert.True(accepted);
        Assert.False(_fs.FileExists("game_state/control/validation_repair_request.json"));
        Assert.False(_fs.FileExists("game_state/control/validation_repair_ready.json"));

        var ledgerJson = await _fs.ReadFileAsync("game_state/control/gm_trajectory_ledger.jsonl");
        Assert.False(string.IsNullOrWhiteSpace(ledgerJson));
        var records = ledgerJson!
            .Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries)
            .Select(line => JsonDocument.Parse(line))
            .ToList();

        Assert.Equal(2, records.Count);
        var repairReady = records[0].RootElement;
        Assert.Equal("correlated_repair_ready", repairReady.GetProperty("validation").GetProperty("acceptanceScope").GetString());
        Assert.False(repairReady.GetProperty("validation").GetProperty("fullCanonicalStateAccepted").GetBoolean());
        Assert.Contains(
            "soul_form_shape_repair",
            repairReady.GetProperty("validation").GetProperty("repairPacketRefs")
                .EnumerateArray()
                .Select(item => item.GetString()));

        var cleared = records[1].RootElement;
        Assert.Equal("repair", cleared.GetProperty("kind").GetString());
        Assert.Equal(sessionId, cleared.GetProperty("sessionId").GetString());
        Assert.Equal(requestId, cleared.GetProperty("requestId").GetString());
        Assert.Equal(turnNumber, cleared.GetProperty("turnNumber").GetInt32());
        Assert.Equal("validation_repair", cleared.GetProperty("mode").GetString());
        var validation = cleared.GetProperty("validation");
        Assert.Equal("accepted", validation.GetProperty("status").GetString());
        Assert.Equal("state validation", validation.GetProperty("source").GetString());
        Assert.Equal("full_canonical_state_after_repair", validation.GetProperty("acceptanceScope").GetString());
        Assert.True(validation.GetProperty("fullCanonicalStateAccepted").GetBoolean());
        Assert.Contains(
            "soul_form_description_invalid_shape",
            validation.GetProperty("issueKinds")
                .EnumerateArray()
                .Select(item => item.GetString()));
        Assert.Contains(
            "soul_form_shape_repair",
            validation.GetProperty("repairPacketRefs")
                .EnumerateArray()
                .Select(item => item.GetString()));
        Assert.Equal(1, cleared.GetProperty("repair").GetProperty("attempts").GetInt32());
        Assert.Equal("cleared", cleared.GetProperty("repair").GetProperty("status").GetString());
        Assert.Equal("validation_repair_cleared", cleared.GetProperty("terminal").GetProperty("kind").GetString());
        Assert.True(cleared.GetProperty("rubric").GetProperty("validTurn").GetBoolean());

        foreach (var record in records)
            record.Dispose();
    }

    [Fact]
    public async Task ValidateCurrentGameStateOrShowErrorsAsync_CanonicalRepairRequiresFreshPlayerFacingOutput()
    {
        const string sessionId = "session-canonical-repair-refreshes-output";
        const string requestId = "request-canonical-repair-refreshes-output";
        const int turnNumber = 35;
        const string trackedPath = "game_state/meta/soul_state.json";

        await CanonicalResourceQuartetTestFixture.CommitFreshBootstrapAsync(
            _fs,
            new AfterlifeOwnerResourceAcceptedState(
                Profiles: AfterlifeEntityProfileState.CreateDefaultRoot()));
        await WriteJsonAsync(trackedPath, new
        {
            soulName = "Искра Испытаний",
            currentRealm = "Chaos Sea",
            currentIncarnation = 0,
            soulFormDescription = new { invalid = true }
        });
        await WriteJsonAsync($"game_state/control/pending_turn_snapshot/{trackedPath}", new
        {
            soulName = "Искра Испытаний",
            currentRealm = "Chaos Sea",
            currentIncarnation = 0,
            soulFormDescription = new { invalid = true }
        });
        var profilesJson = await _fs.ReadFileAsync(AfterlifeEntityProfileState.StatePath);
        Assert.False(string.IsNullOrWhiteSpace(profilesJson));
        await _fs.WriteFileAtomicAsync(
            $"game_state/control/pending_turn_snapshot/{AfterlifeEntityProfileState.StatePath}",
            profilesJson!);
        await WritePendingTurnSnapshotManifestAsync(
            sessionId,
            requestId,
            turnNumber,
            trackedPath,
            AfterlifeEntityProfileState.StatePath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });
        await WriteJsonAsync("output/narrative_response.json", new
        {
            response = "До ремонта canonical state: Средоточие возвращает 1 ОД, теперь 3/6.",
            timestamp = "2026-07-04T05:18:22Z"
        });
        await WriteJsonAsync("output/debug_logs.json", new
        {
            timestamp = "2026-07-04T05:18:22Z",
            gm_thoughts_markdown = "## Охват NPC-анализа\nРежим: Guardian-centric\nРелевантные акторы: Иларион Архивный Свет\nПочему они релевантны: он ведёт учебный духовный обмен.\nАкторы вне охвата: нет\nПочему они вне охвата: все видимые акторы учтены.\n\n## Размышления акторов\n### Иларион Архивный Свет\n- Текущая локация: Архив Лучистых Тишин\n- Ситуация: учебный духовный обмен\n- Мысли: проверить темп восстановления\n- Действия: удерживает безопасное давление"
        });
        File.SetLastWriteTimeUtc(
            _fs.ResolvePath("output/narrative_response.json"),
            DateTime.UtcNow.AddMinutes(-10));

        string[]? outputRepairTargetFiles = null;
        var gmRepair = Task.Run(async () =>
        {
            var firstRequest = await WaitForValidationRepairRequestContainingAsync(
                "soul_form_description_invalid_shape",
                TimeSpan.FromSeconds(5));
            Assert.Contains("game_state/meta/soul_state.json", firstRequest, StringComparison.OrdinalIgnoreCase);

            var prematureOutputWrittenAtUtc = DateTime.UtcNow;
            await WriteJsonAsync("output/narrative_response.json", new
            {
                response = "Ответ переписан после запроса, но до фактического ремонта canonical state: Средоточие возвращает 1 ОД, теперь 3/6.",
                timestamp = "2026-07-04T05:18:45Z"
            });
            File.SetLastWriteTimeUtc(
                _fs.ResolvePath("output/narrative_response.json"),
                prematureOutputWrittenAtUtc);

            await WriteJsonAsync(trackedPath, new
            {
                soulName = "Искра Испытаний",
                currentRealm = "Chaos Sea",
                currentIncarnation = 0,
                soulFormDescription = "Женский силуэт из серебристого пепла."
            });
            var canonicalStateWrittenAtUtc = prematureOutputWrittenAtUtc.AddSeconds(2);
            File.SetLastWriteTimeUtc(
                _fs.ResolvePath(trackedPath),
                canonicalStateWrittenAtUtc);
            await WriteJsonAsync("game_state/control/validation_repair_ready.json", new
            {
                sessionId,
                requestId,
                turnNumber,
                updatedAtUtc = "2026-07-04T05:19:00Z",
                note = "Canonical state repaired, but player-facing output intentionally left stale."
            });

            var secondRequest = await WaitForValidationRepairRequestContainingAsync(
                "accepted_turn_stale_player_facing_output_after_canonical_repair",
                TimeSpan.FromSeconds(5));
            Assert.Contains("output/narrative_response.json", secondRequest, StringComparison.OrdinalIgnoreCase);
            Assert.Contains("accepted_turn_output_artifact_repair", secondRequest, StringComparison.OrdinalIgnoreCase);
            Assert.Contains("canonical state repair", secondRequest, StringComparison.OrdinalIgnoreCase);
            using (var repairDocument = JsonDocument.Parse(secondRequest))
            {
                var packet = Assert.Single(
                    repairDocument.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
                outputRepairTargetFiles = packet
                    .GetProperty("targetFiles")
                    .EnumerateArray()
                    .Select(item => item.GetString() ?? string.Empty)
                    .ToArray();
            }

            await WriteJsonAsync("output/narrative_response.json", new
            {
                response = "После первого ремонта canonical state: Средоточие не восстановило ОД, теперь 2/6.",
                timestamp = "2026-07-04T05:20:00Z"
            });
            var firstRefreshedOutputWrittenAtUtc = canonicalStateWrittenAtUtc.AddSeconds(2);
            File.SetLastWriteTimeUtc(
                _fs.ResolvePath("output/narrative_response.json"),
                firstRefreshedOutputWrittenAtUtc);
            await WriteJsonAsync(trackedPath, new
            {
                soulName = "Искра Испытаний",
                currentRealm = "Chaos Sea",
                currentIncarnation = 0,
                soulFormDescription = "Женский силуэт из серебристого пепла с новой светлой отметиной."
            });
            var secondCanonicalStateWrittenAtUtc = canonicalStateWrittenAtUtc.AddSeconds(4);
            File.SetLastWriteTimeUtc(
                _fs.ResolvePath(trackedPath),
                secondCanonicalStateWrittenAtUtc);
            await WriteJsonAsync("game_state/control/validation_repair_ready.json", new
            {
                sessionId,
                requestId,
                turnNumber,
                updatedAtUtc = "2026-07-04T05:20:05Z",
                note = "Player-facing output refreshed, then canonical state was rewritten again."
            });

            var thirdRequest = await WaitForUpdatedValidationRepairRequestContainingAsync(
                "accepted_turn_stale_player_facing_output_after_canonical_repair",
                secondRequest,
                TimeSpan.FromSeconds(5));
            Assert.Contains("output/narrative_response.json", thirdRequest, StringComparison.OrdinalIgnoreCase);

            await WriteJsonAsync("output/narrative_response.json", new
            {
                response = "После окончательного canonical state: Средоточие не восстановило ОД, теперь 2/6.",
                timestamp = "2026-07-04T05:20:10Z"
            });
            File.SetLastWriteTimeUtc(
                _fs.ResolvePath("output/narrative_response.json"),
                secondCanonicalStateWrittenAtUtc.AddSeconds(2));
            await WriteJsonAsync("game_state/control/validation_repair_ready.json", new
            {
                sessionId,
                requestId,
                turnNumber,
                updatedAtUtc = "2026-07-04T05:20:15Z",
                note = "Player-facing output refreshed after the latest canonical rewrite."
            });
        });

        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var accepted = await InvokePrivateAsync<bool>(
            engine,
            "ValidateCurrentGameStateOrShowErrorsAsync",
            "state validation",
            null,
            null,
            true);

        await gmRepair;

        Assert.True(accepted);
        Assert.NotNull(outputRepairTargetFiles);
        Assert.DoesNotContain("output/debug_logs.json", outputRepairTargetFiles);
        Assert.False(_fs.FileExists("game_state/control/validation_repair_request.json"));
        Assert.False(_fs.FileExists("game_state/control/validation_repair_ready.json"));

        var narrativeJson = await _fs.ReadFileAsync("output/narrative_response.json");
        Assert.Contains("2/6", narrativeJson, StringComparison.Ordinal);
        Assert.DoesNotContain("3/6", narrativeJson, StringComparison.Ordinal);
    }

    [Fact]
    public async Task CollectPlayerFacingOutputStaleAfterCanonicalRepairIssues_ActorMemoryOnlyRepair_DoesNotRequireNarrativeRewrite()
    {
        await WriteJsonAsync("output/narrative_response.json", new
        {
            response = "Элиара объясняет, как сохранить память.",
            timestamp = "2026-07-10T07:30:00Z"
        });
        await WriteJsonAsync("output/interface_updates.json", new
        {
            dialogueOptions = new[]
            {
                new { text = "Задать следующий вопрос", inputValue = "Спросить Элиару ещё раз." }
            },
            timestamp = "2026-07-10T07:30:00Z"
        });
        await WriteJsonAsync("game_state/control/validation_repair_request.json", new
        {
            sessionId = "actor-memory-test",
            requestId = "actor-memory-repair",
            turnNumber = 2
        });

        var outputWrittenAt = new DateTime(2026, 7, 10, 7, 30, 0, DateTimeKind.Utc);
        var requestWrittenAt = outputWrittenAt.AddMinutes(1);
        File.SetLastWriteTimeUtc(_fs.ResolvePath("output/narrative_response.json"), outputWrittenAt);
        File.SetLastWriteTimeUtc(_fs.ResolvePath("output/interface_updates.json"), outputWrittenAt);
        File.SetLastWriteTimeUtc(_fs.ResolvePath("game_state/control/validation_repair_request.json"), requestWrittenAt);

        var repairedErrors = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardian_thought_journal.json",
                IssueSeverity.Error,
                "Значимая реакция Хранителя осталась только в прозе.",
                code: "guardian_relevant_actor_missing_thought_journal_delta",
                actor: "Хранительница Элиара Карт Невозвращения",
                section: "actor_memory")
        };
        var engine = CreateGameEngine();
        var method = typeof(GameEngine).GetMethod(
            "CollectPlayerFacingOutputStaleAfterCanonicalRepairIssues",
            BindingFlags.Instance | BindingFlags.NonPublic);

        Assert.NotNull(method);
        var issues = Assert.IsType<List<ValidationIssue>>(method!.Invoke(
            engine,
            new object[] { repairedErrors, requestWrittenAt }));

        Assert.Empty(issues);
    }

    [Theory]
    [InlineData("actor_thought_journal_not_first_person", "game_state/meta/guardian_thought_journal.json.entries[0].summary")]
    [InlineData("flexible_state_unknown_top_level_key", "game_state/meta/guardian_thought_journal.json.schemaVersion")]
    public async Task CollectPlayerFacingOutputStaleAfterCanonicalRepairIssues_OtherActorMemoryRepairsDoNotRequireNarrativeRewrite(
        string issueCode,
        string issuePath)
    {
        await WriteJsonAsync("output/narrative_response.json", new
        {
            response = "Элиара объясняет, как сохранить память.",
            timestamp = "2026-07-10T07:30:00Z"
        });
        await WriteJsonAsync("output/interface_updates.json", new
        {
            dialogueOptions = new[]
            {
                new { text = "Задать следующий вопрос", inputValue = "Спросить Элиару ещё раз." }
            },
            timestamp = "2026-07-10T07:30:00Z"
        });
        await WriteJsonAsync("game_state/control/validation_repair_request.json", new
        {
            sessionId = "actor-memory-test",
            requestId = "actor-memory-repair",
            turnNumber = 2
        });

        var outputWrittenAt = new DateTime(2026, 7, 10, 7, 30, 0, DateTimeKind.Utc);
        var requestWrittenAt = outputWrittenAt.AddMinutes(1);
        File.SetLastWriteTimeUtc(_fs.ResolvePath("output/narrative_response.json"), outputWrittenAt);
        File.SetLastWriteTimeUtc(_fs.ResolvePath("output/interface_updates.json"), outputWrittenAt);
        File.SetLastWriteTimeUtc(_fs.ResolvePath("game_state/control/validation_repair_request.json"), requestWrittenAt);

        var repairedErrors = new List<ValidationIssue>
        {
            new(
                issuePath,
                IssueSeverity.Error,
                "Внутренняя память Хранителя требует узкой правки.",
                code: issueCode,
                actor: "Хранительница Элиара Карт Невозвращения",
                section: "actor_memory")
        };
        var engine = CreateGameEngine();
        var method = typeof(GameEngine).GetMethod(
            "CollectPlayerFacingOutputStaleAfterCanonicalRepairIssues",
            BindingFlags.Instance | BindingFlags.NonPublic);

        Assert.NotNull(method);
        var issues = Assert.IsType<List<ValidationIssue>>(method!.Invoke(
            engine,
            new object[] { repairedErrors, requestWrittenAt }));

        Assert.Empty(issues);
    }

    [Fact]
    [Trait("Category", "PreMergeSentinel")]
    public async Task WriteValidationRepairRequestAsync_GuardianScopeErrors_AddsConcreteHarnessRepairPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardians.json.guardians",
                IssueSeverity.Error,
                "Current guardians[] must match kernel-authoritative guardian state reconstructed from validated pre-turn baseline and authorized same-turn guardian mutations.",
                code: "guardian_materialized_state_outside_authority",
                section: "Guardians",
                expected: "kernel-authoritative guardians[] only",
                actual: "materialized current guardians[] diverges from kernel authority view"),
            new(
                "game_state/meta/guardians.json.activeGuardian",
                IssueSeverity.Error,
                "Current activeGuardian must match kernel-authoritative guardian mirror state.",
                code: "guardian_materialized_state_outside_authority",
                section: "Guardians",
                expected: "kernel-authoritative activeGuardian only",
                actual: "materialized current activeGuardian diverges from kernel authority view"),
            new(
                "game_state/meta/guardians.json",
                IssueSeverity.Error,
                "Структурированное обновление Guardian 'Азалия' не покрыто declared relevant actors",
                code: "structured_guardian_update_out_of_scope",
                actor: "Азалия",
                section: "UpdateGuardians",
                expected: "'Азалия' declared in Relevant actors",
                actual: "UpdateGuardians changed actor outside declared scope"),
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Отсутствует reasoning block для Guardian 'Азалия' в gm_thoughts_markdown",
                code: "missing_actor_block",
                actor: "Азалия",
                section: "npc_reasoning",
                expected: "### Азалия block",
                actual: "missing")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "ответа GM", issues, 2 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("guardian_scope_repair", packet.GetProperty("kind").GetString());
        Assert.Equal("high", packet.GetProperty("priority").GetString());
        Assert.Contains("Азалия", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("output/debug_logs.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/meta/guardians.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("game_state/meta/guardians.json", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("output/debug_logs.json.gm_thoughts_markdown", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Relevant actors", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("### Азалия", StringComparison.OrdinalIgnoreCase));

        var template = packet.GetProperty("debugLogTemplate").GetString();
        Assert.Contains("## Охват NPC-анализа", template, StringComparison.Ordinal);
        Assert.Contains("Релевантные акторы: Азалия", template, StringComparison.Ordinal);
        Assert.Contains("### Азалия", template, StringComparison.Ordinal);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_GuardianAuthorityErrors_UsesCurrentGuardianNameAndProjectTargets()
    {
        await _fs.WriteFileAtomicAsync("game_state/meta/guardians.json", """
        {
          "activeGuardian": {
            "guardianId": "guardian_azalia",
            "displayName": "Азалия"
          },
          "guardians": [
            {
              "guardianId": "guardian_azalia",
              "displayName": "Азалия"
            }
          ]
        }
        """);
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardian_projects.json.activeProjects",
                IssueSeverity.Error,
                "Current activeProjects must match kernel-authoritative guardian project tracker state reconstructed from validated pre-turn baseline and same-turn project commands.",
                code: "guardian_project_materialized_state_outside_authority",
                section: "GuardianProjects",
                expected: "kernel-authoritative activeProjects only",
                actual: "materialized current activeProjects diverges from kernel authority view"),
            new(
                "game_state/meta/guardians.json.activeGuardian",
                IssueSeverity.Error,
                "Current activeGuardian must match kernel-authoritative guardian mirror state.",
                code: "guardian_materialized_state_outside_authority",
                section: "Guardians",
                expected: "kernel-authoritative activeGuardian only",
                actual: "materialized current activeGuardian diverges from kernel authority view")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("guardian_scope_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("Азалия", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/meta/guardian_projects.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/meta/guardians.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains(
            packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("implementation code", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_GuardianScopeErrors_DebugTemplateIncludesEveryListedGuardian()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardians.json.guardians[0]",
                IssueSeverity.Error,
                "Structured Guardian update is outside declared scope.",
                code: "structured_guardian_update_out_of_scope",
                actor: "Азалия",
                section: "UpdateGuardians",
                expected: "Азалия declared in Relevant actors",
                actual: "missing"),
            new(
                "game_state/meta/guardians.json.guardians[1]",
                IssueSeverity.Error,
                "Structured Guardian update is outside declared scope.",
                code: "structured_guardian_update_out_of_scope",
                actor: "Эфон",
                section: "UpdateGuardians",
                expected: "Эфон declared in Relevant actors",
                actual: "missing")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 2 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("guardian_scope_repair", packet.GetProperty("kind").GetString());

        var template = packet.GetProperty("debugLogTemplate").GetString() ?? string.Empty;
        Assert.Contains("Релевантные акторы: Азалия, Эфон", template, StringComparison.Ordinal);
        Assert.Contains("### Азалия", template, StringComparison.Ordinal);
        Assert.Contains("### Эфон", template, StringComparison.Ordinal);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_GuardianTradeInventoryResolutionErrors_AddsConcreteHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/control/pending_guardian_trade_request.json",
                IssueSeverity.Error,
                "pending_guardian_trade_request из pre-turn snapshot не привёл к matching guardian.tradeInventory",
                code: "guardian_trade_request_missing_inventory_resolution",
                section: "GuardianTrade",
                expected: "guardian.tradeInventory matching requestId/tradeCycleId/returnCycleId",
                actual: "missing tradeInventory",
                repairHint: "На accepted turn обязательно materialize-ь guardian.tradeInventory по exact client-authored request contract; не игнорируй request и не закрывай его частично совпадающей витриной."),
            new(
                "game_state/control/pending_guardian_trade_request.json",
                IssueSeverity.Error,
                "pending_guardian_trade_request из pre-turn snapshot не был закрыт canonical tradeInventory receipt",
                code: "guardian_trade_request_missing_receipt_resolution",
                section: "GuardianTrade",
                expected: "matching guardianTradeInventoryReceipts[] entry",
                actual: "missing receipt")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 3 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("guardian_trade_inventory_resolution_repair", packet.GetProperty("kind").GetString());
        Assert.Equal("high", packet.GetProperty("priority").GetString());
        Assert.Contains("game_state/meta/guardians.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/control/pending_guardian_trade_request.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("guardian.tradeInventory", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("requestId", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("tradeCycleId", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("tradeInventoryReceipts", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("pending_guardian_trade_request.json", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Read-BoeJson", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("tradeInventory", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Complete-BoeValidationRepair", StringComparison.OrdinalIgnoreCase));

        var doNotDo = packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(doNotDo, item => item.Contains("new turn", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("pending_guardian_trade_request.json", StringComparison.OrdinalIgnoreCase) &&
                                         item.Contains("rewrite", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_PendingGuardianCreationMaterializationErrors_AddsConcreteHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardians.json.guardians[0].guardianId",
                IssueSeverity.Error,
                "Fresh startup Guardian was materialized without the supported create surface.",
                code: "guardian_materialized_without_create_surface",
                section: "Guardians",
                expected: "UpdateGuardians.create with full canonical Guardian shape",
                actual: "direct materialized guardian object"),
            new(
                "game_state/meta/guardians.json.pendingGuardianCreation",
                IssueSeverity.Error,
                "pendingGuardianCreation remains after Guardian materialization.",
                code: "stale_pending_guardian_creation_after_materialization",
                section: "Guardians",
                expected: "pendingGuardianCreation removed after canonical guardians[] and activeGuardian materialization",
                actual: "pending request still present"),
            new(
                "game_state/meta/guardians.json",
                IssueSeverity.Error,
                "Structured Guardian create update is missing canonical identity.",
                code: "structured_guardian_update_missing_canonical_identity",
                section: "UpdateGuardians",
                expected: "canonical guardianId/displayName/title/domain/abode identity",
                actual: "partial startup guardian")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "первого хода после создания души", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("guardian_pending_creation_materialization_repair", packet.GetProperty("kind").GetString());
        Assert.Equal("high", packet.GetProperty("priority").GetString());
        Assert.Contains("game_state/meta/guardians.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("output/debug_logs.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        var skeleton = packet.GetProperty("canonicalCreateSkeleton");
        Assert.True(skeleton.TryGetProperty("UpdateGuardians", out var updateGuardians));
        Assert.Equal(JsonValueKind.Array, updateGuardians.ValueKind);
        Assert.False(skeleton.TryGetProperty("updateGuardians", out _));
        var createCommand = Assert.Single(updateGuardians.EnumerateArray());
        Assert.Equal("create", createCommand.GetProperty("command").GetString());
        Assert.True(createCommand.TryGetProperty("data", out var createData));
        Assert.True(createData.TryGetProperty("guardianId", out _));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("pendingGuardianCreation", StringComparison.Ordinal));
        Assert.Contains(expectedShape, item => item.Contains("UpdateGuardians.create", StringComparison.Ordinal));
        Assert.Contains(expectedShape, item => item.Contains("UpdateGuardians", StringComparison.Ordinal) &&
                                               item.Contains("command", StringComparison.OrdinalIgnoreCase) &&
                                               item.Contains("create", StringComparison.OrdinalIgnoreCase) &&
                                               item.Contains("data", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("guardians[]", StringComparison.Ordinal));
        Assert.Contains(expectedShape, item => item.Contains("activeGuardian", StringComparison.Ordinal));
        Assert.Contains(expectedShape, item => item.Contains("chaosSeaNavigation", StringComparison.Ordinal));
        Assert.Contains(expectedShape, item => item.Contains("remove pendingGuardianCreation", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("validation_repair_request.json", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Read-BoeJson", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("pendingGuardianCreation", StringComparison.Ordinal));
        Assert.Contains(steps, step => step.Contains("UpdateGuardians.create", StringComparison.Ordinal));
        Assert.Contains(steps, step => step.Contains("do not repair", StringComparison.OrdinalIgnoreCase) &&
                                       step.Contains("guardians[]", StringComparison.Ordinal) &&
                                       step.Contains("activeGuardian", StringComparison.Ordinal));
        Assert.Contains(steps, step => step.Contains("Complete-BoeValidationRepair", StringComparison.OrdinalIgnoreCase));

        var doNotDo = packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(doNotDo, item => item.Contains("delete pendingGuardianCreation", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("direct materialized", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("guardians[]", StringComparison.Ordinal) &&
                                         item.Contains("activeGuardian", StringComparison.Ordinal) &&
                                         item.Contains("without UpdateGuardians", StringComparison.OrdinalIgnoreCase));

        var safeCorrectionRules = packet.GetProperty("safeCorrectionRules").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(safeCorrectionRules, item => item.Contains("pending-only", StringComparison.OrdinalIgnoreCase));
        Assert.DoesNotContain(safeCorrectionRules, item => item.Contains("materialization was not intended", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_PendingGuardianCreationRepair_IncludesBoundedCreateSkeletonAndEnums()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardians.json.guardians[0].guardianId",
                IssueSeverity.Error,
                "Fresh startup Guardian was materialized without the supported create surface.",
                code: "guardian_materialized_without_create_surface",
                section: "Guardians",
                expected: "UpdateGuardians.create with full canonical Guardian shape",
                actual: "direct materialized guardian object"),
            new(
                "game_state/meta/guardians.json.guardians[0].loreFragments",
                IssueSeverity.Error,
                "Canonical guardian state должен хранить как минимум 7 pre-planned lore fragments",
                code: "guardian_state_lore_fragments_below_minimum",
                section: "Guardians",
                expected: ">= 7 lore fragments",
                actual: "2"),
            new(
                "game_state/meta/guardians.json.guardians[0].musings[0].topic",
                IssueSeverity.Error,
                "Guardian musing.topic должен быть одним из canonical topic enums",
                code: "guardian_musing_invalid_topic",
                section: "Guardians",
                expected: "soul_assessment | domain_insight | guardian_politics | chaos_sea | personal_reflection | quest_planning",
                actual: "mirror_memory"),
            new(
                "game_state/meta/guardians.json.guardians[0].relationshipData.guardianRoleToPlayer",
                IssueSeverity.Error,
                "guardianRoleToPlayer поддерживает только canonical значение former_patron в v1 foundation branch",
                code: "guardian_relationship_invalid_role_to_player",
                section: "Guardians",
                expected: "former_patron or omit field",
                actual: "mentor")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "первого хода после создания души", issues, 2 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("guardian_pending_creation_materialization_repair", packet.GetProperty("kind").GetString());

        var skeleton = packet.GetProperty("canonicalCreateSkeleton");
        Assert.Equal("UpdateGuardians.create", skeleton.GetProperty("authoritySurface").GetString());
        Assert.True(skeleton.TryGetProperty("UpdateGuardians", out var updateGuardians));
        Assert.Equal(JsonValueKind.Array, updateGuardians.ValueKind);
        Assert.False(skeleton.TryGetProperty("updateGuardians", out _));
        var createCommand = updateGuardians.EnumerateArray().Single();
        Assert.Equal("create", createCommand.GetProperty("command").GetString());
        var data = createCommand.GetProperty("data");
        Assert.True(data.TryGetProperty("guardianId", out _));
        Assert.True(data.TryGetProperty("canonicalName", out _));
        Assert.True(data.TryGetProperty("manifestation", out _));
        Assert.True(data.TryGetProperty("abode", out _));
        Assert.True(data.TryGetProperty("relationshipData", out var relationshipData));
        Assert.False(relationshipData.TryGetProperty("guardianRoleToPlayer", out _));
        Assert.True(relationshipData.TryGetProperty("lastInteraction", out var lastInteraction));
        Assert.Equal(JsonValueKind.Null, lastInteraction.ValueKind);
        Assert.True(data.TryGetProperty("abodePower", out var abodePower));
        Assert.Equal(10, abodePower.GetProperty("currentPower").GetInt32());
        Assert.Equal("Угасающая", abodePower.GetProperty("tier").GetString());
        Assert.DoesNotContain("startup_turn", data.GetRawText(), StringComparison.OrdinalIgnoreCase);
        Assert.True(data.TryGetProperty("mood", out var mood));
        Assert.Equal("focused", mood.GetProperty("current").GetString());
        Assert.True(data.TryGetProperty("loreFragments", out var loreFragments));
        Assert.Equal(7, loreFragments.GetArrayLength());
        Assert.True(data.TryGetProperty("musings", out var musings));
        Assert.Equal("soul_assessment", musings.EnumerateArray().Single().GetProperty("topic").GetString());

        var allowedEnums = packet.GetProperty("allowedEnums");
        Assert.Contains("soul_assessment", allowedEnums.GetProperty("guardianMusingTopics").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("contemplative", allowedEnums.GetProperty("guardianMusingMoods").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("focused", allowedEnums.GetProperty("guardianMoodCurrent").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("personal_history", allowedEnums.GetProperty("guardianLoreFragmentCategories").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("230", allowedEnums.GetProperty("guardianLoreFragmentRequiredReputation").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("former_patron", allowedEnums.GetProperty("guardianRoleToPlayerV1").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("canonicalCreateSkeleton", StringComparison.Ordinal));
        Assert.Contains(expectedShape, item => item.Contains("7 loreFragments", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("guardianRoleToPlayer", StringComparison.Ordinal) &&
                                               item.Contains("omit", StringComparison.OrdinalIgnoreCase));

        var doNotDo = packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(doNotDo, item => item.Contains("invent", StringComparison.OrdinalIgnoreCase) &&
                                         item.Contains("guardianRoleToPlayer", StringComparison.Ordinal));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_UnresolvedStartupPendingGuardianCreation_AddsConcreteHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardians.json.pendingGuardianCreation",
                IssueSeverity.Error,
                "Стартовый freeform pendingGuardianCreation нельзя оставлять неразрешенным после принятого первого хода.",
                code: "pending_guardian_creation_unresolved_after_startup_turn",
                section: "Guardians",
                expected: "startup freeform Guardian materialized into canonical guardians[] + activeGuardian + chaosSeaNavigation",
                actual: "pending-only state")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "первого хода после создания души", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());

        Assert.Equal("guardian_pending_creation_materialization_repair", packet.GetProperty("kind").GetString());
        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("UpdateGuardians.create", StringComparison.Ordinal));
        Assert.Contains(expectedShape, item => item.Contains("command", StringComparison.OrdinalIgnoreCase) &&
                                               item.Contains("create", StringComparison.OrdinalIgnoreCase) &&
                                               item.Contains("data", StringComparison.OrdinalIgnoreCase));
        var safeCorrectionRules = packet.GetProperty("safeCorrectionRules").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(safeCorrectionRules, item => item.Contains("pending-only", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_ActorReasoningSubpointErrors_AddsHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Для Guardian 'Азалия' отсутствует подпункт ситуации/current situation",
                code: "missing_actor_situation",
                actor: "Азалия",
                section: "npc_reasoning",
                expected: "Situation / Current situation",
                actual: "missing"),
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Для Guardian 'Азалия' отсутствует подпункт мыслей/internal thoughts",
                code: "missing_actor_thoughts",
                actor: "Азалия",
                section: "npc_reasoning",
                expected: "Thoughts / Internal thoughts",
                actual: "missing"),
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Для Guardian 'Азалия' отсутствует подпункт действий/intended actions",
                code: "missing_actor_actions",
                actor: "Азалия",
                section: "npc_reasoning",
                expected: "Actions / Intended actions",
                actual: "missing")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 4 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("actor_reasoning_subpoint_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("Азалия", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("output/debug_logs.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.DoesNotContain("game_state/meta/guardians.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var template = packet.GetProperty("debugLogTemplate").GetString() ?? string.Empty;
        Assert.Contains("### Азалия", template, StringComparison.Ordinal);
        Assert.Contains("- Ситуация:", template, StringComparison.Ordinal);
        Assert.Contains("- Мысли:", template, StringComparison.Ordinal);
        Assert.Contains("- Действия:", template, StringComparison.Ordinal);
        Assert.Contains(
            packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("Complete-BoeValidationRepair", StringComparison.Ordinal));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_FullActorBrainErrors_AddsDecisionAuditTemplate()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Отсутствуют данные профиля",
                code: "actor_brain_missing_profile_inputs",
                actor: "Иветта",
                section: "npc_reasoning",
                expected: "Profile inputs / Данные профиля",
                actual: "missing"),
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Отсутствует сравнение стратегий",
                code: "actor_brain_missing_strategy_tradeoffs",
                actor: "Иветта",
                section: "npc_reasoning",
                expected: "two strategies with Benefit/Risk",
                actual: "missing"),
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Отсутствует выбранная стратегия",
                code: "actor_brain_missing_chosen_strategy",
                actor: "Иветта",
                section: "npc_reasoning",
                expected: "Chosen strategy",
                actual: "missing")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        using var doc = JsonDocument.Parse((await _fs.ReadFileAsync("game_state/control/validation_repair_request.json"))!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("actor_reasoning_subpoint_repair", packet.GetProperty("kind").GetString());
        var template = packet.GetProperty("debugLogTemplate").GetString() ?? string.Empty;
        Assert.Contains("- Данные профиля:", template, StringComparison.Ordinal);
        Assert.Contains("- Мотивация:", template, StringComparison.Ordinal);
        Assert.Contains("- Ограничения:", template, StringComparison.Ordinal);
        Assert.Contains("- Варианты стратегий:", template, StringComparison.Ordinal);
        Assert.Contains("Выгода:", template, StringComparison.Ordinal);
        Assert.Contains("Риск:", template, StringComparison.Ordinal);
        Assert.Contains("- Выбранная стратегия:", template, StringComparison.Ordinal);
        Assert.Contains("- Почему альтернативы отвергнуты:", template, StringComparison.Ordinal);
        Assert.Contains("- Изменения состояния:", template, StringComparison.Ordinal);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_ActorMemoryErrors_AddsNarrowPersistencePacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardians.json.guardians[guard_elara].musings",
                IssueSeverity.Error,
                "Хранитель не записал мысль",
                code: "guardian_relevant_actor_missing_thought_journal_delta",
                actor: "Элиара",
                section: "actor_memory"),
            new(
                "game_state/npcs/npc_journals.json",
                IssueSeverity.Error,
                "NPC не записал мысль",
                code: "mortal_npc_relevant_actor_missing_thought_journal_delta",
                actor: "Иветта",
                section: "actor_memory"),
            new(
                "game_state/meta/guardian_abode_residents.json",
                IssueSeverity.Error,
                "Житель не записал мысль",
                code: "afterlife_resident_relevant_actor_missing_thought_journal_delta",
                actor: "Лиора",
                section: "actor_memory")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        using var doc = JsonDocument.Parse((await _fs.ReadFileAsync("game_state/control/validation_repair_request.json"))!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("actor_memory_persistence_repair", packet.GetProperty("kind").GetString());
        var targetFiles = packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()).ToArray();
        Assert.Contains(GuardianThoughtJournalState.StatePath, targetFiles);
        Assert.DoesNotContain("game_state/meta/guardians.json", targetFiles);
        Assert.Contains("game_state/npcs/npc_journals.json", targetFiles);
        Assert.Contains("game_state/meta/guardian_abode_residents.json", targetFiles);
        Assert.Contains("output/debug_logs.json", targetFiles);
        Assert.DoesNotContain("output/narrative_response.json", targetFiles);
        Assert.Contains(
            packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("Изменения состояния", StringComparison.OrdinalIgnoreCase) &&
                    item.Contains("journal", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(
            packet.GetProperty("safeCorrectionRules").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("first-person", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(
            packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("\"entries\"", StringComparison.Ordinal) &&
                    item.Contains("\"guardianId\"", StringComparison.Ordinal));
        Assert.Contains(
            packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("schemaVersion", StringComparison.Ordinal) &&
                    item.Contains("guardianThoughtJournalUpdates", StringComparison.Ordinal));
        Assert.Contains(
            packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("unrelated", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_GuardianJournalShapeErrors_StayInActorMemoryPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardian_thought_journal.json",
                IssueSeverity.Error,
                "Файл не содержит ни одного допустимого top-level ключа для своего контракта",
                code: "strict_state_missing_allowed_top_level_key",
                section: "StateFiles",
                expected: "entries",
                actual: "schemaVersion, guardianThoughtJournalUpdates"),
            new(
                "game_state/meta/guardian_thought_journal.json.schemaVersion",
                IssueSeverity.Error,
                "Недопустимый top-level ключ: schemaVersion",
                code: "flexible_state_unknown_top_level_key",
                section: "StateFiles",
                expected: "entries, guardianThoughtJournalUpdates",
                actual: "schemaVersion")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 2 })!);

        await task;

        using var doc = JsonDocument.Parse((await _fs.ReadFileAsync("game_state/control/validation_repair_request.json"))!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("actor_memory_persistence_repair", packet.GetProperty("kind").GetString());
        var targetFiles = packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()).ToArray();
        Assert.Contains(GuardianThoughtJournalState.StatePath, targetFiles);
        Assert.Contains("output/debug_logs.json", targetFiles);
        Assert.DoesNotContain("game_state/control/mortal_bootstrap_scaffold.json", targetFiles);
        Assert.DoesNotContain(targetFiles, path => path?.Contains("schemaVersion", StringComparison.Ordinal) == true);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_ShiningFactionMemoryError_TargetsFactionMemorySurface()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                ShiningAbodeState.StatePath,
                IssueSeverity.Error,
                "Сияющая фракция не обновила стратегическую память",
                code: "shining_faction_relevant_actor_missing_strategic_memory_delta",
                actor: "Орден Рассвета",
                section: "actor_memory")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        using var doc = JsonDocument.Parse((await _fs.ReadFileAsync("game_state/control/validation_repair_request.json"))!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("actor_memory_persistence_repair", packet.GetProperty("kind").GetString());
        var targetFiles = packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()).ToArray();
        Assert.Contains(ShiningAbodeState.StatePath, targetFiles);
        Assert.Contains("output/debug_logs.json", targetFiles);
        Assert.Equal(2, targetFiles.Length);
        Assert.Contains(
            packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains(ShiningAbodeState.FactionChronicleUpdatesProperty, StringComparison.Ordinal) &&
                    !item.Contains(ShiningAbodeState.FactionStrategicMemoryUpdatesProperty, StringComparison.Ordinal));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_AfterlifeActorWithoutMemoryOwner_OffersMaterializeOrDescopeRepair()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Актор не имеет canonical memory owner",
                code: "afterlife_relevant_actor_missing_canonical_memory_owner",
                actor: "Безымянный Советник",
                section: "actor_memory")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        using var doc = JsonDocument.Parse((await _fs.ReadFileAsync("game_state/control/validation_repair_request.json"))!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("afterlife_entity_profile_scaffold_repair", packet.GetProperty("kind").GetString());
        Assert.Contains(
            AfterlifeEntityProfileState.StatePath,
            packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains(
            packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("material", StringComparison.OrdinalIgnoreCase) &&
                    item.Contains("relevant actors", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_DirectlyAddressedActorScopeError_UsesFullActorBrainScopePacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Прямо названный NPC отсутствует в scope",
                code: "directly_addressed_actor_missing_from_scope",
                actor: "Иветта",
                section: "npc_scope")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        using var doc = JsonDocument.Parse((await _fs.ReadFileAsync("game_state/control/validation_repair_request.json"))!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("npc_scope_declaration_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("Иветта", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        var template = packet.GetProperty("debugLogTemplate").GetString() ?? string.Empty;
        Assert.Contains("- Данные профиля:", template, StringComparison.Ordinal);
        Assert.Contains("- Варианты стратегий:", template, StringComparison.Ordinal);
        Assert.Contains("Выгода:", template, StringComparison.Ordinal);
        Assert.Contains("Риск:", template, StringComparison.Ordinal);
        Assert.Contains("- Изменения состояния:", template, StringComparison.Ordinal);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_AcceptedTurnOutputArtifactErrors_AddsHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "output/narrative_response.json",
                IssueSeverity.Error,
                "Accepted GM turn должен содержать свежий output/narrative_response.json с непустым response",
                code: "accepted_turn_missing_narrative_response",
                section: "Narrative",
                expected: "output/narrative_response.json with non-empty response",
                actual: "missing or empty",
                repairHint: "Запиши output/narrative_response.json с полем response для текущего accepted turn."),
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Отсутствует gm_thoughts_markdown при обязательной проверке actor reasoning scope",
                code: "missing_gm_thoughts",
                section: "gm_thoughts_markdown",
                expected: "gm_thoughts_markdown with NPC scope declaration",
                actual: "missing or empty",
                repairHint: "Добавь debug_logs.json.gm_thoughts_markdown с секцией 'Охват NPC-анализа' и reasoning blocks.")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("accepted_turn_output_artifact_repair", packet.GetProperty("kind").GetString());
        Assert.Equal("high", packet.GetProperty("priority").GetString());
        Assert.Contains("output/narrative_response.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("output/debug_logs.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("\"response\"", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("gm_thoughts_markdown", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("## Охват NPC-анализа", StringComparison.Ordinal));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("output/narrative_response.json", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("output/debug_logs.json.gm_thoughts_markdown", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("validation_repair_ready.json", StringComparison.OrdinalIgnoreCase));

        Assert.Contains(
            packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("new turn", StringComparison.OrdinalIgnoreCase));

        var debugTemplate = packet.GetProperty("debugLogTemplate").GetString() ?? string.Empty;
        Assert.Contains("- Данные профиля:", debugTemplate, StringComparison.Ordinal);
        Assert.Contains("- Варианты стратегий:", debugTemplate, StringComparison.Ordinal);
        Assert.Contains("Выгода:", debugTemplate, StringComparison.Ordinal);
        Assert.Contains("Риск:", debugTemplate, StringComparison.Ordinal);
        Assert.Contains("- Изменения состояния:", debugTemplate, StringComparison.Ordinal);
        Assert.Contains("NPCJournals[].journalEntries[]", string.Join("\n", steps), StringComparison.Ordinal);
        Assert.Contains("guardianThoughtJournalUpdates", string.Join("\n", steps), StringComparison.Ordinal);
        Assert.Contains("residentThoughtJournalUpdates", string.Join("\n", steps), StringComparison.Ordinal);
        Assert.Contains("ledger/progressionLedger", string.Join("\n", steps), StringComparison.Ordinal);
        Assert.Contains("shiningFactionChronicleUpdates", string.Join("\n", steps), StringComparison.Ordinal);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_NarrativeTimestampError_AddsAcceptedTurnOutputPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "output/narrative_response.json.timestamp",
                IssueSeverity.Error,
                "output/narrative_response.json must include timestamp",
                code: "narrative_response_missing_timestamp",
                section: "Narrative",
                expected: "ISO-8601 UTC timestamp",
                actual: "missing")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("accepted_turn_output_artifact_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("output/narrative_response.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.DoesNotContain("output/debug_logs.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains(
            packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("\"timestamp\"", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(
            packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("Do not rewrite output/debug_logs.json", StringComparison.Ordinal));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_OutputUnknownFieldCodes_WhitelistCanonicalTargetsWhenPathsAreMalformed()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "unexpected/narrative-path.json",
                IssueSeverity.Error,
                "Narrative output contains an unsupported field.",
                code: "narrative_response_unknown_field",
                section: "Narrative"),
            new(
                string.Empty,
                IssueSeverity.Error,
                "Interface output is empty.",
                code: "accepted_turn_empty_interface_updates",
                section: "Interface"),
            new(
                "unexpected/debug-path.json",
                IssueSeverity.Error,
                "Debug output contains an unsupported field.",
                code: "debug_logs_unknown_field",
                section: "gm_thoughts_markdown")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        using var doc = JsonDocument.Parse(
            (await _fs.ReadFileAsync("game_state/control/validation_repair_request.json"))!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("accepted_turn_output_artifact_repair", packet.GetProperty("kind").GetString());

        var targets = packet.GetProperty("targetFiles")
            .EnumerateArray()
            .Select(item => item.GetString() ?? string.Empty)
            .ToArray();
        Assert.Equal(3, targets.Length);
        Assert.Contains("output/narrative_response.json", targets);
        Assert.Contains("output/interface_updates.json", targets);
        Assert.Contains("output/debug_logs.json", targets);
        Assert.DoesNotContain(targets, path => string.IsNullOrWhiteSpace(path));
        Assert.DoesNotContain(targets, path => path.StartsWith("unexpected/", StringComparison.OrdinalIgnoreCase));

        var debugTemplate = packet.GetProperty("debugLogTemplate").GetString() ?? string.Empty;
        Assert.Contains("- Данные профиля:", debugTemplate, StringComparison.Ordinal);
        Assert.Contains("- Изменения состояния:", debugTemplate, StringComparison.Ordinal);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_UnroutableStaleOutputDiagnostic_DoesNotEmitEmptyHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "unexpected/player-facing-output.json",
                IssueSeverity.Error,
                "A player-facing artifact is stale, but its canonical output file is unknown.",
                code: "accepted_turn_stale_player_facing_output_after_canonical_repair",
                section: "PlayerFacingOutput")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        using var doc = JsonDocument.Parse(
            (await _fs.ReadFileAsync("game_state/control/validation_repair_request.json"))!);
        Assert.Empty(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MissingNpcActorBlock_AddsActorReasoningPacketNotGuardianPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Relevant actor 'Ирен Соль' has no reasoning block.",
                code: "missing_actor_block",
                actor: "Ирен Соль.",
                section: "npc_reasoning",
                expected: "### Ирен Соль reasoning block",
                actual: "missing")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("actor_reasoning_subpoint_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("Ирен Соль", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.DoesNotContain("game_state/meta/guardians.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("create a missing reasoning block", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("current location", StringComparison.OrdinalIgnoreCase) || step.Contains("Текущ", StringComparison.OrdinalIgnoreCase));

        var template = packet.GetProperty("debugLogTemplate").GetString() ?? string.Empty;
        Assert.Contains("### Ирен Соль", template, StringComparison.Ordinal);
        Assert.Contains("- Текущая локация:", template, StringComparison.Ordinal);
        Assert.Contains("- Ситуация:", template, StringComparison.Ordinal);
        Assert.Contains("- Мысли:", template, StringComparison.Ordinal);
        Assert.Contains("- Действия:", template, StringComparison.Ordinal);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MixedGuardianAndNpcReasoningErrors_KeepsSeparatePackets()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardians.json.guardians[0]",
                IssueSeverity.Error,
                "Structured Guardian update is outside declared scope.",
                code: "structured_guardian_update_out_of_scope",
                actor: "Эфон",
                section: "UpdateGuardians",
                expected: "Эфон declared in Relevant actors",
                actual: "missing"),
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Relevant actor 'Ирен Соль' has no reasoning block.",
                code: "missing_actor_block",
                actor: "Ирен Соль.",
                section: "npc_reasoning",
                expected: "### Ирен Соль reasoning block",
                actual: "missing")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packets = doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray().ToArray();
        Assert.Equal(2, packets.Length);

        var guardianPacket = Assert.Single(
            packets,
            packet => packet.GetProperty("kind").GetString() == "guardian_scope_repair");
        Assert.Contains("Эфон", guardianPacket.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.DoesNotContain("Ирен Соль", guardianPacket.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var actorPacket = Assert.Single(
            packets,
            packet => packet.GetProperty("kind").GetString() == "actor_reasoning_subpoint_repair");
        Assert.Contains("Ирен Соль", actorPacket.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.DoesNotContain("Эфон", actorPacket.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_FactionMaterializationRepair_MortalBoundedBundle_UsesExactTargetsAndPreservationRules()
    {
        const string coordinate = "mortal_faction:faction_watch";
        const string resourcePath =
            "game_state/factions/faction_resources.json.entries[0].materialization.sections.resources";
        const string resourceLinkMissingPath =
            "game_state/factions/faction_resources.json.entries[0].materialization.requiredLinks[0]";
        const string resourceMismatchPath =
            "game_state/factions/faction_resources.json.entries[0].materialization.sections.strategicGoods";
        const string npcLinkPath =
            "game_state/npcs/npc_core.json:npc_watch_captain.factionAffiliations[0].factionId";
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                resourcePath,
                IssueSeverity.Error,
                "Faction materialization does not govern the resources sidecar.",
                code: "faction_materialization_section_missing",
                actor: coordinate,
                section: "FactionMaterialization",
                expected: "populated or exact empty section",
                actual: "missing"),
            new(
                resourceLinkMissingPath,
                IssueSeverity.Error,
                "Faction materialization is missing its exact resource-sidecar link.",
                code: "faction_materialization_link_missing",
                actor: coordinate,
                section: "FactionMaterialization",
                expected: coordinate,
                actual: "missing"),
            new(
                resourceMismatchPath,
                IssueSeverity.Error,
                "Faction materialization contradicts the strategic-goods sidecar.",
                code: "faction_materialization_section_content_mismatch",
                actor: coordinate,
                section: "FactionMaterialization",
                expected: "receipt-bound strategic goods",
                actual: "unbound strategic goods"),
            new(
                npcLinkPath,
                IssueSeverity.Error,
                "Mortal NPC affiliation references an unknown effective faction ID.",
                code: "faction_materialization_mortal_npc_affiliation_unknown_faction",
                actor: coordinate,
                section: "FactionMaterialization",
                expected: "one exact effective faction ID",
                actual: "faction_unknown")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("faction_materialization_repair", packet.GetProperty("kind").GetString());
        Assert.Equal("critical", packet.GetProperty("priority").GetString());
        Assert.Contains(
            coordinate,
            packet.GetProperty("title").GetString() ?? string.Empty,
            StringComparison.Ordinal);
        Assert.Equal(
            new[] { coordinate },
            packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[]
            {
                "game_state/factions/faction_core.json",
                "game_state/factions/faction_resources.json",
                "game_state/npcs/npc_core.json"
            },
            packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { "Templates/MORTAL_FACTION_UPDATE_TEMPLATE.md" },
            packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));

        var targetFiles = packet.GetProperty("targetFiles")
            .EnumerateArray()
            .Select(item => item.GetString() ?? string.Empty)
            .ToArray();
        Assert.DoesNotContain(targetFiles, path => path.StartsWith("game_state/meta/", StringComparison.Ordinal));
        Assert.DoesNotContain(targetFiles, path => path.StartsWith("game_state/player/", StringComparison.Ordinal));
        Assert.DoesNotContain(targetFiles, path => path.Contains("faction_structure.json", StringComparison.Ordinal));
        Assert.DoesNotContain(targetFiles, path => path.Contains("world_map.json", StringComparison.Ordinal));

        Assert.Equal(
            new[] { resourceLinkMissingPath, resourcePath },
            packet.GetProperty("missingFields").EnumerateArray().Select(item => item.GetString()));

        var correctionKeys = packet.GetProperty("exactFieldCorrections")
            .EnumerateArray()
            .Select(correction =>
                $"{correction.GetProperty("path").GetString()}|{correction.GetProperty("code").GetString()}")
            .ToArray();
        Assert.Equal(
            new[]
            {
                $"{resourceLinkMissingPath}|faction_materialization_link_missing",
                $"{resourcePath}|faction_materialization_section_missing",
                $"{resourceMismatchPath}|faction_materialization_section_content_mismatch",
                $"{npcLinkPath}|faction_materialization_mortal_npc_affiliation_unknown_faction"
            },
            correctionKeys);

        var expectedShape = string.Join(
            "\n",
            packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("materialization v1", expectedShape, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("receipt", expectedShape, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("populated", expectedShape, StringComparison.Ordinal);
        Assert.Contains("empty", expectedShape, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("actor", expectedShape, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("location", expectedShape, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("sidecar", expectedShape, StringComparison.OrdinalIgnoreCase);

        var safeRules = string.Join(
            "\n",
            packet.GetProperty("safeCorrectionRules").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains(coordinate, safeRules, StringComparison.Ordinal);
        Assert.Contains("listed", safeRules, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("target", safeRules, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("preserve", safeRules, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("valid", safeRules, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("receipt", safeRules, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("histor", safeRules, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("chronicle", safeRules, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("unrelated faction", safeRules, StringComparison.OrdinalIgnoreCase);

        var steps = string.Join(
            "\n",
            packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("one by one", steps, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("raw faction materialization", steps, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("before normalization", steps, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("Complete-BoeValidationRepair", steps, StringComparison.Ordinal);

        var doNotDo = string.Join(
            "\n",
            packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("another faction", doNotDo, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("materializationId", doNotDo, StringComparison.Ordinal);
        Assert.Contains("validated history", doNotDo, StringComparison.OrdinalIgnoreCase);
        Assert.True(
            doNotDo.Contains("whole-file", StringComparison.OrdinalIgnoreCase) ||
            doNotDo.Contains("whole file", StringComparison.OrdinalIgnoreCase));
        Assert.Contains("name", doNotDo, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("tag", doNotDo, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("description", doNotDo, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("genre", doNotDo, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_FactionMaterializationRepair_ShiningExactCrossLinks_UsesOnlyNamedAuthorityRoots()
    {
        const string coordinate = "shining_faction:faction_aurora_council";
        const string residentPath =
            "game_state/meta/guardian_abode_residents.json.residents[0].factionId";
        const string profilePath =
            "game_state/meta/afterlife_entity_profiles.json.profiles[0].factionIds[0]";
        const string sarefPath =
            "game_state/meta/main_story_saref_state.json.alliedFactionId";
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                residentPath,
                IssueSeverity.Error,
                "Shining faction resident link is missing.",
                code: "faction_materialization_resident_link_missing",
                actor: coordinate,
                section: "FactionMaterialization",
                expected: coordinate,
                actual: "missing"),
            new(
                profilePath,
                IssueSeverity.Error,
                "Shining faction afterlife profile link is missing.",
                code: "faction_materialization_profile_link_missing",
                actor: coordinate,
                section: "FactionMaterialization",
                expected: coordinate,
                actual: "missing"),
            new(
                sarefPath,
                IssueSeverity.Error,
                "Shining faction Saref story link is missing.",
                code: "faction_materialization_story_link_missing",
                actor: coordinate,
                section: "FactionMaterialization",
                expected: coordinate,
                actual: "missing")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("faction_materialization_repair", packet.GetProperty("kind").GetString());
        Assert.Equal("critical", packet.GetProperty("priority").GetString());
        Assert.Equal(
            new[] { coordinate },
            packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[]
            {
                "game_state/meta/afterlife_entity_profiles.json",
                "game_state/meta/guardian_abode_residents.json",
                "game_state/meta/main_story_saref_state.json",
                "game_state/meta/shining_abode_state.json"
            },
            packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[]
            {
                "Examples/E_CLI_Afterlife_Turns.txt",
                "OtherGuides/Afterlife_Contract_Matrix.md"
            },
            packet.GetProperty("templateRefs")
                .EnumerateArray()
                .Select(item => item.GetString())
                .OrderBy(item => item, StringComparer.Ordinal));

        var targetFiles = packet.GetProperty("targetFiles")
            .EnumerateArray()
            .Select(item => item.GetString() ?? string.Empty)
            .ToArray();
        Assert.DoesNotContain("game_state/meta/guardians.json", targetFiles);
        Assert.DoesNotContain(targetFiles, path => path.Contains("soul", StringComparison.OrdinalIgnoreCase));
        Assert.DoesNotContain(targetFiles, path => path.StartsWith("game_state/factions/", StringComparison.Ordinal));
        Assert.DoesNotContain(
            targetFiles,
            path => path.Contains("afterlife_spiritual_conflict_state.json", StringComparison.Ordinal));
        Assert.DoesNotContain(targetFiles, path => path.StartsWith("game_state/control/", StringComparison.Ordinal));

        Assert.Equal(
            new[] { profilePath, residentPath, sarefPath },
            packet.GetProperty("missingFields").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { profilePath, residentPath, sarefPath },
            packet.GetProperty("exactFieldCorrections")
                .EnumerateArray()
                .Select(correction => correction.GetProperty("path").GetString()));
    }

    [Theory]
    [InlineData(
        "shining_faction:faction_aurora_council",
        "game_state/meta/guardian_abode_residents.json.entries[0]",
        "game_state/meta/afterlife_entity_profiles.json",
        "game_state/meta/shining_abode_state.json",
        "game_state/meta/guardian_abode_residents.json")]
    [InlineData(
        "mortal_faction:faction_missing",
        "location:location_watch_road.factionControl[0].factionId",
        "game_state/world/current_location.json",
        "game_state/factions/faction_core.json",
        null)]
    public async Task WriteValidationRepairRequestAsync_FactionMaterializationRepair_TypedTargetMetadataIsHonored(
        string coordinate,
        string issuePath,
        string typedTarget,
        string baseTarget,
        string? pathDerivedTarget)
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                issuePath,
                IssueSeverity.Error,
                "Faction repair requires one exact related authority root.",
                code: "faction_materialization_section_missing",
                actor: coordinate,
                section: "FactionMaterialization",
                expected: "exact current authority",
                actual: "missing",
                repairTargetFiles: new[] { typedTarget },
                factionRepairClassification: FactionTouchKind.New)
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync(
            "game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(
            doc.RootElement.GetProperty("harnessRepairPackets")
                .EnumerateArray());
        var targetFiles = packet.GetProperty("targetFiles")
            .EnumerateArray()
            .Select(item => item.GetString())
            .ToArray();

        Assert.Contains(baseTarget, targetFiles);
        Assert.Contains(typedTarget, targetFiles);
        if (pathDerivedTarget != null)
            Assert.Contains(pathDerivedTarget, targetFiles);
        Assert.Contains(
            "new",
            packet.GetProperty("expectedShape")
                .EnumerateArray()
                .Select(item => item.GetString()));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_FactionMaterializationRepair_ExactGrouping_PreservesDistinctCoordinates()
    {
        const string mortalCoordinate = "mortal_faction:faction_receiptless_watch";
        const string shiningCoordinate = "shining_faction:faction_moon_choir";
        const string mortalPath =
            "game_state/factions/faction_custom.json.entries[0].materialization";
        const string shiningPath =
            "game_state/meta/shining_abode_state.json.factions[0].materialization";
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                mortalPath,
                IssueSeverity.Error,
                "Receipt-less Mortal faction state is obsolete.",
                code: "faction_materialization_obsolete_receiptless_state",
                actor: mortalCoordinate,
                section: "FactionMaterialization",
                expected: "complete materialization receipt",
                actual: "receipt-less obsolete faction state",
                factionRepairClassification:
                    FactionTouchKind.InvalidReceiptless),
            new(
                shiningPath,
                IssueSeverity.Error,
                "Shining faction materialization receipt is missing.",
                code: "faction_materialization_receipt_missing",
                actor: shiningCoordinate,
                section: "FactionMaterialization",
                expected: "complete materialization receipt",
                actual: "missing from a genuinely new faction",
                factionRepairClassification: FactionTouchKind.New)
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packets = doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray().ToArray();
        Assert.Equal(2, packets.Length);
        Assert.All(
            packets,
            packet => Assert.Equal(
                "faction_materialization_repair",
                packet.GetProperty("kind").GetString()));

        var mortalPacket = Assert.Single(
            packets,
            packet => packet.GetProperty("canonicalActorNames")
                .EnumerateArray()
                .Any(item => item.GetString() == mortalCoordinate));
        var shiningPacket = Assert.Single(
            packets,
            packet => packet.GetProperty("canonicalActorNames")
                .EnumerateArray()
                .Any(item => item.GetString() == shiningCoordinate));

        Assert.Equal(
            new[] { mortalCoordinate },
            mortalPacket.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { shiningCoordinate },
            shiningPacket.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[]
            {
                "game_state/factions/faction_core.json",
                "game_state/factions/faction_custom.json"
            },
            mortalPacket.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { "game_state/meta/shining_abode_state.json" },
            shiningPacket.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { mortalPath },
            mortalPacket.GetProperty("exactFieldCorrections")
                .EnumerateArray()
                .Select(correction => correction.GetProperty("path").GetString()));
        Assert.Equal(
            new[] { shiningPath },
            shiningPacket.GetProperty("exactFieldCorrections")
                .EnumerateArray()
                .Select(correction => correction.GetProperty("path").GetString()));

        var mortalExpectedShape = mortalPacket.GetProperty("expectedShape")
            .EnumerateArray()
            .Select(item => item.GetString())
            .ToArray();
        var shiningExpectedShape = shiningPacket.GetProperty("expectedShape")
            .EnumerateArray()
            .Select(item => item.GetString())
            .ToArray();
        Assert.Contains("invalid_receiptless", mortalExpectedShape);
        Assert.DoesNotContain("invalid_receiptless", shiningExpectedShape);
        Assert.Contains("new", shiningExpectedShape);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_FactionMaterializationRepair_MalformedCoordinates_DoNotBroadenValidPacket()
    {
        const string validCoordinate = "mortal_faction:faction_valid";
        const string validUnrelatedPath =
            "game_state/player/player.json.factionMaterialization";
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                validUnrelatedPath,
                IssueSeverity.Error,
                "A valid faction coordinate names an unrelated player root.",
                code: "faction_materialization_section_missing",
                actor: validCoordinate,
                section: "FactionMaterialization",
                expected: "bounded faction state",
                actual: "missing"),
            new(
                "game_state/factions/faction_resources.json.entries[0]",
                IssueSeverity.Error,
                "Faction materialization actor is missing.",
                code: "faction_materialization_section_missing",
                section: "FactionMaterialization",
                expected: "exact machine coordinate",
                actual: "missing actor"),
            new(
                "game_state/factions/faction_structure.json.entries[0]",
                IssueSeverity.Error,
                "Faction materialization actor has leading whitespace.",
                code: "faction_materialization_section_missing",
                actor: " mortal_faction:faction_padded",
                section: "FactionMaterialization",
                expected: "exact machine coordinate",
                actual: "padded actor"),
            new(
                "game_state/factions/faction_projects.json.entries[0]",
                IssueSeverity.Error,
                "Faction materialization actor has trailing whitespace.",
                code: "faction_materialization_section_missing",
                actor: "mortal_faction:faction_padded ",
                section: "FactionMaterialization",
                expected: "exact machine coordinate",
                actual: "padded actor"),
            new(
                "game_state/factions/faction_custom.json.entries[0]",
                IssueSeverity.Error,
                "Faction materialization actor has an empty suffix.",
                code: "faction_materialization_section_missing",
                actor: "mortal_faction:",
                section: "FactionMaterialization",
                expected: "exact machine coordinate",
                actual: "empty suffix"),
            new(
                "game_state/factions/faction_core.json.factions[9]",
                IssueSeverity.Error,
                "Faction materialization actor has an extra coordinate suffix.",
                code: "faction_materialization_section_missing",
                actor: "mortal_faction:faction_bad:extra",
                section: "FactionMaterialization",
                expected: "exact machine coordinate",
                actual: "extra colon suffix"),
            new(
                "game_state/factions/faction_chronicles.json.entries[0]",
                IssueSeverity.Error,
                "Faction materialization actor uses the wrong case.",
                code: "faction_materialization_section_missing",
                actor: "Mortal_faction:faction_wrong_case",
                section: "FactionMaterialization",
                expected: "exact machine coordinate",
                actual: "wrong case"),
            new(
                "game_state/meta/shining_abode_state.json.factions[0]",
                IssueSeverity.Error,
                "Faction materialization actor uses an unsupported domain.",
                code: "faction_materialization_section_missing",
                actor: "faction:faction_wrong_domain",
                section: "FactionMaterialization",
                expected: "exact machine coordinate",
                actual: "wrong domain")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("faction_materialization_repair", packet.GetProperty("kind").GetString());
        Assert.Equal(
            new[] { validCoordinate },
            packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { "game_state/factions/faction_core.json" },
            packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { validUnrelatedPath },
            packet.GetProperty("missingFields").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { validUnrelatedPath },
            packet.GetProperty("exactFieldCorrections")
                .EnumerateArray()
                .Select(correction => correction.GetProperty("path").GetString()));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_FactionMaterializationRepair_NonOrdinalIssueCodes_DoNotRoute()
    {
        const string coordinate = "mortal_faction:faction_issue_code_guard";
        var issueCodes = new[]
        {
            "Faction_materialization_section_missing",
            "faction_Materialization_section_missing",
            "faction_materialization",
            "factionmaterialization_section_missing",
            "faction_existing_full_resend_Forbidden",
            "faction_existing_full_resend_forbidden_extra"
        };
        var engine = CreateGameEngine();
        var issues = issueCodes
            .Select((code, index) => new ValidationIssue(
                $"game_state/factions/faction_core.json.factions[{index}].materialization",
                IssueSeverity.Error,
                "Near-match Faction Materialization issue code must not route.",
                code: code,
                actor: coordinate,
                section: "FactionMaterialization",
                expected: "exact ordinal closed issue family",
                actual: code))
            .ToList();

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        Assert.Empty(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_FactionMaterializationRepair_ClassificationPropagation_UsesOnlyTypedValuesPerCoordinate()
    {
        const string acceptedCoordinate = "mortal_faction:faction_classifications_accepted";
        const string rejectedCoordinate = "mortal_faction:faction_classifications_rejected";
        const string shiningCoordinate = "shining_faction:faction_classifications_new";
        var acceptedCases = new[]
        {
            FactionTouchKind.New,
            FactionTouchKind.AlreadyMaterialized,
            FactionTouchKind.InvalidReceiptless
        };
        var rejectedValues = new[]
        {
            "New",
            "INVALID_RECEIPTLESS",
            "already_materialized because a receipt exists",
            "invalid receiptless"
        };
        var issues = new List<ValidationIssue>();
        for (var index = 0; index < acceptedCases.Length; index++)
        {
            issues.Add(new ValidationIssue(
                $"game_state/factions/faction_core.json.factions[0].materialization.classification[{index}]",
                IssueSeverity.Error,
                "Exact Faction Materialization classification evidence.",
                code: "faction_materialization_classification_invalid",
                actor: acceptedCoordinate,
                section: "FactionMaterialization",
                expected: "not typed classification authority",
                actual: "new",
                factionRepairClassification: acceptedCases[index]));
        }

        for (var index = 0; index < rejectedValues.Length; index++)
        {
            issues.Add(new ValidationIssue(
                $"game_state/factions/faction_core.json.factions[1].materialization.classification[{index}]",
                IssueSeverity.Error,
                "Non-ordinal or fuzzy classification evidence.",
                code: "faction_materialization_classification_invalid",
                actor: rejectedCoordinate,
                section: "FactionMaterialization",
                expected: "one exact closed classification",
                actual: rejectedValues[index]));
        }

        const string shiningPath =
            "game_state/meta/shining_abode_state.json.factions[0].materialization.classification";
        issues.Add(new ValidationIssue(
            shiningPath,
            IssueSeverity.Error,
            "Exact Shining Faction Materialization classification evidence.",
            code: "faction_materialization_classification_invalid",
            actor: shiningCoordinate,
            section: "FactionMaterialization",
            expected: "not typed classification authority",
            actual: "not a classification",
            factionRepairClassification: FactionTouchKind.New));

        var engine = CreateGameEngine();
        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packets = doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray().ToArray();
        Assert.Equal(3, packets.Length);
        Assert.All(
            packets,
            packet => Assert.Equal(
                "faction_materialization_repair",
                packet.GetProperty("kind").GetString()));

        var acceptedPacket = Assert.Single(
            packets,
            packet => packet.GetProperty("canonicalActorNames")
                .EnumerateArray()
                .Any(item => item.GetString() == acceptedCoordinate));
        var rejectedPacket = Assert.Single(
            packets,
            packet => packet.GetProperty("canonicalActorNames")
                .EnumerateArray()
                .Any(item => item.GetString() == rejectedCoordinate));
        var shiningPacket = Assert.Single(
            packets,
            packet => packet.GetProperty("canonicalActorNames")
                .EnumerateArray()
                .Any(item => item.GetString() == shiningCoordinate));

        Assert.Equal(
            new[] { acceptedCoordinate },
            acceptedPacket.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { rejectedCoordinate },
            rejectedPacket.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { shiningCoordinate },
            shiningPacket.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { "game_state/factions/faction_core.json" },
            acceptedPacket.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { "game_state/factions/faction_core.json" },
            rejectedPacket.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { "game_state/meta/shining_abode_state.json" },
            shiningPacket.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var acceptedPaths = Enumerable.Range(0, acceptedCases.Length)
            .Select(index =>
                $"game_state/factions/faction_core.json.factions[0].materialization.classification[{index}]")
            .ToArray();
        var rejectedPaths = Enumerable.Range(0, rejectedValues.Length)
            .Select(index =>
                $"game_state/factions/faction_core.json.factions[1].materialization.classification[{index}]")
            .ToArray();
        Assert.Equal(
            acceptedPaths,
            acceptedPacket.GetProperty("exactFieldCorrections")
                .EnumerateArray()
                .Select(correction => correction.GetProperty("path").GetString()));
        Assert.Equal(
            rejectedPaths,
            rejectedPacket.GetProperty("exactFieldCorrections")
                .EnumerateArray()
                .Select(correction => correction.GetProperty("path").GetString()));
        Assert.Equal(
            new[] { shiningPath },
            shiningPacket.GetProperty("exactFieldCorrections")
                .EnumerateArray()
                .Select(correction => correction.GetProperty("path").GetString()));

        var exactClassifications = new[]
        {
            "already_materialized",
            "invalid_receiptless",
            "new"
        };
        var acceptedExpectedShape = acceptedPacket.GetProperty("expectedShape")
            .EnumerateArray()
            .Select(item => item.GetString() ?? string.Empty)
            .ToArray();
        var rejectedExpectedShape = rejectedPacket.GetProperty("expectedShape")
            .EnumerateArray()
            .Select(item => item.GetString() ?? string.Empty)
            .ToArray();
        var shiningExpectedShape = shiningPacket.GetProperty("expectedShape")
            .EnumerateArray()
            .Select(item => item.GetString() ?? string.Empty)
            .ToArray();
        Assert.Equal(
            exactClassifications,
            acceptedExpectedShape.Where(item =>
                exactClassifications.Contains(item, StringComparer.Ordinal)));
        Assert.DoesNotContain(
            rejectedExpectedShape,
            item => exactClassifications.Contains(item, StringComparer.Ordinal));
        Assert.Equal(
            new[] { "new" },
            shiningExpectedShape.Where(item =>
                exactClassifications.Contains(item, StringComparer.Ordinal)));
        Assert.All(
            rejectedValues,
            rejectedValue => Assert.DoesNotContain(rejectedValue, rejectedExpectedShape));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_FactionMaterializationRepair_MissingFields_RequireExactLowercaseMissingComponent()
    {
        const string coordinate = "mortal_faction:faction_missing_components";
        var cases = new[]
        {
            (
                Path: "game_state/factions/faction_core.json.factions[0].materialization.components[0]",
                Code: "faction_materialization_section_missing"),
            (
                Path: "game_state/factions/faction_core.json.factions[0].materialization.components[1]",
                Code: "faction_materialization_missing_section"),
            (
                Path: "game_state/factions/faction_core.json.factions[0].materialization.components[2]",
                Code: "faction_materialization_section_Missing"),
            (
                Path: "game_state/factions/faction_core.json.factions[0].materialization.components[3]",
                Code: "faction_materialization_section_missingness"),
            (
                Path: "game_state/factions/faction_core.json.factions[0].materialization.components[4]",
                Code: "faction_materialization_section_notmissing"),
            (
                Path: "game_state/factions/faction_core.json.factions[0].materialization.components[5]",
                Code: "faction_materialization_section_premissingpost")
        };
        var issues = cases
            .Select(item => new ValidationIssue(
                item.Path,
                IssueSeverity.Error,
                "Faction Materialization missing-component boundary.",
                code: item.Code,
                actor: coordinate,
                section: "FactionMaterialization",
                expected: "exact lowercase missing component",
                actual: "invalid"))
            .ToList();
        var engine = CreateGameEngine();

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("faction_materialization_repair", packet.GetProperty("kind").GetString());
        Assert.Equal(
            new[] { coordinate },
            packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { "game_state/factions/faction_core.json" },
            packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            new[] { cases[0].Path, cases[1].Path },
            packet.GetProperty("missingFields").EnumerateArray().Select(item => item.GetString()));
        Assert.Equal(
            cases.Select(item => item.Path),
            packet.GetProperty("exactFieldCorrections")
                .EnumerateArray()
                .Select(correction => correction.GetProperty("path").GetString()));
        Assert.Equal(
            cases.Select(item => item.Code),
            packet.GetProperty("exactFieldCorrections")
                .EnumerateArray()
                .Select(correction => correction.GetProperty("code").GetString()));
    }

    [Theory]
    [InlineData(
        "faction_materialization_section_missing",
        "mortal_faction:faction_closed_prefix",
        "game_state/factions/faction_projects.json.entries[0].materialization",
        "game_state/factions/faction_core.json",
        "game_state/factions/faction_projects.json",
        "new")]
    [InlineData(
        "faction_materialization_obsolete_receiptless_state",
        "shining_faction:faction_closed_receiptless",
        "game_state/meta/shining_abode_state.json.factions[0].materialization",
        "game_state/meta/shining_abode_state.json",
        null,
        "invalid_receiptless")]
    [InlineData(
        "faction_existing_full_resend_forbidden",
        "mortal_faction:faction_closed_resend",
        "game_state/factions/faction_core.json.factions[0].materialization",
        "game_state/factions/faction_core.json",
        null,
        "already_materialized")]
    public async Task WriteValidationRepairRequestAsync_FactionMaterializationRepair_ClosedIssueFamilies_AreRouted(
        string code,
        string coordinate,
        string issuePath,
        string primaryTarget,
        string? secondaryTarget,
        string classification)
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                issuePath,
                IssueSeverity.Error,
                "Faction materialization requires a bounded repair.",
                code: code,
                actor: coordinate,
                section: "FactionMaterialization",
                expected: "one exact bounded repair",
                actual: "human-readable diagnostic prose",
                factionRepairClassification: classification switch
                {
                    "new" => FactionTouchKind.New,
                    "already_materialized" =>
                        FactionTouchKind.AlreadyMaterialized,
                    "invalid_receiptless" =>
                        FactionTouchKind.InvalidReceiptless,
                    _ => throw new InvalidOperationException(
                        $"Unsupported test classification: {classification}")
                })
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("faction_materialization_repair", packet.GetProperty("kind").GetString());
        Assert.Equal("critical", packet.GetProperty("priority").GetString());
        Assert.Equal(
            new[] { coordinate },
            packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var expectedTargets = new List<string> { primaryTarget };
        if (secondaryTarget != null)
            expectedTargets.Add(secondaryTarget);
        expectedTargets.Sort(StringComparer.Ordinal);
        Assert.Equal(
            expectedTargets,
            packet.GetProperty("targetFiles")
                .EnumerateArray()
                .Select(item => item.GetString() ?? string.Empty));

        var correction = Assert.Single(packet.GetProperty("exactFieldCorrections").EnumerateArray());
        Assert.Equal(issuePath, correction.GetProperty("path").GetString());
        Assert.Equal(code, correction.GetProperty("code").GetString());
        Assert.Contains(
            classification,
            packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString()));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_FactionIdentityErrors_AddsHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/factions/faction_core.json.factions[0].factionId",
                IssueSeverity.Error,
                "Full faction object references an unknown permanent factionId.",
                code: "faction_full_object_unknown_faction_id",
                section: "Factions",
                expected: "existing permanent factionId from faction_core.json",
                actual: "faction_merchant_guild"),
            new(
                "game_state/factions/faction_core.json.factions[0].initialId",
                IssueSeverity.Error,
                "Full faction object uses initialId for an existing faction.",
                code: "faction_full_object_existing_requires_faction_id",
                section: "Factions",
                expected: "permanent factionId for existing faction",
                actual: "initialId=temp-faction-merchant-guild-eternia"),
            new(
                "game_state/factions/faction_custom.json.entries[0]",
                IssueSeverity.Error,
                "Canonical faction sidecar entry requires a permanent factionId.",
                code: "canonical_faction_sidecar_requires_permanent_faction_id",
                section: "Factions",
                expected: "existing permanent factionId from faction_core.json",
                actual: "Null")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 3 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("faction_identity_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/factions/faction_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/factions/faction_custom.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/control/pending_turn_snapshot/game_state/factions/faction_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("pending_turn_snapshot", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("factionId = null", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("initialId", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("isNewFaction = true", StringComparison.OrdinalIgnoreCase));

        Assert.Contains(
            "Templates/MORTAL_FACTION_UPDATE_TEMPLATE.md",
            packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("factions[]", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("factionId", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("sidecar", StringComparison.OrdinalIgnoreCase));

        var safeRules = packet.GetProperty("safeCorrectionRules").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(safeRules, item => item.Contains("create", StringComparison.OrdinalIgnoreCase) && item.Contains("missing faction", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(safeRules, item => item.Contains("remove", StringComparison.OrdinalIgnoreCase) && item.Contains("sidecar", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(safeRules, item => item.Contains("existing canonical factionId", StringComparison.OrdinalIgnoreCase));

        Assert.Contains(
            packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty),
            item => item.Contains("invent a permanent factionId", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_FactionResourceEntryShapeErrors_AddsHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/factions/faction_resources.json.entries[0]",
                IssueSeverity.Error,
                "Canonical faction resource entries require full object shape.",
                code: "canonical_faction_resource_entry_missing_required_fields",
                section: "Factions",
                expected: "resourceId/name/displayName/type/value/source/visibility and upkeep fields for metaResources",
                actual: "missing value, source, visibility, upkeep")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 2 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_faction_resource_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/factions/faction_resources.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Templates/MORTAL_FACTION_UPDATE_TEMPLATE.md", packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("canonical_faction_resource_entry_missing_required_fields", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("metaResources", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("strategicGoods", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("MORTAL_FACTION_UPDATE_TEMPLATE", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("full resource object", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Complete-BoeValidationRepair", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_LegacyLocationTransitionCodesDoNotEmitLegacyPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/world/current_location.json.locationId",
                IssueSeverity.Error,
                "Current location references an unknown location id.",
                code: "current_location_unknown_location_id",
                section: "WorldMap",
                expected: "current location id must exist in world map",
                actual: "loc_family_library"),
            new(
                "game_state/npcs/npc_core.json.NPCs[0].currentLocationId",
                IssueSeverity.Error,
                "NPC currentLocationId references an unknown location id.",
                code: "npc_unknown_current_location_id",
                actor: "Мариус де Гран",
                section: "NPC",
                expected: "known world map location id",
                actual: "loc_family_library"),
            new(
                "game_state/world/world_map.json.newLocations[1].coordinates",
                IssueSeverity.Error,
                "Two same-turn new locations use duplicate coordinates.",
                code: "world_map_new_location_coordinates_duplicate_same_turn",
                section: "WorldMap",
                expected: "unique coordinates for each same-turn new location",
                actual: "x=2,y=1,z=0")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packets = doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray().ToArray();
        Assert.DoesNotContain(packets, packet =>
            packet.GetProperty("kind").GetString() is
                "mortal_location_transition_repair" or
                "mortal_world_map_adjacency_repair");
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_LegacyLocationShapeCodesDoNotEmitLegacyPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/world/world_map.json.newLocations[0].activeThreats",
                IssueSeverity.Error,
                "Location is missing activeThreats array.",
                code: "location_missing_active_threat_array",
                section: "WorldMap",
                expected: "activeThreats as array",
                actual: "missing"),
            new(
                "game_state/world/world_map.json.newLocations[0].adjacencyMap",
                IssueSeverity.Error,
                "Location is missing adjacencyMap array.",
                code: "location_missing_adjacency_array",
                section: "WorldMap",
                expected: "adjacencyMap as array",
                actual: "missing"),
            new(
                "game_state/world/world_map.json.newLocations[0].internalDifficultyProfile",
                IssueSeverity.Error,
                "Location is missing internal difficulty profile.",
                code: "location_missing_difficulty_profile",
                section: "WorldMap",
                expected: "internalDifficultyProfile and externalDifficultyProfile",
                actual: "missing"),
            new(
                "game_state/world/world_map.json.newLocations[0].locationStorages",
                IssueSeverity.Error,
                "Location is missing locationStorages array.",
                code: "location_missing_storage_array",
                section: "WorldMap",
                expected: "locationStorages as array",
                actual: "missing"),
            new(
                "game_state/world/world_map.json.newLinks[0]",
                IssueSeverity.Error,
                "World-map new link is missing preview fields.",
                code: "world_map_new_link_missing_required_fields",
                section: "WorldMap",
                expected: "targetName, targetCoordinates, estimatedInternalDifficultyProfile, estimatedExternalDifficultyProfile",
                actual: "missing estimated profiles")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packets = doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray().ToArray();
        Assert.DoesNotContain(packets, packet =>
            packet.GetProperty("kind").GetString() is
                "mortal_location_transition_repair" or
                "mortal_world_map_adjacency_repair");
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_LegacyAdjacencyCodesDoNotEmitLegacyPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/world/world_map.json.adjacency[1].targetLocationId",
                IssueSeverity.Error,
                "World map adjacency points to an unknown target location.",
                code: "world_map_adjacency_unknown_target",
                section: "WorldMap",
                expected: "targetLocationId must reference an existing locationId or a same-turn newLocations.initialId",
                actual: "loc_salt_awning"),
            new(
                "game_state/world/world_map.json.linkUpdates[0].sourceLocationId",
                IssueSeverity.Error,
                "World map link update source is unknown.",
                code: "world_map_link_update_unknown_source",
                section: "WorldMap",
                expected: "sourceLocationId must reference an existing locationId",
                actual: "loc_hidden_panel")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packets = doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray().ToArray();
        Assert.DoesNotContain(packets, packet =>
            packet.GetProperty("kind").GetString() is
                "mortal_location_transition_repair" or
                "mortal_world_map_adjacency_repair");
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_LegacyOutdoorBiomeCodeDoesNotEmitLegacyPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/world/current_location.json.biome",
                IssueSeverity.Error,
                "Outdoor location обязан содержать biome.",
                code: "location_outdoor_biome_missing",
                section: "Location",
                expected: "TemperateForest | ColdForest | Swamp | Urban | Plains | Mountains | Desert | Coast | Unique",
                actual: "missing",
                repairHint: "Choose the canonical biome that matches the scene.")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packets = doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray().ToArray();
        Assert.DoesNotContain(packets, packet =>
            packet.GetProperty("kind").GetString() is
                "mortal_location_transition_repair" or
                "mortal_world_map_adjacency_repair");
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalNpcLocationErrors_AddsHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/npcs/npc_core.json.NPCsInScene[0].currentLocationId",
                IssueSeverity.Error,
                "Same-turn scene NPC must not use currentLocationId.",
                code: "npc_same_turn_initial_location_requires_null_current_location",
                actor: "Мариус де Гран",
                section: "UpdateNPCs",
                expected: "initialLocationId=current location and currentLocationId=null",
                actual: "currentLocationId=loc_library"),
            new(
                "game_state/npcs/npc_core.json.NPCsInScene[0].initialLocationId",
                IssueSeverity.Error,
                "Current location scene NPC is missing the same-turn initial location id.",
                code: "current_location_new_scene_missing_initial_id_for_npc_scene",
                actor: "Мариус де Гран",
                section: "UpdateNPCs",
                expected: "initialLocationId from current location",
                actual: "missing")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_npc_location_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Templates/MORTAL_NPC_UPDATE_TEMPLATE.md", packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Мариус де Гран", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("initialLocationId", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("currentLocationId", StringComparison.OrdinalIgnoreCase) && step.Contains("null", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("NPCsInScene", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalNpcScopeErrors_AddsHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/npcs/npc_core.json.UpdateNPCs[1]",
                IssueSeverity.Error,
                "Structured NPC update is outside declared relevant actors.",
                code: "structured_npc_update_out_of_scope",
                actor: "Мальчишка-посыльный дома Виренто",
                section: "UpdateNPCs",
                expected: "'Мальчишка-посыльный дома Виренто' declared in Relevant actors",
                actual: "UpdateNPCs changed actor outside declared scope")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_npc_scope_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("output/debug_logs.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Templates/MORTAL_NPC_UPDATE_TEMPLATE.md", packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Мальчишка-посыльный дома Виренто", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("Relevant actors", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("reasoning", StringComparison.OrdinalIgnoreCase));

        var safeRules = packet.GetProperty("safeCorrectionRules").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(safeRules, item => item.Contains("add", StringComparison.OrdinalIgnoreCase) && item.Contains("Relevant actors", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(safeRules, item => item.Contains("remove", StringComparison.OrdinalIgnoreCase) && item.Contains("structured", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalRelevantActorMissingPersistence_AddsNpcSpecificHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Mortal World relevant actor 'Матео' declared in NPC scope but has no persistent Mortal surface",
                code: "mortal_relevant_actor_missing_persistence",
                actor: "Матео",
                section: "npc_scope",
                expected: "matching NPC/faction/quest/inventory persistence in canonical state or structured same-turn updates",
                actual: "actor appears only in gm_thoughts_markdown / narrative reasoning")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_npc_scope_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("output/debug_logs.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Templates/MORTAL_NPC_UPDATE_TEMPLATE.md", packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Матео", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step =>
            step.Contains("persistent", StringComparison.OrdinalIgnoreCase) &&
            step.Contains("NPC", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_TrainingShowcaseStaleSnapshot_AddsExactHashHarnessPacket()
    {
        var engine = CreateGameEngine();
        var expectedHash = "401ba6b8c2d057a629cf1bf97820fb050c6b1ec25e89e7ee853e85f0c3324079";
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/npcs/npc_core.json.UpdateNPCs[0].trainingShowcase.sourceActorSnapshotHash",
                IssueSeverity.Error,
                "Витрина обучения устарела: sourceActorSnapshotHash не совпадает с текущим профилем источника.",
                code: "training_showcase_stale_source_actor_snapshot",
                actor: "Селина Орвейн",
                section: "trainingShowcase",
                expected: expectedHash,
                actual: "stale-hash",
                repairHint: "Запиши свежий sourceActorSnapshotHash.")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("training_showcase_snapshot_hash_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/control/pending_training_showcase_requests.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Examples/E_CLI_Training_Showcases.txt", packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Селина Орвейн", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var correction = Assert.Single(packet.GetProperty("exactFieldCorrections").EnumerateArray());
        Assert.Equal("game_state/npcs/npc_core.json.UpdateNPCs[0].trainingShowcase.sourceActorSnapshotHash", correction.GetProperty("path").GetString());
        Assert.Equal(expectedHash, correction.GetProperty("expected").GetString());
        Assert.Equal("stale-hash", correction.GetProperty("actual").GetString());

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, item => item.Contains("pending_training_showcase_requests.json", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, item => item.Contains("Complete-BoeValidationRepair", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_PendingPassiveTrainingSkillEvolution_AddsTargetKindHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/player/skill_mastery.json.skillMasteryChanges[0].skillName",
                IssueSeverity.Error,
                "skillMasteryChanges не может ссылаться на навык, которого нет в canonical active skills state",
                code: "skill_mastery_unknown_active_skill",
                actor: "Чтение следов",
                section: "Skills.Active",
                expected: "existing skillName from game_state/player/skills_active.json",
                actual: "Чтение следов",
                repairHint: "Сохраняй mastery только для реально существующих active skills.")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_training_skill_evolution_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/control/pending_training_showcase_requests.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/player/skills_passive.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/player/skill_mastery.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Examples/E_CLI_Training_Showcases.txt", packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("details.targetKind", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("passive_skill_mastery", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("passiveSkillChanges", StringComparison.OrdinalIgnoreCase));

        var safeRules = packet.GetProperty("safeCorrectionRules").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(safeRules, item => item.Contains("Do not charge", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(safeRules, item => item.Contains("structuredBonuses", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, item => item.Contains("pending_training_showcase_requests.json", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, item => item.Contains("details.targetKind", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, item => item.Contains("remove", StringComparison.OrdinalIgnoreCase) && item.Contains("skillMasteryChanges", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, item => item.Contains("Complete-BoeValidationRepair", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalSkillProgressionShapeErrors_AddsConcreteHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/player/skills_active.json.activeSkillChanges",
                IssueSeverity.Error,
                "activeSkillChanges должен быть массивом объектов.",
                code: "expected_array_of_objects",
                actor: "Ножевой бой",
                section: "Skills.Active",
                expected: "array<object>",
                actual: "Object",
                repairHint: "Запиши изменение навыка как массив объектов, даже если изменение одно."),
            new(
                "game_state/player/skill_mastery.json.skillMasteryChanges",
                IssueSeverity.Error,
                "skillMasteryChanges должен быть массивом.",
                code: "expected_array",
                actor: "Ножевой бой",
                section: "Skills.Mastery",
                expected: "JSON array",
                actual: "Object",
                repairHint: "Запиши изменение мастерства как массив, даже если изменение одно.")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 2 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_skill_progression_shape_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/control/pending_training_showcase_requests.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/player/skills_active.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/player/skills_passive.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/player/skill_mastery.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Templates/MORTAL_SKILL_PROGRESSION_TEMPLATE.md", packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Ножевой бой", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("activeSkillChanges", StringComparison.OrdinalIgnoreCase) && item.Contains("array", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("skillMasteryChanges", StringComparison.OrdinalIgnoreCase) && item.Contains("array", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("pending_training_showcase_requests.json", StringComparison.OrdinalIgnoreCase));

        var safeRules = packet.GetProperty("safeCorrectionRules").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(safeRules, item => item.Contains("Do not charge", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(safeRules, item => item.Contains("single object", StringComparison.OrdinalIgnoreCase) && item.Contains("array", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, item => item.Contains("pending_training_showcase_requests.json", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, item => item.Contains("wrap", StringComparison.OrdinalIgnoreCase) && item.Contains("array", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, item => item.Contains("Complete-BoeValidationRepair", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_EmptyRelevantActorsScopeError_AddsExecutableHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Mode 'Mixed' requires at least one relevant actor.",
                code: "empty_relevant_actors_for_mode",
                section: "npc_scope",
                expected: "At least one relevant actor",
                actual: "empty relevant actor list")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("npc_scope_declaration_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("output/debug_logs.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("World-progression", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("Mixed", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("Scene-local", StringComparison.OrdinalIgnoreCase));

        var template = packet.GetProperty("debugLogTemplate").GetString() ?? string.Empty;
        Assert.Contains("## NPC Scope", template, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("Relevant actors", template, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("Why relevant", template, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("Actors outside scope", template, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("### <actor name>", template, StringComparison.OrdinalIgnoreCase);

        var doNotDo = packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(doNotDo, item => item.Contains("new turn", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalNpcKnownSceneLocationErrors_AddsExecutableHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/npcs/npc_core.json.NPCsInScene[0].currentLocationId",
                IssueSeverity.Error,
                "NPCsInScene entry for a known current scene location must carry currentLocationId.",
                code: "npc_scene_missing_current_location_id",
                actor: "Лира Нериль",
                section: "NPCsInScene",
                expected: "currentLocationId = loc_life_001_start",
                actual: "missing")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_npc_location_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("Лира Нериль", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("known current scene location", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("currentLocationId = loc_life_001_start", StringComparison.OrdinalIgnoreCase));
        Assert.DoesNotContain(steps, step => step.Contains("currentLocationId to JSON null", StringComparison.OrdinalIgnoreCase));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("known current location", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("same-turn new location", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalNpcExistingInventoryResend_DistinguishesAllLifecycleCases()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/npcs/npc_core.json.UpdateNPCs[0].inventory",
                IssueSeverity.Error,
                "UpdateNPCs must not resend inventory for existing NPC.",
                code: "npc_existing_inventory_resend_forbidden",
                actor: "Миртан Велор",
                section: "NPCInventory",
                expected: "Use NPCInventoryAdds/Updates/Removals for existing NPC inventory changes",
                actual: "inventory: []")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_npc_inventory_update_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Миртан Велор", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var guidance = string.Join(
            Environment.NewLine,
            new[] { "expectedShape", "safeCorrectionRules", "steps", "doNotDo" }
                .SelectMany(property => packet.GetProperty(property).EnumerateArray())
                .Select(item => item.GetString() ?? string.Empty));
        Assert.DoesNotContain(
            "remove only the forbidden inventory resend while preserving any other validated update fields",
            guidance,
            StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain(
            "remove the forbidden inventory resend or remove the whole",
            guidance,
            StringComparison.OrdinalIgnoreCase);
        Assert.Contains("genuinely new NPC", guidance, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("ordinary existing NPC", guidance, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("true legacy promotion", guidance, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("remove the whole ordinary-existing full-object resend", guidance, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("skill, inventory, relationship, journal, activity, equipment/resource", guidance, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("main-GM rollback/repair path", guidance, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("exact semantically unchanged validated pre-turn inventory snapshot", guidance, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("NPCInventoryAdds", guidance, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("Do not remove the schema-required inventory", guidance, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("Remove inventory from UpdateNPCs for every existing NPC", guidance, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("Do not keep inventory: []", guidance, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalNpcReasoningLocationErrors_TargetsDebugLog()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "NPC reasoning block is missing current location.",
                code: "missing_actor_current_location",
                actor: "Ирен Соль",
                section: "npc_reasoning",
                expected: "Current location / Текущая локация / currentLocationId line inside actor block",
                actual: "missing")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_npc_location_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("output/debug_logs.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.DoesNotContain("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Ирен Соль", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("output/debug_logs.json", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("current location", StringComparison.OrdinalIgnoreCase) || step.Contains("Текущ", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalNpcJournalReferenceErrors_AddsReferencePacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "output/structured_state_updates.json.npcJournals[0]",
                IssueSeverity.Error,
                "NPC journal references an unknown NPC.",
                code: "npc_journal_unknown_npc_reference",
                actor: "Ночной посыльный",
                section: "NPCJournals",
                expected: "existing NPCId/NPCName from pre-turn/current npc_core.json",
                actual: "npc_night_messenger")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_npc_reference_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Templates/MORTAL_NPC_UPDATE_TEMPLATE.md", packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Ночной посыльный", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("NPCJournals", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("existing NPC", StringComparison.OrdinalIgnoreCase) || step.Contains("full NPC", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalNpcFullObjectErrors_AddsHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/npcs/npc_core.json.NPCs[0]",
                IssueSeverity.Error,
                "Full NPC object is missing required fields.",
                code: "npc_full_object_missing_required_fields",
                actor: "Ирен Соль",
                section: "UpdateNPCs",
                expected: "full NPC object with profile, social, location, relationshipLock, goals, personalityTraits, attitude, culturalStance",
                actual: "missing worldview, race, class, appearanceDescription, inventory")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_npc_full_object_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Templates/MORTAL_NPC_UPDATE_TEMPLATE.md", packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Ирен Соль", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("inventory", packet.GetProperty("missingFields").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("worldview", packet.GetProperty("missingFields").EnumerateArray().Select(item => item.GetString()));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("full NPC object", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("relationshipLock", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("goals", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("personalityTraits", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("inventory", StringComparison.OrdinalIgnoreCase) && step.Contains("[]", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task CollectPlayerFacingOutputStaleAfterCanonicalRepairIssues_UsesExplicitBoundaryWithoutLegacyRequest()
    {
        await WriteJsonAsync("output/narrative_response.json", new
        {
            response = "Старый ответ до ремонта.",
            timestamp = "2026-07-10T07:30:00Z"
        });
        var boundary = DateTime.UtcNow.AddMinutes(1);
        File.SetLastWriteTimeUtc(_fs.ResolvePath("output/narrative_response.json"), boundary.AddMinutes(-1));
        _fs.DeleteFile("game_state/control/validation_repair_request.json");
        var repairedErrors = new List<ValidationIssue>
        {
            new(
                "game_state/world/weather.json",
                IssueSeverity.Error,
                "Canonical weather was repaired.",
                code: "normalized_weather_missing_description")
        };
        var engine = CreateGameEngine();
        var method = typeof(GameEngine).GetMethod(
            "CollectPlayerFacingOutputStaleAfterCanonicalRepairIssues",
            BindingFlags.Instance | BindingFlags.NonPublic);

        Assert.NotNull(method);
        var issues = Assert.IsType<List<ValidationIssue>>(method!.Invoke(
            engine,
            new object[] { repairedErrors, boundary }));

        Assert.Contains(issues, issue =>
            string.Equals(
                issue.Code,
                "accepted_turn_stale_player_facing_output_after_canonical_repair",
                StringComparison.Ordinal));
    }

    [Fact]
    public async Task CollectPlayerFacingOutputStaleAfterCanonicalRepairIssues_EqualBoundaryIsStale()
    {
        await WriteJsonAsync("output/narrative_response.json", new
        {
            response = "Ответ записан одновременно с canonical repair.",
            timestamp = "2026-07-10T07:30:00Z"
        });
        var boundary = new DateTime(2026, 7, 10, 7, 31, 0, DateTimeKind.Utc);
        File.SetLastWriteTimeUtc(_fs.ResolvePath("output/narrative_response.json"), boundary);
        var repairedErrors = new List<ValidationIssue>
        {
            new(
                "game_state/world/weather.json",
                IssueSeverity.Error,
                "Canonical weather was repaired.",
                code: "normalized_weather_missing_description")
        };
        var engine = CreateGameEngine();

        var issues = InvokePrivateValue<List<ValidationIssue>>(
            engine,
            "CollectPlayerFacingOutputStaleAfterCanonicalRepairIssues",
            repairedErrors,
            boundary);

        Assert.Contains(issues, issue =>
            string.Equals(
                issue.Code,
                "accepted_turn_stale_player_facing_output_after_canonical_repair",
                StringComparison.Ordinal));
    }

    [Fact]
    public async Task ResolveCanonicalRepairOutputFreshnessBoundaryUtc_UsesLatestActualTargetWrite()
    {
        const string firstTarget = "game_state/world/weather.json";
        const string secondTarget = "game_state/meta/soul_state.json";
        await WriteJsonAsync(firstTarget, new { description = "Туман рассеялся." });
        await WriteJsonAsync(secondTarget, new { soulFormDescription = "Серебристый силуэт." });

        var repairStartedAtUtc = DateTime.UtcNow.AddMinutes(-3);
        var firstWriteUtc = repairStartedAtUtc.AddMinutes(1);
        var latestWriteUtc = repairStartedAtUtc.AddMinutes(2);
        File.SetLastWriteTimeUtc(_fs.ResolvePath(firstTarget), firstWriteUtc);
        File.SetLastWriteTimeUtc(_fs.ResolvePath(secondTarget), latestWriteUtc);

        var repairedErrors = new List<ValidationIssue>
        {
            new(
                $"{firstTarget}.description",
                IssueSeverity.Error,
                "Weather repaired.",
                code: "normalized_weather_missing_description"),
            new(
                $"{secondTarget}.soulFormDescription",
                IssueSeverity.Error,
                "Soul form repaired.",
                code: "soul_form_description_invalid_shape")
        };

        var boundary = InvokePrivateValue<DateTime>(
            CreateGameEngine(),
            "ResolveCanonicalRepairOutputFreshnessBoundaryUtc",
            repairedErrors,
            repairStartedAtUtc);

        Assert.Equal(latestWriteUtc, boundary);
    }

    [Fact]
    public async Task ResolveCanonicalRepairOutputFreshnessBoundaryUtc_UnobservableTargetFailsOutputFreshnessClosed()
    {
        await WriteJsonAsync("output/narrative_response.json", new
        {
            response = "Ответ создан до ненаблюдаемого canonical repair.",
            timestamp = "2026-07-10T07:30:00Z"
        });
        var repairStartedAtUtc = DateTime.UtcNow.AddMinutes(-1);
        File.SetLastWriteTimeUtc(
            _fs.ResolvePath("output/narrative_response.json"),
            repairStartedAtUtc);
        var repairedErrors = new List<ValidationIssue>
        {
            new(
                "game_state/world/missing_canonical_target.json.value",
                IssueSeverity.Error,
                "Canonical target repair could not be observed.",
                code: "missing_canonical_target_repaired_elsewhere")
        };
        var engine = CreateGameEngine();

        var boundary = InvokePrivateValue<DateTime>(
            engine,
            "ResolveCanonicalRepairOutputFreshnessBoundaryUtc",
            repairedErrors,
            repairStartedAtUtc);
        var issues = InvokePrivateValue<List<ValidationIssue>>(
            engine,
            "CollectPlayerFacingOutputStaleAfterCanonicalRepairIssues",
            repairedErrors,
            boundary);

        Assert.True(boundary > repairStartedAtUtc);
        Assert.Contains(issues, issue =>
            string.Equals(
                issue.Code,
                "accepted_turn_stale_player_facing_output_after_canonical_repair",
                StringComparison.Ordinal));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_ActorMaterializationErrors_AddsBoundedHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/npcs/npc_core.json.UpdateNPCs[0].materialization.sections.inventory",
                IssueSeverity.Error,
                "Первичная материализация не объясняет секцию inventory.",
                code: "actor_materialization_section_missing",
                actor: "mortal_npc:npc_iren_sol",
                section: "inventory",
                expected: "populated or empty_by_design with reason",
                actual: "missing"),
            new(
                "game_state/meta/guardians.json.guardians[0]",
                IssueSeverity.Error,
                "Новая значимая сущность посмертия не связана с точным common profile.",
                code: "afterlife_actor_materialization_profile_missing",
                actor: "guardian:guardian_selena",
                section: "ActorMaterialization",
                expected: "exact guardian:guardian_selena profile in game_state/meta/afterlife_entity_profiles.json",
                actual: "no exact actorType + actorId profile"),
            new(
                "game_state/meta/afterlife_entity_profiles.json.profiles[0].materialization.sections.fateCards",
                IssueSeverity.Error,
                "Disposition секции fateCards противоречит её каноническому содержимому.",
                code: "actor_materialization_section_content_mismatch",
                actor: "guardian:guardian_selena",
                section: "fateCards",
                expected: "empty_by_design with reason",
                actual: "populated")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("actor_materialization_repair", packet.GetProperty("kind").GetString());
        Assert.Equal(
            new[]
            {
                "game_state/meta/afterlife_entity_profiles.json",
                "game_state/npcs/npc_core.json"
            },
            packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()).OrderBy(item => item, StringComparer.Ordinal));
        Assert.Equal(
            new[] { "guardian:guardian_selena", "mortal_npc:npc_iren_sol" },
            packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()).OrderBy(item => item, StringComparer.Ordinal));

        var missingFields = packet.GetProperty("missingFields").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(missingFields, item => item.Contains("mortal_npc:npc_iren_sol", StringComparison.Ordinal) &&
                                               item.Contains("inventory", StringComparison.Ordinal));
        Assert.Contains(missingFields, item => item.Contains("guardian:guardian_selena", StringComparison.Ordinal) &&
                                               item.Contains("profile", StringComparison.OrdinalIgnoreCase));
        Assert.DoesNotContain(missingFields, item => item.Contains("fateCards", StringComparison.Ordinal));

        var corrections = packet.GetProperty("exactFieldCorrections").EnumerateArray().ToArray();
        Assert.Equal(3, corrections.Length);
        Assert.Contains(corrections, correction =>
            correction.GetProperty("code").GetString() == "actor_materialization_section_content_mismatch" &&
            correction.GetProperty("path").GetString()!.EndsWith("sections.fateCards", StringComparison.Ordinal));

        var safeRules = packet.GetProperty("safeCorrectionRules").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(safeRules, rule => rule.Contains("only", StringComparison.OrdinalIgnoreCase) &&
                                          rule.Contains("listed", StringComparison.OrdinalIgnoreCase) &&
                                          rule.Contains("section", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(safeRules, rule => rule.Contains("preserve", StringComparison.OrdinalIgnoreCase) &&
                                          rule.Contains("valid", StringComparison.OrdinalIgnoreCase));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("empty_by_design", StringComparison.Ordinal) &&
                                              item.Contains("physically present", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("appearanceDescription", StringComparison.Ordinal) &&
                                              item.Contains("profileSummary", StringComparison.Ordinal) &&
                                              item.Contains("personalityProfile", StringComparison.Ordinal) &&
                                              item.Contains("motivation", StringComparison.Ordinal) &&
                                              item.Contains("worldview", StringComparison.Ordinal) &&
                                              item.Contains("locationId", StringComparison.Ordinal));
        Assert.Contains(expectedShape, item => item.Contains("goals", StringComparison.Ordinal) &&
                                              item.Contains("plan", StringComparison.OrdinalIgnoreCase) &&
                                              item.Contains("actor-owned memory", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("exactly one", StringComparison.OrdinalIgnoreCase) &&
                                              item.Contains("currentLocationId", StringComparison.Ordinal) &&
                                              item.Contains("initialLocationId", StringComparison.Ordinal));

        var doNotDo = packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(doNotDo, item => item.Contains("implementation code", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("whole actor", StringComparison.OrdinalIgnoreCase) ||
                                         item.Contains("entire actor", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("delete", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("name", StringComparison.OrdinalIgnoreCase) &&
                                         item.Contains("prose", StringComparison.OrdinalIgnoreCase) &&
                                         item.Contains("genre", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("archetype", StringComparison.OrdinalIgnoreCase) &&
                                         item.Contains("item type", StringComparison.OrdinalIgnoreCase) &&
                                         item.Contains("genre keyword", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("client", StringComparison.OrdinalIgnoreCase) &&
                                         item.Contains("invent", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_UnusableActorMaterializationPreTurnAuthority_DoesNotAskGmToRewriteActors()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/afterlife_entity_profiles.json",
                IssueSeverity.Error,
                "Validated pre-turn authority отсутствует или повреждена.",
                code: "actor_materialization_pre_turn_authority_unusable",
                section: "ActorMaterialization",
                expected: "readable validated pre-turn afterlife actor authority",
                actual: "missing, unreadable, hash-invalid, or ambiguous source authority")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        Assert.Empty(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
    }

    [Theory]
    [InlineData("actor_materialization_missing")]
    [InlineData("actor_materialization_invalid_envelope")]
    [InlineData("actor_materialization_actor_binding_mismatch")]
    [InlineData("actor_materialization_duplicate_id")]
    [InlineData("actor_materialization_duplicate_property")]
    [InlineData("actor_materialization_invalid_actor_type")]
    [InlineData("actor_materialization_inventory_reference_mismatch")]
    [InlineData("actor_materialization_section_missing")]
    [InlineData("actor_materialization_section_content_mismatch")]
    [InlineData("actor_materialization_section_empty_surface_invalid")]
    [InlineData("actor_materialization_capability_mismatch")]
    [InlineData("actor_materialization_existing_resend_forbidden")]
    [InlineData("actor_materialization_historical_envelope_changed")]
    [InlineData("actor_materialization_afterlife_missing_appearance")]
    [InlineData("actor_materialization_afterlife_missing_profile_summary")]
    [InlineData("actor_materialization_afterlife_missing_personality")]
    [InlineData("actor_materialization_afterlife_missing_motivation")]
    [InlineData("actor_materialization_afterlife_missing_worldview")]
    [InlineData("actor_materialization_afterlife_missing_realm")]
    [InlineData("actor_materialization_afterlife_missing_location")]
    [InlineData("actor_materialization_afterlife_missing_goals_plan")]
    [InlineData("afterlife_actor_materialization_profile_missing")]
    [InlineData("afterlife_actor_materialization_profile_ambiguous")]
    [InlineData("afterlife_actor_materialization_memory_missing")]
    [InlineData("npc_new_update_location_authority_not_exactly_one")]
    [InlineData("npc_new_update_current_location_unknown")]
    public async Task WriteValidationRepairRequestAsync_ActionableActorMaterializationCode_IsClassified(
        string code)
    {
        var isAfterlife = code.StartsWith("afterlife_", StringComparison.Ordinal) ||
                          code.StartsWith("actor_materialization_afterlife_", StringComparison.Ordinal);
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                isAfterlife
                    ? "game_state/meta/guardians.json.guardians[0]"
                    : "game_state/npcs/npc_core.json.UpdateNPCs[0].materialization",
                IssueSeverity.Error,
                "Actor Materialization validation error.",
                code: code,
                actor: isAfterlife ? "guardian:guardian_classification" : "mortal_npc:npc_classification",
                section: "ActorMaterialization",
                expected: "valid bounded target",
                actual: "invalid")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        using var doc = JsonDocument.Parse(
            (await _fs.ReadFileAsync("game_state/control/validation_repair_request.json"))!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("actor_materialization_repair", packet.GetProperty("kind").GetString());
    }

    [Theory]
    [InlineData("npc_new_update_location_authority_not_exactly_one")]
    [InlineData("npc_new_update_current_location_unknown")]
    public async Task WriteValidationRepairRequestAsync_NewMortalLocationIssueTargetsNpcCore(
        string code)
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/npcs/npc_core.json.UpdateNPCs[0].currentLocationId",
                IssueSeverity.Error,
                "New Mortal actor location authority is invalid.",
                code: code,
                actor: "mortal_npc:npc_location_repair",
                section: "NPC",
                expected: "exactly one known currentLocationId or same-turn initialLocationId",
                actual: "missing or unknown")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 1 })!);

        await task;

        using var doc = JsonDocument.Parse(
            (await _fs.ReadFileAsync("game_state/control/validation_repair_request.json"))!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal(
            new[] { "game_state/npcs/npc_core.json" },
            packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("exactly one", StringComparison.OrdinalIgnoreCase) &&
                                              item.Contains("currentLocationId", StringComparison.Ordinal) &&
                                              item.Contains("initialLocationId", StringComparison.Ordinal));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalNpcSkillStringShapeErrors_AddsFullObjectHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/npcs/npc_core.json.NPCsInScene[0].activeSkills[0]",
                IssueSeverity.Error,
                "Элемент должен быть объектом",
                code: "expected_object",
                actor: "Старый Мирон",
                section: "NPC",
                expected: "JSON object",
                actual: "String",
                repairHint: "Исправь элемент до JSON object перед заполнением его обязательных полей."),
            new(
                "game_state/npcs/npc_core.json.NPCsInScene[0].passiveSkills[0]",
                IssueSeverity.Error,
                "Элемент должен быть объектом",
                code: "expected_object",
                actor: "Старый Мирон",
                section: "NPC",
                expected: "JSON object",
                actual: "String",
                repairHint: "Исправь элемент до JSON object перед заполнением его обязательных полей.")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_npc_full_object_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Старый Мирон", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("activeSkills/passiveSkills", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("full skill objects", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("activeSkills/passiveSkills", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("string names", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalBootstrapMaterializationErrors_AddsHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "lore/codex_entries.json",
                IssueSeverity.Error,
                "Opening Mortal bootstrap must include current-world codex entries.",
                code: "bootstrap_codex_missing_current_world_entries",
                section: "MortalBootstrap"),
            new(
                "game_state/inventory/items.json.items[0]",
                IssueSeverity.Error,
                "Readable document item has no detail authority.",
                code: "readable_document_missing_detail_authority",
                section: "Inventory",
                actual: "item_letter_black_seal"),
            new(
                "game_state/inventory/items.json.items[1].quality",
                IssueSeverity.Error,
                "Item quality is not canonical.",
                code: "item_invalid_quality",
                section: "Inventory",
                actual: "обычное"),
            new(
                "game_state/factions/faction_core.json.factions[0]",
                IssueSeverity.Error,
                "Faction sidecar is missing required fields.",
                code: "canonical_faction_custom_state_missing_required_fields",
                section: "Faction"),
            new(
                "game_state/world/current_location.json.coordinates",
                IssueSeverity.Error,
                "Current location coordinates differ from world map.",
                code: "current_location_coordinates_mismatch",
                section: "Location"),
            new(
                "game_state/world/current_location.json.factionControl",
                IssueSeverity.Error,
                "Location faction control must be object-shaped.",
                code: "location_faction_control_invalid_type",
                section: "Location"),
            new(
                "lore/current_world/history.json",
                IssueSeverity.Error,
                "Mortal bootstrap reused previous world lore.",
                code: "mortal_bootstrap_reused_previous_world_lore",
                section: "MortalBootstrap"),
            new(
                "game_state/npcs/npc_core.json",
                IssueSeverity.Error,
                "Mortal bootstrap promised training but has no usable teacherProfile.",
                code: "mortal_bootstrap_requested_teacher_missing",
                section: "MortalBootstrap"),
            new(
                "game_state/player/skills_active.json.activeSkillChanges",
                IssueSeverity.Error,
                "Mortal bootstrap lost an explicit starter competency.",
                code: "mortal_bootstrap_explicit_competency_missing",
                section: "MortalBootstrap"),
            new(
                "game_state/world/world_events.json.worldEventsLog",
                IssueSeverity.Error,
                "Mortal bootstrap lost its opening world event.",
                code: "mortal_bootstrap_world_event_missing",
                section: "MortalBootstrap")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_bootstrap_materialization_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/control/mortal_bootstrap_scaffold.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("lore/codex_entries.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/inventory/items.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/factions/faction_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/world/current_location.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/player/skills_active.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("game_state/world/world_events.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("bootstrap_codex_missing_current_world_entries", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("readable_document_missing_detail_authority", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("canonical_faction_custom_state_missing_required_fields", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("teacherProfile.canTeach=true", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("structuredGmAuthority.playerSkills", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("worldEventRequirements", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("mortal_bootstrap_scaffold.json", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("current-world", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("readable", StringComparison.OrdinalIgnoreCase) && step.Contains("document", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("structuredGmAuthority.actorCapabilities", StringComparison.OrdinalIgnoreCase) && step.Contains("teacherProfile", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("structuredGmAuthority.playerSkills", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("opening world news", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalBootstrapTradeAnchorMissing_AddsMerchantHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/npcs/npc_core.json",
                IssueSeverity.Error,
                "Mortal bootstrap promised trade but has no usable merchant NPC.",
                code: "mortal_bootstrap_requested_trade_missing",
                section: "MortalBootstrap",
                expected: "NPCsInScene/UpdateNPCs entry with tradeState.canTrade=true and a valid merchant profile",
                actual: "missing usable tradeState")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_bootstrap_materialization_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Templates/MORTAL_NPC_UPDATE_TEMPLATE.md", packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("mortal_bootstrap_requested_trade_missing", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("tradeState.canTrade=true", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("merchantProfile", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("tradeInventory", StringComparison.OrdinalIgnoreCase) && item.Contains("object", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("structuredGmAuthority.actorCapabilities", StringComparison.OrdinalIgnoreCase) && step.Contains("tradeState", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("tradeBlockedReason", StringComparison.OrdinalIgnoreCase) && step.Contains("string", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("do not include inventory", StringComparison.OrdinalIgnoreCase) && step.Contains("UpdateNPCs", StringComparison.OrdinalIgnoreCase));

        var doNotDo = packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(doNotDo, item => item.Contains("tradeInventory", StringComparison.OrdinalIgnoreCase) && item.Contains("scalar", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("structuredGmAuthority canTrade", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalBootstrapItemShapeAndActorPersistenceErrors_AddsHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/inventory/items.json.items[0].image_prompt",
                IssueSeverity.Error,
                "Отсутствует обязательное строковое поле: image_prompt",
                code: "missing_required_string",
                expected: "image_prompt as non-empty string",
                actual: "missing"),
            new(
                "game_state/inventory/items.json.items[0].isContainer",
                IssueSeverity.Error,
                "Отсутствует обязательное boolean поле: isContainer",
                code: "missing_required_boolean_field",
                expected: "boolean",
                actual: "missing"),
            new(
                "game_state/inventory/items.json.items[0].durability",
                IssueSeverity.Error,
                "durability должен быть percentage string",
                code: "validation_error"),
            new(
                "game_state/inventory/items.json.items[0].journalEntries[0]",
                IssueSeverity.Error,
                "Элемент должен быть непустой строкой",
                code: "invalid_string_array_item",
                section: "Inventory",
                expected: "non-empty string",
                actual: "Object"),
            new(
                "game_state/inventory/items.json.items[0].equipmentSlot",
                IssueSeverity.Error,
                "equipmentSlot содержит неизвестный слот.",
                code: "item_invalid_equipment_slot",
                section: "Inventory",
                expected: "valid equipment slot",
                actual: "Pocket"),
            new(
                "game_state/inventory/items.json.items[0].accessoryForSlot",
                IssueSeverity.Error,
                "accessoryForSlot содержит неизвестный слот.",
                code: "item_invalid_accessory_slot",
                section: "Inventory",
                expected: "valid accessory slot",
                actual: "Hands"),
            new(
                "lore/codex_entries.json.entries[0].tags",
                IssueSeverity.Error,
                "tags должен быть массивом строк.",
                code: "expected_string_array",
                section: "Codex",
                expected: "string[]",
                actual: "String"),
            new(
                "output/debug_logs.json",
                IssueSeverity.Error,
                "Mortal World relevant actor 'Дом Вальмонт' declared in NPC scope but has no persistent NPC surface",
                code: "mortal_relevant_actor_missing_persistence",
                actor: "Дом Вальмонт",
                section: "npc_scope",
                expected: "matching NPC persistence",
                actual: "actor appears only in gm_thoughts_markdown / narrative reasoning")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "ответа GM", issues, 2 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packets = doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray().ToArray();
        Assert.Equal(2, packets.Length);
        var packet = Assert.Single(packets, item =>
            string.Equals(item.GetProperty("kind").GetString(), "mortal_bootstrap_materialization_repair", StringComparison.Ordinal));
        Assert.Equal("mortal_bootstrap_materialization_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/inventory/items.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("lore/codex_entries.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("missing_required_string", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("missing_required_boolean_field", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("item_invalid_accessory_slot", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item =>
            item.Contains("durability", StringComparison.OrdinalIgnoreCase) &&
            item.Contains("percentage string", StringComparison.OrdinalIgnoreCase) &&
            item.Contains("100%", StringComparison.Ordinal));
        Assert.Contains(expectedShape, item =>
            item.Contains("journalEntries", StringComparison.Ordinal) &&
            item.Contains("non-empty string", StringComparison.OrdinalIgnoreCase) &&
            item.Contains("not objects", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("image_prompt", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("isContainer", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("existedId", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step =>
            step.Contains("durability", StringComparison.OrdinalIgnoreCase) &&
            step.Contains("100%", StringComparison.Ordinal));
        Assert.Contains(steps, step =>
            step.Contains("journalEntries", StringComparison.Ordinal) &&
            step.Contains("array", StringComparison.OrdinalIgnoreCase) &&
            step.Contains("strings", StringComparison.OrdinalIgnoreCase) &&
            step.Contains("not objects", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Relevant actors", StringComparison.OrdinalIgnoreCase));

        var npcPacket = Assert.Single(packets, item =>
            string.Equals(item.GetProperty("kind").GetString(), "mortal_npc_scope_repair", StringComparison.Ordinal));
        Assert.Contains("game_state/npcs/npc_core.json", npcPacket.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("output/debug_logs.json", npcPacket.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Дом Вальмонт", npcPacket.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
        var npcSteps = npcPacket.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(npcSteps, step => step.Contains("mortal_relevant_actor_missing_persistence", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_MortalNpcRelationshipAndCulturalErrors_AddsHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/npcs/npc_core.json.NPCs[0].attitude",
                IssueSeverity.Error,
                "NPC attitude must match relationship tier.",
                code: "npc_attitude_relationship_tier_mismatch",
                actor: "Ренар",
                section: "UpdateNPCs",
                expected: "attitude derived from relationshipLevel",
                actual: "Friendly"),
            new(
                "game_state/npcs/npc_core.json.NPCs[0].culturalStance",
                IssueSeverity.Error,
                "NPC culturalStance must be canonical.",
                code: "npc_invalid_cultural_stance",
                actor: "Ренар",
                section: "UpdateNPCs",
                expected: "Conformist|Pragmatist|Dissident",
                actual: "Loyalist")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "обработки хода", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("mortal_npc_relationship_enum_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("game_state/npcs/npc_core.json", packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Templates/MORTAL_NPC_UPDATE_TEMPLATE.md", packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Ренар", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("Непримиримый Враг", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Conformist", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Pragmatist", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Dissident", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_AfterlifeActionCostSequenceErrors_AddsConcreteHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/afterlife_spiritual_conflict_state.json.activeConflict.exchangeLog[2].actionCostAudit.opposition.before",
                IssueSeverity.Error,
                "Последовательные текущие обмены должны расходовать/восстанавливать ОД от результата предыдущего обмена.",
                code: "afterlife_conflict_action_cost_sequence_mismatch",
                section: "AfterlifeSpiritualConflict",
                expected: "2",
                actual: "4"),
            new(
                "game_state/meta/afterlife_spiritual_conflict_state.json.activeConflict.exchangeLog[2].actionCostAudit.player.before",
                IssueSeverity.Error,
                "Последовательные текущие обмены должны расходовать/восстанавливать ОД от результата предыдущего обмена.",
                code: "afterlife_conflict_action_cost_sequence_mismatch",
                section: "AfterlifeSpiritualConflict",
                expected: "0",
                actual: "3"),
            new(
                "game_state/meta/afterlife_spiritual_conflict_state.json.activeConflict.exchangeLog[2].actionCostAudit.player.after",
                IssueSeverity.Error,
                "actionCostAudit.player.after должен точно равняться before - effectiveCost.",
                code: "afterlife_conflict_action_cost_delta_mismatch",
                section: "AfterlifeSpiritualConflict",
                expected: "0",
                actual: "4"),
            new(
                "game_state/meta/afterlife_spiritual_conflict_state.json.activeConflict.exchangeLog[2].actionCostAudit.opposition.after",
                IssueSeverity.Error,
                "actionCostAudit.opposition.after должен точно равняться before - effectiveCost.",
                code: "afterlife_conflict_opposition_action_cost_delta_mismatch",
                section: "AfterlifeSpiritualConflict",
                expected: "2",
                actual: "3")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 4 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("afterlife_spiritual_conflict_action_cost_repair", packet.GetProperty("kind").GetString());
        Assert.Equal("high", packet.GetProperty("priority").GetString());
        Assert.Contains(
            "game_state/meta/afterlife_spiritual_conflict_state.json",
            packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("exchangeLog[2]", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("opposition.before", StringComparison.OrdinalIgnoreCase) &&
                                      step.Contains("expected 2", StringComparison.OrdinalIgnoreCase) &&
                                      step.Contains("actual 4", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("player.before", StringComparison.OrdinalIgnoreCase) &&
                                      step.Contains("expected 0", StringComparison.OrdinalIgnoreCase) &&
                                      step.Contains("actual 3", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("player.after", StringComparison.OrdinalIgnoreCase) &&
                                      step.Contains("expected 0", StringComparison.OrdinalIgnoreCase) &&
                                      step.Contains("actual 4", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("opposition.after", StringComparison.OrdinalIgnoreCase) &&
                                      step.Contains("expected 2", StringComparison.OrdinalIgnoreCase) &&
                                      step.Contains("actual 3", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("validation_repair_ready.json", StringComparison.OrdinalIgnoreCase));

        var exactFieldCorrections = packet.GetProperty("exactFieldCorrections").EnumerateArray().ToArray();
        Assert.Contains(exactFieldCorrections, correction =>
            correction.GetProperty("path").GetString()!.Contains("exchangeLog[2].actionCostAudit.player.after", StringComparison.OrdinalIgnoreCase) &&
            string.Equals(correction.GetProperty("expected").GetString(), "0", StringComparison.OrdinalIgnoreCase) &&
            string.Equals(correction.GetProperty("actual").GetString(), "4", StringComparison.OrdinalIgnoreCase) &&
            string.Equals(correction.GetProperty("code").GetString(), "afterlife_conflict_action_cost_delta_mismatch", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(exactFieldCorrections, correction =>
            correction.GetProperty("path").GetString()!.Contains("exchangeLog[2].actionCostAudit.opposition.after", StringComparison.OrdinalIgnoreCase) &&
            string.Equals(correction.GetProperty("expected").GetString(), "2", StringComparison.OrdinalIgnoreCase) &&
            string.Equals(correction.GetProperty("actual").GetString(), "3", StringComparison.OrdinalIgnoreCase) &&
            string.Equals(correction.GetProperty("code").GetString(), "afterlife_conflict_opposition_action_cost_delta_mismatch", StringComparison.OrdinalIgnoreCase));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("actionCostAudit.<side>.before", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("before - effectiveCost", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("spiritual_action_points", StringComparison.OrdinalIgnoreCase));
        Assert.DoesNotContain(expectedShape, item => item.Contains("actionEconomy", StringComparison.OrdinalIgnoreCase));

        var safeCorrectionRules = packet.GetProperty("safeCorrectionRules").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(safeCorrectionRules, item => item.Contains("spiritual_action_points", StringComparison.OrdinalIgnoreCase));
        Assert.DoesNotContain(safeCorrectionRules, item => item.Contains("actionEconomy", StringComparison.OrdinalIgnoreCase));
        Assert.DoesNotContain(steps, item => item.Contains("actionEconomy", StringComparison.OrdinalIgnoreCase));

        var doNotDo = packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(doNotDo, item => item.Contains("Do not create a new turn", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("pending_turn_snapshot", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("actionEconomy", StringComparison.OrdinalIgnoreCase) &&
                                         item.Contains("resourceOwnerBindings", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("resource_state.json", StringComparison.OrdinalIgnoreCase) &&
                                         item.Contains("resource_history.json", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_AfterlifeChronicleStringArrayErrors_AddsConcreteHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/afterlife_chronicles.json.chronicles[0].persistentConsequences[0]",
                IssueSeverity.Error,
                "persistentConsequences entries должны быть непустыми строками.",
                code: "afterlife_chronicle_persistent_consequences_entry_invalid",
                section: "AfterlifeChronicles",
                expected: "non-empty string",
                actual: "Object"),
            new(
                "game_state/meta/afterlife_chronicles.json.chronicles[0].openThreads[0]",
                IssueSeverity.Error,
                "openThreads entries должны быть непустыми строками.",
                code: "afterlife_chronicle_open_threads_entry_invalid",
                section: "AfterlifeChronicles",
                expected: "non-empty string",
                actual: "Object")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "ответа GM", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("afterlife_chronicle_string_array_repair", packet.GetProperty("kind").GetString());
        Assert.Equal("high", packet.GetProperty("priority").GetString());
        Assert.Contains(
            "game_state/meta/afterlife_chronicles.json",
            packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains(
            "Examples/E_CLI_Afterlife_Turns.txt",
            packet.GetProperty("templateRefs").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("afterlifeChronicleUpdates[]", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("persistentConsequences[]", StringComparison.Ordinal));
        Assert.Contains(expectedShape, item => item.Contains("openThreads[]", StringComparison.Ordinal));
        Assert.Contains(expectedShape, item => item.Contains("array of non-empty strings", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("persistentConsequences[0]", StringComparison.OrdinalIgnoreCase) &&
                                      step.Contains("Object", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("openThreads[0]", StringComparison.OrdinalIgnoreCase) &&
                                      step.Contains("Object", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Remove afterlifeChronicleUpdates from output/narrative_response.json", StringComparison.OrdinalIgnoreCase));
        Assert.DoesNotContain(steps, step => step.Contains("keep the same shape there too", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("validation_repair_ready.json", StringComparison.OrdinalIgnoreCase));

        var doNotDo = packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(doNotDo, item => item.Contains("Do not create a new turn", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("eventDescriptions", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("afterlifeChronicleUpdates", StringComparison.OrdinalIgnoreCase) &&
                                         item.Contains("narrative_response.json", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_AfterlifeConflictRewardNotAllowed_AddsConcreteHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/afterlife_spiritual_conflict_state.json.recentConflicts[0].rewardAudit",
                IssueSeverity.Error,
                "Этот terminal afterlife conflict outcome не может выдавать currency reward.",
                code: "afterlife_conflict_reward_not_allowed",
                section: "AfterlifeSpiritualConflict",
                expected: "resolved contested player victory with diceAudit.outcomeBand=player_success|decisive_player_success",
                actual: "terminalOutcome=negotiated_training; diceAudit.outcomeBand=negotiated")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 2 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("afterlife_spiritual_conflict_reward_repair", packet.GetProperty("kind").GetString());
        Assert.Contains(
            "game_state/meta/afterlife_spiritual_conflict_state.json",
            packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("player_success", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("decisive_player_success", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("negotiated", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("rewardAudit", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("remove", StringComparison.OrdinalIgnoreCase) &&
                                      step.Contains("currency reward", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Complete-BoeValidationRepair", StringComparison.OrdinalIgnoreCase));

        var doNotDo = packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(doNotDo, item => item.Contains("upgrade", StringComparison.OrdinalIgnoreCase) &&
                                         item.Contains("negotiated", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("new turn", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_AfterlifeEntityProfileScaffoldErrors_AddsConcreteHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/afterlife_entity_profiles.json.profiles[0].goals",
                IssueSeverity.Error,
                "goals профиля духовной сущности должен быть object.",
                code: "afterlife_entity_profile_agency_goals_not_object",
                actor: "Душа игрока",
                section: "AfterlifeEntityProfiles",
                expected: "object",
                actual: "Array"),
            new(
                "game_state/meta/afterlife_entity_profiles.json.profiles[0].progressionStrategy",
                IssueSeverity.Error,
                "Профиль должен явно хранить progressionStrategy.",
                code: "afterlife_entity_profile_missing_progression_strategy",
                actor: "Душа игрока",
                section: "AfterlifeEntityProfiles",
                expected: "object with strategyId/summary/priorityOrder/resourceReserve/allowedSpends/forbiddenSpends"),
            new(
                "game_state/meta/afterlife_entity_profiles.json.profiles[0].ledger",
                IssueSeverity.Error,
                "Профиль должен явно хранить ledger.",
                code: "afterlife_entity_profile_missing_ledger",
                actor: "Душа игрока",
                section: "AfterlifeEntityProfiles",
                expected: "array"),
            new(
                "game_state/meta/afterlife_entity_profiles.json.profileCommands.specialArtLearningReceipts[0]",
                IssueSeverity.Error,
                "specialArtLearningReceipts entry incomplete.",
                code: "incomplete_special_art_learning_receipt",
                actor: "Душа игрока",
                section: "AfterlifeEntityProfiles",
                expected: "receiptId/artId/teacherActorType/teacherActorId/playerActorId/trainingConditionSatisfied/learnedAtTurn/roleplayEvidence/summary")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "повторной проверки repair", issues, 2 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("afterlife_entity_profile_scaffold_repair", packet.GetProperty("kind").GetString());
        Assert.Contains(
            "game_state/meta/afterlife_entity_profiles.json",
            packet.GetProperty("targetFiles").EnumerateArray().Select(item => item.GetString()));
        Assert.Contains("Душа игрока", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));

        var expectedShape = packet.GetProperty("expectedShape").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(expectedShape, item => item.Contains("goals", StringComparison.OrdinalIgnoreCase) &&
                                              item.Contains("goalId", StringComparison.OrdinalIgnoreCase) &&
                                              item.Contains("updatedAtTurn", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("progressionStrategy", StringComparison.OrdinalIgnoreCase) &&
                                              item.Contains("priorityOrder", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("ledger", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(expectedShape, item => item.Contains("specialArtLearningReceipts", StringComparison.OrdinalIgnoreCase) &&
                                              item.Contains("initialTier", StringComparison.OrdinalIgnoreCase));

        var steps = packet.GetProperty("steps").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(steps, step => step.Contains("minimum profile scaffold", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("profileCommands.specialArtLearningReceipts", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(steps, step => step.Contains("Complete-BoeValidationRepair", StringComparison.OrdinalIgnoreCase));

        var doNotDo = packet.GetProperty("doNotDo").EnumerateArray().Select(item => item.GetString() ?? string.Empty).ToArray();
        Assert.Contains(doNotDo, item => item.Contains("Mortal", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(doNotDo, item => item.Contains("initialTier", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task WriteValidationRepairRequestAsync_AfterlifeEntityProfileActivityAndRelationshipErrors_AddsScaffoldHarnessPacket()
    {
        var engine = CreateGameEngine();
        var issues = new List<ValidationIssue>
        {
            new(
                "game_state/meta/afterlife_entity_profiles.json.profiles[0].currentActivity.activityType",
                IssueSeverity.Error,
                "currentActivity должен явно хранить тип активности.",
                code: "afterlife_entity_profile_agency_activity_missing_type",
                actor: "Хранительница Селена",
                section: "AfterlifeEntityProfiles",
                expected: "activityType"),
            new(
                "game_state/meta/afterlife_entity_profiles.json.profiles[0].currentActivity.linkedQuestId",
                IssueSeverity.Error,
                "currentActivity должен ссылаться на квест.",
                code: "afterlife_entity_profile_agency_activity_missing_linked_quest_id",
                actor: "Хранительница Селена",
                section: "AfterlifeEntityProfiles",
                expected: "linkedQuestId"),
            new(
                "game_state/meta/afterlife_entity_profiles.json.profiles[0].relationshipLock",
                IssueSeverity.Error,
                "relationshipLock должен хранить направление, evidence и reason.",
                code: "afterlife_entity_profile_relationship_lock_missing_direction",
                actor: "Хранительница Селена",
                section: "AfterlifeEntityProfiles",
                expected: "direction/evidence/reason"),
            new(
                "game_state/meta/afterlife_entity_profiles.json.profiles[0].relationships[0].updatedAtTurn",
                IssueSeverity.Error,
                "relationship turn должен быть числом.",
                code: "afterlife_entity_profile_relationship_invalid_turn",
                actor: "Хранительница Селена",
                section: "AfterlifeEntityProfiles",
                expected: "non-negative integer")
        };

        var method = typeof(GameEngine).GetMethod(
            "WriteValidationRepairRequestAsync",
            BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(method);
        var task = Assert.IsAssignableFrom<Task>(method!.Invoke(
            engine,
            new object[] { "первого хода после создания души", issues, 1 })!);

        await task;

        var requestJson = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
        Assert.False(string.IsNullOrWhiteSpace(requestJson));
        using var doc = JsonDocument.Parse(requestJson!);
        var packet = Assert.Single(doc.RootElement.GetProperty("harnessRepairPackets").EnumerateArray());
        Assert.Equal("afterlife_entity_profile_scaffold_repair", packet.GetProperty("kind").GetString());
        Assert.Contains("Хранительница Селена", packet.GetProperty("canonicalActorNames").EnumerateArray().Select(item => item.GetString()));
    }

    [Fact]
    public async Task TryAutoRepairStartupGuardianDirectMaterializationAsync_AddsCreateAuthorityAndClearsPending()
    {
        await _fs.WriteFileAtomicAsync("game_state/meta/guardians.json", """
        {
          "guardians": [
            {
              "guardianId": "guard_freeform_selena",
              "canonicalName": "Хранительница Селена",
              "originType": "freeform",
              "domain": "Забытые библиотеки",
              "nameVariants": { "default": "Хранительница Селена", "feminine": "Хранительница Селена", "masculine": "Хранитель Селен", "neutral": "Селена" },
              "manifestation": {
                "currentDisplayName": "Хранительница Селена",
                "formFlexibility": "selective",
                "currentPresentationStyle": "feminine",
                "currentPronouns": "она/её",
                "appearanceDescription": "Женщина в тёмном плаще архивариуса."
              },
              "manifestationHistory": [],
              "abode": { "abodeId": "abode_selena_archive", "name": "Башня архивов", "isDiscovered": true },
              "personalityProfile": { "archetype": "Строгая наставница", "speechPattern": "сухо и точно", "coreValues": [ "память", "осторожность", "правда" ] },
              "relationshipData": { "currentReputation": 10, "reputationHistory": [], "lastInteraction": null },
              "abodePower": { "currentPower": 10, "tier": "Угасающая", "lastUpdatedAt": "2026-07-06T00:00:00Z", "history": [] },
              "guardianRelationships": [],
              "questManagement": { "availableQuests": [], "activeQuests": [], "completedQuests": [] },
              "gachaSystem": { "chargesPerReturn": 1, "chargesUsedThisReturn": 0, "gachaHistory": [] },
              "mood": { "current": "focused", "intensity": 40, "reason": "Первая встреча.", "since": 1 },
              "loreFragments": [
                { "fragmentId": "selena_lore_1", "category": "personal_history", "title": "Первый урок", "content": "Селена не скрывает цену знания.", "requiredReputation": 0 },
                { "fragmentId": "selena_lore_2", "category": "domain_mastery", "title": "Архивы", "content": "Её домен связан с забытыми библиотеками.", "requiredReputation": 0 },
                { "fragmentId": "selena_lore_3", "category": "soul_mechanics", "title": "Память души", "content": null, "requiredReputation": 50 },
                { "fragmentId": "selena_lore_4", "category": "lost_world", "title": "Серый берег", "content": null, "requiredReputation": 50 },
                { "fragmentId": "selena_lore_5", "category": "other_guardians", "title": "Долги", "content": null, "requiredReputation": 130 },
                { "fragmentId": "selena_lore_6", "category": "cosmic_secret", "title": "Последняя полка", "content": null, "requiredReputation": 130 },
                { "fragmentId": "selena_lore_7", "category": "personal_history", "title": "Скрытое имя", "content": null, "requiredReputation": 230 }
              ],
              "musings": [
                { "turn": 1, "topic": "first_soul_assessment", "mood": "contemplative", "thought": "Новая душа требует осторожного первого урока." }
              ]
            }
          ],
          "activeGuardian": { "guardianId": "guard_freeform_selena" },
          "chaosSeaNavigation": {
            "currentAbodeId": "abode_selena_archive",
            "currentGuardianId": "guard_freeform_selena",
            "discoveredAbodes": [ "abode_selena_archive" ]
          },
          "pendingGuardianCreation": {
            "mode": "freeform",
            "soulName": "Искра Перед Рассветом",
            "description": "Хранительница Селена, покровительница забытых библиотек."
          }
        }
        """);
        var engine = CreateGameEngine();
        var errors = new List<ValidationIssue>
        {
            new(
                "game_state/meta/guardians.json.guardians[0].guardianId",
                IssueSeverity.Error,
                "Fresh startup Guardian was materialized without the supported create surface.",
                code: "guardian_materialized_without_create_surface",
                section: "Guardians",
                expected: "UpdateGuardians.create",
                actual: "direct guardians[] entry"),
            new(
                "game_state/meta/guardians.json.pendingGuardianCreation",
                IssueSeverity.Error,
                "pendingGuardianCreation remains after Guardian materialization.",
                code: "stale_pending_guardian_creation_after_materialization",
                section: "Guardians",
                expected: "pendingGuardianCreation removed",
                actual: "pending request still present")
        };

        var repaired = await InvokePrivateAsync<bool>(
            engine,
            "TryAutoRepairStartupGuardianDirectMaterializationAsync",
            "первого хода после создания души",
            errors);

        Assert.True(repaired);
        var repairedJson = await _fs.ReadFileAsync("game_state/meta/guardians.json");
        Assert.False(string.IsNullOrWhiteSpace(repairedJson));
        using var doc = JsonDocument.Parse(repairedJson!);
        var root = doc.RootElement;
        var createCommand = Assert.Single(root.GetProperty("UpdateGuardians").EnumerateArray());
        Assert.Equal("create", createCommand.GetProperty("command").GetString());
        Assert.Equal(
            "guard_freeform_selena",
            createCommand.GetProperty("data").GetProperty("guardianId").GetString());
        Assert.Equal(
            "soul_assessment",
            createCommand.GetProperty("data").GetProperty("musings")[0].GetProperty("topic").GetString());
        Assert.False(root.TryGetProperty("pendingGuardianCreation", out var pending) && pending.ValueKind != JsonValueKind.Null);
        Assert.Equal(
            "guard_freeform_selena",
            root.GetProperty("activeGuardian").GetProperty("guardianId").GetString());
    }


    [Theory]
    [InlineData("[ABODE_OFFERING] Игрок подносит Реликвию Души.", true)]
    [InlineData("[INK_FEATHER_ACTION: ABODE_OFFERING] Игрок подносит 100 Чернильных Перьев.", true)]
    [InlineData("[INK_FEATHER_ACTION: DONATE_TO_GUARDIAN] Игрок жертвует 60 Чернильных Перьев.", false)]
    public void IsPendingAbodeOfferingTurnAction_DetectsPlainAndInkFeatherOfferingTags(string action, bool expected)
    {
        Assert.Equal(expected, GameEngine.IsPendingAbodeOfferingTurnAction(action));
    }

    [Fact]
    [Trait("Category", "PreMergeSentinel")]
    public async Task ProcessPlayerTurn_UnresolvedRealm_DoesNotCreatePendingDiceState()
    {
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            soulName = "Тестовая Душа",
            currentRealm = "",
            currentIncarnation = 1,
            inkFeathers = new { current = 50 }
        });
        var engine = CreateGameEngine();

        var ex = await Assert.ThrowsAsync<InvalidOperationException>(() =>
            InvokePrivateTaskAsync(engine, "ProcessPlayerTurn", "Тестовый ход", null));

        Assert.Contains("currentRealm", ex.Message, StringComparison.OrdinalIgnoreCase);
        Assert.False(_fs.FileExists(PendingTurnStateService.PendingDiceStatePath));
        Assert.False(_fs.FileExists("input/turn_request.json"));
    }

    [Fact]
    public async Task ProcessPlayerTurn_InvalidCurrentState_BlocksBeforeDispatchingGm()
    {
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            soulName = "Тестовая Душа",
            currentRealm = "Mortal World",
            currentIncarnation = 2,
            inkFeathers = new { current = 50 },
            afterlifeArchive = new
            {
                stored = new object[]
                {
                    new
                    {
                        archiveId = "archive_missing_source_life",
                        entryType = AfterlifeArchiveState.EntryTypeLoreFragment,
                        title = "Запись без жизни-источника",
                        summary = "Эта запись должна блокировать ход до вызова GM.",
                        rarity = "Rare",
                        sourceKind = AfterlifeArchiveState.SourceKindCodex,
                        acquiredAtUtc = "2026-06-18T00:00:00Z"
                    }
                },
                actionReceipts = Array.Empty<object>()
            }
        });
        var engine = CreateGameEngine(new QueuedConsoleInputSource([Key(ConsoleKey.Enter)]));

        await InvokePrivateTaskAsync(engine, "ProcessPlayerTurn", "Тестовый ход", null);

        Assert.False(_fs.FileExists("input/turn_request.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
    }

    [Fact]
    public async Task ProcessPlayerTurn_TerminalError_CleansTurnRequestAndPendingSnapshot()
    {
        CopyDirectory(TestRepoPaths.BaseSessionRoot, _fs.GameSessionPath);
        var input = new QueuedConsoleInputSource([Key(ConsoleKey.Enter)]);
        var engine = CreateGameEngine(input);
        var gmErrorTask = Task.Run(async () =>
        {
            var request = await WaitForTurnRequestAsync();
            await _fs.WriteFileAtomicAsync("ready/turn_error.json", JsonSerializer.Serialize(new
            {
                sessionId = request.SessionId,
                requestId = request.RequestId,
                turnNumber = request.TurnNumber,
                timestamp = DateTime.UtcNow.ToString("o"),
                status = "error",
                error = "GM bridge did not accept dispatch before the dispatch timeout."
            }, SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed));
        });

        await InvokePrivateTaskAsync(engine, "ProcessPlayerTurn", "Тестовый ход, который завершится terminal error", null);
        await gmErrorTask.WaitAsync(TimeSpan.FromSeconds(5));

        Assert.False(_fs.FileExists("input/turn_request.json"));
        Assert.False(_fs.FileExists("ready/turn_error.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.authority.json"));
    }

    [Fact]
    public async Task ProcessPlayerTurn_GenerationChangesAfterAcceptedValidation_AbortsBeforeMutatingReplacement()
    {
        CopyDirectory(TestRepoPaths.BaseSessionRoot, _fs.GameSessionPath);
        using var owned = new CleanupOwnedFixture(_rootPath, line => _directGachaOutput?.WriteLine(line));
        var probe = await SessionGenerationCheckpointFixture.CreateAsync(_rootPath, line => _directGachaOutput?.WriteLine(line));
        var terminalStarts = 0;
        GenerationFinalizerState? stateAtCheckpoint = null;
        GameEngine? engine = null;
        engine = CreateGameEngine(
            probe.ObserveInput(new QueuedConsoleInputSource([])), configureSettings: InertRealmSettings,
            fileSystem: probe.Files,
            finalizationHooks: new GameEngineSessionFinalizationHooks
            {
                AtCheckpointAsync = async checkpoint =>
                {
                    if (checkpoint == SessionFinalizationCheckpoint.TerminalWaitStarted)
                    {
                        terminalStarts++;
                        Assert.Equal(1, terminalStarts);
                        var requestJson = await probe.Files.ReadFileAsync("input/turn_request.json");
                        var request = JsonSerializer.Deserialize<TurnRequest>(requestJson!, SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed);
                        Assert.NotNull(request);
                        var outputTimestamp = DateTime.UtcNow.ToString("o");
                        await WriteJsonAsync("output/narrative_response.json", new
                        {
                            response = "Старый ход успешно прошёл проверку, но не должен затронуть загруженную сессию.",
                            timestamp = outputTimestamp
                        });
                        await WriteJsonAsync("output/interface_updates.json", new
                        {
                            dialogueOptions = new[]
                            {
                                new
                                {
                                    text = "Продолжить.",
                                    category = "neutral"
                                }
                            },
                            timestamp = outputTimestamp
                        });
                        await WriteJsonAsync("output/debug_logs.json", new
                        {
                            timestamp = outputTimestamp,
                            gm_thoughts_markdown = string.Join(
                                "\n",
                                "## NPC Scope",
                                "- Mode: Scene-local",
                                "- Relevant actors: нет",
                                "- Why relevant: Синтетический ход без акторов проверяет session fence.",
                                "- Actors outside scope: нет",
                                "- Why outside scope: Структурные акторы не меняются.",
                                "",
                                "## Reasoning",
                                "- Accepted result is paused before materialization.")
                        });
                        await WriteJsonAsync("ready/turn_complete.json", new
                        {
                            sessionId = request.SessionId,
                            requestId = request.RequestId,
                            turnNumber = request.TurnNumber,
                            timestamp = outputTimestamp,
                            status = "success",
                            filesModified = new[]
                            {
                                "output/narrative_response.json",
                                "output/interface_updates.json",
                                "output/debug_logs.json"
                            }
                        });
                        return;
                    }
                    if (checkpoint == SessionFinalizationCheckpoint.AcceptedOutcomeValidatedBeforeMaterialization)
                    {
                        stateAtCheckpoint = CaptureGenerationFinalizerState(engine!);
                        await probe.RotateAsync(checkpoint.ToString(), SessionGenerationCheckpointFixture.ReplacementTerminalSentinels(),
                            ["output/narrative_response.json", "output/interface_updates.json", "output/debug_logs.json", "game_state/combat/combat_log.json"]);
                    }
                }
            });
        var failure = await Record.ExceptionAsync(() => InvokePrivateTaskAsync(
            engine, "ProcessPlayerTurn", "Проверить финализацию старого хода.", null));
        var stateAfterFailure = CaptureGenerationFinalizerState(engine);
        probe.Verify(failure, new { terminalStarts, stateAtCheckpoint, stateAfterFailure });
        Assert.NotNull(stateAtCheckpoint);
        Assert.Same(stateAtCheckpoint.Response, stateAfterFailure.Response);
        Assert.Equal(stateAtCheckpoint, stateAfterFailure);
        Assert.Equal(1, terminalStarts);
        Assert.False(File.Exists(probe.Files.ResolvePath("stories/story.md")));
    }

    [Fact]
    public async Task ProcessPlayerTurn_RepairStalledAcceptedTurn_RestoresPreTurnSnapshot()
    {
        CopyDirectory(TestRepoPaths.BaseSessionRoot, _fs.GameSessionPath);
        const string passiveSkillsPath = "game_state/player/skills_passive.json";
        const string activeSkillsPath = "game_state/player/skills_active.json";
        const string skillMasteryPath = "game_state/player/skill_mastery.json";

        var input = new QueuedConsoleInputSource([Key(ConsoleKey.Enter)]);
        var engine = CreateGameEngine(input);
        var gmOutputTask = Task.Run(async () =>
        {
            var request = await WaitForTurnRequestAsync();
            var outputTimestamp = DateTime.UtcNow.ToString("o");
            await WriteJsonAsync("output/narrative_response.json", new
            {
                response = "Наставница показывает печать, но запись урока намеренно повреждена для проверки rollback.",
                timestamp = outputTimestamp
            });
            await WriteJsonAsync("output/interface_updates.json", new
            {
                dialogueOptions = new[]
                {
                    new
                    {
                        text = "Вернуться к уроку позже.",
                        category = "neutral"
                    }
                },
                timestamp = outputTimestamp
            });
            await WriteJsonAsync("output/debug_logs.json", new
            {
                timestamp = outputTimestamp,
                gm_thoughts_markdown = string.Join(
                    "\n",
                    "## NPC Scope",
                    "- Mode: Scene-local",
                    "- Relevant actors: наставница архива",
                    "- Why relevant: Проверяется провал repair loop после paid training.",
                    "- Actors outside scope: нет",
                    "- Why outside scope: Ход не меняет других NPC.",
                    "",
                    "## Reasoning",
                    "- The test intentionally writes a passive skill and an invalid active mastery entry.")
            });
            await WriteJsonAsync(passiveSkillsPath, new
            {
                passiveSkillChanges = new[]
                {
                    new
                    {
                        skillId = "skill_life_001_seal_reading",
                        skillName = "Чтение печатей",
                        skillKind = "passive_skill_mastery",
                        description = "Распознавание родовых и торговых печатей.",
                        rarity = "Common",
                        category = "knowledge"
                    }
                }
            });
            await WriteJsonAsync(activeSkillsPath, new
            {
                activeSkillChanges = Array.Empty<object>()
            });
            await WriteJsonAsync(skillMasteryPath, new
            {
                skillMasteryChanges = new[]
                {
                    new
                    {
                        skillId = "skill_life_001_seal_reading",
                        skillName = "Чтение печатей",
                        targetKind = "passive_skill_mastery",
                        newMasteryLevel = 1,
                        newCurrentMasteryProgress = 0,
                        newMasteryProgressNeeded = 100,
                        masteryLeveledUp = true
                    }
                }
            });
            await WriteJsonAsync("ready/turn_complete.json", new
            {
                sessionId = request.SessionId,
                requestId = request.RequestId,
                turnNumber = request.TurnNumber,
                timestamp = DateTime.UtcNow.ToString("o"),
                status = "success",
                filesModified = new[]
                {
                    "output/narrative_response.json",
                    "output/interface_updates.json",
                    "output/debug_logs.json",
                    passiveSkillsPath,
                    activeSkillsPath,
                    skillMasteryPath
                }
            });

            await WaitForValidationRepairRequestContainingAsync(
                "skills_passive",
                TimeSpan.FromSeconds(30));
            await WriteJsonAsync("game_state/control/gm_validation_repair_artifact_stall_report.json", new
            {
                isStalled = true,
                elapsedSeconds = 180,
                bridgeCleanup = new
                {
                    reason = "gm_validation_repair_artifact_stall",
                    status = "fallback-stopped",
                    ok = true
                }
            });
        });

        var processTask = InvokePrivateTaskAsync(
            engine,
            "ProcessPlayerTurn",
            "Купить урок чтения печатей.",
            null);
        await Task.WhenAll(processTask, gmOutputTask)
            .WaitAsync(TimeSpan.FromSeconds(45));

        Assert.False(_fs.FileExists(passiveSkillsPath));
        Assert.False(_fs.FileExists(activeSkillsPath));
        Assert.False(_fs.FileExists(skillMasteryPath));
        Assert.False(_fs.FileExists("input/turn_request.json"));
        Assert.False(_fs.FileExists("ready/turn_complete.json"));
        Assert.False(_fs.FileExists("ready/turn_error.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.authority.json"));
    }

    [Fact]
    public async Task ProcessPlayerTurn_IdleBridgeErrorWithFreshOutputArtifacts_RecoversAsAcceptedTurn()
    {
        CopyDirectory(TestRepoPaths.BaseSessionRoot, _fs.GameSessionPath);
        var input = new QueuedConsoleInputSource([Key(ConsoleKey.Enter)]);
        var engine = CreateGameEngine(input);
        var gmOutputTask = Task.Run(async () =>
        {
            var request = await WaitForTurnRequestAsync();
            var outputTimestamp = DateTime.UtcNow.ToString("o");
            await WriteJsonAsync("output/narrative_response.json", new
            {
                response = "Книга напоминает: первые Чернильные Перья обычно приходят после завершения первой смертной жизни.",
                timestamp = outputTimestamp
            });
            await WriteJsonAsync("output/interface_updates.json", new
            {
                dialogueOptions = new[]
                {
                    new
                    {
                        text = "Перейти к выбору первой смертной жизни.",
                        category = "neutral"
                    }
                },
                timestamp = outputTimestamp
            });
            await WriteJsonAsync("output/debug_logs.json", new
            {
                timestamp = outputTimestamp,
                gm_thoughts_markdown = string.Join(
                    "\n",
                    "## NPC Scope",
                    "- Mode: Scene-local",
                    "- Relevant actors: нет",
                    "- Why relevant: Ход отвечает на системный вопрос игрока без действий NPC, Хранителей или фракций.",
                    "- Actors outside scope: нет",
                    "- Why outside scope: В сцене нет акторов, получающих структурное состояние.",
                    "",
                    "## Reasoning",
                    "- Structured actor reasoning is not required for this actor-free explanatory turn.")
            });
            await WriteJsonAsync("ready/turn_error.json", new
            {
                sessionId = request.SessionId,
                requestId = request.RequestId,
                turnNumber = request.TurnNumber,
                timestamp = DateTime.UtcNow.ToString("o"),
                status = "error",
                harnessSource = "gm_bridge_idle_without_terminal_signal",
                error = "GM bridge returned to idle without a correlated terminal signal."
            });
        });

        await InvokePrivateTaskAsync(engine, "ProcessPlayerTurn", "Спросить, как заработать первые Чернильные Перья.", null);
        await gmOutputTask.WaitAsync(TimeSpan.FromSeconds(5));

        var gameLoop = GetPrivateField<GameLoop>(engine, "_gameLoop");
        Assert.Equal(1, gameLoop.TurnNumber);
        var lastResponse = GetPrivateField<GameResponse>(engine, "_lastResponse");
        Assert.Contains("Чернильные Перья", lastResponse.Response, StringComparison.Ordinal);
        Assert.False(_fs.FileExists("input/turn_request.json"));
        Assert.False(_fs.FileExists("ready/turn_error.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.authority.json"));
    }

    [Fact]
    public async Task ProcessPlayerTurn_OutputWithoutTerminalErrorWithFreshOutputArtifacts_RecoversAsAcceptedTurn()
    {
        CopyDirectory(TestRepoPaths.BaseSessionRoot, _fs.GameSessionPath);
        var input = new QueuedConsoleInputSource([Key(ConsoleKey.Enter)]);
        var engine = CreateGameEngine(input);
        var gmOutputTask = Task.Run(async () =>
        {
            var request = await WaitForTurnRequestAsync();
            var outputTimestamp = DateTime.UtcNow.ToString("o");
            await WriteJsonAsync("output/narrative_response.json", new
            {
                response = "Книга принимает записанный ответ, даже если daemon восстановил пропущенный terminal signal.",
                timestamp = outputTimestamp
            });
            await WriteJsonAsync("output/interface_updates.json", new
            {
                dialogueOptions = new[]
                {
                    new
                    {
                        text = "Продолжить путь.",
                        category = "neutral"
                    }
                },
                timestamp = outputTimestamp
            });
            await WriteJsonAsync("output/debug_logs.json", new
            {
                timestamp = outputTimestamp,
                gm_thoughts_markdown = string.Join(
                    "\n",
                    "## NPC Scope",
                    "- Mode: Scene-local",
                    "- Relevant actors: нет",
                    "- Why relevant: Ход проверяет восстановление свежего payload после daemon output-stall.",
                    "- Actors outside scope: нет",
                    "- Why outside scope: Нет акторов со структурным состоянием.",
                    "",
                    "## Reasoning",
                    "- The client can validate fresh output artifacts after daemon reports gm_output_without_terminal_signal.")
            });
            await WriteJsonAsync("ready/turn_error.json", new
            {
                sessionId = request.SessionId,
                requestId = request.RequestId,
                turnNumber = request.TurnNumber,
                timestamp = DateTime.UtcNow.ToString("o"),
                status = "error",
                harnessSource = "gm_output_without_terminal_signal",
                error = "GM wrote turn payload files without a correlated terminal signal.",
                changedFiles = new[]
                {
                    "output/narrative_response.json",
                    "output/interface_updates.json",
                    "output/debug_logs.json"
                }
            });
        });

        await InvokePrivateTaskAsync(engine, "ProcessPlayerTurn", "Проверить восстановление свежего ответа GM.", null);
        await gmOutputTask.WaitAsync(TimeSpan.FromSeconds(5));

        var gameLoop = GetPrivateField<GameLoop>(engine, "_gameLoop");
        Assert.Equal(1, gameLoop.TurnNumber);
        var lastResponse = GetPrivateField<GameResponse>(engine, "_lastResponse");
        Assert.Contains("пропущенный terminal signal", lastResponse.Response, StringComparison.Ordinal);
        Assert.False(_fs.FileExists("input/turn_request.json"));
        Assert.False(_fs.FileExists("ready/turn_error.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.authority.json"));
    }

    [Fact]
    public async Task ProcessPlayerTurn_IdleBridgeErrorWithoutOutputArtifacts_RemainsFailClosed()
    {
        CopyDirectory(TestRepoPaths.BaseSessionRoot, _fs.GameSessionPath);
        var input = new QueuedConsoleInputSource([Key(ConsoleKey.Enter)]);
        var engine = CreateGameEngine(input);
        var gmErrorTask = Task.Run(async () =>
        {
            var request = await WaitForTurnRequestAsync();
            await WriteJsonAsync("ready/turn_error.json", new
            {
                sessionId = request.SessionId,
                requestId = request.RequestId,
                turnNumber = request.TurnNumber,
                timestamp = DateTime.UtcNow.ToString("o"),
                status = "error",
                harnessSource = "gm_bridge_idle_without_terminal_signal",
                error = "GM bridge returned to idle without a correlated terminal signal."
            });
        });

        await InvokePrivateTaskAsync(engine, "ProcessPlayerTurn", "Спросить, как заработать первые Чернильные Перья.", null);
        await gmErrorTask.WaitAsync(TimeSpan.FromSeconds(5));

        var gameLoop = GetPrivateField<GameLoop>(engine, "_gameLoop");
        Assert.Equal(0, gameLoop.TurnNumber);
        Assert.False(_fs.FileExists("input/turn_request.json"));
        Assert.False(_fs.FileExists("ready/turn_complete.json"));
        Assert.False(_fs.FileExists("ready/turn_error.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.authority.json"));
    }

    [Fact]
    public async Task ProcessPlayerTurn_IdleBridgeErrorWithStaleOutputTimestamps_RemainsFailClosed()
    {
        CopyDirectory(TestRepoPaths.BaseSessionRoot, _fs.GameSessionPath);
        var input = new QueuedConsoleInputSource([Key(ConsoleKey.Enter)]);
        var engine = CreateGameEngine(input);
        var gmOutputTask = Task.Run(async () =>
        {
            var request = await WaitForTurnRequestAsync();
            var staleOutputTimestamp = DateTime.UtcNow.AddMinutes(-10).ToString("o");
            await WriteJsonAsync("output/narrative_response.json", new
            {
                response = "Старый ответ ГМа не должен быть принят новым ходом.",
                timestamp = staleOutputTimestamp
            });
            await WriteJsonAsync("output/debug_logs.json", new
            {
                timestamp = staleOutputTimestamp,
                gm_thoughts_markdown = string.Join(
                    "\n",
                    "## NPC Scope",
                    "- Mode: Scene-local",
                    "- Relevant actors: нет",
                    "- Why relevant: Старый артефакт не относится к текущему ходу.",
                    "- Actors outside scope: нет",
                    "- Why outside scope: Проверяется только свежесть GM output.",
                    "",
                    "## Reasoning",
                    "- Recovery must reject output artifacts whose internal timestamp predates the active turn request.")
            });
            await WriteJsonAsync("ready/turn_error.json", new
            {
                sessionId = request.SessionId,
                requestId = request.RequestId,
                turnNumber = request.TurnNumber,
                timestamp = DateTime.UtcNow.ToString("o"),
                status = "error",
                harnessSource = "gm_bridge_idle_without_terminal_signal",
                error = "GM bridge returned to idle without a correlated terminal signal."
            });
        });

        await InvokePrivateTaskAsync(engine, "ProcessPlayerTurn", "Спросить, как заработать первые Чернильные Перья.", null);
        await gmOutputTask.WaitAsync(TimeSpan.FromSeconds(5));

        var gameLoop = GetPrivateField<GameLoop>(engine, "_gameLoop");
        Assert.Equal(0, gameLoop.TurnNumber);
        Assert.False(_fs.FileExists("input/turn_request.json"));
        Assert.False(_fs.FileExists("ready/turn_complete.json"));
        Assert.False(_fs.FileExists("ready/turn_error.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.authority.json"));
    }

    [Fact]
    public async Task HasCurrentSessionAsync_TerminalSoulDissipation_BlocksContinueSession()
    {
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            soulName = "Развеянная Душа",
            currentRealm = "Chaos Sea",
            currentIncarnation = 3,
            terminalGameOver = new
            {
                state = "soul_dispersed",
                message = AfterlifeSpiritualConflictState.TerminalSoulDissipationMessage,
                conflictId = "afterlife_conflict_terminal_001",
                proofId = "soul_dissipation_proof_terminal_001"
            }
        });
        var engine = CreateGameEngine();

        var hasCurrentSession = await InvokePrivateAsync<bool>(engine, "HasCurrentSessionAsync");

        Assert.False(hasCurrentSession);
        var warning = GetPrivateField<string>(engine, "_mainMenuSessionWarning");
        Assert.Contains(AfterlifeSpiritualConflictState.TerminalSoulDissipationMessage, warning, StringComparison.Ordinal);
        Assert.Contains("загрузите сохранение", warning, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void TryDescribeMalformedPendingWorldSetup_RejectsNullWorldDirectives()
    {
        var method = typeof(GameEngine).GetMethod(
            "TryDescribeMalformedPendingWorldSetup",
            BindingFlags.Static | BindingFlags.NonPublic);
        Assert.NotNull(method);

        object?[] args =
        {
            """
            {
              "mode": "manual",
              "worldDirectives": null
            }
            """,
            string.Empty
        };

        var malformed = Assert.IsType<bool>(method!.Invoke(null, args));

        Assert.True(malformed);
        var description = Assert.IsType<string>(args[1]);
        Assert.Contains("worldDirectives", description, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("non-null JSON object", description, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task CollectIncarnationBlockersAsync_SystemGuardianAttractionBlocksIncarnation()
    {
        await WriteJsonAsync(SystemGuardianLibraryService.AttractionRequestPath, new
        {
            mode = "system_guardian_attraction",
            targetPresetId = "eternal_tide_001",
            targetPresetDisplayName = "Прилив Памяти",
            targetPresetVersion = "1.0",
            sourceLibrary = "built_in",
            targetSummary = "Извечный Хранитель памяти.",
            renderedPromptPackage = "Досье Хранителя.",
            _lastUpdated = "2026-04-27T12:00:00Z"
        });

        var engine = CreateGameEngine();

        var blockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        Assert.Contains(blockers, blocker =>
            blocker.Contains("притяжение к извечному Хранителю", StringComparison.OrdinalIgnoreCase) &&
            blocker.Contains("отмените attraction contract", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task CollectIncarnationBlockersAsync_MalformedSystemGuardianAttractionBlocksIncarnation()
    {
        await _fs.WriteFileAtomicAsync(SystemGuardianLibraryService.AttractionRequestPath, "{ malformed");

        var engine = CreateGameEngine();

        var blockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        Assert.Contains(blockers, blocker =>
            blocker.Contains("system_guardian_attraction.json повреждён", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task CollectIncarnationBlockersAsync_ResidentTransferEnumeratesEveryPendingRequest()
    {
        await WriteJsonAsync(GuardianAbodeResidentRequestState.PendingTransfersRequestPath, new
        {
            requests = new[]
            {
                new
                {
                    requestId = "transfer_alpha",
                    residentId = "resident_alpha",
                    sourceGuardianId = "guardian_old_alpha",
                    sourceAbodeId = "abode_old_alpha",
                    targetGuardianId = "guardian_new_alpha",
                    targetAbodeId = "abode_new_alpha",
                    createdAtTurn = 12
                },
                new
                {
                    requestId = "transfer_beta",
                    residentId = "resident_beta",
                    sourceGuardianId = "guardian_old_beta",
                    sourceAbodeId = "abode_old_beta",
                    targetGuardianId = "guardian_new_beta",
                    targetAbodeId = "abode_new_beta",
                    createdAtTurn = 13
                }
            }
        });
        var engine = CreateGameEngine();

        var blockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        var blocker = Assert.Single(blockers);
        Assert.Contains("pending_guardian_abode_resident_transfers.json", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("request[0]:", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("requestId=transfer_alpha", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("targetAbodeId=abode_new_alpha", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("request[1]:", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("requestId=transfer_beta", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("sourceGuardianId=guardian_old_beta", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("full payload:", blocker, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task CollectIncarnationBlockersAsync_AbodeOfferingShowsGenericPayloadAndClosure()
    {
        await WriteJsonAsync(GuardianAbodeOfferingState.PendingRequestPath, new
        {
            requestId = "offering_blocker_001",
            guardianId = "guardian_offering_001",
            abodeId = "abode_offering_001",
            offeringType = "ink_feathers",
            inkFeathersOffered = 100,
            powerGain = 20,
            createdAtTurn = 14
        });
        var engine = CreateGameEngine();

        var blockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        var blocker = Assert.Single(blockers);
        Assert.Contains("pending_abode_offering.json", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("requestId=offering_blocker_001", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("offeringType=ink_feathers", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("inkFeathersOffered=100", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("output/ink_feather_action_result.json", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("\"powerGain\": 20", blocker, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task CollectIncarnationBlockersAsync_NpcSocialAndTradeBlockSoulGates()
    {
        await WriteJsonAsync(ActorSocialInteractionRequestState.PendingNpcRequestPath, new
        {
            requests = new[]
            {
                new
                {
                    requestId = "npc_social_alpha",
                    npcId = "npc_mira",
                    npcName = "Мира",
                    interactionType = "talk",
                    createdAtTurn = 14,
                    createdAtUtc = "2026-04-27T14:00:00Z"
                }
            }
        });
        await WriteJsonAsync(NpcTradeRequestState.PendingRequestPath, new
        {
            requests = new[]
            {
                new
                {
                    requestId = "npc_trade_alpha",
                    npcId = "npc_mira",
                    npcName = "Мира",
                    merchantProfile = "local_merchant",
                    tradeCycleId = "mortal_trade_14",
                    derivedTradeSlotCount = 4,
                    createdAtTurn = 14,
                    createdAtUtc = "2026-04-27T14:00:00Z"
                }
            }
        });
        var engine = CreateGameEngine();

        var blockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        Assert.Contains(blockers, blocker =>
            blocker.Contains(ActorSocialInteractionRequestState.PendingNpcRequestPath, StringComparison.OrdinalIgnoreCase) &&
            blocker.Contains("npc_social_alpha", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(blockers, blocker =>
            blocker.Contains(NpcTradeRequestState.PendingRequestPath, StringComparison.OrdinalIgnoreCase) &&
            blocker.Contains("npc_trade_alpha", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task CollectIncarnationBlockersAsync_EmptyGuardianSocialRequestsDoNotBlockSoulGates()
    {
        await WriteJsonAsync(ActorSocialInteractionRequestState.PendingGuardianRequestPath, new
        {
            requests = Array.Empty<object>()
        });
        var engine = CreateGameEngine();

        var blockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        Assert.Empty(blockers);
        Assert.False(_fs.FileExists(ActorSocialInteractionRequestState.PendingGuardianRequestPath));
    }

    [Theory]
    [InlineData(GuardianAbodeResidentRequestState.PendingResidentsRequestPath)]
    [InlineData(GuardianAbodeResidentRequestState.PendingInteractionsRequestPath)]
    [InlineData(GuardianAbodeResidentRequestState.PendingTransfersRequestPath)]
    public async Task CollectIncarnationBlockersAsync_EmptyResidentRequestBundlesDoNotBlockSoulGates(string pendingPath)
    {
        await WriteJsonAsync(pendingPath, new
        {
            requests = Array.Empty<object>()
        });
        var engine = CreateGameEngine();

        var blockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        Assert.Empty(blockers);
        Assert.False(_fs.FileExists(pendingPath));
    }

    [Fact]
    public async Task CollectIncarnationBlockersAsync_ValidManifestationRequestDoesNotBlockSoulGates()
    {
        await WriteJsonAsync(GuardianAbodeResidentRequestState.PendingManifestationRequestPath, new
        {
            requests = new[]
            {
                new
                {
                    requestId = "manifest_next_life",
                    manifestationSource = "resident_relic",
                    relicId = "relic_echo",
                    relicName = "Эхо Лиоры",
                    sourceResidentId = "resident_liora",
                    sourceGuardianId = "guardian_azalia",
                    sourceGuardianName = "Азалия",
                    targetIncarnation = 5,
                    companionNameHint = "Лиора",
                    originWorldSummary = "Следующая смертная жизнь.",
                    futureCompanionPrompt = "Лиора проявится как ранняя спутница в следующей смертной жизни.",
                    bondReason = "Связь закреплена через реликвию резидента.",
                    coreTraits = new[] { "loyal" },
                    archetypeHints = new[] { "guide" },
                    appearanceMotifs = new[] { "dawn" },
                    createdAtUtc = "2026-04-27T14:00:00Z"
                }
            }
        });
        var engine = CreateGameEngine();

        var blockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        Assert.Empty(blockers);
        Assert.True(_fs.FileExists(GuardianAbodeResidentRequestState.PendingManifestationRequestPath));
    }

    [Fact]
    public async Task CollectIncarnationBlockersAsync_ShiningArrayPayloadIsSafeForSoulGatesPanel()
    {
        await WriteJsonAsync(ShiningCoreActionRequestState.PendingActionsRequestPath, new
        {
            requests = new[]
            {
                new
                {
                    requestId = "core_blocker_array_001",
                    actionType = "prepare_incarnation_package",
                    selectedCardIds = new[] { "card_alpha", "card_beta" },
                    createdAtTurn = 14,
                    createdAtUtc = "2026-04-28T00:00:00Z"
                }
            }
        });
        var engine = CreateGameEngine();

        var blockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        var blocker = Assert.Single(blockers);
        Assert.Contains("core_blocker_array_001", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("selectedCardIds=[card_alpha, card_beta]", blocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("\"selectedCardIds\": [", blocker, StringComparison.OrdinalIgnoreCase);

        var panelBody = string.Join("\n", new[]
        {
            "Нельзя войти в новую смертную жизнь, пока остаются незакрытые загробные контракты.",
            string.Empty,
            string.Join("\n", blockers.Select(item => $"• {item}")),
            string.Empty,
            "Сначала дождитесь явного закрытия GM или почините повреждённый pending contract."
        });
        var ex = Record.Exception(() => new Panel(GameInterface.SafeMarkup(panelBody)));

        Assert.Null(ex);
    }

    [Fact]
    public async Task CollectIncarnationBlockersAsync_SourceOfLightPendingBlocksSoulGates()
    {
        await WriteJsonAsync(
            SourceOfLightCapstoneState.PendingRequestPath,
            SourceOfLightCapstoneState.CreateRequest(12, 580, 4));
        var engine = CreateGameEngine();

        var blockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        Assert.Contains(blockers, blocker =>
            blocker.Contains(SourceOfLightCapstoneState.PendingRequestPath, StringComparison.OrdinalIgnoreCase) &&
            blocker.Contains(SourceOfLightCapstoneState.PassiveId, StringComparison.OrdinalIgnoreCase) &&
            blocker.Contains(SourceOfLightCapstoneState.RelicId, StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task CollectIncarnationBlockersAsync_ActiveSpiritualConflictBlocksSoulGates()
    {
        await WriteJsonAsync(AfterlifeSpiritualConflictState.StatePath, new
        {
            schemaVersion = 1,
            activeConflict = new
            {
                conflictId = "afterlife_conflict_active_gate_blocker",
                realm = "Chaos Sea",
                operationType = "pressure",
                resolutionState = "active"
            },
            recentConflicts = Array.Empty<object>()
        });
        var engine = CreateGameEngine();

        var blockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        Assert.Contains(blockers, blocker =>
            blocker.Contains(AfterlifeSpiritualConflictState.StatePath, StringComparison.OrdinalIgnoreCase) &&
            blocker.Contains("activeConflict", StringComparison.OrdinalIgnoreCase) &&
            blocker.Contains("resolve", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task ChaosSeaToSoulGatesJourney_HygieneBlockersAndSnapshotsRemainConsistent()
    {
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            soulName = "Тестовая Душа",
            currentRealm = "Chaos Sea",
            currentIncarnation = 4,
            inkFeathers = new { current = 40 }
        });
        await WriteJsonAsync(ActorSocialInteractionRequestState.PendingGuardianRequestPath, new { requests = Array.Empty<object>() });
        await WriteJsonAsync(GuardianAbodeResidentRequestState.PendingResidentsRequestPath, new { requests = Array.Empty<object>() });
        Directory.CreateDirectory(_fs.ResolvePath("game_state/control/pending_turn_snapshot"));
        await WriteJsonAsync(SystemGuardianLibraryService.AttractionRequestPath, new
        {
            mode = "system_guardian_attraction",
            targetPresetId = "eternal_tide_001",
            targetPresetDisplayName = "Прилив Памяти",
            targetPresetVersion = "1.0",
            sourceLibrary = "built_in",
            targetSummary = "Извечный Хранитель памяти.",
            renderedPromptPackage = "Досье Хранителя.",
            _lastUpdated = "2026-04-27T12:00:00Z"
        });
        await WriteJsonAsync(AfterlifeSpiritualConflictState.StatePath, new
        {
            schemaVersion = 1,
            activeConflict = new
            {
                conflictId = "afterlife_conflict_gate_journey",
                realm = "Chaos Sea",
                operationType = "pressure",
                resolutionState = "active"
            },
            recentConflicts = Array.Empty<object>()
        });
        var engine = CreateGameEngine();

        var initialBlockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        Assert.Contains(initialBlockers, blocker =>
            blocker.Contains("притяжение к извечному Хранителю", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(initialBlockers, blocker =>
            blocker.Contains(AfterlifeSpiritualConflictState.StatePath, StringComparison.OrdinalIgnoreCase) &&
            blocker.Contains("activeConflict", StringComparison.OrdinalIgnoreCase));
        Assert.DoesNotContain(initialBlockers, blocker =>
            blocker.Contains("pending_turn_snapshot", StringComparison.OrdinalIgnoreCase));
        Assert.False(_fs.FileExists(ActorSocialInteractionRequestState.PendingGuardianRequestPath));
        Assert.False(_fs.FileExists(GuardianAbodeResidentRequestState.PendingResidentsRequestPath));

        _fs.DeleteFile(SystemGuardianLibraryService.AttractionRequestPath);
        await WriteJsonAsync(AfterlifeSpiritualConflictState.StatePath, new
        {
            schemaVersion = 1,
            activeConflict = (object?)null,
            recentConflicts = new[]
            {
                new
                {
                    conflictId = "afterlife_conflict_gate_journey",
                    realm = "Chaos Sea",
                    resolutionState = "repair_cancelled",
                    resolvedAtTurn = 40,
                    repairReason = "test cleanup before Soul Gates"
                }
            }
        });
        await _fs.WriteFileAtomicAsync(GuardianTradeRequestState.PendingRequestPath, "{ malformed");

        var malformedBlockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");

        Assert.Contains(malformedBlockers, blocker =>
            blocker.Contains(GuardianTradeRequestState.PendingRequestPath, StringComparison.OrdinalIgnoreCase) &&
            blocker.Contains("повреждённый", StringComparison.OrdinalIgnoreCase));

        _fs.DeleteFile(GuardianTradeRequestState.PendingRequestPath);
        var clearBlockers = await InvokePrivateAsync<List<string>>(engine, "CollectIncarnationBlockersAsync");
        Assert.Empty(clearBlockers);

        var request = new TurnRequest
        {
            SessionId = "session_chaos_soul_gates_journey",
            RequestId = "request_chaos_soul_gates_journey",
            TurnNumber = 41,
            PlayerAction = "Soul Gates prep after Chaos Sea journey",
            Timestamp = "2026-03-24T00:00:00Z",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Chaos Sea" }
        };
        await InvokePrivateTaskResultAsync(engine, "CreateCanonicalBaselineSnapshotAsync", request, null, "chaos-to-soul-gates-journey");

        var manifestJson = await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json");
        Assert.NotNull(manifestJson);
        var manifest = Assert.IsType<JsonObject>(JsonNode.Parse(manifestJson!)!);
        var files = Assert.IsType<JsonObject>(manifest["files"]);
        var snapshotHashes = Assert.IsType<JsonObject>(manifest["snapshotFileHashes"]);
        var rollbackBaselineFiles = Assert.IsType<JsonArray>(manifest["rollbackBaselineFiles"])
            .Select(node => node?.GetValue<string>() ?? string.Empty)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        Assert.True(files.ContainsKey("game_state/meta/soul_state.json"));
        Assert.True(files.ContainsKey(AfterlifeSpiritualConflictState.StatePath));
        Assert.False(files.ContainsKey(SystemGuardianLibraryService.AttractionRequestPath));
        Assert.False(files.ContainsKey(GuardianTradeRequestState.PendingRequestPath));
        Assert.Contains("game_state/meta/soul_state.json", rollbackBaselineFiles);
        Assert.Contains(AfterlifeSpiritualConflictState.StatePath, rollbackBaselineFiles);
        Assert.DoesNotContain(SystemGuardianLibraryService.AttractionRequestPath, rollbackBaselineFiles);

        foreach (var fileEntry in files)
        {
            var snapshotPath = fileEntry.Value?.GetValue<string>();
            Assert.False(string.IsNullOrWhiteSpace(snapshotPath));
            Assert.True(_fs.FileExists(snapshotPath!), $"{snapshotPath} should exist for {fileEntry.Key}.");
            Assert.True(snapshotHashes.TryGetPropertyValue(fileEntry.Key, out var hashNode));
            var expectedHash = hashNode?.GetValue<string>();
            Assert.False(string.IsNullOrWhiteSpace(expectedHash));
            var snapshotContent = await _fs.ReadFileBytesAsync(snapshotPath!);
            Assert.NotNull(snapshotContent);
            Assert.Equal(
                expectedHash,
                Convert.ToHexString(SHA256.HashData(snapshotContent!)),
                ignoreCase: true);
        }
    }

    [Fact]
    public async Task CleanupAfterCancelledChaosSeaMarkerTurn_PreservesSystemGuardianAttractionForLateResponse()
    {
        await WriteJsonAsync(SystemGuardianLibraryService.AttractionRequestPath, new
        {
            mode = "system_guardian_attraction",
            targetPresetId = "eternal_tide_001",
            targetPresetDisplayName = "Прилив Памяти",
            targetPresetVersion = "1.0",
            sourceLibrary = "built_in",
            targetSummary = "Извечный Хранитель памяти.",
            renderedPromptPackage = "Досье Хранителя.",
            _lastUpdated = "2026-04-27T12:00:00Z"
        });
        var engine = CreateGameEngine();

        InvokePrivate(
            engine,
            "CleanupAfterCancelledChaosSeaMarkerTurn",
            "[CHAOS_SEA_SYSTEM_GUARDIAN_ATTRACTION: eternal_tide_001] Игрок слышит зов.");

        Assert.True(_fs.FileExists(SystemGuardianLibraryService.AttractionRequestPath));
        var json = await _fs.ReadFileAsync(SystemGuardianLibraryService.AttractionRequestPath);
        Assert.Contains("eternal_tide_001", json, StringComparison.Ordinal);
    }

    [Fact]
    public async Task NormalizeRuntimeUiArtifactsAsync_PreservesResolvedPendingContractsBeforeValidation_AndAcceptedCleanupClearsThem()
    {
        const string sessionId = "session-terminal-validation";
        const string requestId = "request-terminal-validation";
        const int turnNumber = 21;
        var pendingRequest = new
        {
            requestId = "guardian_trade_late_response",
            guardianId = "guardian_alpha",
            guardianName = "Азалия",
            abodeId = "abode_alpha",
            returnCycleId = "return_21",
            currentReputation = 110,
            derivedTradeSlotCount = 1,
            effectiveRarityCeilingBonusSteps = 0,
            projectBonusSignature = "0|0|0",
            createdAtUtc = "2026-04-27T00:00:00Z",
            createdAtTurn = turnNumber
        };

        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            currentRealm = "Chaos Sea",
            currentIncarnation = 4,
            inkFeathers = new { current = 10, total = 10 },
            soulRelics = new
            {
                equipped = Array.Empty<object>(),
                stored = Array.Empty<object>()
            }
        });
        await WriteJsonAsync("game_state/meta/guardians.json", new
        {
            guardians = new[]
            {
                new
                {
                    guardianId = "guardian_alpha",
                    guardianName = "Азалия",
                    tradeInventory = new
                    {
                        tradeCycleId = "return_21",
                        generatedAtUtc = "2026-04-27T01:00:00Z",
                        generationReputationTier = "Friendly",
                        pricingReputationTier = "Friendly",
                        effectiveRarityCeilingBonusSteps = 0,
                        projectBonusSignature = "0|0|0",
                        items = new[]
                        {
                            new { slotId = "slot_guardian_trade_late_response_001" }
                        }
                    },
                    tradeInventoryReceipts = new[]
                    {
                        new
                        {
                            requestId = "guardian_trade_late_response",
                            guardianId = "guardian_alpha",
                            guardianName = "Азалия",
                            abodeId = "abode_alpha",
                            tradeCycleId = "return_21",
                            status = "ready",
                            itemCount = 1,
                            resolvedAtTurn = turnNumber,
                            resolvedAtUtc = "2026-04-27T01:01:00Z"
                        }
                    }
                }
            }
        });
        await WriteJsonAsync(GuardianTradeRequestState.PendingRequestPath, pendingRequest);
        await WriteJsonAsync(
            $"game_state/control/pending_turn_snapshot/{GuardianTradeRequestState.PendingRequestPath}",
            pendingRequest);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            accepted = true,
            sessionId,
            requestId,
            turnNumber
        });
        await WritePendingTurnSnapshotManifestAsync(
            sessionId,
            requestId,
            turnNumber,
            GuardianTradeRequestState.PendingRequestPath);

        var engine = CreateGameEngine();

        await InvokePrivateTaskAsync(engine, "NormalizeRuntimeUiArtifactsAsync");

        Assert.True(_fs.FileExists(GuardianTradeRequestState.PendingRequestPath));

        await InvokePrivateTaskAsync(engine, "CleanupAcceptedTurnTerminalArtifactsAsync");

        Assert.False(_fs.FileExists(GuardianTradeRequestState.PendingRequestPath));
    }

    [Fact]
    public async Task EnsureClientOwnedSystemFilesHealthyAsync_RemovesOrphanedTurnRequestBeforeValidation()
    {
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            currentRealm = "Mortal World",
            currentIncarnation = 1
        });
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId = "session-stale-request",
            requestId = "request-stale-request",
            turnNumber = 7,
            playerAction = "Старый ход после аварийного завершения"
        });

        var engine = CreateGameEngine();

        await InvokePrivateTaskAsync(engine, "EnsureClientOwnedSystemFilesHealthyAsync");

        Assert.False(_fs.FileExists("input/turn_request.json"));
    }

    [Fact]
    public async Task ResolveTerminalSignalTimeoutSecondsAsync_ActiveDaemonWithDisabledTimeoutUsesBridgeSafeMinimum()
    {
        await WriteJsonAsync("game_state/control/gm_daemon_status.json", new
        {
            status = "running",
            pid = Environment.ProcessId,
            sessionPath = _rootPath,
            turnTimeoutSeconds = 0,
            heartbeatAtUtc = DateTime.UtcNow.ToString("o")
        });

        var engine = CreateGameEngine(configureSettings: settings =>
        {
            settings.GmTimeoutSeconds = 300;
            settings.GmBridgeEnabled = true;
            settings.GmBridgeBackend = "ConPTYBridge";
        });

        var timeoutSeconds = await InvokePrivateAsync<int>(engine, "ResolveTerminalSignalTimeoutSecondsAsync");

        Assert.True(timeoutSeconds >= 900);
    }

    [Fact]
    public async Task CleanupAcceptedTurnTerminalArtifactsAsync_PreservesSnapshotButNotReadyForIncarnationTrigger()
    {
        const string sessionId = "session-late-incarnation";
        const string requestId = "request-late-incarnation";
        const int turnNumber = 23;
        await WriteJsonAsync("game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json", new
        {
            currentRealm = "Chaos Sea",
            currentIncarnation = 2
        });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, "game_state/meta/soul_state.json");
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            accepted = true,
            sessionId,
            requestId,
            turnNumber
        });
        await WriteJsonAsync("game_state/control/incarnation_trigger.json", new
        {
            worldDescription = "Тестовый смертный мир.",
            characterDescription = "Тестовая душа.",
            circumstances = "Проверка late accepted trigger.",
            source = "test"
        });

        var engine = CreateGameEngine();

        await InvokePrivateTaskAsync(engine, "CleanupAcceptedTurnTerminalArtifactsAsync");

        Assert.False(_fs.FileExists("ready/turn_complete.json"));
        Assert.True(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
        Assert.True(_fs.FileExists("game_state/control/incarnation_trigger.json"));
    }

    [Fact]
    [Trait("Category", "PreMergeSentinel")]
    public async Task CleanupAcceptedTurnTerminalArtifactsAsync_WithoutIncarnationTrigger_RemovesTerminalContext()
    {
        const string sessionId = "session-normal-cleanup";
        const string requestId = "request-normal-cleanup";
        const int turnNumber = 24;
        await WriteJsonAsync("game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json", new
        {
            currentRealm = "Chaos Sea",
            currentIncarnation = 2
        });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, "game_state/meta/soul_state.json");
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            accepted = true,
            sessionId,
            requestId,
            turnNumber
        });

        var engine = CreateGameEngine();

        await InvokePrivateTaskAsync(engine, "CleanupAcceptedTurnTerminalArtifactsAsync");

        Assert.False(_fs.FileExists("ready/turn_complete.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
    }

    [Fact]
    public async Task CleanupAcceptedTurnTerminalArtifactsAsync_WithoutIncarnationTrigger_RemovesAcceptedTurnRequest()
    {
        const string sessionId = "session-accepted-input-cleanup";
        const string requestId = "request-accepted-input-cleanup";
        const int turnNumber = 26;
        await WriteJsonAsync("game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json", new
        {
            currentRealm = "Chaos Sea",
            currentIncarnation = 2
        });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, "game_state/meta/soul_state.json");
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber,
            playerAction = "Проверка очистки принятого хода."
        });
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            accepted = true,
            sessionId,
            requestId,
            turnNumber
        });

        var engine = CreateGameEngine();

        await InvokePrivateTaskAsync(engine, "CleanupAcceptedTurnTerminalArtifactsAsync");

        Assert.False(_fs.FileExists("input/turn_request.json"));
        Assert.False(_fs.FileExists("ready/turn_complete.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
    }

    [Fact]
    public async Task CheckGmIncarnationTrigger_InputOnlySnapshotWithoutAcceptedContext_DoesNotDispatch()
    {
        const string sessionId = "session-input-only-incarnation";
        const string requestId = "request-input-only-incarnation";
        const int turnNumber = 25;
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            soulName = "Тестовая Душа",
            currentRealm = "Chaos Sea",
            currentIncarnation = 2,
            inkFeathers = new { current = 12 }
        });
        await WriteJsonAsync("game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json", new
        {
            currentRealm = "Chaos Sea",
            currentIncarnation = 2
        });
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, "game_state/meta/soul_state.json");
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber,
            playerAction = "Обычный ожидающий ход без accepted ready signal."
        });
        await WriteJsonAsync("game_state/control/incarnation_trigger.json", new
        {
            worldDescription = "Тестовый смертный мир.",
            characterDescription = "Тестовая душа.",
            circumstances = "Этот trigger не подтверждён accepted turn.",
            source = "test"
        });

        var engine = CreateGameEngine();
        var stateManager = GetPrivateField<StateManager>(engine, "_stateManager");
        await stateManager.RefreshGameStateAsync();

        var dispatched = await InvokePrivateAsync<bool>(engine, "CheckGmIncarnationTrigger", new object?[] { null });

        Assert.False(dispatched);
        Assert.False(_fs.FileExists("game_state/control/incarnation_trigger.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
        var inputTurn = await _fs.ReadFileAsync("input/turn_request.json");
        Assert.NotNull(inputTurn);
        Assert.Contains(requestId, inputTurn, StringComparison.Ordinal);
        Assert.DoesNotContain("Тестовый смертный мир", inputTurn, StringComparison.Ordinal);
    }

    [Fact]
    public async Task CheckGmIncarnationTrigger_BootstrapRepairStall_ReturnsFalseAfterRollback()
    {
        CopyDirectory(TestRepoPaths.BaseSessionRoot, _fs.GameSessionPath);
        const string acceptedSessionId = "session-incarnation-trigger-stall";
        const string acceptedRequestId = "request-incarnation-trigger-stall";
        const int acceptedTurnNumber = 12;
        var chaosSoul = new
        {
            soulName = "Тестовая Душа",
            currentRealm = "Chaos Sea",
            currentIncarnation = 0,
            inkFeathers = new { current = 0, total = 0 }
        };
        await WriteJsonAsync("game_state/meta/soul_state.json", chaosSoul);
        await WriteJsonAsync("game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json", chaosSoul);
        await WritePendingTurnSnapshotManifestAsync(
            acceptedSessionId,
            acceptedRequestId,
            acceptedTurnNumber,
            "game_state/meta/soul_state.json");
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            sessionId = acceptedSessionId,
            requestId = acceptedRequestId,
            turnNumber = acceptedTurnNumber,
            status = "success",
            timestamp = "2026-07-09T01:00:00Z",
            filesModified = new[] { "game_state/control/incarnation_trigger.json" }
        });
        await WriteJsonAsync("game_state/control/incarnation_trigger.json", new
        {
            worldDescription = "Портовый город Аргенвик с купеческими каналами.",
            characterDescription = "Писарь Нерий Сольвейн.",
            circumstances = "Наставница Селена и торговец Мирко ждут в канцелярии.",
            source = "test"
        });

        var inputKeys = new List<ConsoleKeyInfo> { Key(ConsoleKey.Enter) };
        inputKeys.AddRange(Enumerable.Repeat(Key(ConsoleKey.RightArrow), 8));
        inputKeys.Add(Key(ConsoleKey.Enter));
        inputKeys.Add(Key(ConsoleKey.Enter));
        inputKeys.Add(Key(ConsoleKey.Enter));
        var engine = CreateGameEngine(new QueuedConsoleInputSource(inputKeys));
        var stateManager = GetPrivateField<StateManager>(engine, "_stateManager");
        await stateManager.RefreshGameStateAsync();
        SetPrivateField(engine, "_lastResponse", new GameResponse
        {
            Response = "Серет открывает Врата Души. Следующее пробуждение уже принадлежит смертной жизни Нерия Сольвейна."
        });
        var manifest = await InvokePrivateTaskResultAsync(engine, "LoadPendingTurnSnapshotManifestAsync");
        var acceptedSnapshotContext = await InvokePrivateTaskResultAsync(
            engine,
            "LoadValidatedPendingTurnSnapshotContextAsync",
            manifest,
            true);

        var gmOutputTask = Task.Run(async () =>
        {
            var request = await WaitForTurnRequestAsync();
            var scaffoldRoot = JsonNode.Parse((await _fs.ReadFileAsync(
                MortalBootstrapLocationScaffold.StatePath))!)!.AsObject();
            var locationRequest = scaffoldRoot["locationMaterializationRequest"]!.AsObject();
            var reservation = locationRequest["startReservation"]!.AsObject();
            var initialId = reservation["initialId"]!.GetValue<string>();
            var start = MortalLocationTestFixture.CreateRawLocation(
                reservation["route"]!.GetValue<string>());
            start["initialId"] = initialId;
            start["coordinates"] = reservation["coordinates"]!.DeepClone();
            start["materialization"]!["initialId"] = initialId;
            start["materialization"]!["materializationId"] =
                "mlocmat_bootstrap_repair_stall_start";
            start["materialization"]!["sourceTurn"] =
                locationRequest["turnNumber"]!.DeepClone();
            start["materialization"]!["sourceAuthority"] =
                locationRequest["sourceAuthority"]!.DeepClone();
            await _fs.WriteFileAtomicAsync(
                MortalLocationMaterializationContract.CurrentLocationPath,
                new JsonObject { ["currentLocationData"] = start }.ToJsonString());
            await _fs.WriteFileAtomicAsync(
                MortalLocationMaterializationContract.WorldMapPath,
                new JsonObject
                {
                    ["worldMapUpdates"] = new JsonObject
                    {
                        ["newLocations"] = new JsonArray(),
                        ["newLinks"] = new JsonArray()
                    }
                }.ToJsonString());
            await WriteJsonAsync("output/narrative_response.json", new
            {
                narrative = "Повреждённый bootstrap без response и timestamp."
            });
            await WriteJsonAsync("output/interface_updates.json", new
            {
                dialogueOptions = Array.Empty<object>(),
                timestamp = DateTime.UtcNow.ToString("o")
            });
            await WriteJsonAsync("output/debug_logs.json", new
            {
                timestamp = DateTime.UtcNow.ToString("o"),
                gm_thoughts_markdown = "## Охват NPC-анализа\n- Режим / Mode: Scene-local\n- Релевантные акторы / Relevant actors: Селена, Мирко\n- Почему они релевантны / Why they are relevant: Тестовый bootstrap.\n- Акторы вне охвата / Actors outside scope: нет\n- Почему они вне охвата / Why outside scope: нет\n\n## Reasoning / Размышления NPC\n- Bootstrap intentionally malformed for rollback test."
            });
            var bootstrapValidator = new ValidationService(
                _fs,
                NullLogger<ValidationService>.Instance);
            var rawLocationIssues = await bootstrapValidator
                .ValidateAcceptedTurnRawMortalLocationMaterializationAsync();
            Assert.True(
                rawLocationIssues.All(issue => issue.Severity != IssueSeverity.Error),
                string.Join(
                    " | ",
                    rawLocationIssues
                        .Where(issue => issue.Severity == IssueSeverity.Error)
                        .Select(issue =>
                            $"{issue.Code}:{issue.FilePath}:{issue.Actor}:" +
                            $"expected={issue.Expected}:actual={issue.Actual}")));
            var rawItemIssues = await bootstrapValidator
                .ValidateAcceptedTurnRawMortalItemMaterializationAsync();
            Assert.True(
                rawItemIssues.All(issue => issue.Severity != IssueSeverity.Error),
                string.Join(
                    " | ",
                    rawItemIssues
                        .Where(issue => issue.Severity == IssueSeverity.Error)
                        .Select(issue => $"{issue.Code}:{issue.FilePath}:{issue.Actor}")));
            await WriteJsonAsync("ready/turn_complete.json", new
            {
                sessionId = request.SessionId,
                requestId = request.RequestId,
                turnNumber = request.TurnNumber,
                status = "success",
                timestamp = DateTime.UtcNow.ToString("o"),
                filesModified = new[]
                {
                    "output/narrative_response.json",
                    "output/interface_updates.json",
                    "output/debug_logs.json"
                }
            });

            await WaitForValidationRepairRequestContainingAsync(
                "narrative_response",
                TimeSpan.FromSeconds(20));
            await WriteJsonAsync("game_state/control/gm_validation_repair_artifact_stall_report.json", new
            {
                isStalled = true,
                completed = false,
                elapsedSeconds = 180,
                noProgressSeconds = 180,
                harnessSource = "gm_validation_repair_artifact_stall",
                bridgeCleanup = new
                {
                    reason = "gm_validation_repair_artifact_stall",
                    status = "fallback-stopped",
                    ok = true
                }
            });
        });

        var dispatchTask = InvokePrivateAsync<bool>(
            engine,
            "CheckGmIncarnationTrigger",
            new[] { acceptedSnapshotContext });
        await gmOutputTask.WaitAsync(TimeSpan.FromSeconds(60));
        await dispatchTask.WaitAsync(TimeSpan.FromSeconds(20));
        var dispatched = await dispatchTask;

        Assert.False(dispatched);
        var soul = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/soul_state.json"))!)!.AsObject();
        Assert.Equal("Chaos Sea", soul["currentRealm"]!.GetValue<string>());
        Assert.Equal(0, soul["currentIncarnation"]!.GetValue<int>());
        Assert.False(_fs.FileExists("input/turn_request.json"));
        Assert.False(_fs.FileExists("ready/turn_complete.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
        var lastResponse = GetPrivateField<GameResponse>(engine, "_lastResponse");
        Assert.DoesNotContain("Следующее пробуждение уже принадлежит смертной жизни", lastResponse.Response, StringComparison.Ordinal);
        Assert.Contains("не удалось подготовить смертную жизнь", lastResponse.Response, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    [Trait("Category", "PreMergeSentinel")]
    public async Task ResolveLifecycleAuthorizedTriggerLifeEndFromPendingSnapshotAsync_ValidActiveManifest_Authorizes()
    {
        await WriteJsonAsync("game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json", new
        {
            currentRealm = "Mortal World",
            currentIncarnation = 2
        });
        await WritePendingTurnSnapshotManifestAsync("test-session", "test-request", 14, "game_state/meta/soul_state.json");
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId = "test-session",
            requestId = "test-request",
            turnNumber = 14
        });
        await WriteJsonAsync("game_state/control/life_transitions.json", new
        {
            reason = "Death",
            summary = "Жизнь завершена."
        });

        var resolution = await CanonicalStateNormalizer.ResolveLifecycleAuthorizedTriggerLifeEndFromPendingSnapshotAsync(
            _fs,
            await _fs.ReadFileAsync("game_state/control/life_transitions.json"),
            "Mortal World");

        Assert.True(resolution.IsAuthorized);
        Assert.Equal("authorized", resolution.Code);
    }

    [Fact]
    public async Task ResolveLifecycleAuthorizedTriggerLifeEndFromPendingSnapshotAsync_GachaManifest_Authorizes()
    {
        await WriteJsonAsync("game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json", new
        {
            currentRealm = "Mortal World",
            currentIncarnation = 2
        });
        await WritePendingTurnSnapshotManifestAsync(
            "test-session",
            "test-request",
            14,
            new JsonObject
            {
                ["baseRarity"] = "Rare",
                ["formula"] = "test-gacha-roll"
            },
            "game_state/meta/soul_state.json");
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId = "test-session",
            requestId = "test-request",
            turnNumber = 14
        });
        await WriteJsonAsync("game_state/control/life_transitions.json", new
        {
            reason = "Death",
            summary = "Жизнь завершена."
        });

        var resolution = await CanonicalStateNormalizer.ResolveLifecycleAuthorizedTriggerLifeEndFromPendingSnapshotAsync(
            _fs,
            await _fs.ReadFileAsync("game_state/control/life_transitions.json"),
            "Mortal World");

        Assert.True(resolution.IsAuthorized);
        Assert.Equal("authorized", resolution.Code);
    }

    [Fact]
    public async Task ResolveLifecycleAuthorizedTriggerLifeEndFromPendingSnapshotAsync_InactiveManifest_FailsClosed()
    {
        await WriteJsonAsync("game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json", new
        {
            currentRealm = "Mortal World",
            currentIncarnation = 2
        });
        await WritePendingTurnSnapshotManifestAsync("stale-session", "stale-request", 99, "game_state/meta/soul_state.json");
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId = "test-session",
            requestId = "test-request",
            turnNumber = 14
        });
        await WriteJsonAsync("game_state/control/life_transitions.json", new
        {
            reason = "Death",
            summary = "Жизнь завершена."
        });

        var resolution = await CanonicalStateNormalizer.ResolveLifecycleAuthorizedTriggerLifeEndFromPendingSnapshotAsync(
            _fs,
            await _fs.ReadFileAsync("game_state/control/life_transitions.json"),
            "Mortal World");

        Assert.False(resolution.IsAuthorized);
        Assert.Equal("inactive_manifest", resolution.Code);
    }

    [Fact]
    public async Task ResolveLifecycleAuthorizedTriggerLifeEndFromPendingSnapshotAsync_StructurallyInvalidManifest_FailsClosed()
    {
        await WriteJsonAsync("game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json", new
        {
            currentRealm = "Mortal World",
            currentIncarnation = 2
        });
        await WritePendingTurnSnapshotManifestAsync("test-session", "test-request", 14, "game_state/meta/soul_state.json");
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId = "test-session",
            requestId = "test-request",
            turnNumber = 14
        });
        await WriteJsonAsync("game_state/control/life_transitions.json", new
        {
            reason = "Death",
            summary = "Жизнь завершена."
        });

        var manifest = JsonNode.Parse((await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json"))!)!.AsObject();
        manifest["snapshotFileHashes"] = new JsonObject();
        manifest["manifestPayloadHash"] = ComputeManifestPayloadHash(JsonSerializer.Deserialize<PendingTurnSnapshotManifestPayload>(
            manifest.ToJsonString(),
            SnapshotHashJsonOpts)!);
        await _fs.WriteFileAtomicAsync(
            "game_state/control/pending_turn_snapshot.json",
            manifest.ToJsonString(SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed));

        var resolution = await CanonicalStateNormalizer.ResolveLifecycleAuthorizedTriggerLifeEndFromPendingSnapshotAsync(
            _fs,
            await _fs.ReadFileAsync("game_state/control/life_transitions.json"),
            "Mortal World");

        Assert.False(resolution.IsAuthorized);
        Assert.Equal("invalid_manifest", resolution.Code);
    }

    [Fact]
    [Trait("Category", "PreMergeSentinel")]
    public async Task TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync_ResetsEnlightenmentAndPreservesInkFeathers()
    {
        var profiles = new JsonObject
        {
            [AfterlifeEntityProfileState.ProfilesProperty] = new JsonArray
            {
                new JsonObject
                {
                    ["actorType"] = "player_soul",
                    ["actorId"] = "player_soul",
                    ["displayName"] = "Испытующая Душа",
                    ["realm"] = "Shining Abode"
                }
            }
        };
        var soul = new JsonObject
        {
            ["soulName"] = "Испытующая Душа",
            ["currentRealm"] = "Shining Abode",
            ["currentIncarnation"] = 4,
            ["inkFeathers"] = new JsonObject { ["current"] = 7, ["total"] = 31 },
            ["enlightenment"] = new JsonObject
            {
                ["currentTier"] = "Сияющий Мудрец",
                ["experience"] = 187,
                ["level"] = 6,
                ["progressPercent"] = 73
            },
            ["soulProgression"] = new JsonObject
            {
                ["tier"] = 4,
                ["tierName"] = "Transcendence",
                ["progressPercent"] = 100,
                ["totalExperience"] = 999,
                ["experienceInCurrentTier"] = 999
            },
            [AfterlifeSpiritualConflictState.SoulStateProfileProperty] = new JsonObject
            {
                [AfterlifeSpiritualConflictState.SpiritFocusTierProperty] = 0
            }
        };
        var shiningState = ShiningAbodeState.CreateDefaultState();
        shiningState["availability"] = ShiningAbodeState.AvailabilityActive;
        shiningState["radiance"] = new JsonObject
        {
            ["experience"] = 22,
            ["tier"] = 3
        };
        shiningState["lightSparks"] = 88;
        await CanonicalResourceQuartetTestFixture.CommitFreshBootstrapAsync(
            _fs,
            new AfterlifeOwnerResourceAcceptedState(
                Profiles: profiles,
                SpiritualConflict: AfterlifeSpiritualConflictState.CreateDefaultRoot(),
                SoulState: soul,
                ShiningAbode: shiningState));

        var engine = CreateGameEngine();
        var stateManager = GetPrivateField<StateManager>(engine, "_stateManager");

        await stateManager.RefreshGameStateAsync();
        AnsiConsole.Record();

        var completed = await InvokePrivateAsync<bool>(engine, "TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync");

        Assert.True(completed, AnsiConsole.ExportText());

        var soulRoot = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/soul_state.json"))!)!.AsObject();
        var shiningRoot = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/shining_abode_state.json"))!)!.AsObject();

        Assert.Equal("Chaos Sea", soulRoot["currentRealm"]?.GetValue<string>());
        var enlightenment = Assert.IsType<JsonObject>(soulRoot["enlightenment"]);
        Assert.Equal("Новичок", enlightenment["currentTier"]?.GetValue<string>());
        Assert.Equal(0, enlightenment["experience"]?.GetValue<int>());
        Assert.Equal(0, enlightenment["level"]?.GetValue<int>());
        Assert.Equal(0, enlightenment["progressPercent"]?.GetValue<int>());
        var soulProgression = Assert.IsType<JsonObject>(soulRoot["soulProgression"]);
        Assert.Equal(0, soulProgression["tier"]?.GetValue<int>());
        Assert.Equal("Новичок", soulProgression["tierName"]?.GetValue<string>());
        Assert.Equal(0, soulProgression["progressPercent"]?.GetValue<int>());
        Assert.Equal(0, soulProgression["totalExperience"]?.GetValue<int>());
        Assert.Equal(0, soulProgression["experienceInCurrentTier"]?.GetValue<int>());
        var inkFeathers = Assert.IsType<JsonObject>(soulRoot["inkFeathers"]);
        Assert.Equal(7, inkFeathers["current"]?.GetValue<int>());
        Assert.Equal(31, inkFeathers["total"]?.GetValue<int>());
        Assert.Equal(ShiningAbodeState.AvailabilitySealedUntilNextAscension, shiningRoot["availability"]?.GetValue<string>());
        Assert.Equal("Chaos Sea", stateManager.CurrentState.CurrentRealm);
        Assert.Equal("Новичок", stateManager.CurrentState.EnlightenmentTier);
    }

    [Fact]
    public async Task TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync_PublishesProfileAndResourceLifecycleAtomically()
    {
        var bootstrap = ResourceBootstrapStateBuilder.BuildPristine();
        Assert.True(bootstrap.IsValid, string.Join(Environment.NewLine, bootstrap.Issues));
        var definitions = Assert.IsType<ResourceDefinitionCatalog>(bootstrap.Definitions);
        var guardianProfile = AfterlifeActorMaterializationTestFixture.CreateCompleteProfile(
            "guardian",
            "guardian_vesna",
            "Chaos Sea",
            materializedAtTurn: 31);

        var profiles = new JsonObject
        {
            [AfterlifeEntityProfileState.ProfilesProperty] = new JsonArray
            {
                new JsonObject
                {
                    ["actorType"] = "player_soul",
                    ["actorId"] = "player_soul",
                    ["displayName"] = "Испытующая Душа",
                    ["realm"] = "Shining Abode"
                },
                guardianProfile
            }
        };
        var soul = new JsonObject
        {
            ["soulName"] = "Испытующая Душа",
            ["currentRealm"] = "Shining Abode",
            ["currentIncarnation"] = 4,
            ["inkFeathers"] = new JsonObject { ["current"] = 7, ["total"] = 31 },
            ["enlightenment"] = new JsonObject
            {
                ["currentTier"] = "Сияющий Мудрец",
                ["experience"] = 187,
                ["level"] = 6,
                ["progressPercent"] = 73
            },
            [AfterlifeSpiritualConflictState.SoulStateProfileProperty] = new JsonObject
            {
                [AfterlifeSpiritualConflictState.SpiritFocusTierProperty] = 0
            }
        };
        var shining = ShiningAbodeState.CreateDefaultState();
        shining["availability"] = ShiningAbodeState.AvailabilityActive;
        shining["preparedIncarnationPackage"] = null;
        var guardian = new JsonObject
        {
            ["guardianId"] = "guardian_vesna",
            ["relationshipData"] = new JsonObject
            {
                ["currentReputation"] = 50
            },
            ["abodePower"] = new JsonObject
            {
                ["currentPower"] = 0
            },
            ["gachaSystem"] = new JsonObject
            {
                ["currentReturnCycleId"] = "chaos_return_31",
                ["gachaHistory"] = new JsonArray()
            }
        };
        var guardians = new JsonObject
        {
            ["guardians"] = new JsonArray(guardian),
            ["activeGuardian"] = guardian.DeepClone()
        };
        await CanonicalResourceQuartetTestFixture.CommitExplicitBootstrapAsync(
            _fs,
            definitions,
            bootstrap.State!,
            bootstrap.History!,
            new AfterlifeOwnerResourceAcceptedState(
                Profiles: profiles,
                SpiritualConflict: AfterlifeSpiritualConflictState.CreateDefaultRoot(),
                SoulState: soul,
                ShiningAbode: shining,
                Guardians: guardians));
        await SpendGuardianAttemptForFixtureAsync(
            _fs,
            definitions,
            guardianId: "guardian_vesna",
            turn: 31);

        var engine = CreateGameEngine();
        var stateManager = GetPrivateField<StateManager>(engine, "_stateManager");
        GetPrivateField<GameLoop>(engine, "_gameLoop").SetSession(
            "session_shining_return_resource_lifecycle",
            31);
        await stateManager.RefreshGameStateAsync();
        AnsiConsole.Record();

        var completed = await InvokePrivateAsync<bool>(
            engine,
            "TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync");

        Assert.True(completed, AnsiConsole.ExportText());
        var committedProfiles = JsonNode.Parse((await _fs.ReadFileAsync(
            AfterlifeEntityProfileState.StatePath))!)!.AsObject();
        var player = Assert.Single(Assert.IsType<JsonArray>(
                committedProfiles[AfterlifeEntityProfileState.ProfilesProperty])
            .OfType<JsonObject>(), profile =>
                string.Equals(
                    profile["actorType"]?.GetValue<string>(),
                    "player_soul",
                    StringComparison.Ordinal));
        Assert.Equal("Chaos Sea", player["realm"]!.GetValue<string>());
        var bindings = Assert.IsType<JsonArray>(player["resourceOwnerBindings"])
            .OfType<JsonObject>()
            .ToDictionary(
                binding => binding["realm"]!.GetValue<string>(),
                binding => binding["state"]!.GetValue<string>(),
                StringComparer.Ordinal);
        Assert.Equal("suspended", bindings["shining_abode"]);
        Assert.Equal("active", bindings["chaos_sea"]);

        var committedDefinitions = ResourceDefinitionCatalog.ParseCanonical(
            await _fs.ReadFileAsync(ResourceMaterializationContract.DefinitionsPath),
            allowMissingPristine: false).Catalog!;
        var state = ResourceStateContract.ParseCanonical(
            await _fs.ReadFileAsync(ResourceMaterializationContract.StatePath),
            committedDefinitions,
            allowMissingPristine: false);
        Assert.True(state.IsValid, string.Join(Environment.NewLine, state.Issues));
        Assert.Equal(
            ResourceLifecycleState.Suspended,
            Assert.Single(state.Ledger!.Entries, entry =>
                entry.Coordinate.Realm == "shining_abode" &&
                entry.Coordinate.OwnerKind == ResourceOwnerKind.AfterlifeActor &&
                entry.Coordinate.ResourceOwnerId == "player_soul" &&
                entry.Coordinate.ResourceKey == "spiritual_action_points").State);
        Assert.Equal(
            ResourceLifecycleState.Active,
            Assert.Single(state.Ledger.Entries, entry =>
                entry.Coordinate.Realm == "chaos_sea" &&
                entry.Coordinate.OwnerKind == ResourceOwnerKind.AfterlifeActor &&
                entry.Coordinate.ResourceOwnerId == "player_soul" &&
                entry.Coordinate.ResourceKey == "spiritual_action_points").State);
        var guardianAttempts = Assert.Single(state.Ledger.Entries, entry =>
            entry.Coordinate.Realm == "chaos_sea" &&
            entry.Coordinate.OwnerKind == ResourceOwnerKind.AfterlifeActor &&
            entry.Coordinate.ResourceOwnerId == "guardian_vesna" &&
            entry.Coordinate.ResourceKey == "gacha_attempts");
        Assert.Equal(1m, guardianAttempts.Current);
        Assert.Equal(2m, guardianAttempts.Maximum);

        var committedGuardians = JsonNode.Parse((await _fs.ReadFileAsync(
            "game_state/meta/guardians.json"))!)!.AsObject();
        var committedGuardian = Assert.Single(
            Assert.IsType<JsonArray>(committedGuardians["guardians"])
                .OfType<JsonObject>());
        Assert.Equal(
            "chaos_return_31",
            Assert.IsType<JsonObject>(committedGuardian["gachaSystem"])
                ["currentReturnCycleId"]!.GetValue<string>());
        Assert.Equal(
            "chaos_return_31",
            Assert.IsType<JsonObject>(Assert.IsType<JsonObject>(
                    committedGuardians["activeGuardian"])["gachaSystem"])
                ["currentReturnCycleId"]!.GetValue<string>());
    }

    [Fact]
    public async Task UpdateSoulStateRealm_MortalDeathStartsOneIncarnationBoundGuardianCycleAndRefillsAttempts()
    {
        var bootstrap = ResourceBootstrapStateBuilder.BuildPristine();
        Assert.True(bootstrap.IsValid, string.Join(Environment.NewLine, bootstrap.Issues));
        var definitions = Assert.IsType<ResourceDefinitionCatalog>(bootstrap.Definitions);
        var guardianProfile = AfterlifeActorMaterializationTestFixture.CreateCompleteProfile(
            "guardian",
            "guardian_vesna",
            "Chaos Sea",
            materializedAtTurn: 10);

        var profiles = new JsonObject
        {
            [AfterlifeEntityProfileState.ProfilesProperty] = new JsonArray
            {
                new JsonObject
                {
                    ["actorType"] = "player_soul",
                    ["actorId"] = "player_soul",
                    ["displayName"] = "Испытующая Душа",
                    ["realm"] = "Chaos Sea"
                },
                guardianProfile
            }
        };
        var soul = new JsonObject
        {
            ["soulName"] = "Испытующая Душа",
            ["currentRealm"] = "Mortal World",
            ["currentIncarnation"] = 2,
            ["enlightenment"] = new JsonObject
            {
                ["currentTier"] = "Новичок",
                ["experience"] = 0,
                ["level"] = 0
            },
            ["inkFeathers"] = new JsonObject { ["current"] = 0, ["total"] = 0 },
            ["soulRelics"] = new JsonObject
            {
                ["equipped"] = new JsonArray(),
                ["stored"] = new JsonArray()
            },
            ["livesHistory"] = new JsonArray(),
            [AfterlifeSpiritualConflictState.SoulStateProfileProperty] = new JsonObject
            {
                [AfterlifeSpiritualConflictState.SpiritFocusTierProperty] = 0
            }
        };
        var guardian = new JsonObject
        {
            ["guardianId"] = "guardian_vesna",
            ["relationshipData"] = new JsonObject { ["currentReputation"] = 50 },
            ["abodePower"] = new JsonObject { ["currentPower"] = 0 },
            ["gachaSystem"] = new JsonObject
            {
                ["currentReturnCycleId"] = "chaos_return_1",
                ["gachaHistory"] = new JsonArray()
            }
        };
        var guardians = new JsonObject
        {
            ["guardians"] = new JsonArray(guardian),
            ["activeGuardian"] = guardian.DeepClone()
        };
        await CanonicalResourceQuartetTestFixture.CommitExplicitBootstrapAsync(
            _fs,
            definitions,
            bootstrap.State!,
            bootstrap.History!,
            new AfterlifeOwnerResourceAcceptedState(
                Profiles: profiles,
                SpiritualConflict: AfterlifeSpiritualConflictState.CreateDefaultRoot(),
                SoulState: soul,
                ShiningAbode: ShiningAbodeState.CreateDefaultState(),
                Guardians: guardians));
        await SpendGuardianAttemptForFixtureAsync(
            _fs,
            definitions,
            guardianId: "guardian_vesna",
            turn: 10);

        var engine = CreateGameEngine();
        GetPrivateField<GameLoop>(engine, "_gameLoop").SetSession(
            "session_mortal_death_guardian_cycle",
            10);
        var updated = await InvokeSoulRealmTransitionAsync(
            engine,
            "MortalDeathToChaosSea",
            "Ходов прожито: 10. Заметка игрока: completed life.");

        Assert.True(updated);
        var committedGuardians = JsonNode.Parse((await _fs.ReadFileAsync(
            "game_state/meta/guardians.json"))!)!.AsObject();
        var committedGuardian = Assert.Single(
            Assert.IsType<JsonArray>(committedGuardians["guardians"])
                .OfType<JsonObject>());
        Assert.Equal(
            "chaos_return_2",
            Assert.IsType<JsonObject>(committedGuardian["gachaSystem"])
                ["currentReturnCycleId"]!.GetValue<string>());

        var state = ResourceStateContract.ParseCanonical(
            await _fs.ReadFileAsync(ResourceMaterializationContract.StatePath),
            definitions,
            allowMissingPristine: false);
        Assert.True(state.IsValid, string.Join(Environment.NewLine, state.Issues));
        var attempts = Assert.Single(state.Ledger!.Entries, entry =>
            entry.Coordinate.OwnerKind == ResourceOwnerKind.AfterlifeActor &&
            entry.Coordinate.ResourceOwnerId == "guardian_vesna" &&
            entry.Coordinate.ResourceKey == "gacha_attempts");
        Assert.Equal(2m, attempts.Current);
        Assert.Equal(2m, attempts.Maximum);
    }

    [Fact]
    public async Task ConsumePendingShiningMemorySelectionAsync_ReportsFailedZeroCandidateCommit()
    {
        await _fs.WriteFileAtomicAsync(
            "game_state/meta/soul_state.json",
            new JsonObject
            {
                ["soulName"] = "Испытующая Душа",
                ["currentRealm"] = "Mortal World",
                ["currentIncarnation"] = 4,
                ["livesHistory"] = new JsonArray(),
                [ShiningBlessingEffectState.SoulStateProperty] = new JsonObject
                {
                    ["memorySelection"] = new JsonObject
                    {
                        ["options"] = 1,
                        ["status"] = ShiningBlessingEffectState.MemoryStatusPendingPreTurnOneSelection,
                        ["sourceCardIds"] = new JsonArray("card_memory")
                    }
                }
            }.ToJsonString());
        var before = await _fs.ReadFileAsync("game_state/meta/soul_state.json");
        var engine = CreateGameEngine();
        using var soulLock = File.Open(
            _fs.ResolvePath("game_state/meta/soul_state.json"),
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read);

        var outcome = await InvokePrivateTaskResultAsync(
            engine,
            "ConsumePendingShiningMemorySelectionAsync");

        Assert.False((bool)outcome.GetType().GetProperty("Success")!.GetValue(outcome)!);
        Assert.Null(outcome.GetType().GetProperty("Summary")!.GetValue(outcome));
        Assert.Equal(before, await _fs.ReadFileAsync("game_state/meta/soul_state.json"));
    }

    [Fact]
    public async Task TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync_BlocksWhenPendingShiningRequestsExist()
    {
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            soulName = "Испытующая Душа",
            currentRealm = "Shining Abode",
            currentIncarnation = 4,
            inkFeathers = new { current = 7, total = 31 },
            enlightenment = new
            {
                currentTier = "Сияющий Мудрец",
                experience = 187,
                level = 6,
                progressPercent = 73
            }
        });
        await WriteJsonAsync("game_state/meta/shining_abode_state.json", new
        {
            availability = "active",
            radiance = new { experience = 22, tier = 3 },
            lightSparks = 88,
            halls = Array.Empty<object>(),
            factions = Array.Empty<object>(),
            shiningPoliticalActors = Array.Empty<object>(),
            preparedIncarnationPackage = (object?)null,
            gates = new
            {
                hasOpenDraft = false,
                isStale = false,
                openedThisAscension = false,
                draftOpenedAtTurn = (int?)null,
                draftOpenedAtUtc = (string?)null,
                blessingDraft = Array.Empty<object>(),
                selectedBlessingCardIds = Array.Empty<string>()
            }
        });

        await ShiningCoreActionRequestState.WriteRequestAsync(_fs, new ShiningCoreActionRequestState.PendingShiningCoreActionRequest
        {
            RequestId = "core-request-1",
            ActionType = ShiningCoreActionRequestState.ActionTypeOpenGates,
            FactionId = "faction-alpha",
            FactionName = "Фракция Альфа",
            CreatedAtTurn = 41,
            CreatedAtUtc = "2026-04-19T00:00:00Z"
        });
        await ShiningTradeRequestState.WriteRequestAsync(_fs, new ShiningTradeRequestState.PendingShiningTradeInventoryRequest
        {
            RequestId = "trade-request-1",
            FactionId = "faction-alpha",
            FactionName = "Фракция Альфа",
            TradeCycleId = "cycle-alpha",
            DerivedTradeTier = 2,
            DerivedTradeSlotCount = 3,
            DerivedRarityCeiling = "legendary",
            DerivedServiceMultiplier = 1.15,
            CreatedAtTurn = 41,
            CreatedAtUtc = "2026-04-19T00:00:00Z"
        });
        await ShiningFactionRequestState.WriteFoundingRequestAsync(_fs, new ShiningFactionRequestState.PendingShiningFactionFoundingRequest
        {
            RequestId = "founding-request-1",
            ProposedFactionId = "faction-founded",
            ProposedHallId = "hall-founded",
            ProposedHallName = "Зал Основания",
            ProposedHallDescription = "Первый зал новой фракции.",
            CreatedAtTurn = 41,
            CreatedAtUtc = "2026-04-19T00:00:00Z"
        });
        await ShiningFactionRequestState.WriteRealignmentRequestAsync(_fs, new ShiningFactionRequestState.PendingShiningFactionRealignmentRequest
        {
            RequestId = "realignment-request-1",
            ResidentId = "resident-alpha",
            ResidentName = "Альфа",
            SourceFactionId = "faction-alpha",
            SourceFactionName = "Фракция Альфа",
            TargetFactionId = "faction-beta",
            TargetFactionName = "Фракция Бета",
            CreatedAtTurn = 41,
            CreatedAtUtc = "2026-04-19T00:00:00Z"
        });
        await ShiningFactionRequestState.WriteLeadershipTransitionRequestAsync(_fs, new ShiningFactionRequestState.PendingShiningFactionLeadershipTransitionRequest
        {
            RequestId = "leadership-request-1",
            FactionId = "faction-alpha",
            FactionName = "Фракция Альфа",
            IncumbentHeadActorType = ShiningAbodeState.HeadActorTypeGuardian,
            IncumbentHeadActorId = "guardian-alpha",
            CandidateHeadActorType = ShiningAbodeState.HeadActorTypePlayerSoul,
            CandidateHeadActorId = "player",
            CreatedAtTurn = 41,
            CreatedAtUtc = "2026-04-19T00:00:00Z"
        });

        Assert.True(_fs.FileExists(ShiningCoreActionRequestState.PendingActionsRequestPath));
        Assert.True(_fs.FileExists(ShiningTradeRequestState.PendingRequestsPath));
        Assert.True(_fs.FileExists(ShiningFactionRequestState.PendingFoundingsRequestPath));
        Assert.True(_fs.FileExists(ShiningFactionRequestState.PendingRealignmentsRequestPath));
        Assert.True(_fs.FileExists(ShiningFactionRequestState.PendingLeadershipTransitionsRequestPath));

        var engine = CreateGameEngine();
        var stateManager = GetPrivateField<StateManager>(engine, "_stateManager");

        await stateManager.RefreshGameStateAsync();

        var completed = await InvokePrivateAsync<bool>(engine, "TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync");

        Assert.False(completed);
        Assert.True(_fs.FileExists(ShiningCoreActionRequestState.PendingActionsRequestPath));
        Assert.True(_fs.FileExists(ShiningTradeRequestState.PendingRequestsPath));
        Assert.True(_fs.FileExists(ShiningFactionRequestState.PendingFoundingsRequestPath));
        Assert.True(_fs.FileExists(ShiningFactionRequestState.PendingRealignmentsRequestPath));
        Assert.True(_fs.FileExists(ShiningFactionRequestState.PendingLeadershipTransitionsRequestPath));

        var soulRoot = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/soul_state.json"))!)!.AsObject();
        var shiningRoot = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/shining_abode_state.json"))!)!.AsObject();

        Assert.Equal("Shining Abode", soulRoot["currentRealm"]?.GetValue<string>());
        Assert.Equal(ShiningAbodeState.AvailabilityActive, shiningRoot["availability"]?.GetValue<string>());
        Assert.Equal("Shining Abode", stateManager.CurrentState.CurrentRealm);
        Assert.True(stateManager.CurrentState.IsInShiningAbode);
    }

    [Fact]
    public async Task GetBlockingShiningPendingContractPathsAsync_DeletesExplicitEmptyFilesButKeepsMalformedAndActive()
    {
        await WriteJsonAsync(ShiningCoreActionRequestState.PendingActionsRequestPath, new
        {
            requests = Array.Empty<object>()
        });
        await WriteJsonAsync(ShiningTradeRequestState.PendingRequestsPath, new
        {
            requests = new[]
            {
                new
                {
                    requestId = "trade-request-1",
                    factionId = "faction-alpha",
                    tradeCycleId = "shining_return_4",
                    createdAtTurn = 12
                }
            }
        });
        await _fs.WriteFileAtomicAsync(ShiningFactionRequestState.PendingFoundingsRequestPath, "{ malformed");
        await WriteJsonAsync(ShiningFactionRequestState.PendingRealignmentsRequestPath, new { });
        await WriteJsonAsync(
            SourceOfLightCapstoneState.PendingRequestPath,
            SourceOfLightCapstoneState.CreateRequest(12, 580, 4));

        var engine = CreateGameEngine();

        var blockingPaths = await InvokePrivateAsync<IReadOnlyList<string>>(engine, "GetBlockingShiningPendingContractPathsAsync");

        Assert.DoesNotContain(ShiningCoreActionRequestState.PendingActionsRequestPath, blockingPaths);
        Assert.False(_fs.FileExists(ShiningCoreActionRequestState.PendingActionsRequestPath));
        Assert.Contains(blockingPaths, item =>
            item.Contains(ShiningTradeRequestState.PendingRequestsPath, StringComparison.OrdinalIgnoreCase) &&
            item.Contains("trade-request-1", StringComparison.OrdinalIgnoreCase) &&
            item.Contains("shining_return_4", StringComparison.OrdinalIgnoreCase));
        Assert.Contains(blockingPaths, item =>
            item.Contains(SourceOfLightCapstoneState.PendingRequestPath, StringComparison.OrdinalIgnoreCase) &&
            item.Contains(SourceOfLightCapstoneState.PassiveId, StringComparison.OrdinalIgnoreCase) &&
            item.Contains(SourceOfLightCapstoneState.RelicId, StringComparison.OrdinalIgnoreCase));
        Assert.Contains(blockingPaths, item =>
            item.Contains(ShiningFactionRequestState.PendingFoundingsRequestPath, StringComparison.OrdinalIgnoreCase) &&
            item.Contains("malformed", StringComparison.OrdinalIgnoreCase));
        var wrongShapeBlocker = Assert.Single(
            blockingPaths,
            item => item.Contains(ShiningFactionRequestState.PendingRealignmentsRequestPath, StringComparison.OrdinalIgnoreCase));
        Assert.Contains("missing requests[] array", wrongShapeBlocker, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("repair", wrongShapeBlocker, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("active Shining pending contract", wrongShapeBlocker, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("root full payload", wrongShapeBlocker, StringComparison.OrdinalIgnoreCase);
        Assert.True(_fs.FileExists(ShiningTradeRequestState.PendingRequestsPath));
        Assert.True(_fs.FileExists(ShiningFactionRequestState.PendingFoundingsRequestPath));
        Assert.True(_fs.FileExists(ShiningFactionRequestState.PendingRealignmentsRequestPath));
        Assert.True(_fs.FileExists(SourceOfLightCapstoneState.PendingRequestPath));
    }

    [Fact]
    public async Task NormalizeRuntimeUiArtifactsAsync_PreservesResolvedShiningPendingRequestDuringActiveSnapshot()
    {
        var requestRoot = new
        {
            requests = new[]
            {
                new
                {
                    requestId = "core_req_open_gates",
                    actionType = ShiningCoreActionRequestState.ActionTypeOpenGates,
                    factionId = "",
                    factionName = "",
                    projectId = "",
                    projectDisplayName = "",
                    radianceTierAtRequest = 1,
                    quotedCostFeathers = 0,
                    quotedCostLightSparks = 0,
                    sourceDraftVersion = 0,
                    selectedCardIds = Array.Empty<string>(),
                    createdAtTurn = 12,
                    createdAtUtc = "2026-04-30T00:00:00Z"
                }
            }
        };
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            currentRealm = "Shining Abode",
            currentIncarnation = 3,
            inkFeathers = new { current = 40 }
        });
        await WriteJsonAsync(ShiningAbodeState.StatePath, new
        {
            availability = ShiningAbodeState.AvailabilityActive,
            radiance = new { experience = 120, tier = 1 },
            lightSparks = 12,
            gates = new
            {
                draftVersion = 2,
                hasOpenDraft = true,
                isStale = false,
                allCandidateBlessingCards = Array.Empty<object>(),
                availableBlessingCards = Array.Empty<object>(),
                shownBlessingCardIds = Array.Empty<string>(),
                selectedBlessingCardIds = Array.Empty<string>(),
                nextCandidateCursor = 0,
                rerollsRemaining = 0
            },
            coreActionReceipts = new[]
            {
                new
                {
                    requestId = "core_req_open_gates",
                    actionType = ShiningCoreActionRequestState.ActionTypeOpenGates,
                    status = ShiningCoreActionRequestState.RequestStatusAccepted,
                    generatedDraftVersion = 2,
                    selectedCardIds = Array.Empty<string>(),
                    newResidentIds = Array.Empty<string>(),
                    seededProjectIds = Array.Empty<string>(),
                    quotedCostFeathers = 0,
                    quotedCostLightSparks = 0,
                    resolvedAtTurn = 12,
                    resolvedAtUtc = "2026-04-30T00:01:00Z",
                    reason = "gates_opened"
                }
            }
        });
        await WriteJsonAsync(ShiningCoreActionRequestState.PendingActionsRequestPath, requestRoot);
        await WriteJsonAsync(
            $"game_state/control/pending_turn_snapshot/{ShiningCoreActionRequestState.PendingActionsRequestPath}",
            requestRoot);
        await WritePendingTurnSnapshotManifestAsync(
            "test-session",
            "test-request",
            12,
            ShiningCoreActionRequestState.PendingActionsRequestPath);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId = "test-session",
            requestId = "test-request",
            turnNumber = 12
        });
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            sessionId = "test-session",
            requestId = "test-request",
            turnNumber = 12,
            accepted = true
        });
        var engine = CreateGameEngine();

        await InvokePrivateTaskAsync(engine, "NormalizeRuntimeUiArtifactsAsync");

        Assert.True(_fs.FileExists(ShiningCoreActionRequestState.PendingActionsRequestPath));
    }

    [Fact]
    public async Task TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync_BlocksLegacyPendingNativeDiscovery()
    {
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            soulName = "Испытующая Душа",
            currentRealm = "Shining Abode",
            currentIncarnation = 4,
            inkFeathers = new { current = 32, total = 64 }
        });
        await WriteJsonAsync("game_state/meta/shining_abode_state.json", new
        {
            availability = "active",
            radiance = new { experience = 22, tier = 3 },
            lightSparks = 68,
            halls = Array.Empty<object>(),
            factions = Array.Empty<object>(),
            shiningPoliticalActors = Array.Empty<object>(),
            preparedIncarnationPackage = (object?)null,
            pendingNativeFactionDiscovery = new
            {
                requestId = "discover_native_faction:0041",
                createdAtTurn = 41,
                createdAtUtc = "2026-04-19T00:00:00Z",
                radianceTierAtRequest = 3,
                costFeathers = 25,
                costLightSparks = 20
            },
            gates = new
            {
                hasOpenDraft = false,
                isStale = false,
                openedThisAscension = false,
                draftOpenedAtTurn = (int?)null,
                draftOpenedAtUtc = (string?)null,
                blessingDraft = Array.Empty<object>(),
                selectedBlessingCardIds = Array.Empty<string>()
            }
        });

        var engine = CreateGameEngine();
        var stateManager = GetPrivateField<StateManager>(engine, "_stateManager");
        await stateManager.RefreshGameStateAsync();

        var completed = await InvokePrivateAsync<bool>(engine, "TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync");

        Assert.False(completed);
        var soulRoot = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/soul_state.json"))!)!.AsObject();
        var shiningRoot = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/shining_abode_state.json"))!)!.AsObject();
        Assert.Equal("Shining Abode", soulRoot["currentRealm"]?.GetValue<string>());
        Assert.NotNull(shiningRoot["pendingNativeFactionDiscovery"]);
        Assert.Equal(ShiningAbodeState.AvailabilityActive, shiningRoot["availability"]?.GetValue<string>());
        Assert.Equal("Shining Abode", stateManager.CurrentState.CurrentRealm);
    }

    [Fact]
    public async Task TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync_BlocksMalformedNonNullLegacyPendingNativeDiscovery()
    {
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            soulName = "Испытующая Душа",
            currentRealm = "Shining Abode",
            currentIncarnation = 4,
            inkFeathers = new { current = 32, total = 64 }
        });
        await WriteJsonAsync("game_state/meta/shining_abode_state.json", new
        {
            availability = "active",
            radiance = new { experience = 22, tier = 3 },
            lightSparks = 68,
            halls = Array.Empty<object>(),
            factions = Array.Empty<object>(),
            shiningPoliticalActors = Array.Empty<object>(),
            preparedIncarnationPackage = (object?)null,
            pendingNativeFactionDiscovery = "malformed_contract",
            gates = new
            {
                hasOpenDraft = false,
                isStale = false,
                openedThisAscension = false,
                draftOpenedAtTurn = (int?)null,
                draftOpenedAtUtc = (string?)null,
                blessingDraft = Array.Empty<object>(),
                selectedBlessingCardIds = Array.Empty<string>()
            }
        });

        var engine = CreateGameEngine();
        var stateManager = GetPrivateField<StateManager>(engine, "_stateManager");
        await stateManager.RefreshGameStateAsync();

        var completed = await InvokePrivateAsync<bool>(engine, "TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync");

        Assert.False(completed);
        var soulRoot = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/soul_state.json"))!)!.AsObject();
        var shiningRoot = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/shining_abode_state.json"))!)!.AsObject();
        Assert.Equal("Shining Abode", soulRoot["currentRealm"]?.GetValue<string>());
        Assert.Equal("malformed_contract", shiningRoot["pendingNativeFactionDiscovery"]?.GetValue<string>());
        Assert.Equal(ShiningAbodeState.AvailabilityActive, shiningRoot["availability"]?.GetValue<string>());
    }

    [Fact]
    public async Task UpdateSoulStateRealm_WriteFailureReturnsFalseAndLeavesSoulStateUnchanged()
    {
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            soulName = "Испытующая Душа",
            currentRealm = "Chaos Sea",
            currentIncarnation = 4,
            inkFeathers = new { current = 7, total = 31 }
        });

        var engine = CreateGameEngine();
        var beforeSoulJson = await _fs.ReadFileAsync("game_state/meta/soul_state.json");
        using var soulLock = File.Open(
            _fs.ResolvePath("game_state/meta/soul_state.json"),
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read);

        var updated = await InvokeSoulRealmTransitionAsync(
            engine,
            "IncarnationToMortalWorld");

        Assert.False(updated);
        Assert.Equal(beforeSoulJson, await _fs.ReadFileAsync("game_state/meta/soul_state.json"));
    }

    [Fact]
    public async Task UpdateSoulStateRealm_MortalLifeEnd_WithSparseLiveFixtureMovesSoulToChaosSea()
    {
        var soul = new JsonObject
        {
            ["soulName"] = "Пепельная Искра",
            ["currentRealm"] = "Mortal World",
            ["currentIncarnation"] = 2,
            ["enlightenment"] = new JsonObject
            {
                ["currentTier"] = "Новичок",
                ["experience"] = 0,
                ["level"] = 0
            },
            ["inkFeathers"] = new JsonObject { ["current"] = 0, ["total"] = 0 },
            ["soulRelics"] = new JsonObject
            {
                ["equipped"] = new JsonArray(),
                ["stored"] = new JsonArray()
            },
            ["afterlifeArchive"] = new JsonObject { ["stored"] = new JsonArray() },
            ["livesHistory"] = new JsonArray(),
            ["pendingMemoryLegacy"] = null
        };
        await SeedMortalLifeTransitionAuthorityAsync(soul);
        var engine = CreateGameEngine();

        var updated = await InvokeSoulRealmTransitionAsync(
            engine,
            "MortalDeathToChaosSea",
            "Ходов прожито: 1. Заметка игрока: live regression.");

        Assert.True(updated);
        var soulRoot = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/soul_state.json"))!)!.AsObject();
        Assert.Equal("Chaos Sea", soulRoot["currentRealm"]?.GetValue<string>());
        var livesHistory = Assert.IsType<JsonArray>(soulRoot["livesHistory"]);
        Assert.Single(livesHistory);
    }

    [Fact]
    public async Task UpdateSoulStateRealm_MortalLifeEnd_WithPendingScenarioCoreAndCurrentWorldLoreMovesSoulToChaosSea()
    {
        var soul = new JsonObject
        {
            ["soulName"] = "Пепельная Искра",
            ["currentRealm"] = "Mortal World",
            ["currentIncarnation"] = 2,
            ["enlightenment"] = new JsonObject
            {
                ["currentTier"] = "Новичок",
                ["experience"] = 0,
                ["level"] = 0
            },
            ["inkFeathers"] = new JsonObject { ["current"] = 0, ["total"] = 0 },
            ["soulRelics"] = new JsonObject
            {
                ["equipped"] = new JsonArray(),
                ["stored"] = new JsonArray()
            },
            ["afterlifeArchive"] = new JsonObject { ["stored"] = new JsonArray() },
            ["livesHistory"] = new JsonArray(),
            ["pendingMemoryLegacy"] = null
        };
        await SeedMortalLifeTransitionAuthorityAsync(soul);
        await WriteJsonAsync(WorldDirectiveService.PendingSetupPath, new
        {
            mode = "mixed",
            profileId = "victorian-occult-capital",
            profileName = "Викторианская оккультная столица",
            worldDirectives = new { worldTitle = "Серебряный Город" }
        });
        await WriteJsonAsync(ScenarioCoreService.ManifestPath, new
        {
            sourcePath = WorldDirectiveService.PendingSetupPath,
            sourceLastUpdated = "2026-03-13T00:00:00Z",
            lastExtractedAt = "2026-06-19T01:00:00Z",
            candidateAssertions = Array.Empty<object>(),
            scenarioCoreAssertions = new[]
            {
                new
                {
                    assertionId = "core_world",
                    category = "world_premise",
                    value = "Серебряный Город",
                    @explicit = true,
                    source = "structured_field"
                }
            },
            openCorrectionSlots = Array.Empty<object>()
        });
        await WriteJsonAsync("lore/current_world/world_setting.json", new
        {
            title = "Серебряный Город"
        });
        await WriteJsonAsync("lore/current_world/history/era.json", new
        {
            era = "Late 19th century"
        });
        var engine = CreateGameEngine();

        var updated = await InvokeSoulRealmTransitionAsync(
            engine,
            "MortalDeathToChaosSea",
            "Ходов прожито: 1. Заметка игрока: live regression.");

        Assert.True(updated);
        var soulRoot = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/soul_state.json"))!)!.AsObject();
        Assert.Equal("Chaos Sea", soulRoot["currentRealm"]?.GetValue<string>());
        Assert.False(_fs.FileExists(ScenarioCoreService.ManifestPath));
        Assert.False(_fs.FileExists("lore/current_world/world_setting.json"));
        Assert.False(_fs.FileExists("lore/current_world/history/era.json"));
    }

    [Fact]
    public async Task CheckLifeTransitions_VoluntaryEnd_DispatchesAutomaticLifeEvaluationInsteadOfReturningToMortalWorld()
    {
        const string acceptedSessionId = "session_voluntary_end";
        const string acceptedRequestId = "request_voluntary_end";
        const int acceptedTurnNumber = 2;
        var preTurnSoul = new
        {
            soulName = "Пепельная Искра",
            currentRealm = "Mortal World",
            currentIncarnation = 2,
            enlightenment = new { currentTier = "Новичок", experience = 0, level = 0 },
            inkFeathers = new { current = 0, total = 0 },
            soulRelics = new { equipped = Array.Empty<object>(), stored = Array.Empty<object>() },
            afterlifeArchive = new { stored = Array.Empty<object>() },
            livesHistory = Array.Empty<object>(),
            pendingMemoryLegacy = (object?)null
        };

        await SeedMortalLifeTransitionAuthorityAsync(preTurnSoul);
        await WriteCurrentSoulStateToPendingSnapshotAsync();
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId = acceptedSessionId,
            requestId = acceptedRequestId,
            turnNumber = acceptedTurnNumber,
            playerAction = "Я осознанно завершаю эту смертную жизнь."
        });
        await WritePendingTurnSnapshotManifestAsync(
            acceptedSessionId,
            acceptedRequestId,
            acceptedTurnNumber,
            "game_state/meta/soul_state.json");
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            sessionId = acceptedSessionId,
            requestId = acceptedRequestId,
            turnNumber = acceptedTurnNumber,
            status = "success",
            timestamp = "2026-06-19T01:00:00Z",
            filesModified = new[] { "game_state/control/life_transitions.json", "output/narrative_response.json" }
        });
        await WriteJsonAsync("game_state/control/life_transitions.json", new
        {
            reason = "Voluntary",
            summary = "Добровольное завершение тестовой смертной жизни."
        });
        var input = new QueuedConsoleInputSource(Enumerable.Repeat(Key(ConsoleKey.Enter), 4));
        var engine = CreateGameEngine(input);
        var manifest = await InvokePrivateTaskResultAsync(engine, "LoadPendingTurnSnapshotManifestAsync");
        var acceptedSnapshotContext = await InvokePrivateTaskResultAsync(
            engine,
            "LoadValidatedPendingTurnSnapshotContextAsync",
            manifest,
            true);
        var sawEvaluationRequest = false;

        var responder = Task.Run(async () =>
        {
            var deadline = DateTime.UtcNow.AddSeconds(30);
            while (DateTime.UtcNow < deadline)
            {
                var requestJson = await _fs.ReadFileAsync("input/turn_request.json");
                if (!string.IsNullOrWhiteSpace(requestJson) &&
                    requestJson.Contains("Оценка Жизни", StringComparison.Ordinal))
                {
                    sawEvaluationRequest = true;
                    using var requestDoc = JsonDocument.Parse(requestJson);
                    var requestRoot = requestDoc.RootElement;
                    var sessionId = requestRoot.GetProperty("sessionId").GetString();
                    var requestId = requestRoot.GetProperty("requestId").GetString();
                    var turnNumber = requestRoot.GetProperty("turnNumber").GetInt32();

                    await WriteAcceptedLifeEvaluationResponseAsync(sessionId, requestId, turnNumber);
                    return;
                }

                await Task.Delay(50);
            }
        });
        var lifecycleTask = InvokePrivateTaskAsync(engine, "CheckLifeTransitions", acceptedSnapshotContext);

        var completed = await Task.WhenAny(lifecycleTask, Task.Delay(TimeSpan.FromSeconds(35)));
        await responder;

        if (!ReferenceEquals(lifecycleTask, completed))
        {
            var repairRequest = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json") ?? "<missing>";
            var turnRequest = await _fs.ReadFileAsync("input/turn_request.json") ?? "<missing>";
            var errorLogPath = Path.Combine(_fs.GameSessionPath, "error_log.txt");
            var errorLog = File.Exists(errorLogPath) ? await File.ReadAllTextAsync(errorLogPath) : "<missing>";
            Assert.Fail(
                "CheckLifeTransitions did not complete within 35 seconds." +
                Environment.NewLine + "validation_repair_request.json:" + Environment.NewLine + repairRequest +
                Environment.NewLine + "input/turn_request.json:" + Environment.NewLine + turnRequest +
                Environment.NewLine + "error_log.txt:" + Environment.NewLine + errorLog);
        }

        Assert.Same(lifecycleTask, completed);
        await lifecycleTask;
        Assert.True(sawEvaluationRequest, "CheckLifeTransitions must dispatch a separate automatic Life Evaluation request after a valid TriggerLifeEnd.");
        Assert.False(_fs.FileExists("game_state/control/life_transitions.json"));
        var soul = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/soul_state.json"))!)!.AsObject();
        Assert.Equal("Chaos Sea", soul["currentRealm"]?.GetValue<string>());
    }

    [Fact]
    public async Task CheckLifeTransitions_GenerationChangesAfterRawAcceptedValidation_AbortsWithoutMutatingReplacement()
    {
        const string acceptedSessionId = "session_life_eval_rotation";
        const string acceptedRequestId = "request_life_eval_rotation";
        const int acceptedTurnNumber = 2;
        var preTurnSoul = new
        {
            soulName = "Пепельная Искра",
            currentRealm = "Mortal World",
            currentIncarnation = 2,
            enlightenment = new { currentTier = "Новичок", experience = 0, level = 0 },
            inkFeathers = new { current = 0, total = 0 },
            soulRelics = new { equipped = Array.Empty<object>(), stored = Array.Empty<object>() },
            afterlifeArchive = new { stored = Array.Empty<object>() },
            livesHistory = Array.Empty<object>(),
            pendingMemoryLegacy = (object?)null
        };

        var seededSoul = JsonSerializer.SerializeToNode(preTurnSoul)!.AsObject();
        seededSoul[AfterlifeSpiritualConflictState.SoulStateProfileProperty] =
            AfterlifeSpiritualConflictState.CreateDefaultCombatProfile();
        await SeedMortalLifeTransitionAuthorityAsync(seededSoul);
        const string emptyWoundIdentity = """{"schemaVersion":1,"entries":[]}""";
        const string emptyWoundHistory = """{"schemaVersion":1,"nextOrdinal":1,"transitions":[]}""";
        Assert.True(WoundIdentityState.Parse(emptyWoundIdentity, WoundIdentityState.StatePath).IsValid);
        Assert.True(WoundHistoryState.Parse(emptyWoundHistory, WoundHistoryState.HistoryPath).IsValid);
        await _fs.WriteFileAtomicAsync(WoundIdentityState.StatePath, emptyWoundIdentity);
        await _fs.WriteFileAtomicAsync(WoundHistoryState.HistoryPath, emptyWoundHistory);
        await WriteCurrentSoulStateToPendingSnapshotAsync();
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId = acceptedSessionId,
            requestId = acceptedRequestId,
            turnNumber = acceptedTurnNumber,
            playerAction = "Я осознанно завершаю эту смертную жизнь."
        });
        await WritePendingTurnSnapshotManifestAsync(
            acceptedSessionId,
            acceptedRequestId,
            acceptedTurnNumber,
            "game_state/meta/soul_state.json");
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            sessionId = acceptedSessionId,
            requestId = acceptedRequestId,
            turnNumber = acceptedTurnNumber,
            status = "success",
            timestamp = "2026-06-19T01:00:00Z",
            filesModified = new[] { "game_state/control/life_transitions.json" }
        });
        await WriteJsonAsync("game_state/control/life_transitions.json", new
        {
            reason = "Voluntary",
            summary = "Добровольное завершение тестовой смертной жизни."
        });

        using var owned = new CleanupOwnedFixture(_rootPath, line => _directGachaOutput?.WriteLine(line));
        var probe = await SessionGenerationCheckpointFixture.CreateAsync(_rootPath, line => _directGachaOutput?.WriteLine(line));
        var lifeRequests = 0;
        var responseWritten = false;
        var repairDispatchAttempts = 0;
        var repairCleanupIntents = 0;
        var repairPath = probe.Files.ResolvePath("game_state/control/validation_repair_request.json");
        probe.PublicationObserved = (phase, _) =>
        {
            if (!responseWritten || phase != TrustedLocalPublicationPhase.IntentPublished) return;
            using var journal = CleanupPublicationCut.Metadata(File.ReadAllBytes(Path.Combine(
                probe.Files.RuntimeRootPath, "trusted-local-publication-v1", "active.json")));
            foreach (var member in journal.RootElement.GetProperty("Members").EnumerateArray())
            {
                if (member.GetProperty("Path").GetString() != repairPath) continue;
                if (!member.GetProperty("After").GetProperty("Exists").GetBoolean())
                {
                    repairCleanupIntents++;
                    continue;
                }
                repairDispatchAttempts++;
                Assert.Fail("The current Life response must validate without dispatching provider repair.");
            }
        };
        GenerationFinalizerState? stateAtCheckpoint = null;
        GameEngine? engine = null;
        engine = CreateGameEngine(
            probe.ObserveInput(new QueuedConsoleInputSource(Enumerable.Repeat(Key(ConsoleKey.Enter), 4))),
            configureSettings: InertRealmSettings, fileSystem: probe.Files,
            finalizationHooks: new GameEngineSessionFinalizationHooks
            {
                AtCheckpointAsync = async checkpoint =>
                {
                    if (checkpoint == SessionFinalizationCheckpoint.LifeEvaluationRequestDispatchedBeforeWait)
                    {
                        lifeRequests++;
                        var requestJson = await _fs.ReadFileAsync("input/turn_request.json");
                        Assert.False(string.IsNullOrWhiteSpace(requestJson));
                        using var requestDoc = JsonDocument.Parse(requestJson);
                        var requestRoot = requestDoc.RootElement;
                        Assert.Contains(
                            "Оценка Жизни",
                            requestRoot.GetProperty("playerAction").GetString(),
                            StringComparison.Ordinal);
                        await WriteAcceptedLifeEvaluationResponseAsync(
                            requestRoot.GetProperty("sessionId").GetString(),
                            requestRoot.GetProperty("requestId").GetString(),
                            requestRoot.GetProperty("turnNumber").GetInt32());
                        responseWritten = true;
                        var validator = new ValidationService(probe.Files, NullLogger<ValidationService>.Instance);
                        var errors = (await validator.ValidateGameStateAsync())
                            .Where(issue => issue.Severity == IssueSeverity.Error)
                            .Select(issue => new { issue.Code, issue.FilePath, issue.Expected, issue.Actual })
                            .ToArray();
                        _directGachaOutput?.WriteLine(JsonSerializer.Serialize(new
                        {
                            kind = "f18-life-response-seed-validation", root = _rootPath, errors
                        }));
                        Assert.Empty(errors);
                        return;
                    }

                    if (checkpoint == SessionFinalizationCheckpoint.RawAcceptedOutcomeValidatedBeforeLifeEvaluationFinalWrites)
                    {
                        stateAtCheckpoint = CaptureGenerationFinalizerState(engine!);
                        await probe.RotateAsync(checkpoint.ToString(), SessionGenerationCheckpointFixture.ReplacementTerminalSentinels(),
                            ["output/narrative_response.json", "output/interface_updates.json"]);
                    }
                }
            });
        var manifest = await InvokePrivateTaskResultAsync(engine, "LoadPendingTurnSnapshotManifestAsync");
        var acceptedSnapshotContext = await InvokePrivateTaskResultAsync(
            engine,
            "LoadValidatedPendingTurnSnapshotContextAsync",
            manifest,
            true);

        var failure = await Record.ExceptionAsync(() => InvokePrivateTaskAsync(
            engine, "CheckLifeTransitions", acceptedSnapshotContext));
        var stateAfterFailure = CaptureGenerationFinalizerState(engine);
        probe.Verify(failure, new { lifeRequests, repairDispatchAttempts, repairCleanupIntents, stateAtCheckpoint, stateAfterFailure });
        Assert.NotNull(stateAtCheckpoint);
        Assert.Same(stateAtCheckpoint.Response, stateAfterFailure.Response);
        Assert.Equal(stateAtCheckpoint, stateAfterFailure);
        Assert.Equal(0, repairDispatchAttempts);
        Assert.Equal(1, lifeRequests);
        Assert.False(File.Exists(Path.Combine(probe.Files.GameSessionPath, "error_log.txt")));
    }

    [Fact]
    public async Task CheckLifeTransitions_LifeEvaluationDispatchFailure_WritesErrorLog()
    {
        const string acceptedSessionId = "session_life_eval_dispatch_failure";
        const string acceptedRequestId = "request_life_eval_dispatch_failure";
        const int acceptedTurnNumber = 3;
        var preTurnSoul = new
        {
            soulName = "Пепельная Искра",
            currentRealm = "Mortal World",
            currentIncarnation = 2,
            enlightenment = new { currentTier = "Новичок", experience = 0, level = 0 },
            inkFeathers = new { current = 0, total = 0 },
            soulRelics = new { equipped = Array.Empty<object>(), stored = Array.Empty<object>() },
            afterlifeArchive = new { stored = Array.Empty<object>() },
            livesHistory = Array.Empty<object>(),
            pendingMemoryLegacy = (object?)null
        };

        await SeedMortalLifeTransitionAuthorityAsync(preTurnSoul);
        await WriteCurrentSoulStateToPendingSnapshotAsync();
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId = acceptedSessionId,
            requestId = acceptedRequestId,
            turnNumber = acceptedTurnNumber,
            playerAction = "Я осознанно завершаю эту смертную жизнь."
        });
        await WritePendingTurnSnapshotManifestAsync(
            acceptedSessionId,
            acceptedRequestId,
            acceptedTurnNumber,
            "game_state/meta/soul_state.json");
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            sessionId = acceptedSessionId,
            requestId = acceptedRequestId,
            turnNumber = acceptedTurnNumber,
            status = "success",
            timestamp = "2026-06-19T01:00:00Z",
            filesModified = new[] { "game_state/control/life_transitions.json" }
        });
        await WriteJsonAsync("game_state/control/life_transitions.json", new
        {
            reason = "Voluntary",
            summary = "Добровольное завершение тестовой смертной жизни."
        });

        var input = new QueuedConsoleInputSource(new[] { Key(ConsoleKey.Enter) });
        var engine = CreateGameEngine(input);
        var manifest = await InvokePrivateTaskResultAsync(engine, "LoadPendingTurnSnapshotManifestAsync");
        var acceptedSnapshotContext = await InvokePrivateTaskResultAsync(
            engine,
            "LoadValidatedPendingTurnSnapshotContextAsync",
            manifest,
            true);
        _fs.DeleteFile("input/turn_request.json");
        Directory.CreateDirectory(Path.Combine(_fs.GameSessionPath, "input", "turn_request.json"));

        await InvokePrivateTaskAsync(engine, "CheckLifeTransitions", acceptedSnapshotContext);

        var logPath = Path.Combine(_fs.GameSessionPath, "error_log.txt");
        Assert.True(File.Exists(logPath), "Lifecycle dispatch exceptions must be visible in error_log.txt.");
        var log = await File.ReadAllTextAsync(logPath, Encoding.UTF8);
        Assert.Contains("InvalidDataException", log, StringComparison.Ordinal);
    }

    [Fact]
    public async Task CheckLifeTransitions_FileSystemExampleState_DispatchesAutomaticLifeEvaluation()
    {
        const string acceptedSessionId = "session_filesystem_example_voluntary_end";
        const string acceptedRequestId = "request_filesystem_example_voluntary_end";
        const int acceptedTurnNumber = 3;

        CopyDirectory(TestRepoPaths.BaseSessionRoot, _fs.GameSessionPath);

        var preTurnSoulJson = await _fs.ReadFileAsync("game_state/meta/soul_state.json");
        Assert.False(string.IsNullOrWhiteSpace(preTurnSoulJson));
        await _fs.WriteFileAtomicAsync(
            "game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json",
            preTurnSoulJson!);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId = acceptedSessionId,
            requestId = acceptedRequestId,
            turnNumber = acceptedTurnNumber,
            playerAction = "Я осознанно завершаю эту смертную жизнь."
        });
        await WritePendingTurnSnapshotManifestAsync(
            acceptedSessionId,
            acceptedRequestId,
            acceptedTurnNumber,
            "game_state/meta/soul_state.json");
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            sessionId = acceptedSessionId,
            requestId = acceptedRequestId,
            turnNumber = acceptedTurnNumber,
            status = "success",
            timestamp = "2026-06-19T01:00:00Z",
            filesModified = new[] { "game_state/control/life_transitions.json", "output/narrative_response.json" }
        });
        await WriteJsonAsync("output/narrative_response.json", new
        {
            response = "Оценка Жизни в этом ходе не проводится; дальнейший lifecycle-переход передан клиенту.",
            timestamp = "2026-06-19T01:00:00Z"
        });
        await WriteJsonAsync("game_state/control/life_transitions.json", new
        {
            reason = "Voluntary",
            summary = "Добровольное завершение тестовой смертной жизни."
        });

        var input = new QueuedConsoleInputSource(Enumerable.Repeat(Key(ConsoleKey.Enter), 4));
        var engine = CreateGameEngine(input);
        var manifest = await InvokePrivateTaskResultAsync(engine, "LoadPendingTurnSnapshotManifestAsync");
        var acceptedSnapshotContext = await InvokePrivateTaskResultAsync(
            engine,
            "LoadValidatedPendingTurnSnapshotContextAsync",
            manifest,
            true);
        var sawEvaluationRequest = false;

        var responder = Task.Run(async () =>
        {
            var deadline = DateTime.UtcNow.AddSeconds(10);
            while (DateTime.UtcNow < deadline)
            {
                var requestJson = await _fs.ReadFileAsync("input/turn_request.json");
                if (!string.IsNullOrWhiteSpace(requestJson) &&
                    requestJson.Contains("Оценка Жизни", StringComparison.Ordinal))
                {
                    sawEvaluationRequest = true;
                    using var requestDoc = JsonDocument.Parse(requestJson);
                    var requestRoot = requestDoc.RootElement;
                    var sessionId = requestRoot.GetProperty("sessionId").GetString();
                    var requestId = requestRoot.GetProperty("requestId").GetString();
                    var turnNumber = requestRoot.GetProperty("turnNumber").GetInt32();

                    await WriteAcceptedLifeEvaluationResponseAsync(sessionId, requestId, turnNumber);
                    return;
                }

                await Task.Delay(50);
            }
        });
        var lifecycleTask = InvokePrivateTaskAsync(engine, "CheckLifeTransitions", acceptedSnapshotContext);

        var completed = await Task.WhenAny(lifecycleTask, Task.Delay(TimeSpan.FromSeconds(35)));
        await responder;

        if (!ReferenceEquals(lifecycleTask, completed))
        {
            var repairRequest = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json") ?? "<missing>";
            var turnRequest = await _fs.ReadFileAsync("input/turn_request.json") ?? "<missing>";
            var timeoutErrorLogPath = Path.Combine(_fs.GameSessionPath, "error_log.txt");
            var timeoutErrorLog = File.Exists(timeoutErrorLogPath) ? await File.ReadAllTextAsync(timeoutErrorLogPath) : "<missing>";
            Assert.Fail(
                "CheckLifeTransitions did not complete within 35 seconds." +
                Environment.NewLine + "validation_repair_request.json:" + Environment.NewLine + repairRequest +
                Environment.NewLine + "input/turn_request.json:" + Environment.NewLine + turnRequest +
                Environment.NewLine + "error_log.txt:" + Environment.NewLine + timeoutErrorLog);
        }

        Assert.Same(lifecycleTask, completed);
        await lifecycleTask;
        var errorLogPath = Path.Combine(_fs.GameSessionPath, "error_log.txt");
        var errorLog = File.Exists(errorLogPath) ? await File.ReadAllTextAsync(errorLogPath, Encoding.UTF8) : string.Empty;
        Assert.True(sawEvaluationRequest, $"CheckLifeTransitions did not dispatch Life Evaluation. error_log.txt: {errorLog}");
        Assert.False(_fs.FileExists("game_state/control/life_transitions.json"));
        var soul = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/soul_state.json"))!)!.AsObject();
        Assert.Equal("Chaos Sea", soul["currentRealm"]?.GetValue<string>());
    }

    [Fact]
    public async Task TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync_SoulWriteFailureRestoresShiningStateAndReturnsFalse()
    {
        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            soulName = "Испытующая Душа",
            currentRealm = "Shining Abode",
            currentIncarnation = 4,
            inkFeathers = new { current = 7, total = 31 },
            enlightenment = new
            {
                currentTier = "Сияющий Мудрец",
                experience = 187,
                level = 6,
                progressPercent = 73
            }
        });
        await WriteJsonAsync("game_state/meta/shining_abode_state.json", new
        {
            availability = "active",
            radiance = new { experience = 22, tier = 3 },
            lightSparks = 88,
            halls = Array.Empty<object>(),
            factions = Array.Empty<object>(),
            shiningPoliticalActors = Array.Empty<object>(),
            preparedIncarnationPackage = (object?)null,
            gates = new
            {
                hasOpenDraft = false,
                isStale = false,
                openedThisAscension = false,
                draftOpenedAtTurn = (int?)null,
                draftOpenedAtUtc = (string?)null,
                blessingDraft = Array.Empty<object>(),
                selectedBlessingCardIds = Array.Empty<string>()
            }
        });

        var beforeSoulJson = await _fs.ReadFileAsync("game_state/meta/soul_state.json");
        var beforeShiningJson = await _fs.ReadFileAsync("game_state/meta/shining_abode_state.json");
        var engine = CreateGameEngine();
        var stateManager = GetPrivateField<StateManager>(engine, "_stateManager");

        await stateManager.RefreshGameStateAsync();
        using var soulLock = File.Open(
            _fs.ResolvePath("game_state/meta/soul_state.json"),
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read);

        var completed = await InvokePrivateAsync<bool>(engine, "TryPerformOrdinaryReturnToChaosSeaFromShiningAbodeAsync");

        Assert.False(completed);
        Assert.Equal(beforeSoulJson, await _fs.ReadFileAsync("game_state/meta/soul_state.json"));
        Assert.Equal(beforeShiningJson, await _fs.ReadFileAsync("game_state/meta/shining_abode_state.json"));
    }

    [Fact]
    public async Task IncarnationLocalPrepRollbackSnapshot_SurvivesCurrentWorldLoreClear()
    {
        const string worldSettingPath = "lore/current_world/world_setting.json";
        const string nestedLorePath = "lore/current_world/history/era.json";
        const string worldSettingJson = """{ "worldName": "Old World" }""";
        const string nestedLoreJson = """{ "era": "Before Gates" }""";

        await _fs.WriteFileAtomicAsync(worldSettingPath, worldSettingJson);
        await _fs.WriteFileAtomicAsync(nestedLorePath, nestedLoreJson);

        var engine = CreateGameEngine();
        var explorer = GetPrivateField<ExplorerMode>(engine, "_explorer");
        var rollbackFiles = InvokePrivateValue<string[]>(engine, "EnumerateIncarnationLocalPrepRollbackFiles");

        Assert.Contains(worldSettingPath, rollbackFiles);
        Assert.Contains(nestedLorePath, rollbackFiles);

        await explorer.StagePendingLocalTurnRollbackSnapshotAsync(rollbackFiles);
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(engine, "CreatePreTurnBackup", "explorer_rollback_filter");
        var baselineFilesValue = rollbackSnapshot.GetType().GetProperty("BaselineFiles")?.GetValue(rollbackSnapshot);
        var baselineFiles = Assert.IsAssignableFrom<IEnumerable>(baselineFilesValue);
        Assert.DoesNotContain(
            baselineFiles.Cast<object>().Select(value => value?.ToString() ?? string.Empty),
            path => path.StartsWith("game_state/control/explorer_local_turn_rollback/", StringComparison.OrdinalIgnoreCase));

        _fs.ClearCurrentWorldLore();

        Assert.False(_fs.FileExists(worldSettingPath));
        Assert.False(_fs.FileExists(nestedLorePath));

        await explorer.RestoreStagedLocalTurnRollbackSnapshotAsync();

        Assert.Equal(worldSettingJson, await _fs.ReadFileAsync(worldSettingPath));
        Assert.Equal(nestedLoreJson, await _fs.ReadFileAsync(nestedLorePath));
        Assert.False(Directory.Exists(_fs.ResolvePath("game_state/control/explorer_local_turn_rollback")));
    }

    [Fact]
    public async Task IncarnationLocalPrepNewSetupFiles_AreSnapshottedButStillRollbackDeleted()
    {
        const string soulStatePath = "game_state/meta/soul_state.json";
        const string soulStateJson = """{ "soulName": "Тестовая Душа", "currentRealm": "Mortal World", "currentIncarnation": 1 }""";
        const string pendingSetupJson = """{ "mode": "manual", "worldDirectives": { "settingSummary": "New setup" } }""";
        const string scenarioCoreJson = """{ "scenarioCore": { "summary": "New scenario" } }""";

        await _fs.WriteFileAtomicAsync(soulStatePath, soulStateJson);

        var engine = CreateGameEngine();
        var explorer = GetPrivateField<ExplorerMode>(engine, "_explorer");
        var rollbackFiles = InvokePrivateValue<string[]>(engine, "EnumerateIncarnationLocalPrepRollbackFiles");

        Assert.Contains(WorldDirectiveService.PendingSetupPath, rollbackFiles);
        Assert.Contains(ScenarioCoreService.ManifestPath, rollbackFiles);

        await explorer.StagePendingLocalTurnRollbackSnapshotAsync(rollbackFiles);
        await _fs.WriteFileAtomicAsync(WorldDirectiveService.PendingSetupPath, pendingSetupJson);
        await _fs.WriteFileAtomicAsync(ScenarioCoreService.ManifestPath, scenarioCoreJson);
        explorer.MarkExistingPendingLocalTurnValidationSnapshotFiles(
            WorldDirectiveService.PendingSetupPath,
            ScenarioCoreService.ManifestPath);

        var rollbackSnapshot = await InvokePrivateTaskResultAsync(engine, "CreatePreTurnBackup", "incarnation_setup_validation_snapshot");
        var stagedSnapshot = explorer.ConsumePendingLocalTurnRollbackSnapshot();
        InvokePrivate(engine, "OverlayExplorerLocalRollbackSnapshot", rollbackSnapshot, stagedSnapshot);

        var request = new TurnRequest
        {
            SessionId = "session_incarnation_setup_snapshot",
            RequestId = "request_incarnation_setup_snapshot",
            TurnNumber = 42,
            PlayerAction = "incarnation setup snapshot test",
            Timestamp = "2026-03-24T00:00:00Z",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Mortal World" }
        };
        await InvokePrivateTaskResultAsync(engine, "CreateCanonicalBaselineSnapshotAsync", request, rollbackSnapshot, "test");

        var manifestJson = await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json");
        Assert.NotNull(manifestJson);
        var manifest = Assert.IsType<JsonObject>(JsonNode.Parse(manifestJson!)!);
        var files = Assert.IsType<JsonObject>(manifest["files"]);
        var rollbackBaselineFiles = Assert.IsType<JsonArray>(manifest["rollbackBaselineFiles"]);
        var rollbackBaselineSet = rollbackBaselineFiles
            .Select(node => node?.GetValue<string>() ?? string.Empty)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        Assert.True(files.ContainsKey(WorldDirectiveService.PendingSetupPath));
        Assert.True(files.ContainsKey(ScenarioCoreService.ManifestPath));
        Assert.DoesNotContain(WorldDirectiveService.PendingSetupPath, rollbackBaselineSet);
        Assert.DoesNotContain(ScenarioCoreService.ManifestPath, rollbackBaselineSet);

        await InvokePrivateTaskAsync(engine, "RestorePreTurnBackup", rollbackSnapshot);

        Assert.False(_fs.FileExists(WorldDirectiveService.PendingSetupPath));
        Assert.False(_fs.FileExists(ScenarioCoreService.ManifestPath));
    }

    [Fact]
    public async Task CreateCanonicalBaselineSnapshotAsync_GmBridgeStatus_IsExcludedFromRollbackAndValidationSnapshot()
    {
        const string bridgeStatusPath = "game_state/control/gm_bridge_status.json";
        await _fs.WriteFileAtomicAsync(bridgeStatusPath, """
        {
          "backend": "ConPTYBridge",
          "state": "Ready",
          "updatedAtUtc": "2026-06-19T01:00:00Z"
        }
        """);

        var engine = CreateGameEngine();
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(engine, "CreatePreTurnBackup", "gm_bridge_status_runtime");
        var request = new TurnRequest
        {
            SessionId = "session_gm_bridge_status_runtime",
            RequestId = "request_gm_bridge_status_runtime",
            TurnNumber = 42,
            PlayerAction = "ordinary turn while GM bridge status is changing",
            Timestamp = "2026-06-19T01:00:00Z",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Mortal World" }
        };

        await InvokePrivateTaskResultAsync(engine, "CreateCanonicalBaselineSnapshotAsync", request, rollbackSnapshot, "test");

        var manifestJson = await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json");
        Assert.NotNull(manifestJson);
        var manifest = Assert.IsType<JsonObject>(JsonNode.Parse(manifestJson!)!);
        var files = Assert.IsType<JsonObject>(manifest["files"]);
        var rollbackBackups = Assert.IsType<JsonObject>(manifest["rollbackBackups"]);
        var rollbackBaselineFiles = Assert.IsType<JsonArray>(manifest["rollbackBaselineFiles"]);
        var rollbackBaselineSet = rollbackBaselineFiles
            .Select(node => node?.GetValue<string>() ?? string.Empty)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        Assert.False(files.ContainsKey(bridgeStatusPath));
        Assert.False(rollbackBackups.ContainsKey(bridgeStatusPath));
        Assert.DoesNotContain(bridgeStatusPath, rollbackBaselineSet);
    }

    [Fact]
    public async Task CreateCanonicalBaselineSnapshotAsync_ConcurrentWriterCannotMixSnapshotFiles()
    {
        using var owned = new CleanupOwnedFixture(_rootPath, line => _directGachaOutput?.WriteLine(line));
        const string firstPath = "game_state/core/a_atomic_snapshot.json";
        const string laterPath = "game_state/world/z_atomic_snapshot.json";
        const string firstBaseline = """{"version":"first-baseline"}""";
        const string laterBaseline = """{"version":"later-baseline"}""";
        const string laterConcurrent = """{"version":"concurrent-writer"}""";
        await _fs.WriteFileAtomicAsync(firstPath, firstBaseline);
        await _fs.WriteFileAtomicAsync(laterPath, laterBaseline);

        var writerContended = NewSignal();
        var mainAdmissionContentions = 0;
        var writerFs = new FileSystemManager(
            _rootPath,
            NullLogger<FileSystemManager>.Instance,
            PhysicalLoadTransactionOperations.Instance,
            new FileSystemManagerHooks
            {
                MainOwnerLockContendedAsync = () =>
                {
                    Interlocked.Increment(ref mainAdmissionContentions);
                    writerContended.TrySetResult(true);
                    return Task.CompletedTask;
                }
            });
        var firstCaptured = NewSignal();
        var releaseSnapshot = NewSignal();
        var engine = CreateGameEngine();
        engine.ConfigureSnapshotPublicationHooksForTesting(
            new GameEngineSnapshotPublicationHooks
            {
                AfterSnapshotFileCapturedAsync = async path =>
                {
                    if (!path.Equals(firstPath, StringComparison.OrdinalIgnoreCase))
                        return;

                    firstCaptured.TrySetResult(true);
                    await releaseSnapshot.Task;
                }
            });
        var request = new TurnRequest
        {
            SessionId = "session_atomic_snapshot",
            RequestId = "request_atomic_snapshot",
            TurnNumber = 42,
            PlayerAction = "atomic snapshot test",
            Timestamp = "2026-07-26T00:00:00Z",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Mortal World" }
        };

        var snapshotTask = InvokePrivateTaskResultAsync(
            engine,
            "CreateCanonicalBaselineSnapshotAsync",
            request,
            null,
            "atomic snapshot test");
        Task? writerTask = null;
        try
        {
            await firstCaptured.Task.WaitAsync(TimeSpan.FromSeconds(5));
            writerTask = writerFs.WriteFileAtomicAsync(laterPath, laterConcurrent);
            await writerContended.Task.WaitAsync(TimeSpan.FromSeconds(5));
            Assert.False(writerTask.IsCompleted);
        }
        finally
        {
            releaseSnapshot.TrySetResult(true);
            await Task.WhenAll(snapshotTask, writerTask ?? Task.CompletedTask);
        }
        _directGachaOutput?.WriteLine(JsonSerializer.Serialize(new
        {
            mainAdmissionContentions,
            SnapshotJoined = snapshotTask.IsCompletedSuccessfully,
            WriterJoined = writerTask?.IsCompletedSuccessfully == true
        }));
        Assert.True(mainAdmissionContentions > 0);

        Assert.Equal(
            firstBaseline,
            await _fs.ReadFileAsync($"game_state/control/pending_turn_snapshot/{firstPath}"));
        Assert.Equal(
            laterBaseline,
            await _fs.ReadFileAsync($"game_state/control/pending_turn_snapshot/{laterPath}"));
        Assert.Equal(laterConcurrent, await _fs.ReadFileAsync(laterPath));
    }

    [Fact]
    public async Task LoadCanonicalBaselineSnapshotAsync_AbsentCanonicalFiles_DoNotInvalidateExistingBaseline()
    {
        const string soulStatePath = "game_state/meta/soul_state.json";
        const string absentQuestPath = "game_state/quests/regular_quests.json";
        await _fs.WriteFileAtomicAsync(soulStatePath, """
        {
          "soulName": "Тестовая Душа",
          "currentRealm": "Mortal World",
          "currentIncarnation": 1
        }
        """);
        _fs.DeleteFile(absentQuestPath);

        var engine = CreateGameEngine();
        var request = new TurnRequest
        {
            SessionId = "session_absent_canonical_baseline",
            RequestId = "request_absent_canonical_baseline",
            TurnNumber = 42,
            PlayerAction = "ordinary turn with sparse canonical state",
            Timestamp = "2026-06-19T01:00:00Z",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Mortal World" }
        };

        await InvokePrivateTaskResultAsync(engine, "CreateCanonicalBaselineSnapshotAsync", request, null, "test");
        await _fs.WriteFileAtomicAsync("ready/turn_complete.json", """
        {
          "sessionId": "session_absent_canonical_baseline",
          "requestId": "request_absent_canonical_baseline",
          "turnNumber": 42,
          "timestamp": "2026-06-19T01:01:00Z",
          "status": "success"
        }
        """);

        var snapshotObject = await InvokePrivateTaskResultAsync(engine, "LoadCanonicalBaselineSnapshotAsync", 42, null);
        var snapshot = Assert.IsAssignableFrom<IDictionary<string, string>>(snapshotObject);

        Assert.Contains(soulStatePath, snapshot.Keys);
        Assert.DoesNotContain(absentQuestPath, snapshot.Keys);
    }

    [Fact]
    public async Task CreateCanonicalBaselineSnapshotAsync_OrdinaryTurnStagingFiles_AreValidationSnapshottedWithoutRollbackBaseline()
    {
        const string soulStatePath = "game_state/meta/soul_state.json";
        const string soulStateJson = """{ "soulName": "Тестовая Душа", "currentRealm": "Mortal World", "currentIncarnation": 1 }""";
        const string scenarioCoreJson = """{ "scenarioCore": { "summary": "Prepared by client before GM dispatch." } }""";
        const string pendingDiceJson = """{ "rolls": [{ "kind": "1d20", "value": 12 }] }""";

        var engine = CreateGameEngine();
        await _fs.WriteFileAtomicAsync(soulStatePath, soulStateJson);
        _fs.DeleteFile(ScenarioCoreService.ManifestPath);
        _fs.DeleteFile(PendingTurnStateService.PendingDiceStatePath);
        Assert.False(_fs.FileExists(ScenarioCoreService.ManifestPath));
        Assert.False(_fs.FileExists(PendingTurnStateService.PendingDiceStatePath));
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(engine, "CreatePreTurnBackup", "ordinary_turn_staging");
        await _fs.WriteFileAtomicAsync(ScenarioCoreService.ManifestPath, scenarioCoreJson);
        await _fs.WriteFileAtomicAsync(PendingTurnStateService.PendingDiceStatePath, pendingDiceJson);
        InvokePrivate(engine, "RegisterOrdinaryTurnStagingValidationSnapshotFiles", rollbackSnapshot);

        var request = new TurnRequest
        {
            SessionId = "session_ordinary_staging_snapshot",
            RequestId = "request_ordinary_staging_snapshot",
            TurnNumber = 42,
            PlayerAction = "ordinary turn with client staging files",
            Timestamp = "2026-06-19T01:00:00Z",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Mortal World" }
        };

        await InvokePrivateTaskResultAsync(engine, "CreateCanonicalBaselineSnapshotAsync", request, rollbackSnapshot, "test");

        var manifestJson = await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json");
        Assert.NotNull(manifestJson);
        var manifest = Assert.IsType<JsonObject>(JsonNode.Parse(manifestJson!)!);
        var files = Assert.IsType<JsonObject>(manifest["files"]);
        var rollbackBaselineFiles = Assert.IsType<JsonArray>(manifest["rollbackBaselineFiles"]);
        var rollbackBaselineSet = rollbackBaselineFiles
            .Select(node => node?.GetValue<string>() ?? string.Empty)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        Assert.True(files.ContainsKey(ScenarioCoreService.ManifestPath));
        Assert.True(files.ContainsKey(PendingTurnStateService.PendingDiceStatePath));
        Assert.DoesNotContain(ScenarioCoreService.ManifestPath, rollbackBaselineSet);
        Assert.DoesNotContain(PendingTurnStateService.PendingDiceStatePath, rollbackBaselineSet);
    }

    [Fact]
    public async Task LifeEvaluationSnapshot_ClientOwnedCurrentWorldDirectivesUseRollbackBaselineWhenCurrentFileIsCleared()
    {
        const string directivesPath = WorldDirectiveService.ActiveDirectivesPath;
        const string directivesJson = """
        {
          "settingSummary": "Предыдущий смертный мир должен остаться проверяемым baseline.",
          "lastUpdated": "2026-07-02T04:20:00Z"
        }
        """;

        await _fs.WriteFileAtomicAsync("game_state/meta/soul_state.json", """
        {
          "soulName": "Искра Странствий",
          "currentRealm": "Mortal World",
          "currentIncarnation": 1
        }
        """);
        await _fs.WriteFileAtomicAsync(directivesPath, directivesJson);

        var engine = CreateGameEngine();
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(engine, "CreatePreTurnBackup", "life_eval_current_world_directives");

        _fs.DeleteFile(directivesPath);
        await _fs.WriteFileAtomicAsync("game_state/meta/soul_state.json", """
        {
          "soulName": "Искра Странствий",
          "currentRealm": "Chaos Sea",
          "currentIncarnation": 1
        }
        """);

        var request = new TurnRequest
        {
            SessionId = "session_life_eval_current_world_directives",
            RequestId = "request_life_eval_current_world_directives",
            TurnNumber = 22,
            PlayerAction = "life evaluation",
            Timestamp = "2026-07-02T04:22:32Z",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Chaos Sea" }
        };

        await InvokePrivateTaskResultAsync(engine, "CreateCanonicalBaselineSnapshotAsync", request, rollbackSnapshot, "автоматической оценки жизни");

        var manifestJson = await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json");
        Assert.NotNull(manifestJson);
        var manifest = Assert.IsType<JsonObject>(JsonNode.Parse(manifestJson!)!);
        var files = Assert.IsType<JsonObject>(manifest["files"]);
        var snapshotFileHashes = Assert.IsType<JsonObject>(manifest["snapshotFileHashes"]);
        var rollbackBaselineFiles = Assert.IsType<JsonArray>(manifest["rollbackBaselineFiles"]);
        var rollbackBaselineSet = rollbackBaselineFiles
            .Select(node => node?.GetValue<string>() ?? string.Empty)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        Assert.Contains(directivesPath, rollbackBaselineSet);
        Assert.True(files.ContainsKey(directivesPath));
        Assert.True(snapshotFileHashes.ContainsKey(directivesPath));
    }

    [Fact]
    public async Task MortalBootstrapBaselineFiles_AreValidationSnapshottedButRollbackDeletedWhenTurnFails()
    {
        const string soulStateJson = """{ "soulName": "Тестовая Душа", "currentRealm": "Mortal World", "currentIncarnation": 1 }""";

        await SeedMortalLifeTransitionAuthorityAsync(
            JsonNode.Parse(soulStateJson)!.AsObject());
        var engine = CreateGameEngine();

        var bootstrapPaths = new[]
        {
            "game_state/world/current_location.json",
            "game_state/world/world_map.json",
            "game_state/factions/faction_core.json",
            "game_state/factions/faction_resources.json",
            "game_state/quests/regular_quests.json",
            "lore/codex_entries.json"
        };

        foreach (var path in bootstrapPaths)
            Assert.False(_fs.FileExists(path));

        var rollbackSnapshot = await InvokePrivateTaskResultAsync(engine, "CreatePreTurnBackup", "mortal_bootstrap_timeout");

        await InvokePrivateTaskAsync(
            engine,
            "WriteMortalBootstrapBaselineAsync",
            rollbackSnapshot,
            1,
            4,
            "Мирон, архивариус",
            "Город у болот",
            "Башня архива ночью");

        var request = new TurnRequest
        {
            SessionId = "session_mortal_bootstrap_timeout",
            RequestId = "request_mortal_bootstrap_timeout",
            TurnNumber = 4,
            PlayerAction = "first mortal bootstrap",
            Timestamp = "2026-06-29T08:26:03Z",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Mortal World" }
        };

        await InvokePrivateTaskResultAsync(engine, "CreateCanonicalBaselineSnapshotAsync", request, rollbackSnapshot, "test");

        var manifestJson = await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json");
        Assert.NotNull(manifestJson);
        var manifest = Assert.IsType<JsonObject>(JsonNode.Parse(manifestJson!)!);
        var files = Assert.IsType<JsonObject>(manifest["files"]);
        var rollbackBaselineFiles = Assert.IsType<JsonArray>(manifest["rollbackBaselineFiles"]);
        var rollbackBaselineSet = rollbackBaselineFiles
            .Select(node => node?.GetValue<string>() ?? string.Empty)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        foreach (var path in bootstrapPaths)
        {
            Assert.True(files.ContainsKey(path), path);
            Assert.DoesNotContain(path, rollbackBaselineSet);
        }

        await _fs.WriteFileAtomicAsync("game_state/world/current_location.json", """{ "locationId": "gm_mutated_before_timeout" }""");

        await InvokePrivateTaskAsync(engine, "RestorePreTurnBackup", rollbackSnapshot);

        foreach (var path in bootstrapPaths)
            Assert.False(_fs.FileExists(path), path);
    }

    [Fact]
    public async Task CreateCanonicalBaselineSnapshotAsync_AbsentSourceOfLightPending_IsNotRollbackBaseline()
    {
        var engine = CreateGameEngine();
        var request = new TurnRequest
        {
            SessionId = "session_no_source_pending_snapshot",
            RequestId = "request_no_source_pending_snapshot",
            TurnNumber = 42,
            PlayerAction = "ordinary turn without Source pending",
            Timestamp = "2026-03-24T00:00:00Z",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Chaos Sea" }
        };

        await InvokePrivateTaskResultAsync(engine, "CreateCanonicalBaselineSnapshotAsync", request, null, "test");

        var manifestJson = await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json");
        Assert.NotNull(manifestJson);
        var manifest = Assert.IsType<JsonObject>(JsonNode.Parse(manifestJson!)!);
        var files = Assert.IsType<JsonObject>(manifest["files"]);
        var rollbackBaselineFiles = Assert.IsType<JsonArray>(manifest["rollbackBaselineFiles"]);
        var rollbackBaselineSet = rollbackBaselineFiles
            .Select(node => node?.GetValue<string>() ?? string.Empty)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        Assert.False(files.ContainsKey(SourceOfLightCapstoneState.PendingRequestPath));
        Assert.DoesNotContain(SourceOfLightCapstoneState.PendingRequestPath, rollbackBaselineSet);
    }

    [Fact]
    public async Task CreateCanonicalBaselineSnapshotAsync_AbsentAfterlifePendingContracts_AreNotRollbackBaseline()
    {
        var engine = CreateGameEngine();
        var request = new TurnRequest
        {
            SessionId = "session_no_afterlife_pending_snapshot",
            RequestId = "request_no_afterlife_pending_snapshot",
            TurnNumber = 42,
            PlayerAction = "ordinary turn without afterlife pending contracts",
            Timestamp = "2026-03-24T00:00:00Z",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Chaos Sea" }
        };

        await InvokePrivateTaskResultAsync(engine, "CreateCanonicalBaselineSnapshotAsync", request, null, "test");

        var manifestJson = await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json");
        Assert.NotNull(manifestJson);
        var manifest = Assert.IsType<JsonObject>(JsonNode.Parse(manifestJson!)!);
        var files = Assert.IsType<JsonObject>(manifest["files"]);
        var rollbackBaselineFiles = Assert.IsType<JsonArray>(manifest["rollbackBaselineFiles"]);
        var rollbackBaselineSet = rollbackBaselineFiles
            .Select(node => node?.GetValue<string>() ?? string.Empty)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        var optionalPendingPaths = new[]
        {
            GuardianAbodeOfferingState.PendingRequestPath,
            GuardianTradeRequestState.PendingRequestPath,
            NpcTradeRequestState.PendingRequestPath,
            ShiningCoreActionRequestState.PendingActionsRequestPath,
            ShiningTradeRequestState.PendingRequestsPath,
            GuardianAbodeResidentRequestState.PendingResidentsRequestPath,
            GuardianAbodeResidentRequestState.PendingInteractionsRequestPath,
            GuardianAbodeResidentRequestState.PendingTransfersRequestPath,
            ActorSocialInteractionRequestState.PendingGuardianRequestPath,
            ActorSocialInteractionRequestState.PendingNpcRequestPath,
            AfterlifeArchiveActionState.ConsultationRequestPath,
            AfterlifeArchiveActionState.ProjectFuelRequestPath
        };

        foreach (var pendingPath in optionalPendingPaths)
        {
            Assert.False(files.ContainsKey(pendingPath), $"{pendingPath} should not have a snapshot entry when absent.");
            Assert.DoesNotContain(pendingPath, rollbackBaselineSet);
        }
    }

    [Fact]
    public async Task CreateCanonicalBaselineSnapshotAsync_PresentSourceOfLightPending_IsRollbackBaseline()
    {
        var sourceRequest = SourceOfLightCapstoneState.CreateRequest(42, 580, 4);
        await SourceOfLightCapstoneState.WriteRequestAsync(_fs, sourceRequest);
        var engine = CreateGameEngine();
        var request = new TurnRequest
        {
            SessionId = "session_source_pending_snapshot",
            RequestId = "request_source_pending_snapshot",
            TurnNumber = 42,
            PlayerAction = "Source pending snapshot",
            Timestamp = "2026-03-24T00:00:00Z",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Shining Abode" }
        };

        await InvokePrivateTaskResultAsync(engine, "CreateCanonicalBaselineSnapshotAsync", request, null, "test");

        var manifestJson = await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json");
        Assert.NotNull(manifestJson);
        var manifest = Assert.IsType<JsonObject>(JsonNode.Parse(manifestJson!)!);
        var files = Assert.IsType<JsonObject>(manifest["files"]);
        var rollbackBaselineFiles = Assert.IsType<JsonArray>(manifest["rollbackBaselineFiles"]);
        var rollbackBaselineSet = rollbackBaselineFiles
            .Select(node => node?.GetValue<string>() ?? string.Empty)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        Assert.True(files.ContainsKey(SourceOfLightCapstoneState.PendingRequestPath));
        Assert.Contains(SourceOfLightCapstoneState.PendingRequestPath, rollbackBaselineSet);
    }

    [Fact]
    public async Task ValidatedRollbackSnapshot_PreservesExplorerLocalTurnRollbackBackups()
    {
        const string sessionId = "session_explorer_rollback_restart_001";
        const string requestId = "request_explorer_rollback_restart_001";
        const int turnNumber = 77;
        const string soulStatePath = "game_state/meta/soul_state.json";
        const string soulSnapshotPath = "game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json";
        const string trackedPath = "lore/current_world/world_setting.json";
        const string snapshotPath = "game_state/control/pending_turn_snapshot/lore/current_world/world_setting.json";
        const string backupPath = "game_state/control/explorer_local_turn_rollback/restart/world_setting.json.rollback.001";
        const string soulStateJson = """{ "soulName": "Тестовая Душа", "currentRealm": "Mortal World", "currentIncarnation": 1 }""";
        const string worldSettingJson = """{ "worldName": "Old World" }""";

        await _fs.WriteFileAtomicAsync(soulStatePath, soulStateJson);
        await _fs.WriteFileAtomicAsync(soulSnapshotPath, soulStateJson);
        await _fs.WriteFileAtomicAsync(trackedPath, worldSettingJson);
        await _fs.WriteFileAtomicAsync(snapshotPath, worldSettingJson);
        await _fs.WriteFileAtomicAsync(backupPath, worldSettingJson);
        await WriteJsonAsync("input/turn_request.json", new
        {
            sessionId,
            requestId,
            turnNumber
        });

        var manifest = new PendingTurnSnapshotManifestPayload
        {
            SessionId = sessionId,
            RequestId = requestId,
            TurnNumber = turnNumber,
            RequestTimestamp = "2026-03-24T00:00:00Z",
            PlayerAction = "restart rollback test",
            ProgressionControl = new ProgressionControl { CurrentRealm = "Mortal World" },
            Files = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                [soulStatePath] = soulSnapshotPath,
                [trackedPath] = snapshotPath
            },
            SnapshotFileHashes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                [soulStatePath] = ComputeSha256(soulStateJson),
                [trackedPath] = ComputeSha256(worldSettingJson)
            },
            ClientOwnedValidationHashes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase),
            RollbackBackups = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                [trackedPath] = backupPath
            },
            RollbackBaselineFiles = new List<string> { soulStatePath, trackedPath },
            SourceLabel = "game-engine-turn-lifecycle-tests"
        };
        manifest.ManifestPayloadHash = ComputeManifestPayloadHash(manifest);

        await _fs.WriteFileAtomicAsync(
            "game_state/control/pending_turn_snapshot.json",
            JsonSerializer.Serialize(manifest, SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed));
        await PendingTurnSnapshotTestAuthority.SyncAuthorityForCurrentManifestAsync(_fs);

        _fs.DeleteFile(trackedPath);
        var engine = CreateGameEngine();
        var loadedManifest = await InvokePrivateTaskResultAsync(engine, "LoadPendingTurnSnapshotManifestAsync");
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(engine, "GetValidatedRollbackSnapshotAsync", loadedManifest);
        var backupFilesValue = rollbackSnapshot.GetType().GetProperty("BackupFiles")?.GetValue(rollbackSnapshot);
        var backupFiles = Assert.IsAssignableFrom<Dictionary<string, string>>(backupFilesValue);

        Assert.True(backupFiles.TryGetValue(trackedPath, out var restoredBackupPath));
        Assert.Equal(backupPath, restoredBackupPath);

        await InvokePrivateTaskAsync(engine, "RestorePreTurnBackup", rollbackSnapshot);

        Assert.Equal(worldSettingJson, await _fs.ReadFileAsync(trackedPath));
    }

    [Fact]
    public async Task CreatePreTurnBackup_BrowserDirectGachaRollbackEvidenceOverridesPostSpendSoulBackup()
    {
        const string soulStatePath = "game_state/meta/soul_state.json";
        const string browserRollbackPath = "game_state/control/explorer_local_turn_rollback/browser_direct_gacha/game_state_meta_soul_state.json.rollback.test";
        const string preSpendSoulJson = """
        {
          "soulName": "Тестовая Душа",
          "currentRealm": "Chaos Sea",
          "currentIncarnation": 4,
          "inkFeathers": { "current": 18, "total": 55 },
          "soulRelics": { "stored": [], "equipped": [] }
        }
        """;
        const string postSpendSoulJson = """
        {
          "soulName": "Тестовая Душа",
          "currentRealm": "Chaos Sea",
          "currentIncarnation": 4,
          "inkFeathers": { "current": 11, "total": 55 },
          "soulRelics": { "stored": [], "equipped": [] }
        }
        """;

        await _fs.WriteFileAtomicAsync(soulStatePath, postSpendSoulJson);
        await _fs.WriteFileAtomicAsync(browserRollbackPath, preSpendSoulJson);
        var engine = CreateGameEngine();
        var request = new TurnRequest
        {
            SessionId = "session_browser_gacha_rollback",
            RequestId = "request_browser_gacha_rollback",
            TurnNumber = 42,
            PlayerAction = "[CHAOS_SEA_DIRECT_GACHA] Игрок напрямую тянет Реликвию Души из Моря Хаоса и тратит 7 Чернильных Перьев.",
            Timestamp = "2026-06-02T00:00:00Z",
            PreGeneratedDices1d20 = Enumerable.Range(1, 20).ToArray(),
            GachaBaseResult = new GachaResult
            {
                DiceUsed = [18, 18, 18, 18],
                BaseScore = 72,
                BaseRarity = "Rare",
                Formula = "client-computed gacha base (range 4-80)"
            },
            ProgressionControl = new ProgressionControl { CurrentRealm = "Chaos Sea" }
        };

        var rollbackSnapshot = await InvokePrivateTaskResultAsync(engine, "CreatePreTurnBackup", "browser_direct_gacha");
        await InvokePrivateTaskResultAsync(engine, "CreateCanonicalBaselineSnapshotAsync", request, rollbackSnapshot, "browser-direct-gacha-test");

        var manifest = JsonNode.Parse((await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json"))!)!.AsObject();
        var rollbackBackups = Assert.IsType<JsonObject>(manifest["rollbackBackups"]);
        var rollbackBackupPath = rollbackBackups[soulStatePath]!.GetValue<string>();
        Assert.StartsWith("game_state/control/explorer_local_turn_rollback/", rollbackBackupPath, StringComparison.OrdinalIgnoreCase);
        var rollbackSoul = JsonNode.Parse((await _fs.ReadFileAsync(rollbackBackupPath))!)!.AsObject();
        Assert.Equal(18, rollbackSoul["inkFeathers"]!["current"]!.GetValue<int>());
    }

    [Fact]
    [Trait("Category", "PreMergeSentinel")]
    public async Task RestorePreTurnBackup_BrowserDirectGachaPreservesExactPreSpendSoulBytes()
    {
        const string soulStatePath = "game_state/meta/soul_state.json";
        const string browserRollbackPath = "game_state/control/explorer_local_turn_rollback/browser_direct_gacha/game_state_meta_soul_state.json.rollback.exact";
        const string preSpendSoulJson = """
        {
          "soulName": "Тестовая Душа",
          "currentRealm": "Chaos Sea",
          "currentIncarnation": 4,
          "inkFeathers": { "current": 18, "total": 55 },
          "soulRelics": { "stored": [], "equipped": [] }
        }
        """;
        const string postSpendSoulJson = """
        {
          "soulName": "Тестовая Душа",
          "currentRealm": "Chaos Sea",
          "currentIncarnation": 4,
          "inkFeathers": { "current": 11, "total": 55 },
          "soulRelics": { "stored": [], "equipped": [] }
        }
        """;
        var preSpendBytes = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false).GetBytes(preSpendSoulJson);

        await _fs.WriteFileAtomicAsync(soulStatePath, postSpendSoulJson);
        await _fs.WriteFileAtomicBytesAsync(browserRollbackPath, preSpendBytes);
        var engine = CreateGameEngine();
        var request = CreateBrowserDirectGachaRequest("exact_bytes");

        var initialRollback = await InvokePrivateTaskResultAsync(
            engine,
            "CreatePreTurnBackup",
            "browser_direct_gacha_exact_bytes");
        await InvokePrivateTaskResultAsync(
            engine,
            "CreateCanonicalBaselineSnapshotAsync",
            request,
            initialRollback,
            "browser-direct-gacha-exact-bytes-test");
        await _fs.WriteFileAtomicAsync(
            "input/turn_request.json",
            JsonSerializer.Serialize(request, SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed));

        var loadedManifest = await InvokePrivateTaskResultAsync(engine, "LoadPendingTurnSnapshotManifestAsync");
        var validatedRollback = await InvokePrivateTaskResultAsync(
            engine,
            "GetValidatedRollbackSnapshotAsync",
            loadedManifest);

        await InvokePrivateTaskAsync(engine, "RestorePreTurnBackup", validatedRollback);

        Assert.Equal(preSpendBytes, await _fs.ReadFileBytesAsync(soulStatePath));
    }

    [Fact]
    public async Task GetValidatedRollbackSnapshotAsync_BrowserDirectGachaRejectsByteChangedRollbackEvidence()
    {
        const string soulStatePath = "game_state/meta/soul_state.json";
        const string browserRollbackPath = "game_state/control/explorer_local_turn_rollback/browser_direct_gacha/game_state_meta_soul_state.json.rollback.tamper";
        const string preSpendSoulJson = """
        {
          "soulName": "Тестовая Душа",
          "currentRealm": "Chaos Sea",
          "currentIncarnation": 4,
          "inkFeathers": { "current": 18, "total": 55 },
          "soulRelics": { "stored": [], "equipped": [] }
        }
        """;
        const string postSpendSoulJson = """
        {
          "soulName": "Тестовая Душа",
          "currentRealm": "Chaos Sea",
          "currentIncarnation": 4,
          "inkFeathers": { "current": 11, "total": 55 },
          "soulRelics": { "stored": [], "equipped": [] }
        }
        """;
        var noBomBytes = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false).GetBytes(preSpendSoulJson);

        await _fs.WriteFileAtomicAsync(soulStatePath, postSpendSoulJson);
        await _fs.WriteFileAtomicBytesAsync(browserRollbackPath, noBomBytes);
        var engine = CreateGameEngine();
        var request = CreateBrowserDirectGachaRequest("byte_tamper");

        var initialRollback = await InvokePrivateTaskResultAsync(
            engine,
            "CreatePreTurnBackup",
            "browser_direct_gacha_byte_tamper");
        await InvokePrivateTaskResultAsync(
            engine,
            "CreateCanonicalBaselineSnapshotAsync",
            request,
            initialRollback,
            "browser-direct-gacha-byte-tamper-test");
        await _fs.WriteFileAtomicAsync(
            "input/turn_request.json",
            JsonSerializer.Serialize(request, SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed));

        var withBomBytes = Encoding.UTF8.GetPreamble().Concat(noBomBytes).ToArray();
        await _fs.WriteFileAtomicBytesAsync(browserRollbackPath, withBomBytes);

        var loadedManifest = await InvokePrivateTaskResultAsync(engine, "LoadPendingTurnSnapshotManifestAsync");
        var validatedRollback = await InvokePrivateTaskNullableResultAsync(
            engine,
            "GetValidatedRollbackSnapshotAsync",
            loadedManifest);

        Assert.Null(validatedRollback);
    }

    [Fact]
    public async Task CreatePreTurnBackup_UnreadableCanonicalFileFailsClosed()
    {
        const string trackedPath = "lore/current_world/world_setting.json";
        await _fs.WriteFileAtomicAsync(trackedPath, """{ "worldName": "Unreadable baseline" }""");
        var engine = CreateGameEngine();
        await using var exclusiveHandle = new FileStream(
            _fs.ResolvePath(trackedPath),
            FileMode.Open,
            FileAccess.Read,
            FileShare.None);

        await Assert.ThrowsAsync<IOException>(() =>
            InvokePrivateTaskResultAsync(engine, "CreatePreTurnBackup", "capture_failure"));
    }

    [Fact]
    public async Task RestorePreTurnBackup_HashMismatchFailsClosedAndRetainsRollbackEvidence()
    {
        const string trackedPath = "lore/current_world/world_setting.json";
        const string baselineJson = """{ "worldName": "Baseline" }""";
        const string changedJson = """{ "worldName": "Changed" }""";
        await _fs.WriteFileAtomicAsync(trackedPath, baselineJson);
        var engine = CreateGameEngine();
        var generation = await GetOrCreateSessionGenerationAsync();
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(
            engine,
            "CreatePreTurnBackup",
            "restore_hash_mismatch");
        var backupFilesValue = rollbackSnapshot.GetType().GetProperty("BackupFiles")?.GetValue(rollbackSnapshot);
        var backupFiles = Assert.IsAssignableFrom<Dictionary<string, string>>(backupFilesValue);
        var backupPath = Assert.Contains(trackedPath, backupFiles);

        await _fs.WriteFileAtomicAsync(trackedPath, changedJson);
        await _fs.WriteFileAtomicAsync(backupPath, """{ "worldName": "Tampered evidence" }""");

        await Assert.ThrowsAsync<InvalidDataException>(() =>
            InvokePrivateTaskAsync(
                engine,
                "RestorePreTurnBackupForSessionAsync",
                rollbackSnapshot,
                generation));

        Assert.True(_fs.FileExists(backupPath));
        Assert.Equal(changedJson, await _fs.ReadFileAsync(trackedPath));
    }

    [Fact]
    [Trait("Category", "PreMergeSentinel")]
    public async Task CreateCanonicalBaselineSnapshotAsync_PreservesAndHashesExactSnapshotBytes()
    {
        const string trackedPath = "lore/codex_entries.json";
        var bodyBytes = Encoding.UTF8.GetBytes("""{ "entries": [] }""");
        var exactBytes = Encoding.UTF8.GetPreamble().Concat(bodyBytes).ToArray();
        await _fs.WriteFileAtomicBytesAsync(trackedPath, exactBytes);
        var engine = CreateGameEngine();
        var request = CreateSnapshotByteContractRequest("preserve");
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(
            engine,
            "CreatePreTurnBackup",
            "snapshot_exact_bytes");

        await InvokePrivateTaskResultAsync(
            engine,
            "CreateCanonicalBaselineSnapshotAsync",
            request,
            rollbackSnapshot,
            "snapshot-exact-byte-test");

        var manifest = JsonNode.Parse(
            (await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json"))!)!.AsObject();
        var snapshotPath = manifest["files"]![trackedPath]!.GetValue<string>();
        var snapshotHash = manifest["snapshotFileHashes"]![trackedPath]!.GetValue<string>();
        var authorityJson = await _fs.ReadFileAsync(PendingTurnSnapshotAuthority.AuthorityPath);
        Assert.True(PendingTurnSnapshotAuthority.TryReadDetachedAuthorityPayload(authorityJson, out var payload));
        var snapshotHashMode = payload!
            .GetType()
            .GetProperty("SnapshotHashMode")?
            .GetValue(payload) as string;

        Assert.Equal(exactBytes, await _fs.ReadFileBytesAsync(snapshotPath));
        Assert.Equal(
            Convert.ToHexString(SHA256.HashData(exactBytes)),
            snapshotHash,
            ignoreCase: true);
        Assert.Equal("bytes", snapshotHashMode);
    }

    [Fact]
    public async Task CreateCanonicalBaselineSnapshotAsync_RecordsClosedOriginalPathPresenceWithoutChangingRollbackMembership()
    {
        const string settingsPath = "game_state/core/game_settings.json";
        const string absentPath = "game_state/wounds/wound_history.json";
        var settingsBytes = Encoding.UTF8.GetBytes("""{"difficulty":"hard"}""");
        await _fs.WriteFileAtomicBytesAsync(settingsPath, settingsBytes);
        _fs.DeleteFile(absentPath);
        var engine = CreateGameEngine();
        var request = CreateSnapshotByteContractRequest("presence_contract");
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(
            engine,
            "CreatePreTurnBackup",
            "presence_contract");

        await InvokePrivateTaskResultAsync(
            engine,
            "CreateCanonicalBaselineSnapshotAsync",
            request,
            rollbackSnapshot,
            "presence-contract-test");

        var manifest = JsonNode.Parse(
            (await _fs.ReadFileAsync(
                LiveTurnPreparationService.PendingTurnSnapshotManifestPath))!)!.AsObject();
        var presence = manifest["originalPathPresenceV1"]!.AsObject();
        var files = manifest["files"]!.AsObject();
        var rollbackBaseline = manifest["rollbackBaselineFiles"]!.AsArray()
            .Select(static node => node!.GetValue<string>())
            .ToArray();

        Assert.Equal(PendingTurnSnapshotPathPresenceV1.LogicalPaths, presence.Select(static row => row.Key));
        Assert.True(presence[settingsPath]!.GetValue<bool>());
        Assert.False(presence[absentPath]!.GetValue<bool>());
        Assert.NotNull(files[settingsPath]);
        Assert.Null(files[absentPath]);
        Assert.DoesNotContain(absentPath, rollbackBaseline, StringComparer.OrdinalIgnoreCase);
        Assert.Null(files["game_state/control/spiritual_source_snapshot_coverage.json"]);
    }

    [Fact]
    public async Task LoadCanonicalBaselineSnapshotAsync_RejectsBomOnlySnapshotByteChange()
    {
        const string trackedPath = "lore/codex_entries.json";
        var bodyBytes = Encoding.UTF8.GetBytes("""{ "entries": [] }""");
        var exactBytes = Encoding.UTF8.GetPreamble().Concat(bodyBytes).ToArray();
        await _fs.WriteFileAtomicBytesAsync(trackedPath, exactBytes);
        var engine = CreateGameEngine();
        var request = CreateSnapshotByteContractRequest("tamper");
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(
            engine,
            "CreatePreTurnBackup",
            "snapshot_byte_tamper");
        await InvokePrivateTaskResultAsync(
            engine,
            "CreateCanonicalBaselineSnapshotAsync",
            request,
            rollbackSnapshot,
            "snapshot-byte-tamper-test");
        await _fs.WriteFileAtomicAsync(
            "input/turn_request.json",
            JsonSerializer.Serialize(request, SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed));

        var manifest = JsonNode.Parse(
            (await _fs.ReadFileAsync("game_state/control/pending_turn_snapshot.json"))!)!.AsObject();
        var snapshotPath = manifest["files"]![trackedPath]!.GetValue<string>();
        await _fs.WriteFileAtomicBytesAsync(snapshotPath, bodyBytes);

        var loadedSnapshot = await InvokePrivateTaskNullableResultAsync(
            engine,
            "LoadCanonicalBaselineSnapshotAsync",
            request.TurnNumber,
            null);

        Assert.Null(loadedSnapshot);
    }

    [Fact]
    public async Task PreTurnRollback_RestoresExactOriginalBytesWithoutAddingBom()
    {
        const string path = "game_state/world/weather.json";
        var baseline = Encoding.UTF8.GetBytes("""{"weather":"exact"}""");
        await _fs.WriteFileAtomicBytesAsync(path, baseline);
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(
            engine,
            "CreatePreTurnBackup",
            "exact_bytes");

        await _fs.WriteFileAtomicAsync(path, """{"weather":"changed"}""");
        await InvokePrivateTaskAsync(engine, "RestorePreTurnBackup", rollbackSnapshot);

        Assert.Equal(baseline, await _fs.ReadFileBytesAsync(path));
    }

    [Fact]
    public async Task PreTurnRollback_PresenceMetadataDoesNotChangeCanonicalRestoreSemantics()
    {
        const string restoredPath = "game_state/world/weather.json";
        const string absentTrackedPath = "game_state/wounds/wound_history.json";
        const string syntheticPath =
            "game_state/control/spiritual_source_snapshot_coverage.json";
        var baseline = Encoding.UTF8.GetBytes("""{"weather":"before"}""");
        await _fs.WriteFileAtomicBytesAsync(restoredPath, baseline);
        _fs.DeleteFile(absentTrackedPath);
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var request = CreateSnapshotByteContractRequest("presence_rollback");
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(
            engine,
            "CreatePreTurnBackup",
            "presence_rollback");
        await InvokePrivateTaskResultAsync(
            engine,
            "CreateCanonicalBaselineSnapshotAsync",
            request,
            rollbackSnapshot,
            "presence-rollback-test");

        await _fs.WriteFileAtomicAsync(restoredPath, """{"weather":"after"}""");
        await _fs.WriteFileAtomicAsync(absentTrackedPath, """{"entries":[]}""");
        await InvokePrivateTaskAsync(engine, "RestorePreTurnBackup", rollbackSnapshot);

        Assert.Equal(baseline, await _fs.ReadFileBytesAsync(restoredPath));
        Assert.False(_fs.FileExists(absentTrackedPath));
        Assert.False(_fs.FileExists(syntheticPath));
    }

    [Fact]
    public async Task CreatePreTurnBackup_WhenAnyTrackedFileCannotBeCaptured_FailsInsteadOfReturningPartialAuthority()
    {
        const string path = "game_state/world/weather.json";
        const string backupId = "capture_failure";
        await _fs.WriteFileAtomicAsync(path, """{"weather":"baseline"}""");
        Directory.CreateDirectory(_fs.ResolvePath(path + $".rollback.{backupId}"));
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));

        await Assert.ThrowsAnyAsync<Exception>(
            () => InvokePrivateTaskResultAsync(engine, "CreatePreTurnBackup", backupId));
    }

    [Fact]
    public async Task RestorePreTurnBackup_WhenEvidenceHashDoesNotMatch_ThrowsAndRetainsEvidence()
    {
        const string path = "game_state/world/weather.json";
        const string backupPath = path + ".rollback.corrupt_evidence";
        await _fs.WriteFileAtomicAsync(path, """{"weather":"baseline"}""");
        var engine = CreateGameEngine(new QueuedConsoleInputSource([]));
        var rollbackSnapshot = await InvokePrivateTaskResultAsync(
            engine,
            "CreatePreTurnBackup",
            "corrupt_evidence");
        await _fs.WriteFileAtomicAsync(backupPath, """{"weather":"tampered"}""");
        await _fs.WriteFileAtomicAsync(path, """{"weather":"changed"}""");

        await Assert.ThrowsAsync<InvalidDataException>(
            () => InvokePrivateTaskAsync(engine, "RestorePreTurnBackup", rollbackSnapshot));

        Assert.True(_fs.FileExists(backupPath));
        Assert.Contains("changed", await _fs.ReadFileAsync(path), StringComparison.Ordinal);
    }

    [Fact]
    public async Task ConsumedIncarnationLocalPrepRollback_RestorePathRestoresOriginalFiles()
    {
        const string worldSettingPath = "lore/current_world/world_setting.json";
        const string worldSettingJson = """{ "worldName": "Old World" }""";
        const string pendingSetupJson = """{ "mode": "manual", "worldDirectives": { "settingSummary": "Old setup" } }""";
        const string scenarioCoreJson = """{ "scenarioCore": { "summary": "Old scenario" } }""";

        await WriteJsonAsync("game_state/meta/soul_state.json", new
        {
            soulName = "Тестовая Душа",
            currentRealm = "Mortal World",
            currentIncarnation = 1,
            inkFeathers = new { current = 50 }
        });
        await _fs.WriteFileAtomicAsync(worldSettingPath, worldSettingJson);
        await _fs.WriteFileAtomicAsync(WorldDirectiveService.PendingSetupPath, pendingSetupJson);
        await _fs.WriteFileAtomicAsync(ScenarioCoreService.ManifestPath, scenarioCoreJson);

        var engine = CreateGameEngine();
        var explorer = GetPrivateField<ExplorerMode>(engine, "_explorer");
        var rollbackFiles = InvokePrivateValue<string[]>(engine, "EnumerateIncarnationLocalPrepRollbackFiles");
        await explorer.StagePendingLocalTurnRollbackSnapshotAsync(rollbackFiles);

        await _fs.WriteFileAtomicAsync(worldSettingPath, """{ "worldName": "Changed World" }""");
        await _fs.WriteFileAtomicAsync(WorldDirectiveService.PendingSetupPath, """{ "mode": "manual", "worldDirectives": { "settingSummary": "Changed setup" } }""");
        await _fs.WriteFileAtomicAsync(ScenarioCoreService.ManifestPath, """{ "scenarioCore": { "summary": "Changed scenario" } }""");

        var rollbackSnapshot = await InvokePrivateTaskResultAsync(engine, "CreatePreTurnBackup", "incarnation_local_prep_restore");
        var stagedSnapshot = explorer.ConsumePendingLocalTurnRollbackSnapshot();
        InvokePrivate(engine, "OverlayExplorerLocalRollbackSnapshot", rollbackSnapshot, stagedSnapshot);

        await InvokePrivateTaskAsync(engine, "RestorePreTurnBackup", rollbackSnapshot);
        await explorer.RestoreConsumedLocalTurnRollbackSnapshotAsync(stagedSnapshot);
        InvokePrivate(engine, "CleanupBackup", rollbackSnapshot);

        Assert.Equal(worldSettingJson, await _fs.ReadFileAsync(worldSettingPath));
        Assert.Equal(pendingSetupJson, await _fs.ReadFileAsync(WorldDirectiveService.PendingSetupPath));
        Assert.Equal(scenarioCoreJson, await _fs.ReadFileAsync(ScenarioCoreService.ManifestPath));
        Assert.False(_fs.FileExists("input/turn_request.json"));
        Assert.False(_fs.FileExists("game_state/control/pending_turn_snapshot.json"));
        Assert.False(Directory.Exists(_fs.ResolvePath("game_state/control/explorer_local_turn_rollback")));
    }

    private static TurnRequest CreateBrowserDirectGachaRequest(string idSuffix) => new()
    {
        SessionId = $"session_browser_gacha_{idSuffix}",
        RequestId = $"request_browser_gacha_{idSuffix}",
        TurnNumber = 42,
        PlayerAction = "[CHAOS_SEA_DIRECT_GACHA] Игрок напрямую тянет Реликвию Души из Моря Хаоса и тратит 7 Чернильных Перьев.",
        Timestamp = "2026-06-02T00:00:00Z",
        PreGeneratedDices1d20 = Enumerable.Range(1, 20).ToArray(),
        GachaBaseResult = new GachaResult
        {
            DiceUsed = [18, 18, 18, 18],
            BaseScore = 72,
            BaseRarity = "Rare",
            Formula = "client-computed gacha base (range 4-80)"
        },
        ProgressionControl = new ProgressionControl { CurrentRealm = "Chaos Sea" }
    };

    private static TurnRequest CreateSnapshotByteContractRequest(string idSuffix) => new()
    {
        SessionId = $"session_snapshot_bytes_{idSuffix}",
        RequestId = $"request_snapshot_bytes_{idSuffix}",
        TurnNumber = 52,
        PlayerAction = "Проверить точные байты snapshot.",
        Timestamp = "2026-07-27T00:00:00Z",
        PreGeneratedDices1d20 = Enumerable.Range(1, 20).ToArray(),
        ProgressionControl = new ProgressionControl { CurrentRealm = "Mortal World" }
    };

    private async Task WriteJsonAsync(string relativePath, object payload)
    {
        await _fs.WriteFileAtomicAsync(
            relativePath,
            JsonSerializer.Serialize(payload, SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed));
    }

    private async Task WriteAcceptedLifeEvaluationResponseAsync(string? sessionId, string? requestId, int turnNumber)
    {
        await EnsureChaosSeaLifeEvaluationBootstrapAsync();

        var soulRoot = JsonNode.Parse((await _fs.ReadFileAsync("game_state/meta/soul_state.json"))!)!.AsObject();
        var inkFeathers = soulRoot["inkFeathers"] as JsonObject ?? new JsonObject();
        var currentInk = ReadInt(inkFeathers["current"]);
        var totalInk = ReadInt(inkFeathers["total"]);
        inkFeathers["current"] = currentInk + 10;
        inkFeathers["total"] = Math.Max(totalInk + 10, currentInk + 10);
        soulRoot["inkFeathers"] = inkFeathers;

        var soulRelics = soulRoot["soulRelics"] as JsonObject ?? new JsonObject();
        var storedRelics = soulRelics["stored"] as JsonArray ?? new JsonArray();
        soulRelics["stored"] = storedRelics;
        soulRelics["equipped"] ??= new JsonArray();
        if (!storedRelics.OfType<JsonObject>().Any(relic =>
                string.Equals(relic["relicId"]?.GetValue<string>(), "relic_life_evaluation_test", StringComparison.OrdinalIgnoreCase)))
        {
            storedRelics.Add(new JsonObject
            {
                ["relicId"] = "relic_life_evaluation_test",
                ["name"] = "След завершенной жизни",
                ["rarity"] = "Common",
                ["quality"] = "Common",
                ["description"] = "Тихая реликвия, оставшаяся после добровольно завершенной тестовой жизни.",
                ["source"] = "LifeEvaluation"
            });
        }
        soulRoot["soulRelics"] = soulRelics;
        await _fs.WriteFileAtomicAsync(
            "game_state/meta/soul_state.json",
            soulRoot.ToJsonString(SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed));

        await WriteJsonAsync("lore/chaos_sea/player_chronicle.json", new
        {
            entries = new[]
            {
                new
                {
                    entryId = "life_eval_test_001",
                    title = "Добровольное завершение жизни",
                    summary = "Душа завершила тестовую смертную жизнь и вернулась в Море Хаоса с минимальной наградой.",
                    recordedAtTurn = turnNumber
                }
            }
        });
        await WriteJsonAsync("game_state/control/progression_report.json", new
        {
            progressionProcessingReport = new
            {
                sessionId,
                requestId,
                turnNumber,
                worldCyclesProcessed = 0,
                factionCyclesProcessed = 0,
                chaosSeaCyclesProcessed = 1,
                guardianProjectCyclesProcessed = 1,
                residentAgencyCyclesProcessed = 1,
                shiningAbodeCyclesProcessed = 0,
                shiningFactionCyclesProcessed = 0,
                shiningTradeCyclesProcessed = 0,
                newLastChaosSeaSimulationOrdinal = 1,
                newLastGuardianProjectCycleOrdinal = 1,
                newLastResidentAgencyCycleOrdinal = 1,
                afterlifeCatchupProcessed = false,
                afterlifeCatchupSummaryEventsProcessed = 0
            }
        });
        await WriteJsonAsync("output/narrative_response.json", new
        {
            response = "Море Хаоса принимает душу после оценки прожитой жизни.",
            timestamp = "2026-06-19T01:01:00Z"
        });
        await WriteJsonAsync("output/debug_logs.json", new
        {
            timestamp = "2026-06-19T01:01:00Z",
            gm_thoughts_markdown = "## Охват NPC-анализа\n- Режим / Mode: Scene-local\n- Релевантные акторы / Relevant actors: нет\n- Почему они релевантны / Why they are relevant: Оценка Жизни закрывает системный переход без участия NPC.\n- Акторы вне охвата / Actors outside scope: Хранители, резиденты Обители\n- Почему они вне охвата / Why they are outside scope: Тестовая оценка не изменяет их состояние.\n\n## Reasoning / Размышления NPC / Guardian Thoughts\n- Structured actor reasoning is not required for this test life evaluation response."
        });
        await WriteJsonAsync("ready/turn_complete.json", new
        {
            sessionId,
            requestId,
            turnNumber,
            status = "success",
            timestamp = "2026-06-19T01:01:00Z",
            filesModified = new[]
            {
                "game_state/meta/soul_state.json",
                "lore/chaos_sea/player_chronicle.json",
                "game_state/control/progression_report.json",
                "output/narrative_response.json",
                "output/debug_logs.json"
            }
        });
    }

    private async Task EnsureChaosSeaLifeEvaluationBootstrapAsync()
    {
        await WriteJsonIfMissingAsync("game_state/meta/achievements.json", new
        {
            unlockedAchievements = Array.Empty<object>(),
            trackedProgress = Array.Empty<object>(),
            stats = new
            {
                totalUnlocked = 0,
                byCategory = new { combat = 0, exploration = 0, story = 0, social = 0, crafting = 0, meta = 0, death = 0, secret = 0 },
                byRarity = new { common = 0, uncommon = 0, rare = 0, epic = 0, legendary = 0 }
            }
        });
        await WriteJsonIfMissingAsync("lore/codex_entries.json", new
        {
            entries = Array.Empty<object>(),
            totalEntries = 0,
            categories = new { cosmology = 0, geography = 0, history = 0, cultures = 0, creatures = 0, characters = 0, artifacts = 0, factions = 0, magic = 0, other = 0 }
        });
        await WriteJsonIfMissingAsync("lore/chaos_sea/cosmology.json", new
        {
            summary = "Море Хаоса связывает души между смертными жизнями."
        });
        await WriteJsonIfMissingAsync("lore/chaos_sea/soul_system_lore.json", new
        {
            summary = "Душа сохраняет опыт, Чернильные Перья и Реликвии Души между жизнями."
        });
        await WriteJsonIfMissingAsync("lore/chaos_sea/guardians_lore.json", new
        {
            entries = Array.Empty<object>()
        });
    }

    private async Task WriteJsonIfMissingAsync(string relativePath, object payload)
    {
        if (_fs.FileExists(relativePath))
            return;

        await WriteJsonAsync(relativePath, payload);
    }

    private async Task<string> WaitForValidationRepairRequestContainingAsync(string expectedText, TimeSpan timeout)
    {
        var deadline = DateTime.UtcNow + timeout;
        string? lastRequest = null;

        while (DateTime.UtcNow < deadline)
        {
            if (_fs.FileExists("game_state/control/validation_repair_request.json"))
            {
                lastRequest = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
                if (lastRequest?.Contains(expectedText, StringComparison.OrdinalIgnoreCase) == true)
                    return lastRequest;
            }

            await Task.Delay(50);
        }

        var controlRoot = _fs.ResolvePath("game_state/control");
        var controlDiagnostics = Directory.Exists(controlRoot)
            ? string.Join(
                " | ",
                Directory.GetFiles(controlRoot, "*.json", SearchOption.TopDirectoryOnly)
                    .Order(StringComparer.Ordinal)
                    .Select(path =>
                    {
                        var name = Path.GetFileName(path);
                        var content = File.ReadAllText(path);
                        return $"{name}={content}";
                    }))
            : "<missing control directory>";
        throw new TimeoutException(
            $"Timed out waiting for validation_repair_request.json containing '{expectedText}'. " +
            $"Last request: {lastRequest ?? "<missing>"}. Control files: {controlDiagnostics}");
    }

    private async Task<string> WaitForUpdatedValidationRepairRequestContainingAsync(
        string expectedText,
        string previousRequest,
        TimeSpan timeout)
    {
        var deadline = DateTime.UtcNow + timeout;
        string? lastRequest = null;

        while (DateTime.UtcNow < deadline)
        {
            if (_fs.FileExists("game_state/control/validation_repair_request.json"))
            {
                lastRequest = await _fs.ReadFileAsync("game_state/control/validation_repair_request.json");
                if (!string.Equals(lastRequest, previousRequest, StringComparison.Ordinal) &&
                    lastRequest?.Contains(expectedText, StringComparison.OrdinalIgnoreCase) == true)
                {
                    return lastRequest;
                }
            }

            await Task.Delay(50);
        }

        throw new TimeoutException(
            $"Timed out waiting for an updated validation_repair_request.json containing '{expectedText}'. Last request: {lastRequest ?? "<missing>"}");
    }

    private static int ReadInt(JsonNode? node)
    {
        if (node is JsonValue value && value.TryGetValue<int>(out var intValue))
            return intValue;
        if (node is JsonValue longValue && longValue.TryGetValue<long>(out var longResult) && longResult is >= 0 and <= int.MaxValue)
            return (int)longResult;
        return 0;
    }

    private static void CopyDirectory(string sourceDir, string destinationDir)
    {
        Directory.CreateDirectory(destinationDir);

        foreach (var directory in Directory.GetDirectories(sourceDir, "*", SearchOption.AllDirectories))
            Directory.CreateDirectory(directory.Replace(sourceDir, destinationDir));

        foreach (var file in Directory.GetFiles(sourceDir, "*", SearchOption.AllDirectories))
            File.Copy(file, file.Replace(sourceDir, destinationDir), overwrite: true);
    }

    private async Task WritePendingTurnSnapshotManifestAsync(
        string sessionId,
        string requestId,
        int turnNumber,
        params string[] trackedPaths)
    {
        await WritePendingTurnSnapshotManifestAsync(sessionId, requestId, turnNumber, gachaBaseResult: null, trackedPaths);
    }

    private async Task WritePendingTurnSnapshotManifestAsync(
        string sessionId,
        string requestId,
        int turnNumber,
        JsonObject? gachaBaseResult,
        params string[] trackedPaths)
    {
        var files = trackedPaths.ToDictionary(
            path => path,
            path => $"game_state/control/pending_turn_snapshot/{path}",
            StringComparer.OrdinalIgnoreCase);
        var snapshotHashes = trackedPaths.ToDictionary(
            path => path,
            path =>
            {
                var snapshotPath = _fs.ResolvePath($"game_state/control/pending_turn_snapshot/{path}");
                return ComputeSha256(File.ReadAllText(snapshotPath, Encoding.UTF8));
            },
            StringComparer.OrdinalIgnoreCase);

        var manifest = new PendingTurnSnapshotManifestPayload
        {
            SessionId = sessionId,
            RequestId = requestId,
            TurnNumber = turnNumber,
            RequestTimestamp = "2026-03-24T00:00:00Z",
            PlayerAction = "game-engine-turn-lifecycle-test",
            GachaBaseResult = gachaBaseResult,
            ProgressionControl = new ProgressionControl { CurrentRealm = "Mortal World" },
            Files = files,
            SnapshotFileHashes = snapshotHashes,
            ClientOwnedValidationHashes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase),
            RollbackBackups = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase),
            RollbackBaselineFiles = trackedPaths.ToList(),
            SourceLabel = "game-engine-turn-lifecycle-tests"
        };
        manifest.ManifestPayloadHash = ComputeManifestPayloadHash(manifest);

        await _fs.WriteFileAtomicAsync(
            "game_state/control/pending_turn_snapshot.json",
            JsonSerializer.Serialize(manifest, SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed));
        await PendingTurnSnapshotTestAuthority.SyncAuthorityForCurrentManifestAsync(_fs);
    }

    private static string ComputeManifestPayloadHash(PendingTurnSnapshotManifestPayload manifest)
    {
        var originalHash = manifest.ManifestPayloadHash;
        manifest.ManifestPayloadHash = string.Empty;
        var payload = JsonSerializer.Serialize(manifest, SnapshotHashJsonOpts);
        manifest.ManifestPayloadHash = originalHash;
        return ComputeSha256(payload);
    }

    private static string ComputeSha256(string content)
    {
        using var sha = SHA256.Create();
        return Convert.ToHexString(sha.ComputeHash(Encoding.UTF8.GetBytes(content)));
    }

    /// <summary>
    /// Builds a real lifecycle engine with the selected test filesystem, settings and optional diagnostic hooks.
    /// </summary>
    /// <param name="inputSource">
    /// Console input override, or <see langword="null"/> for the engine's default input source.
    /// </param>
    /// <param name="configureSettings">
    /// Optional settings customization applied before service construction.
    /// </param>
    /// <param name="finalizationHooks">
    /// Optional hooks for accepted-session finalization; <see langword="null"/> leaves them disabled.
    /// </param>
    /// <param name="fileSystem">
    /// Shared canonical filesystem, or <see langword="null"/> to use this test instance's filesystem.
    /// </param>
    /// <param name="logger">
    /// Engine diagnostics sink, or <see langword="null"/> to retain the default null logger.
    /// </param>
    /// <param name="loadHooks">Optional cuts in the real save loader.</param>
    /// <returns>
    /// An engine using real lifecycle services and the supplied test overrides.
    /// </returns>
    private GameEngine CreateGameEngine(
        IConsoleInputSource? inputSource = null,
        Action<GameSettings>? configureSettings = null,
        GameEngineSessionFinalizationHooks? finalizationHooks = null,
        FileSystemManager? fileSystem = null,
        Microsoft.Extensions.Logging.ILogger<GameEngine>? logger = null,
        SaveLoadServiceHooks? loadHooks = null)
    {
        var fs = fileSystem ?? _fs;
        var settings = new GameSettings();
        configureSettings?.Invoke(settings);
        var stateManager = new StateManager(fs, settings, NullLogger<StateManager>.Instance);
        var localization = new LocalizationManager { CurrentLanguage = "ru" };
        var gameLoop = new GameLoop();
        var normalizer = new CanonicalStateNormalizer(fs, NullLogger<CanonicalStateNormalizer>.Instance);
        var progressionSchedule = new ProgressionScheduleService(fs, NullLogger<ProgressionScheduleService>.Instance);
        var gameInterface = new GameInterface(localization, settings);
        var clipboardService = new TestClipboardService();
        var explorer = new ExplorerMode(stateManager, fs, localization, clipboardService: clipboardService, console: new TestExplorerConsole());
        var saveLoad = new SaveLoadService(fs, stateManager, NullLogger<SaveLoadService>.Instance, loadHooks);
        var imageService = new ImageService(fs, settings, localization, NullLogger<ImageService>.Instance);
        var validator = new ValidationService(fs, NullLogger<ValidationService>.Instance);
        var characteristicsService = new CharacteristicsService(fs, stateManager, NullLogger<CharacteristicsService>.Instance);
        var storyService = new StoryService(fs, NullLogger<StoryService>.Instance);
        var actorMemoryService = new ActorMemoryService(fs, NullLogger<ActorMemoryService>.Instance);
        var audioService = new AudioService(fs, settings, NullLogger<AudioService>.Instance);
        var consoleAppearance = new ConsoleAppearanceService(settings, NullLogger<ConsoleAppearanceService>.Instance);
        var systemModService = new SystemModService(fs, settings, NullLogger<SystemModService>.Instance);
        var systemGuardianLibraryService = new SystemGuardianLibraryService(fs, NullLogger<SystemGuardianLibraryService>.Instance);
        var criticalStateHealth = new CriticalStateHealthService(fs, NullLogger<CriticalStateHealthService>.Instance);
        var worldDirectiveService = new WorldDirectiveService(fs, NullLogger<WorldDirectiveService>.Instance);
        var scenarioCoreService = new ScenarioCoreService(fs, NullLogger<ScenarioCoreService>.Instance);
        var afterlifeArchiveCandidateService = new AfterlifeArchiveCandidateService(fs, NullLogger<AfterlifeArchiveCandidateService>.Instance);
        var afterlifeReturnGuardService = new AfterlifeReturnGuardService(fs, NullLogger<AfterlifeReturnGuardService>.Instance);
        var rivalSoulArcService = new RivalSoulArcService(fs, NullLogger<RivalSoulArcService>.Instance);
        var guardianCorrectionService = new GuardianCorrectionService(fs, scenarioCoreService, NullLogger<GuardianCorrectionService>.Instance);
        var pendingTurnState = new PendingTurnStateService(fs, NullLogger<PendingTurnStateService>.Instance);
        var stateDistributor = new StateDistributor(fs, NullLogger<StateDistributor>.Instance);
        var qteSceneService = new QteSceneService(
            fs,
            settings,
            characteristicsService,
            imageService,
            audioService,
            stateDistributor,
            validator,
            normalizer,
            stateManager,
            NullLogger<QteSceneService>.Instance);

        var engine = new GameEngine(
            fs,
            stateManager,
            gameLoop,
            normalizer,
            progressionSchedule,
            gameInterface,
            explorer,
            localization,
            saveLoad,
            imageService,
            validator,
            characteristicsService,
            storyService,
            actorMemoryService,
            audioService,
            consoleAppearance,
            systemModService,
            systemGuardianLibraryService,
            criticalStateHealth,
            worldDirectiveService,
            scenarioCoreService,
            afterlifeArchiveCandidateService,
            afterlifeReturnGuardService,
            rivalSoulArcService,
            guardianCorrectionService,
            pendingTurnState,
            qteSceneService,
            clipboardService,
            logger ?? NullLogger<GameEngine>.Instance,
            inputSource);
        engine.ConfigureSessionFinalizationHooksForTesting(finalizationHooks);
        return engine;
    }

    private void ArmCanonicalWriteFailure(string relativePath, int matchingWrite = 1)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(relativePath);
        if (matchingWrite < 1)
            throw new ArgumentOutOfRangeException(nameof(matchingWrite));

        _armedCanonicalWriteFailurePath = relativePath;
        _remainingCanonicalWriteFailureMatches = matchingWrite;
    }

    private Task BeforeCanonicalMutationAsync(string relativePath)
    {
        _consoleMutationObserver?.Invoke(relativePath);
        if (_armedCanonicalWriteFailurePath == null ||
            !string.Equals(
                relativePath,
                _armedCanonicalWriteFailurePath,
                StringComparison.OrdinalIgnoreCase))
        {
            return Task.CompletedTask;
        }

        _remainingCanonicalWriteFailureMatches--;
        if (_remainingCanonicalWriteFailureMatches > 0)
            return Task.CompletedTask;

        _armedCanonicalWriteFailurePath = null;
        return Task.FromException(
            new IOException($"Injected accepted-turn canonical write failure for '{relativePath}'."));
    }

    private static ConsoleKeyInfo Key(ConsoleKey key)
    {
        var keyChar = key == ConsoleKey.Enter
            ? '\r'
            : key == ConsoleKey.Spacebar
                ? ' '
                : char.ToLowerInvariant(key.ToString()[0]);
        return new ConsoleKeyInfo(keyChar, key, shift: false, alt: false, control: false);
    }

    private static async Task<AgentConsoleSnapshot> WaitForAgentConsoleSnapshotAsync(
        AgentConsoleStateStore store,
        string screenId)
    {
        var deadline = DateTime.UtcNow.AddSeconds(2);
        while (DateTime.UtcNow < deadline)
        {
            var snapshot = store.GetSnapshot();
            if (snapshot != null && string.Equals(snapshot.ScreenId, screenId, StringComparison.OrdinalIgnoreCase))
                return snapshot;

            await Task.Delay(25);
        }

        throw new TimeoutException($"Agent Console snapshot '{screenId}' was not published.");
    }

    private async Task<TurnRequest> WaitForTurnRequestAsync()
    {
        var deadline = DateTime.UtcNow.AddSeconds(30);
        while (DateTime.UtcNow < deadline)
        {
            var json = await _fs.ReadFileAsync("input/turn_request.json");
            if (!string.IsNullOrWhiteSpace(json))
                return JsonSerializer.Deserialize<TurnRequest>(json, SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed)
                       ?? throw new InvalidOperationException("turn_request.json could not be deserialized.");

            await Task.Delay(25);
        }

        throw new TimeoutException("input/turn_request.json was not created.");
    }

    private sealed class QueuedConsoleInputSource : IConsoleInputSource
    {
        private readonly ConcurrentQueue<ConsoleKeyInfo> _keys;

        public QueuedConsoleInputSource(IEnumerable<ConsoleKeyInfo> keys)
        {
            _keys = new ConcurrentQueue<ConsoleKeyInfo>(keys);
        }

        public bool IsScripted => true;

        public bool KeyAvailable => !_keys.IsEmpty;

        public ConsoleKeyInfo ReadKey(bool intercept = true)
        {
            return _keys.TryDequeue(out var key) ? key : Key(ConsoleKey.Enter);
        }

        public string? ReadLine() => string.Empty;

        public void Enqueue(ConsoleKeyInfo key) => _keys.Enqueue(key);

        public void AssertCompleted()
        {
        }
    }

    private sealed record GenerationFinalizerState(
        int TurnNumber, GameResponse? Response, string? ResponseJson, string? ImagePrompt);

    private static GenerationFinalizerState CaptureGenerationFinalizerState(GameEngine engine)
    {
        var response = GetPrivateFieldValue<GameResponse?>(engine, "_lastResponse");
        return new GenerationFinalizerState(
            GetPrivateField<GameLoop>(engine, "_gameLoop").TurnNumber,
            response,
            response is null ? null : JsonSerializer.Serialize(response, SnapshotHashJsonOpts),
            GetPrivateFieldValue<string?>(engine, "_pendingImagePrompt"));
    }

    private static T GetPrivateField<T>(object instance, string fieldName) where T : class
    {
        var field = instance.GetType().GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(field);
        var value = field!.GetValue(instance) as T;
        Assert.NotNull(value);
        return value!;
    }

    private static void SetPrivateField<T>(object instance, string fieldName, T value)
    {
        var field = instance.GetType().GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(field);
        field!.SetValue(instance, value);
    }

    private static T GetPrivateFieldValue<T>(object instance, string fieldName)
    {
        var field = instance.GetType().GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
        Assert.NotNull(field);
        return (T)field!.GetValue(instance)!;
    }

    private async Task<string> GetOrCreateSessionGenerationAsync()
    {
        await using var writeLease = await _fs.AcquireCanonicalWriteLeaseAsync();
        return _fs.GetOrCreateSessionGeneration(writeLease);
    }

    private static TaskCompletionSource<bool> NewSignal() =>
        new(TaskCreationOptions.RunContinuationsAsynchronously);

    private static async Task WriteArchiveTextEntryAsync(
        ZipArchive archive,
        string path,
        string content)
    {
        var entry = archive.CreateEntry(path);
        await using var stream = entry.Open();
        await using var writer = new StreamWriter(stream);
        await writer.WriteAsync(content);
    }

    private async Task SeedMortalLifeTransitionAuthorityAsync(object soulPayload)
    {
        var soul = soulPayload is JsonObject soulRoot
            ? soulRoot.DeepClone().AsObject()
            : Assert.IsType<JsonObject>(JsonSerializer.SerializeToNode(
                soulPayload,
                SharedJsonOptions.PrettyCamelCaseUnsafeRelaxed));
        if (soul[AfterlifeSpiritualConflictState.SoulStateProfileProperty] is not
            JsonObject combatProfile)
        {
            combatProfile = new JsonObject();
            soul[AfterlifeSpiritualConflictState.SoulStateProfileProperty] = combatProfile;
        }
        if (combatProfile[AfterlifeSpiritualConflictState.SpiritFocusTierProperty] == null)
            combatProfile[AfterlifeSpiritualConflictState.SpiritFocusTierProperty] = 0;
        var soulName = soul["soulName"]?.GetValue<string>() ?? "Пепельная Искра";
        await CanonicalResourceQuartetTestFixture.CommitFreshBootstrapAsync(
            _fs,
            new AfterlifeOwnerResourceAcceptedState(
                Profiles: CreatePlayerSoulProfiles(soulName, "Chaos Sea"),
                SpiritualConflict: AfterlifeSpiritualConflictState.CreateDefaultRoot(),
                SoulState: soul,
                ShiningAbode: ShiningAbodeState.CreateDefaultState(),
                Guardians: CreateEmptyGuardiansState()));
    }

    private async Task WriteCurrentSoulStateToPendingSnapshotAsync()
    {
        var soulJson = await _fs.ReadFileAsync("game_state/meta/soul_state.json");
        Assert.False(string.IsNullOrWhiteSpace(soulJson));
        await _fs.WriteFileAtomicAsync(
            "game_state/control/pending_turn_snapshot/game_state/meta/soul_state.json",
            soulJson!);
    }

    private static JsonObject CreatePlayerSoulProfiles(string displayName, string realm)
    {
        var playerSoul = AfterlifeActorMaterializationTestFixture.CreateCompleteProfile(
            "guardian",
            "player_soul",
            realm,
            materializedAtTurn: 1);
        playerSoul["actorType"] = "player_soul";
        playerSoul.Remove(ActorMaterializationContract.PropertyName);
        playerSoul["displayName"] = displayName;
        return new JsonObject
        {
            [AfterlifeEntityProfileState.ProfilesProperty] = new JsonArray
            {
                playerSoul
            }
        };
    }

    private static JsonObject CreateEmptyGuardiansState() =>
        new()
        {
            ["activeGuardian"] = null,
            ["guardians"] = new JsonArray(),
            ["chaosSeaNavigation"] = new JsonObject { ["currentAbodeId"] = null }
        };

    private static JsonObject CreateLifecycleSoulState(string soulName, string realm) =>
        new()
        {
            ["soulName"] = soulName,
            ["currentRealm"] = realm,
            ["currentIncarnation"] = 2,
            ["enlightenment"] = new JsonObject
            {
                ["currentTier"] = "Новичок",
                ["experience"] = 0,
                ["level"] = 0
            },
            ["inkFeathers"] = new JsonObject { ["current"] = 0, ["total"] = 0 },
            ["soulRelics"] = new JsonObject
            {
                ["equipped"] = new JsonArray(),
                ["stored"] = new JsonArray()
            },
            ["afterlifeArchive"] = new JsonObject { ["stored"] = new JsonArray() },
            ["livesHistory"] = new JsonArray(),
            ["pendingMemoryLegacy"] = null,
            [AfterlifeSpiritualConflictState.SoulStateProfileProperty] = new JsonObject
            {
                [AfterlifeSpiritualConflictState.SpiritFocusTierProperty] = 0
            }
        };

    private static Task<bool> InvokeSoulRealmTransitionAsync(
        object engine,
        string causeName,
        string? lifeSummary = null)
    {
        var causeType = engine.GetType().GetNestedType(
            "SoulRealmTransitionCause",
            BindingFlags.NonPublic);
        Assert.NotNull(causeType);
        var cause = Enum.Parse(causeType!, causeName, ignoreCase: false);
        return InvokePrivateAsync<bool>(
            engine,
            "UpdateSoulStateRealm",
            cause,
            lifeSummary);
    }

    private static async Task SpendGuardianAttemptForFixtureAsync(
        FileSystemManager fileSystem,
        ResourceDefinitionCatalog definitions,
        string guardianId,
        int turn)
    {
        var stateResult = ResourceStateContract.ParseCanonical(
            await fileSystem.ReadFileAsync(ResourceMaterializationContract.StatePath),
            definitions,
            allowMissingPristine: false);
        var historyResult = ResourceHistoryState.ParseCanonical(
            await fileSystem.ReadFileAsync(ResourceMaterializationContract.HistoryPath),
            definitions,
            allowMissingPristine: false);
        Assert.True(stateResult.IsValid, string.Join(Environment.NewLine, stateResult.Issues));
        Assert.True(historyResult.IsValid, string.Join(Environment.NewLine, historyResult.Issues));
        var ledger = Assert.IsType<ResourceStateLedger>(stateResult.Ledger);
        var history = Assert.IsType<ResourceHistoryState>(historyResult.History);
        var before = Assert.Single(
            ledger.Entries,
            entry => entry.Coordinate.OwnerKind == ResourceOwnerKind.AfterlifeActor &&
                     entry.Coordinate.ResourceOwnerId == guardianId &&
                     entry.Coordinate.ResourceKey == "gacha_attempts");
        Assert.Equal(2m, before.Current);
        var prior = Assert.Single(
            history.Transitions,
            transition => ResourceCoordinateComparer.Instance.Equals(
                transition.Coordinate,
                before.Coordinate));
        var sequence = history.Transitions
            .Where(transition => transition.Turn == turn)
            .Select(static transition => transition.ExecutionSequence)
            .DefaultIfEmpty(-1)
            .Max() + 1;
        var transition = new ResourceTransition(
            $"resource_transition_guardian_fixture_spend_{turn}",
            $"resource_operation_guardian_fixture_spend_{turn}",
            $"turn_{turn}:guardian_fixture_spend",
            "registered_system_outcome",
            $"guardian_fixture_spend_{turn}",
            ResourceMutationPhase.RegisteredSystemOutcome,
            Priority: 60,
            sequence,
            before.Coordinate,
            ResourceTransitionOperation.Spend,
            RequestedAmount: 1m,
            AppliedAmount: 1m,
            ResourceTransitionOutcome.Applied,
            CapacityDisposition: null,
            before.Snapshot,
            before.Snapshot with { Current = 1m },
            new ResourceSourceEvidence(
                "registered_system_outcome",
                $"guardian_fixture_spend_{turn}",
                prior.PolicyFingerprint),
            prior.PolicyFingerprint,
            ReceiptId: null,
            turn);
        var updatedHistoryResult = ResourceHistoryState.CreateValidated(
            history.Transitions.Append(transition),
            definitions);
        Assert.True(
            updatedHistoryResult.IsValid,
            string.Join(Environment.NewLine, updatedHistoryResult.Issues));
        var updatedHistory = Assert.IsType<ResourceHistoryState>(updatedHistoryResult.History);
        var updatedState = new ResourceStateLedger(ledger.Entries.Select(entry =>
            ResourceCoordinateComparer.Instance.Equals(entry.Coordinate, before.Coordinate)
                ? entry with
                {
                    Current = 1m,
                    Chronology = entry.Chronology with
                    {
                        LastTransitionId = transition.TransitionId,
                        LastEventRef = transition.EventRef,
                        LastTransitionTurn = transition.Turn
                    }
                }
                : entry));
        Assert.Empty(updatedHistory.ValidateStateAgreement(updatedState));
        await CanonicalResourceQuartetTestFixture.CommitExistingStateAsync(
            fileSystem,
            definitions,
            ledger,
            history,
            updatedState,
            updatedHistory);
    }

    private static async Task<T> InvokePrivateAsync<T>(object instance, string methodName, params object?[]? args)
    {
        var method = ResolvePrivateMethod(instance, methodName, args);
        var task = method.Invoke(instance, BuildPrivateInvocationArguments(method, args)) as Task<T>;
        Assert.NotNull(task);
        return await task!;
    }

    private static async Task InvokePrivateTaskAsync(object instance, string methodName, params object?[]? args)
    {
        var method = ResolvePrivateMethod(instance, methodName, args);
        var task = method.Invoke(instance, BuildPrivateInvocationArguments(method, args)) as Task;
        Assert.NotNull(task);
        await task!;
    }

    private static void InvokePrivate(object instance, string methodName, params object?[]? args)
    {
        var method = ResolvePrivateMethod(instance, methodName, args);
        method.Invoke(instance, BuildPrivateInvocationArguments(method, args));
    }

    private static T InvokePrivateValue<T>(object instance, string methodName, params object?[]? args)
    {
        var method = ResolvePrivateMethod(instance, methodName, args);
        var value = method.Invoke(instance, BuildPrivateInvocationArguments(method, args));
        Assert.IsType<T>(value);
        return (T)value!;
    }

    private static async Task<object> InvokePrivateTaskResultAsync(object instance, string methodName, params object?[]? args)
    {
        var method = ResolvePrivateMethod(instance, methodName, args);
        var task = method.Invoke(instance, BuildPrivateInvocationArguments(method, args)) as Task;
        Assert.NotNull(task);
        await task!;
        var resultProperty = task.GetType().GetProperty("Result");
        Assert.NotNull(resultProperty);
        var result = resultProperty!.GetValue(task);
        Assert.NotNull(result);
        return result!;
    }

    private static async Task<object?> InvokePrivateTaskNullableResultAsync(
        object instance,
        string methodName,
        params object?[]? args)
    {
        var method = ResolvePrivateMethod(instance, methodName, args);
        var task = method.Invoke(instance, BuildPrivateInvocationArguments(method, args)) as Task;
        Assert.NotNull(task);
        await task!;
        var resultProperty = task.GetType().GetProperty("Result");
        Assert.NotNull(resultProperty);
        return resultProperty!.GetValue(task);
    }

    private static MethodInfo ResolvePrivateMethod(
        object instance,
        string methodName,
        object?[]? args)
    {
        var supplied = args ?? Array.Empty<object?>();
        var compatible = instance
            .GetType()
            .GetMethods(BindingFlags.Instance | BindingFlags.NonPublic)
            .Where(method => string.Equals(method.Name, methodName, StringComparison.Ordinal))
            .Where(method => CanInvokeWith(method, supplied))
            .ToArray();

        var exactArity = compatible
            .Where(method => method.GetParameters().Length == supplied.Length)
            .ToArray();
        return exactArity.Length > 0
            ? Assert.Single(exactArity)
            : Assert.Single(compatible);
    }

    private static bool CanInvokeWith(MethodInfo method, IReadOnlyList<object?> supplied)
    {
        var parameters = method.GetParameters();
        if (supplied.Count > parameters.Length)
            return false;

        for (var i = 0; i < supplied.Count; i++)
        {
            var argument = supplied[i];
            var parameterType = parameters[i].ParameterType;
            if (argument == null)
            {
                if (parameterType.IsValueType && Nullable.GetUnderlyingType(parameterType) == null)
                    return false;
                continue;
            }

            if (!parameterType.IsInstanceOfType(argument))
                return false;
        }

        return parameters
            .Skip(supplied.Count)
            .All(parameter => parameter.HasDefaultValue);
    }

    private static object?[]? BuildPrivateInvocationArguments(MethodInfo method, object?[]? args)
    {
        var supplied = args ?? Array.Empty<object?>();
        var parameters = method.GetParameters();
        if (supplied.Length == parameters.Length)
            return supplied;

        if (supplied.Length > parameters.Length)
            return supplied;

        var completed = new object?[parameters.Length];
        Array.Copy(supplied, completed, supplied.Length);
        for (var i = supplied.Length; i < parameters.Length; i++)
        {
            if (!parameters[i].HasDefaultValue)
                return supplied;

            completed[i] = parameters[i].DefaultValue;
        }

        return completed;
    }

    public void Dispose()
    {
        try
        {
            if (Directory.Exists(_rootPath))
                Directory.Delete(_rootPath, recursive: true);
        }
        catch
        {
            // best-effort cleanup
        }
    }
}
