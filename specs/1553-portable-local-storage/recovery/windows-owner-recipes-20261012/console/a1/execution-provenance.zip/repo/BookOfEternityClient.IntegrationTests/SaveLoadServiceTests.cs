using System.IO.Compression;
using System.Linq;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using BookOfEternityClient.Configuration;
using BookOfEternityClient.Core;
using BookOfEternityClient.Services;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

namespace BookOfEternityClient.Tests;

[Trait("Category", "ProcessIntegration")]
public sealed class SaveLoadServiceTests : IDisposable
{
    private readonly string _rootPath;
    private readonly FileSystemManager _fs;
    private readonly SaveLoadService _service;
    private readonly PortableSaveFixture.CaptureLogger _serviceLogger = new();

    public SaveLoadServiceTests()
    {
        _rootPath = Path.Combine(Path.GetTempPath(), "boe-save-load-tests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(_rootPath);

        _fs = new FileSystemManager(_rootPath, NullLogger<FileSystemManager>.Instance);
        _fs.EnsureDirectoryStructure();
        _fs.WriteFileAtomicAsync(
                "game_state/meta/soul_state.json",
                """
                {
                  "soulName": "Тестовая Душа",
                  "currentRealm": "Mortal World",
                  "currentIncarnation": 1
                }
                """)
            .GetAwaiter()
            .GetResult();
        _fs.WriteFileAtomicAsync(
                "game_state/world/test_fixture_state.json",
                """{ "state": "test-fixture" }""")
            .GetAwaiter()
            .GetResult();
        var resourceBootstrap = ResourceBootstrapStateBuilder.BuildPristine();
        _fs.WriteFileAtomicAsync(
                ResourceMaterializationContract.DefinitionsPath,
                resourceBootstrap.Definitions!.ToCanonicalJson())
            .GetAwaiter()
            .GetResult();
        _fs.WriteFileAtomicAsync(
                ResourceMaterializationContract.StatePath,
                resourceBootstrap.State!.ToCanonicalJson())
            .GetAwaiter()
            .GetResult();
        _fs.WriteFileAtomicAsync(
                ResourceMaterializationContract.HistoryPath,
                resourceBootstrap.History!.ToCanonicalJson())
            .GetAwaiter()
            .GetResult();
        _fs.WriteFileAtomicAsync(
                CanonicalResourceOwnerAuthorityComposer.AuthorityPath,
                "{\"schemaVersion\":1,\"historicalOwners\":[],\"capacityDrafts\":[]}")
            .GetAwaiter()
            .GetResult();

        var settings = new GameSettings();
        var stateManager = new StateManager(_fs, settings, NullLogger<StateManager>.Instance);
        stateManager.RefreshGameStateAsync().GetAwaiter().GetResult();
        _service = new SaveLoadService(_fs, stateManager, _serviceLogger);
    }

    [Fact]
    public async Task SaveAndLoad_ConsolePreparationArtifactsRemainEphemeral()
    {
        var state = new StateManager(_fs, new GameSettings(), NullLogger<StateManager>.Instance);
        var explorer = new BookOfEternityClient.UI.ExplorerMode(state, _fs, new BookOfEternityClient.UI.LocalizationManager());
        await explorer.StagePendingLocalTurnRollbackSnapshotAsync("game_state/world/test_fixture_state.json");
        Assert.True(Directory.Exists(_fs.ResolvePath(ConsoleLocalTurnRollbackArtifacts.Root)));
        Assert.True(await _service.SaveGameAsync("console_preparation", "console preparation exclusion"));
        var savePath = Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip").Single();
        using (var archive = ZipFile.OpenRead(savePath))
            Assert.DoesNotContain(archive.Entries, entry =>
                entry.FullName.StartsWith(ConsoleLocalTurnRollbackArtifacts.Root, StringComparison.Ordinal));
        await explorer.RestoreStagedLocalTurnRollbackSnapshotAsync();
        using (var archive = ZipFile.Open(savePath, ZipArchiveMode.Update))
        {
            var entry = archive.CreateEntry(ConsoleLocalTurnRollbackArtifacts.Root + "/unowned/marker");
            await using var stream = entry.Open();
            await stream.WriteAsync(new byte[] { 0x41 });
        }
        Assert.True(await _service.LoadGameAsync(savePath));
        Assert.False(Directory.Exists(_fs.ResolvePath(ConsoleLocalTurnRollbackArtifacts.Root)));
    }

    [Fact]
    public async Task SaveGameAsync_FailureBeforeCommitLeavesNoPartialSaveOrTemporaryFile()
    {
        var settings = new GameSettings();
        var stateManager = new StateManager(_fs, settings, NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            _fs,
            stateManager,
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeSaveCommitAsync = () =>
                    throw new InvalidOperationException("simulated save commit failure")
            });

        var saved = await service.SaveGameAsync(
            "atomic_failure",
            "must not publish a partial archive");

        Assert.False(saved);
        var saveDirectory = _fs.ResolvePath("saves/manual_saves");
        Assert.Empty(Directory.GetFiles(saveDirectory, "*.zip"));
        Assert.Empty(Directory.GetFiles(saveDirectory, "*.tmp.*"));
    }

    [Fact]
    public async Task SaveGameAsync_SaveDirectoryReplacedAtCommitCannotPublishOutsideSession()
    {
        if (!OperatingSystem.IsWindows())
            return;

        var saveDirectory = _fs.ResolvePath("saves/manual_saves");
        var displacedSaveDirectory = _fs.ResolvePath("saves/manual_saves-original");
        var outsideDirectory = Path.Combine(
            Path.GetTempPath(),
            "boe-save-publish-outside-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(outsideDirectory);
        var swapped = false;
        var service = new SaveLoadService(
            _fs,
            new StateManager(
                _fs,
                new GameSettings(),
                NullLogger<StateManager>.Instance),
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeSaveCommitAsync = () =>
                {
                    Directory.Move(saveDirectory, displacedSaveDirectory);
                    CreateDirectoryJunction(saveDirectory, outsideDirectory);
                    swapped = true;
                    var stagedSave = Directory
                        .GetFiles(displacedSaveDirectory, "*.tmp.*")
                        .SingleOrDefault();
                    if (stagedSave != null)
                    {
                        File.Copy(
                            stagedSave,
                            Path.Combine(outsideDirectory, Path.GetFileName(stagedSave)));
                    }
                    return Task.CompletedTask;
                }
            });

        try
        {
            Assert.False(await service.SaveGameAsync(
                "save_destination_race",
                "save destination race regression"));
            Assert.True(swapped);
            Assert.Empty(Directory.GetFiles(outsideDirectory, "*.zip"));
        }
        finally
        {
            if (Directory.Exists(saveDirectory) && FileSystemManager.IsReparsePoint(saveDirectory))
                Directory.Delete(saveDirectory, recursive: false);
            if (Directory.Exists(displacedSaveDirectory))
                Directory.Move(displacedSaveDirectory, saveDirectory);
            if (Directory.Exists(outsideDirectory))
                Directory.Delete(outsideDirectory, recursive: true);
        }
    }

    [Fact]
    public async Task SaveGameAsync_RuntimeStagingParentSwapCannotCreateExternalArchive()
    {
        if (!OperatingSystem.IsWindows())
            return;

        var outsideDirectory = Path.Combine(
            Path.GetTempPath(),
            "boe-save-staging-outside-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(outsideDirectory);
        var outsideArchive = Path.Combine(outsideDirectory, "save.zip");
        var outsideSentinel = new byte[] { 0x31, 0x42, 0x53, 0x64 };
        await File.WriteAllBytesAsync(outsideArchive, outsideSentinel);

        var stagingRoot = string.Empty;
        var displacedStagingRoot = string.Empty;
        var swapAttempted = false;
        var swapBlocked = false;
        var swapped = false;
        var raceFs = new FileSystemManager(
            _rootPath,
            NullLogger<FileSystemManager>.Instance,
            PhysicalLoadTransactionOperations.Instance,
            new FileSystemManagerHooks
            {
                BeforeRuntimeFileCreateAsync = path =>
                {
                    if (swapAttempted ||
                        !path.EndsWith(
                            $"{Path.DirectorySeparatorChar}save.zip",
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return Task.CompletedTask;
                    }

                    swapAttempted = true;
                    stagingRoot = Path.GetDirectoryName(path)!;
                    displacedStagingRoot = stagingRoot + "-displaced";
                    try
                    {
                        Directory.Move(stagingRoot, displacedStagingRoot);
                        CreateDirectoryJunction(stagingRoot, outsideDirectory);
                        swapped = true;
                    }
                    catch (Exception ex) when (
                        ex is IOException or UnauthorizedAccessException)
                    {
                        swapBlocked = true;
                    }

                    return Task.CompletedTask;
                }
            });
        var service = new SaveLoadService(
            raceFs,
            new StateManager(
                raceFs,
                new GameSettings(),
                NullLogger<StateManager>.Instance),
            NullLogger<SaveLoadService>.Instance);

        try
        {
            Assert.True(await service.SaveGameAsync(
                "runtime_staging_authority",
                "runtime staging authority regression"));
            Assert.True(swapAttempted);
            Assert.True(swapBlocked);
            Assert.False(swapped);
            Assert.Equal(
                outsideSentinel,
                await File.ReadAllBytesAsync(outsideArchive));
        }
        finally
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(stagingRoot) &&
                    Directory.Exists(stagingRoot) &&
                    FileSystemManager.IsReparsePoint(stagingRoot))
                {
                    Directory.Delete(stagingRoot, recursive: false);
                }

                if (!string.IsNullOrWhiteSpace(displacedStagingRoot) &&
                    Directory.Exists(displacedStagingRoot) &&
                    !Directory.Exists(stagingRoot))
                {
                    Directory.Move(displacedStagingRoot, stagingRoot);
                }
            }
            catch
            {
                // Best effort cleanup for the intentionally raced staging tree.
            }

            if (Directory.Exists(outsideDirectory))
                Directory.Delete(outsideDirectory, recursive: true);
        }
    }

    [Fact]
    public async Task AutosaveAsync_DirectoryReplacedAfterEnumerationCannotDeleteOutsideFile()
    {
        if (!OperatingSystem.IsWindows())
            return;

        const string oldAutosaveRelativePath = "saves/autosaves/old.zip";
        await _fs.WriteFileAtomicBytesAsync(oldAutosaveRelativePath, [1, 2, 3]);
        var oldAutosavePath = _fs.ResolvePath(oldAutosaveRelativePath);
        File.SetCreationTimeUtc(oldAutosavePath, DateTime.UtcNow.AddDays(-2));

        var autosaveDirectory = _fs.ResolvePath("saves/autosaves");
        var displacedAutosaveDirectory = _fs.ResolvePath("saves/autosaves-original");
        var outsideDirectory = Path.Combine(
            Path.GetTempPath(),
            "boe-autosave-delete-outside-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(outsideDirectory);
        var outsideOldAutosave = Path.Combine(outsideDirectory, "old.zip");
        await File.WriteAllBytesAsync(outsideOldAutosave, [9, 8, 7]);
        var swapped = false;
        var service = new SaveLoadService(
            _fs,
            new StateManager(
                _fs,
                new GameSettings { MaxAutosaves = 1 },
                NullLogger<StateManager>.Instance),
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeAutosaveDeletionAsync = () =>
                {
                    Directory.Move(autosaveDirectory, displacedAutosaveDirectory);
                    CreateDirectoryJunction(autosaveDirectory, outsideDirectory);
                    swapped = true;
                    return Task.CompletedTask;
                }
            });

        try
        {
            Assert.True(await service.AutosaveAsync(12));
            Assert.True(swapped);
            Assert.True(File.Exists(outsideOldAutosave));
            Assert.Equal(new byte[] { 9, 8, 7 }, await File.ReadAllBytesAsync(outsideOldAutosave));
        }
        finally
        {
            if (Directory.Exists(autosaveDirectory) &&
                FileSystemManager.IsReparsePoint(autosaveDirectory))
            {
                Directory.Delete(autosaveDirectory, recursive: false);
            }
            if (Directory.Exists(displacedAutosaveDirectory))
                Directory.Move(displacedAutosaveDirectory, autosaveDirectory);
            if (Directory.Exists(outsideDirectory))
                Directory.Delete(outsideDirectory, recursive: true);
        }
    }

    [Fact]
    public async Task SaveAndLoad_TreatsProgressionReportAsEphemeralControlFile()
    {
        await _fs.WriteFileAtomicAsync("game_state/meta/soul_state.json", """
        {
          "soulName": "Тестовая Душа",
          "currentRealm": "Chaos Sea",
          "currentIncarnation": 3
        }
        """);
        await _fs.WriteFileAtomicAsync(ProgressionScheduleService.ReportPath, """
        {
          "progressionProcessingReport": {
            "chaosSeaCyclesProcessed": 1,
            "guardianProjectCyclesProcessed": 1,
            "newLastChaosSeaSimulationOrdinal": 4,
            "newLastGuardianProjectCycleOrdinal": 4
          }
        }
        """);

        Assert.True(await _service.SaveGameAsync("ephemeral_progression_report", "save/load ephemeral regression"));

        var savePath = Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip").Single();
        using (var archive = ZipFile.OpenRead(savePath))
            Assert.Null(archive.GetEntry(ProgressionScheduleService.ReportPath));

        Assert.True(await _service.LoadGameAsync(savePath));
        Assert.False(_fs.FileExists(ProgressionScheduleService.ReportPath));
    }

    [Fact]
    public async Task SaveAndLoad_PreservesUnifiedResourceRootsAndExcludesTransientCommand()
    {
        var definitions = await _fs.ReadFileAsync(
            ResourceMaterializationContract.DefinitionsPath);
        var state = await _fs.ReadFileAsync(
            ResourceMaterializationContract.StatePath);
        var history = await _fs.ReadFileAsync(
            ResourceMaterializationContract.HistoryPath);
        await _fs.WriteFileAtomicAsync(
            ResourceMaterializationContract.CommandPath,
            """{ "resourceChanges": [] }""");

        Assert.True(await _service.SaveGameAsync(
            "unified_resources",
            "resource authority round-trip"));

        var savePath = Directory
            .GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip")
            .Single();
        using (var archive = ZipFile.OpenRead(savePath))
        {
            Assert.NotNull(archive.GetEntry(
                ResourceMaterializationContract.DefinitionsPath));
            Assert.NotNull(archive.GetEntry(
                ResourceMaterializationContract.StatePath));
            Assert.NotNull(archive.GetEntry(
                ResourceMaterializationContract.HistoryPath));
            Assert.Null(archive.GetEntry(
                ResourceMaterializationContract.CommandPath));
        }

        await _fs.WriteFileAtomicAsync(
            ResourceMaterializationContract.StatePath,
            """{ "invalid": true }""");

        Assert.True(await _service.LoadGameAsync(savePath));
        Assert.Equal(definitions, await _fs.ReadFileAsync(
            ResourceMaterializationContract.DefinitionsPath));
        Assert.Equal(state, await _fs.ReadFileAsync(
            ResourceMaterializationContract.StatePath));
        Assert.Equal(history, await _fs.ReadFileAsync(
            ResourceMaterializationContract.HistoryPath));
        Assert.False(_fs.FileExists(ResourceMaterializationContract.CommandPath));
    }

    [Fact]
    public async Task SaveGameAsync_SelfConsistentUnknownResourceOwnerIsRejected()
    {
        var roots = CreateUnknownOwnerResourceRoots();
        await _fs.WriteFileAtomicAsync(
            ResourceMaterializationContract.DefinitionsPath,
            roots.Definitions);
        await _fs.WriteFileAtomicAsync(
            ResourceMaterializationContract.StatePath,
            roots.State);
        await _fs.WriteFileAtomicAsync(
            ResourceMaterializationContract.HistoryPath,
            roots.History);

        Assert.False(await _service.SaveGameAsync(
            "forged_resource_owner",
            "must not archive an unknown resource owner"));
        Assert.Empty(Directory.GetFiles(
            _fs.ResolvePath("saves/manual_saves"),
            "*.zip"));
    }

    [Fact]
    public async Task SaveGameAsync_InvalidUtf8CanonicalResourceInputFailsClosed()
    {
        await File.WriteAllBytesAsync(
            _fs.ResolvePath(InventoryEquipmentService.ItemsPath),
            Encoding.ASCII.GetBytes("{\"items\":[],\"note\":\"")
                .Concat(new byte[] { 0xC3, 0x28 })
                .Concat(Encoding.ASCII.GetBytes("\"}"))
                .ToArray());

        Assert.False(await _service.SaveGameAsync(
            "invalid_utf8_resource",
            "must reject replacement decoding"));
        Assert.Empty(Directory.GetFiles(
            _fs.ResolvePath("saves/manual_saves"),
            "*.zip"));
    }

    [Fact]
    public async Task LoadGameAsync_SelfConsistentUnknownResourceOwnerIsRejected()
    {
        var roots = CreateUnknownOwnerResourceRoots();
        var archivePath = Path.Combine(_rootPath, "forged-resource-owner.zip");
        using (var archive = ZipFile.Open(archivePath, ZipArchiveMode.Create))
        {
            await WriteArchiveEntryAsync(
                archive,
                "game_state/meta/soul_state.json",
                """{ "soulName": "Поддельный владелец", "currentRealm": "Mortal World" }""");
            await WriteArchiveEntryAsync(
                archive,
                ResourceMaterializationContract.DefinitionsPath,
                roots.Definitions);
            await WriteArchiveEntryAsync(
                archive,
                ResourceMaterializationContract.StatePath,
                roots.State);
            await WriteArchiveEntryAsync(
                archive,
                ResourceMaterializationContract.HistoryPath,
                roots.History);
        }
        var liveState = await _fs.ReadFileAsync(
            ResourceMaterializationContract.StatePath);

        Assert.False(await _service.LoadGameAsync(archivePath));
        Assert.Equal(liveState, await _fs.ReadFileAsync(
            ResourceMaterializationContract.StatePath));
    }

    [Fact]
    public async Task SaveAndLoad_TreatsLatestWorkerRepairTaskAsEphemeralControlFile()
    {
        const string path = "game_state/control/gm_worker_latest_validation_repair_task.json";
        await _fs.WriteFileAtomicAsync("game_state/meta/soul_state.json", "{\"currentRealm\":\"Chaos Sea\"}");
        await _fs.WriteFileAtomicAsync(path, "{\"taskId\":\"stale_worker_task\"}");

        Assert.True(await _service.SaveGameAsync("ephemeral_worker_task", "worker task save/load regression"));

        var savePath = Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip").Single();
        using (var archive = ZipFile.OpenRead(savePath))
            Assert.Null(archive.GetEntry(path));

        Assert.True(await _service.LoadGameAsync(savePath));
        Assert.False(_fs.FileExists(path));
    }

    [Fact]
    public async Task SaveAndLoad_TreatsLocalUiSessionLockAsEphemeralControlFile()
    {
        await _fs.WriteFileAtomicAsync(
            "game_state/meta/soul_state.json",
            "{\"currentRealm\":\"Chaos Sea\"}");
        await _fs.WriteFileAtomicAsync(
            LocalUiSessionLockService.LockPath,
            """
            {
              "schemaVersion": 1,
              "ownerId": "stale-browser-owner",
              "ownerKind": "browser",
              "ownerLabel": "Stale browser",
              "acquiredAtUtc": "2026-07-29T00:00:00.0000000Z",
              "heartbeatAtUtc": "2026-07-29T00:00:00.0000000Z",
              "leaseSeconds": 120,
              "lastOperation": "stale form"
            }
            """);

        Assert.True(await _service.SaveGameAsync(
            "ephemeral_local_ui_lock",
            "local UI lock save/load regression"));

        var savePath = Directory
            .GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip")
            .Single();
        using (var archive = ZipFile.OpenRead(savePath))
            Assert.Null(archive.GetEntry(LocalUiSessionLockService.LockPath));

        using (var archive = ZipFile.Open(savePath, ZipArchiveMode.Update))
        {
            var entry = archive.CreateEntry(LocalUiSessionLockService.LockPath);
            await using var stream = entry.Open();
            await stream.WriteAsync(
                System.Text.Encoding.UTF8.GetBytes(
                    """{ "ownerId": "crafted-restored-owner" }"""));
        }

        Assert.True(await _service.LoadGameAsync(savePath));
        Assert.False(_fs.FileExists(LocalUiSessionLockService.LockPath));
    }

    [Fact]
    public async Task SaveGameAsync_ExcludesLocalUiLockNamespaceDescendants()
    {
        const string craftedDescendant =
            "game_state/control/local_ui_session_lock.json/nested/lock.json";
        await _fs.WriteFileAtomicAsync(
            "game_state/meta/soul_state.json",
            "{\"currentRealm\":\"Chaos Sea\"}");
        Directory.CreateDirectory(
            Path.GetDirectoryName(_fs.ResolvePath(craftedDescendant))!);
        await File.WriteAllTextAsync(
            _fs.ResolvePath(craftedDescendant),
            "{\"crafted\":true}");

        Assert.True(await _service.SaveGameAsync(
            "ephemeral_local_ui_lock_descendant",
            "local UI lock namespace save regression"));

        var savePath = Directory
            .GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip")
            .Single();
        using var archive = ZipFile.OpenRead(savePath);
        Assert.Null(archive.GetEntry(craftedDescendant));
    }

    [Fact]
    public async Task LoadGameAsync_StripsCraftedLocalUiLockNamespaceDescendants()
    {
        await _fs.WriteFileAtomicAsync(
            "game_state/meta/soul_state.json",
            "{\"currentRealm\":\"Chaos Sea\"}");
        Assert.True(await _service.SaveGameAsync(
            "crafted_local_ui_lock_descendant",
            "local UI lock namespace load regression"));
        var savePath = Directory
            .GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip")
            .Single();
        const string craftedDescendant =
            "game_state/control/local_ui_session_lock.json/nested/lock.json";
        using (var archive = ZipFile.Open(savePath, ZipArchiveMode.Update))
        {
            var entry = archive.CreateEntry(craftedDescendant);
            await using var stream = entry.Open();
            await stream.WriteAsync(
                System.Text.Encoding.UTF8.GetBytes("{\"crafted\":true}"));
        }

        Assert.True(await _service.LoadGameAsync(savePath));

        var lockNode = _fs.ResolvePath(LocalUiSessionLockService.LockPath);
        Assert.False(File.Exists(lockNode));
        Assert.False(Directory.Exists(lockNode));
    }

    [Fact]
    public async Task SaveGameAsync_RetainedBrowserRollbackEvidenceBlocksOrdinaryAdmission()
    {
        var stalePath =
            $"{ExplorerLocalTurnRollbackArtifacts.Root}/browser_write/stale_evidence/marker.json";
        await _fs.WriteFileAtomicAsync("game_state/meta/soul_state.json", "{\"currentRealm\":\"Chaos Sea\"}");
        // Retained legacy evidence predates ordinary admission; seeding it is not a new legacy publication.
        var staleFullPath = _fs.ResolvePath(stalePath);
        Directory.CreateDirectory(Path.GetDirectoryName(staleFullPath)!);
        await File.WriteAllTextAsync(staleFullPath, "{\"stale\":true}", System.Text.Encoding.UTF8);

        var evidence = File.ReadAllBytes(_fs.ResolvePath(stalePath));
        var before = CaptureSessionSnapshot(_fs.GameSessionPath);
        var failure = await Assert.ThrowsAsync<CoordinatedStatePublicationUncertainException>(() => _service.SaveGameAsync(
            "ephemeral_browser_rollback",
            "browser rollback save regression"));
        var admissionFailure = Assert.IsType<InvalidDataException>(failure.GetBaseException());
        Assert.Equal("Unresolved legacy storage evidence requires its original supported recovery handler: " +
            _fs.ResolvePath(ExplorerLocalTurnRollbackArtifacts.Root), admissionFailure.Message);
        Assert.Equal(evidence, File.ReadAllBytes(_fs.ResolvePath(stalePath)));
        Assert.Equal(before, CaptureSessionSnapshot(_fs.GameSessionPath));
        Assert.Empty(Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip"));
    }

    [Fact]
    public async Task LoadGameAsync_StripsBrowserRollbackTransactionsFromLegacyArchive()
    {
        var stalePath =
            $"{ExplorerLocalTurnRollbackArtifacts.Root}/browser_write/legacy_evidence/marker.json";
        await _fs.WriteFileAtomicAsync("game_state/meta/soul_state.json", "{\"currentRealm\":\"Chaos Sea\"}");
        Assert.True(await _service.SaveGameAsync(
            "legacy_browser_rollback",
            "legacy browser rollback load regression"));

        var savePath = Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip").Single();
        using (var archive = ZipFile.Open(savePath, ZipArchiveMode.Update))
        {
            var entry = archive.CreateEntry(stalePath);
            await using var stream = entry.Open();
            await stream.WriteAsync(System.Text.Encoding.UTF8.GetBytes("{\"stale\":true}"));
        }

        Assert.True(await _service.LoadGameAsync(savePath));
        Assert.False(Directory.Exists(_fs.ResolvePath(ExplorerLocalTurnRollbackArtifacts.Root)));
    }

    [Fact]
    public async Task LoadGameAsync_StripsExactBrowserRollbackRootFileFromCraftedArchive()
    {
        await _fs.WriteFileAtomicAsync(
            "game_state/meta/soul_state.json",
            "{\"currentRealm\":\"Chaos Sea\"}");
        Assert.True(await _service.SaveGameAsync(
            "exact_browser_rollback_file",
            "exact browser rollback root load regression"));

        var savePath = Directory
            .GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip")
            .Single();
        using (var archive = ZipFile.Open(savePath, ZipArchiveMode.Update))
        {
            var entry = archive.CreateEntry(
                ExplorerLocalTurnRollbackArtifacts.Root);
            await using var stream = entry.Open();
            await stream.WriteAsync(
                System.Text.Encoding.UTF8.GetBytes("{\"stale\":true}"));
        }

        Assert.True(await _service.LoadGameAsync(savePath));
        var rollbackRoot = _fs.ResolvePath(
            ExplorerLocalTurnRollbackArtifacts.Root);
        Assert.False(File.Exists(rollbackRoot));
        Assert.False(Directory.Exists(rollbackRoot));
    }

    [Fact]
    public async Task GetAvailableSavesAsync_RetriesWhenSaveMetadataIsTemporarilyLocked()
    {
        await _fs.WriteFileAtomicAsync("game_state/meta/soul_state.json", """
        {
          "soulName": "Тестовая Душа",
          "currentRealm": "Mortal World",
          "currentIncarnation": 1
        }
        """);
        Assert.True(await _service.SaveGameAsync("temporarily_locked_metadata", "save list transient lock regression"));

        var savePath = Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip").Single();
        await using var lockStream = new FileStream(savePath, FileMode.Open, FileAccess.Read, FileShare.None);
        var readTask = _service.GetAvailableSavesAsync("saves/manual_saves");

        await Task.Delay(75);
        await lockStream.DisposeAsync();
        var saves = await readTask;

        var save = Assert.Single(saves);
        Assert.Equal(savePath, save.FileName);
        Assert.Equal("temporarily_locked_metadata", save.Metadata?.SaveName);
    }

    [Fact]
    public async Task GetAvailableSavesAsync_RejectsOversizedMetadataThroughTrustedBudget()
    {
        var savePath = Path.Combine(
            _fs.ResolvePath("saves/manual_saves"),
            "oversized-metadata.zip");
        using (var archive = ZipFile.Open(
                   savePath,
                   ZipArchiveMode.Create))
        {
            await WritePaddedSaveMetadataAsync(
                archive,
                SaveLoadService
                    .TrustedArchiveBudget
                    .MaxEntryExpandedBytes + 1);
        }

        Assert.Empty(
            await _service.GetAvailableSavesAsync(
                "saves/manual_saves"));
    }

    [Fact]
    public async Task SaveGameAsync_WaitsForCanonicalWriteLeaseBeforeReadingSessionSnapshot()
    {
        await _fs.WriteFileAtomicAsync("game_state/world/weather.json", "{\"state\":\"stable\"}");
        Task<bool> saveTask;

        var writeLease = await _fs.AcquireCanonicalWriteLeaseAsync();
        try
        {
            saveTask = _service.SaveGameAsync("leased_save", "canonical save snapshot regression");
            await Task.Delay(200);
            Assert.False(saveTask.IsCompleted);
        }
        finally
        {
            await writeLease.DisposeAsync();
        }

        Assert.True(await saveTask);
    }

    [Fact]
    public async Task SaveGameAsync_DoesNotArchiveDirectoryJunctionTarget()
    {
        if (!OperatingSystem.IsWindows())
            return;

        var outsideRoot = Path.Combine(
            Path.GetTempPath(),
            "boe-save-load-outside-" + Guid.NewGuid().ToString("N"));
        var outsideFile = Path.Combine(outsideRoot, "external-secret.txt");
        var junctionPath = _fs.ResolvePath("game_state/world/external-link");
        Directory.CreateDirectory(outsideRoot);
        await File.WriteAllTextAsync(outsideFile, "must-not-enter-save");
        try
        {
            CreateDirectoryJunction(junctionPath, outsideRoot);

            Assert.True(await _service.SaveGameAsync("no_reparse_traversal", "junction regression"));

            var savePath = Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip").Single();
            using var archive = ZipFile.OpenRead(savePath);
            Assert.DoesNotContain(
                archive.Entries,
                entry => entry.FullName.Contains("external-secret", StringComparison.OrdinalIgnoreCase));
        }
        finally
        {
            if (Directory.Exists(junctionPath))
                Directory.Delete(junctionPath, recursive: false);
            if (Directory.Exists(outsideRoot))
                Directory.Delete(outsideRoot, recursive: true);
        }
    }

    [Fact]
    public async Task SaveGameAsync_MissingMandatoryGameStateRootFailsClosed()
    {
        var gameStateRoot = Path.Combine(
            _rootPath,
            "game_session",
            "game_state");
        Directory.Delete(gameStateRoot, recursive: true);

        Assert.False(await _service.SaveGameAsync(
            "missing_game_state",
            "mandatory game-state root regression"));
        Assert.Empty(Directory.GetFiles(
            _fs.ResolvePath("saves/manual_saves"),
            "*.zip"));
    }

    [Fact]
    public async Task SaveGameAsync_EmptyMandatoryGameStateRootFailsClosed()
    {
        var gameStateRoot = Path.Combine(
            _rootPath,
            "game_session",
            "game_state");
        Directory.Delete(gameStateRoot, recursive: true);
        Directory.CreateDirectory(gameStateRoot);

        Assert.False(await _service.SaveGameAsync(
            "empty_game_state",
            "empty mandatory game-state root regression"));
        Assert.Empty(Directory.GetFiles(
            _fs.ResolvePath("saves/manual_saves"),
            "*.zip"));
    }

    [Fact]
    public async Task SaveGameAsync_RegularFileAtMandatoryGameStateRootFailsClosed()
    {
        var gameStateRoot = Path.Combine(
            _rootPath,
            "game_session",
            "game_state");
        Directory.Delete(gameStateRoot, recursive: true);
        await File.WriteAllTextAsync(gameStateRoot, "not-a-directory");

        await Assert.ThrowsAsync<CoordinatedStatePublicationUncertainException>(() => _service.SaveGameAsync(
            "file_game_state",
            "wrong-kind game-state root regression"));
        Assert.Equal("not-a-directory", await File.ReadAllTextAsync(gameStateRoot));
        Assert.Empty(Directory.GetFiles(
            _fs.ResolvePath("saves/manual_saves"),
            "*.zip"));
    }

    [Fact]
    public async Task SaveGameAsync_ReparsePointAtMandatoryGameStateRootFailsClosed()
    {
        if (!OperatingSystem.IsWindows())
            return;

        var gameStateRoot = Path.Combine(
            _rootPath,
            "game_session",
            "game_state");
        var outsideRoot = Path.Combine(
            Path.GetTempPath(),
            "boe-save-game-state-outside-" + Guid.NewGuid().ToString("N"));
        Directory.Delete(gameStateRoot, recursive: true);
        Directory.CreateDirectory(outsideRoot);
        await File.WriteAllTextAsync(
            Path.Combine(outsideRoot, "external-state.json"),
            """{ "mustNotArchive": true }""");

        try
        {
            CreateDirectoryJunction(gameStateRoot, outsideRoot);

            await Assert.ThrowsAsync<CoordinatedStatePublicationUncertainException>(() => _service.SaveGameAsync(
                "reparse_game_state",
                "reparse game-state root regression"));
            Assert.Equal("""{ "mustNotArchive": true }""", await File.ReadAllTextAsync(Path.Combine(outsideRoot, "external-state.json")));
            Assert.Empty(Directory.GetFiles(
                _fs.ResolvePath("saves/manual_saves"),
                "*.zip"));
        }
        finally
        {
            if (Directory.Exists(gameStateRoot) &&
                FileSystemManager.IsReparsePoint(gameStateRoot))
            {
                Directory.Delete(gameStateRoot, recursive: false);
            }
            if (Directory.Exists(outsideRoot))
                Directory.Delete(outsideRoot, recursive: true);
        }
    }

    [Fact]
    public async Task SaveGameAsync_ParentReplacedByJunctionBeforeReadFailsClosed()
    {
        if (!OperatingSystem.IsWindows())
            return;

        const string relativePath = "game_state/world/save-race/state.json";
        var parentPath = _fs.ResolvePath("game_state/world/save-race");
        var displacedParentPath = _fs.ResolvePath("game_state/world/save-race-original");
        var outsideRoot = Path.Combine(
            Path.GetTempPath(),
            "boe-save-load-race-outside-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(outsideRoot);
        await _fs.WriteFileAtomicAsync(relativePath, "{\"canonical\":true}");
        await File.WriteAllTextAsync(
            Path.Combine(outsideRoot, "state.json"),
            "{\"externalSecret\":true}");

        var swapped = false;
        var raceFs = new FileSystemManager(
            _rootPath,
            NullLogger<FileSystemManager>.Instance,
            PhysicalLoadTransactionOperations.Instance,
            new FileSystemManagerHooks
            {
                BeforeCanonicalReadOpenAsync = path =>
                {
                    if (swapped || !path.Equals(relativePath, StringComparison.OrdinalIgnoreCase))
                        return Task.CompletedTask;

                    swapped = true;
                    Directory.Move(parentPath, displacedParentPath);
                    CreateDirectoryJunction(parentPath, outsideRoot);
                    return Task.CompletedTask;
                }
            });
        var raceStateManager = new StateManager(
            raceFs,
            new GameSettings(),
            NullLogger<StateManager>.Instance);
        var raceService = new SaveLoadService(
            raceFs,
            raceStateManager,
            NullLogger<SaveLoadService>.Instance);

        try
        {
            Assert.False(await raceService.SaveGameAsync(
                "save_read_race",
                "canonical read race regression"));
            Assert.True(swapped);
            var saveDirectory = raceFs.ResolvePath("saves/manual_saves");
            Assert.True(
                !Directory.Exists(saveDirectory) ||
                Directory.GetFiles(saveDirectory, "*.zip").Length == 0);
        }
        finally
        {
            if (Directory.Exists(parentPath) && FileSystemManager.IsReparsePoint(parentPath))
                Directory.Delete(parentPath, recursive: false);
            if (Directory.Exists(displacedParentPath))
                Directory.Move(displacedParentPath, parentPath);
            if (Directory.Exists(outsideRoot))
                Directory.Delete(outsideRoot, recursive: true);
        }
    }

    [Fact]
    public async Task AutosaveAsync_CleanupWaitsForCanonicalWriteLeaseAfterSavePublication()
    {
        var cleanupReached = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var releaseCleanup = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var settings = new GameSettings { MaxAutosaves = 1 };
        var stateManager = new StateManager(_fs, settings, NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            _fs,
            stateManager,
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeAutosaveCleanupLeaseAcquisitionAsync = async () =>
                {
                    cleanupReached.TrySetResult();
                    await releaseCleanup.Task;
                }
            });

        var autosaveTask = service.AutosaveAsync(1);
        await cleanupReached.Task.WaitAsync(TimeSpan.FromSeconds(5));

        var writeLease = await _fs.AcquireCanonicalWriteLeaseAsync();
        try
        {
            releaseCleanup.TrySetResult();
            await Task.Delay(200);
            Assert.False(autosaveTask.IsCompleted);
        }
        finally
        {
            await writeLease.DisposeAsync();
        }

        Assert.True(await autosaveTask.WaitAsync(TimeSpan.FromSeconds(5)));
        Assert.Single(Directory.GetFiles(_fs.ResolvePath("saves/autosaves"), "*.zip"));
    }

    [Fact]
    public async Task LoadGameAsync_WaitsForCanonicalWriteLeaseBeforeReplacingLiveSession()
    {
        const string weatherPath = "game_state/world/weather.json";
        await _fs.WriteFileAtomicAsync(weatherPath, "{\"state\":\"saved\"}");
        Assert.True(await _service.SaveGameAsync("leased_load", "canonical load swap regression"));
        var savePath = Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip").Single();
        await _fs.WriteFileAtomicAsync(weatherPath, "{\"state\":\"live\"}");
        Task<bool> loadTask;

        var writeLease = await _fs.AcquireCanonicalWriteLeaseAsync();
        try
        {
            loadTask = _service.LoadGameAsync(savePath);
            await Task.Delay(250);
            Assert.False(loadTask.IsCompleted);
            Assert.Equal("{\"state\":\"live\"}", await _fs.ReadFileAsync(weatherPath));
        }
        finally
        {
            await writeLease.DisposeAsync();
        }

        Assert.True(await loadTask);
        Assert.Equal("{\"state\":\"saved\"}", await _fs.ReadFileAsync(weatherPath));
    }

    [Fact]
    public async Task LoadGameAsync_WaitsForSessionLifecycleLeaseBeforeReplacingLiveSession()
    {
        const string weatherPath = "game_state/world/weather.json";
        await _fs.WriteFileAtomicAsync(weatherPath, "{\"state\":\"saved\"}");
        Assert.True(await _service.SaveGameAsync("lifecycle_load", "session lifecycle regression"));
        var savePath = Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip").Single();
        await _fs.WriteFileAtomicAsync(weatherPath, "{\"state\":\"live\"}");

        var lifecycleContended = new TaskCompletionSource<bool>(
            TaskCreationOptions.RunContinuationsAsynchronously);
        var competingFs = new FileSystemManager(
            _rootPath,
            NullLogger<FileSystemManager>.Instance,
            PhysicalLoadTransactionOperations.Instance,
            new FileSystemManagerHooks
            {
                SessionLifecycleLockContendedAsync = () =>
                {
                    lifecycleContended.TrySetResult(true);
                    return Task.CompletedTask;
                }
            });
        competingFs.EnsureDirectoryStructure();
        var settings = new GameSettings();
        var stateManager = new StateManager(
            competingFs,
            settings,
            NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            competingFs,
            stateManager,
            NullLogger<SaveLoadService>.Instance);

        var lifecycleLease = await _fs.AcquireSessionLifecycleLeaseAsync();
        Task<bool> loadTask;
        try
        {
            loadTask = service.LoadGameAsync(savePath);
            await lifecycleContended.Task.WaitAsync(TimeSpan.FromSeconds(5));
            Assert.False(loadTask.IsCompleted);
            Assert.Equal("{\"state\":\"live\"}", await _fs.ReadFileAsync(weatherPath));
        }
        finally
        {
            await lifecycleLease.DisposeAsync();
        }

        Assert.True(await loadTask);
        Assert.Equal("{\"state\":\"saved\"}", await _fs.ReadFileAsync(weatherPath));
    }

    [Fact]
    public async Task SaveAndLoad_PreservesLivePendingContracts()
    {
        await _fs.WriteFileAtomicAsync("game_state/meta/soul_state.json", """
        {
          "soulName": "Тестовая Душа",
          "currentRealm": "Chaos Sea",
          "currentIncarnation": 3
        }
        """);
        await _fs.WriteFileAtomicAsync(GuardianAbodeResidentRequestState.PendingResidentsRequestPath, """
        {
          "requests": [
            {
              "requestId": "abode_roster_req_1",
              "guardianId": "guardian_test",
              "guardianName": "Тестовый Хранитель",
              "abodeId": "abode_test",
              "abodeName": "Тестовая Обитель",
              "currentReputation": 10,
              "requestMode": "standard_roster",
              "createdAtTurn": 3,
              "createdAtUtc": "2026-04-22T00:00:00Z"
            }
          ]
        }
        """);
        await _fs.WriteFileAtomicAsync(ActorSocialInteractionRequestState.PendingGuardianRequestPath, """
        {
          "requests": [
            {
              "requestId": "guardian_social_req_1",
              "guardianId": "guardian_test",
              "guardianName": "Тестовый Хранитель",
              "interactionType": "talk",
              "createdAtTurn": 3,
              "createdAtUtc": "2026-04-22T00:00:00Z"
            }
          ]
        }
        """);
        await _fs.WriteFileAtomicAsync(SystemGuardianLibraryService.AttractionRequestPath, """
        {
          "mode": "system_guardian_attraction",
          "targetPresetId": "preset_test",
          "targetPresetDisplayName": "Тестовый Хранитель",
          "targetPresetVersion": "1.0",
          "sourceLibrary": "built_in",
          "targetSummary": "summary",
          "renderedPromptPackage": "dossier",
          "lastUpdated": "2026-04-22T00:00:00Z"
        }
        """);
        await _fs.WriteFileAtomicAsync(ShiningTradeRequestState.PendingRequestsPath, """
        {
          "requests": [
            {
              "requestId": "shining_trade_req_1",
              "factionId": "faction_test",
              "factionName": "Хор Теста",
              "tradeCycleId": "shining_return_3",
              "derivedTradeTier": 2,
              "derivedTradeSlotCount": 6,
              "derivedRarityCeiling": "rare",
              "derivedServiceMultiplier": 1.25,
              "merchantProfile": "shining_faction",
              "createdAtTurn": 3,
              "createdAtUtc": "2026-04-22T00:00:00Z"
            }
          ]
        }
        """);
        await _fs.WriteFileAtomicAsync(AfterlifeArchiveActionState.ConsultationRequestPath, """
        {
          "requestId": "archive_consult_1",
          "archiveId": "archive_entry_1",
          "archiveTitle": "Запись Памяти",
          "requestedMode": "consultation",
          "createdAtTurn": 3,
          "createdAtUtc": "2026-04-22T00:00:00Z"
        }
        """);

        Assert.True(await _service.SaveGameAsync("ephemeral_chaos_pending", "save/load chaos pending regression"));

        var savePath = Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip").Single();
        using (var archive = ZipFile.OpenRead(savePath))
        {
            Assert.NotNull(archive.GetEntry(GuardianAbodeResidentRequestState.PendingResidentsRequestPath));
            Assert.NotNull(archive.GetEntry(ActorSocialInteractionRequestState.PendingGuardianRequestPath));
            Assert.NotNull(archive.GetEntry(SystemGuardianLibraryService.AttractionRequestPath));
            Assert.NotNull(archive.GetEntry(ShiningTradeRequestState.PendingRequestsPath));
            Assert.NotNull(archive.GetEntry(AfterlifeArchiveActionState.ConsultationRequestPath));
        }

        Assert.True(await _service.LoadGameAsync(savePath));
        Assert.True(_fs.FileExists(GuardianAbodeResidentRequestState.PendingResidentsRequestPath));
        Assert.True(_fs.FileExists(ActorSocialInteractionRequestState.PendingGuardianRequestPath));
        Assert.True(_fs.FileExists(SystemGuardianLibraryService.AttractionRequestPath));
        Assert.True(_fs.FileExists(ShiningTradeRequestState.PendingRequestsPath));
        Assert.True(_fs.FileExists(AfterlifeArchiveActionState.ConsultationRequestPath));
    }

    [Fact]
    public async Task LoadGameAsync_RejectsZipSlipEntriesAndPreservesLiveSession()
    {
        const string soulStatePath = "game_state/meta/soul_state.json";
        await _fs.WriteFileAtomicAsync(soulStatePath, """
        {
          "soulName": "Живая Душа",
          "currentRealm": "Chaos Sea",
          "currentIncarnation": 7
        }
        """);

        var outsidePath = Path.Combine(_rootPath, "outside.txt");
        var maliciousZip = Path.Combine(_rootPath, "zip_slip.zip");
        using (var archive = ZipFile.Open(maliciousZip, ZipArchiveMode.Create))
        {
            using var entryWriter = new StreamWriter(archive.CreateEntry("../../outside.txt").Open());
            await entryWriter.WriteAsync("owned");
        }

        Assert.False(await _service.LoadGameAsync(maliciousZip));
        Assert.False(File.Exists(outsidePath));

        var soulState = await _fs.ReadFileAsync(soulStatePath);
        Assert.NotNull(soulState);
        Assert.Contains("Живая Душа", soulState);
    }

    [Fact]
    public async Task LoadGameAsync_CorruptArchiveDoesNotDestroyLiveSession()
    {
        const string soulStatePath = "game_state/meta/soul_state.json";
        await _fs.WriteFileAtomicAsync(soulStatePath, """
        {
          "soulName": "Неприкосновенная Душа",
          "currentRealm": "Shining Abode",
          "currentIncarnation": 2
        }
        """);
        await _fs.WriteFileAtomicAsync("mods/custom_rule.json", """
        { "enabled": true }
        """);

        var corruptZip = Path.Combine(_rootPath, "corrupt.zip");
        await File.WriteAllTextAsync(corruptZip, "this is not a zip archive");

        Assert.False(await _service.LoadGameAsync(corruptZip));
        Assert.True(_fs.FileExists(soulStatePath));
        Assert.True(_fs.FileExists("mods/custom_rule.json"));

        var soulState = await _fs.ReadFileAsync(soulStatePath);
        Assert.NotNull(soulState);
        Assert.Contains("Неприкосновенная Душа", soulState);
    }

    [Fact]
    public void TrustedArchiveBudgets_AcceptExactLimitsAndRejectOverByOne()
    {
        var budget = SaveLoadService.TrustedArchiveBudget;

        SaveLoadService.ValidateTrustedArchiveBudget(
            Enumerable
                .Range(0, budget.MaxEntryCount)
                .Select(index =>
                    new SaveLoadService.SaveArchiveEntryDescriptor(
                        $"e/{index:D4}",
                        IsDirectory: true,
                        Length: 0,
                        CompressedLength: 0))
                .ToArray());
        Assert.Throws<InvalidDataException>(() =>
            SaveLoadService.ValidateTrustedArchiveBudget(
                Enumerable
                    .Range(0, budget.MaxEntryCount + 1)
                    .Select(index =>
                        new SaveLoadService.SaveArchiveEntryDescriptor(
                            $"e/{index:D4}",
                            IsDirectory: true,
                            Length: 0,
                            CompressedLength: 0))
                    .ToArray()));

        SaveLoadService.ValidateTrustedArchiveBudget(
            [
                    new SaveLoadService.SaveArchiveEntryDescriptor(
                    new string(
                        'n',
                        checked((int)budget.MaxTotalEntryNameUtf8Bytes)),
                    IsDirectory: true,
                    Length: 0,
                    CompressedLength: 0)
            ]);
        Assert.Throws<InvalidDataException>(() =>
            SaveLoadService.ValidateTrustedArchiveBudget(
                [
                    new SaveLoadService.SaveArchiveEntryDescriptor(
                        new string(
                            'n',
                            checked((int)
                                budget.MaxTotalEntryNameUtf8Bytes + 1)),
                        IsDirectory: true,
                        Length: 0,
                        CompressedLength: 0)
                ]));
        Assert.Throws<InvalidDataException>(() =>
            SaveLoadService.ValidateTrustedArchiveBudget(
                [
                    new SaveLoadService.SaveArchiveEntryDescriptor(
                        "game_state/world/state.json:foreign",
                        IsDirectory: false,
                        Length: 1,
                        CompressedLength: 1)
                ]));

        AssertEntryLimitBoundary(
            "save_manifest.json",
            budget.MaxManifestExpandedBytes);
        AssertEntryLimitBoundary(
            "game_state/meta/soul_state.json",
            budget.MaxSoulStateExpandedBytes);
        AssertEntryLimitBoundary(
            "game_state/world/payload.bin",
            budget.MaxEntryExpandedBytes);

        var aggregateExact = Enumerable
            .Range(
                0,
                checked((int)(
                    budget.MaxTotalExpandedBytes /
                    budget.MaxEntryExpandedBytes)))
            .Select(index =>
                new SaveLoadService.SaveArchiveEntryDescriptor(
                    $"game_state/world/exact-{index:D2}.bin",
                    IsDirectory: false,
                    Length: budget.MaxEntryExpandedBytes,
                    CompressedLength: 1024 * 1024))
            .ToList();
        SaveLoadService.ValidateTrustedArchiveBudget(aggregateExact);
        aggregateExact.Add(
            new SaveLoadService.SaveArchiveEntryDescriptor(
                "game_state/world/over-by-one.bin",
                IsDirectory: false,
                Length: 1,
                CompressedLength: 1));
        Assert.Throws<InvalidDataException>(() =>
            SaveLoadService.ValidateTrustedArchiveBudget(aggregateExact));

        SaveLoadService.ValidateTrustedArchiveBudget(
            [
                new SaveLoadService.SaveArchiveEntryDescriptor(
                    "game_state/world/ratio-exact.bin",
                    IsDirectory: false,
                    Length: 2_000_000,
                    CompressedLength: 10_000)
            ]);
        Assert.Throws<InvalidDataException>(() =>
            SaveLoadService.ValidateTrustedArchiveBudget(
                [
                    new SaveLoadService.SaveArchiveEntryDescriptor(
                        "game_state/world/ratio-over.bin",
                        IsDirectory: false,
                        Length: 2_000_001,
                        CompressedLength: 10_000)
                ]));
        SaveLoadService.ValidateTrustedArchiveBudget(
            [
                new SaveLoadService.SaveArchiveEntryDescriptor(
                    "game_state/world/ratio-grace.bin",
                    IsDirectory: false,
                    Length: budget.CompressionRatioGraceExpandedBytes,
                    CompressedLength: 1)
            ]);
        Assert.Throws<InvalidDataException>(() =>
            SaveLoadService.ValidateTrustedArchiveBudget(
                [
                    new SaveLoadService.SaveArchiveEntryDescriptor(
                        "game_state/world/ratio-after-grace.bin",
                        IsDirectory: false,
                        Length:
                            budget.CompressionRatioGraceExpandedBytes + 1,
                        CompressedLength: 1)
                ]));
    }

    [Theory]
    [InlineData("entry-count")]
    [InlineData("entry-name-metadata")]
    public async Task TrustedArchivePreflight_RejectsCentralDirectoryMetadataBeforeZipArchiveMaterialization(
        string attack)
    {
        var archivePath = Path.Combine(
            _rootPath,
            $"raw-preflight-{attack}.zip");
        await CreateBudgetAttackArchiveAsync(
            archivePath,
            attack);
        await using var stream = new FileStream(
            archivePath,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read);
        stream.Position = 1;

        Assert.Throws<InvalidDataException>(() =>
            SaveLoadService
                .ValidateTrustedArchiveBeforeMaterialization(
                    stream));

        Assert.Equal(1, stream.Position);
    }

    [Fact]
    public async Task TrustedArchivePreflight_AcceptsBoundedArchiveAndRestoresStreamPosition()
    {
        var archivePath = Path.Combine(
            _rootPath,
            "raw-preflight-valid.zip");
        using (var archive = ZipFile.Open(
                   archivePath,
                   ZipArchiveMode.Create))
        {
            await WriteArchiveEntryAsync(
                archive,
                "game_state/world/state.json",
                """{"state":"valid"}""");
        }

        await using var stream = new FileStream(
            archivePath,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read);
        stream.Position = 1;

        SaveLoadService
            .ValidateTrustedArchiveBeforeMaterialization(
                stream);

        Assert.Equal(1, stream.Position);
    }

    [Theory]
    [InlineData("mortal_world_command_display_fixture.zip")]
    [InlineData("chaos_sea_command_display_fixture.zip")]
    [InlineData("shining_abode_command_display_fixture.zip")]
    public async Task LoadGameAsync_ReusableRealmFixturesPreserveExactCanonicalOwnerAuthority(
        string fixtureName)
    {
        var fixturePath = Path.Combine(
            TestRepoPaths.BaseSessionRoot,
            "saves",
            "manual_saves",
            fixtureName);

        string expectedAuthority;
        using (var archive = ZipFile.OpenRead(fixturePath))
        {
            var entry = Assert.Single(
                archive.Entries,
                candidate => candidate.FullName ==
                             CanonicalResourceOwnerAuthorityComposer.AuthorityPath);
            using var reader = new StreamReader(entry.Open(), Encoding.UTF8);
            expectedAuthority = await reader.ReadToEndAsync();
        }

        Assert.True(await _service.LoadGameAsync(fixturePath));
        Assert.Equal(
            expectedAuthority,
            await _fs.ReadFileAsync(
                CanonicalResourceOwnerAuthorityComposer.AuthorityPath));
    }

    [Theory]
    [InlineData("entry-count")]
    [InlineData("entry-name-metadata")]
    [InlineData("manifest-expanded")]
    [InlineData("soul-state-expanded")]
    [InlineData("single-entry-expanded")]
    [InlineData("aggregate-expanded")]
    [InlineData("compression-ratio")]
    [InlineData("alternate-data-stream")]
    public async Task LoadGameAsync_ArchiveBudgetRejectionPrecedesLifecycleAndPreservesSession(
        string attack)
    {
        var archivePath = Path.Combine(
            _rootPath,
            $"budget-{attack}.zip");
        await CreateBudgetAttackArchiveAsync(archivePath, attack);
        var before = CaptureSessionSnapshot(_fs.GameSessionPath);
        var lifecycleReached = false;
        var stateManager = new StateManager(
            _fs,
            new GameSettings(),
            NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            _fs,
            stateManager,
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeLoadLeaseAcquisitionAsync = () =>
                {
                    lifecycleReached = true;
                    return Task.CompletedTask;
                }
            });

        Assert.False(await service.LoadGameAsync(archivePath));
        Assert.False(lifecycleReached);
        Assert.Equal(before, CaptureSessionSnapshot(_fs.GameSessionPath));
        Assert.False(File.Exists(_fs.ActiveLoadTransactionJournalPath));
    }






    [Fact]
    public async Task LoadGameAsync_MetadataOnlyArchiveIsRejectedBeforeLifecycleLease()
    {
        const string liveStatePath = "game_state/world/live_state.json";
        const string liveState = """{ "state": "live" }""";
        await _fs.WriteFileAtomicAsync(liveStatePath, liveState);
        var archivePath = Path.Combine(_rootPath, "metadata-only.zip");
        using (var archive = ZipFile.Open(archivePath, ZipArchiveMode.Create))
        {
            await WriteArchiveEntryAsync(
                archive,
                "save_metadata.json",
                """
                {
                  "saveName": "metadata only",
                  "description": "must not replace a live session",
                  "timestamp": "2026-07-30T00:00:00Z",
                  "turnNumber": 7
                }
                """);
        }

        var lifecycleBoundaryReached = false;
        var stateManager = new StateManager(
            _fs,
            new GameSettings(),
            NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            _fs,
            stateManager,
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeLoadLeaseAcquisitionAsync = () =>
                {
                    lifecycleBoundaryReached = true;
                    return Task.CompletedTask;
                }
            });

        Assert.False(await service.LoadGameAsync(archivePath));
        Assert.False(lifecycleBoundaryReached);
        Assert.Equal(liveState, await _fs.ReadFileAsync(liveStatePath));
    }

    [Fact]
    public async Task LoadGameAsync_ArchiveWithOnlyOptionalContentIsRejectedBeforeLifecycleLease()
    {
        const string liveStatePath = "game_state/world/live_state.json";
        const string liveState = """{ "state": "live" }""";
        await _fs.WriteFileAtomicAsync(liveStatePath, liveState);
        var archivePath = Path.Combine(_rootPath, "optional-content-only.zip");
        using (var archive = ZipFile.Open(archivePath, ZipArchiveMode.Create))
        {
            await WriteArchiveEntryAsync(
                archive,
                "save_metadata.json",
                """{ "saveName": "crafted optional-only archive" }""");
            await WriteArchiveEntryAsync(
                archive,
                "lore/current_world/setting.json",
                """{ "setting": "crafted" }""");
        }

        var lifecycleBoundaryReached = false;
        var stateManager = new StateManager(
            _fs,
            new GameSettings(),
            NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            _fs,
            stateManager,
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeLoadLeaseAcquisitionAsync = () =>
                {
                    lifecycleBoundaryReached = true;
                    return Task.CompletedTask;
                }
            });

        Assert.False(await service.LoadGameAsync(archivePath));
        Assert.False(lifecycleBoundaryReached);
        Assert.Equal(liveState, await _fs.ReadFileAsync(liveStatePath));
    }

    [Fact]
    public async Task SaveGameAsync_WritesIntegrityManifestCoveringEveryPayloadEntry()
    {
        Assert.True(await _service.SaveGameAsync(
            "manifested-save",
            "integrity manifest regression"));

        var savePath = Directory
            .GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip")
            .Single();
        using var archive = ZipFile.OpenRead(savePath);
        var manifestEntry = archive.GetEntry("save_manifest.json");
        Assert.NotNull(manifestEntry);

        using var manifestDocument = await JsonDocument.ParseAsync(
            manifestEntry.Open());
        var root = manifestDocument.RootElement;
        Assert.Equal(1, root.GetProperty("schemaVersion").GetInt32());
        Assert.Equal("SHA-256", root.GetProperty("algorithm").GetString());
        var manifested = root
            .GetProperty("entries")
            .EnumerateArray()
            .ToDictionary(
                item => item.GetProperty("path").GetString()!,
                item => (
                    Length: item.GetProperty("length").GetInt64(),
                    Sha256: item.GetProperty("sha256").GetString()!),
                StringComparer.OrdinalIgnoreCase);

        var payloadEntries = archive.Entries
            .Where(entry =>
                !string.IsNullOrEmpty(entry.Name) &&
                !entry.FullName.Equals(
                    "save_manifest.json",
                    StringComparison.OrdinalIgnoreCase))
            .ToArray();
        Assert.Equal(payloadEntries.Length, manifested.Count);
        Assert.Contains(
            "game_state/meta/soul_state.json",
            manifested.Keys,
            StringComparer.OrdinalIgnoreCase);

        foreach (var entry in payloadEntries)
        {
            await using var stream = entry.Open();
            var digest = Convert.ToHexString(
                await SHA256.HashDataAsync(stream));
            var expected = manifested[entry.FullName];
            Assert.Equal(entry.Length, expected.Length);
            Assert.Equal(expected.Sha256, digest, ignoreCase: true);
        }
    }

    [Fact]
    public async Task LoadGameAsync_UsesIntegrityManifestWithoutAddingItToCanonicalSession()
    {
        Assert.True(await _service.SaveGameAsync(
            "manifest-is-archive-metadata",
            "manifest extraction regression"));
        var savePath = Directory
            .GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip")
            .Single();

        Assert.True(await _service.LoadGameAsync(savePath));
        Assert.False(_fs.FileExists("save_manifest.json"));
    }

    [Fact]
    public async Task SaveGameAsync_InvalidSoulStateRootDoesNotPublishArchive()
    {
        await _fs.WriteFileAtomicAsync(
            "game_state/meta/soul_state.json",
            """[{"not":"a canonical soul object"}]""");

        Assert.False(await _service.SaveGameAsync(
            "invalid-soul-state",
            "must not publish an invalid canonical save"));
        Assert.Empty(
            Directory.GetFiles(
                _fs.ResolvePath("saves/manual_saves"),
                "*.zip"));
    }

    [Fact]
    public async Task LoadGameAsync_LegacySoulStateWithoutRealmIsRejectedBeforeLifecycleLease()
    {
        const string liveStatePath = "game_state/world/live_state.json";
        const string liveState = """{ "state": "live" }""";
        await _fs.WriteFileAtomicAsync(liveStatePath, liveState);
        var archivePath = Path.Combine(
            _rootPath,
            "legacy-soul-without-realm.zip");
        using (var archive = ZipFile.Open(
                   archivePath,
                   ZipArchiveMode.Create))
        {
            await WriteArchiveEntryAsync(
                archive,
                "game_state/meta/soul_state.json",
                """{ "soulName": "Неполная Душа" }""");
        }

        var lifecycleBoundaryReached = false;
        var stateManager = new StateManager(
            _fs,
            new GameSettings(),
            NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            _fs,
            stateManager,
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeLoadLeaseAcquisitionAsync = () =>
                {
                    lifecycleBoundaryReached = true;
                    return Task.CompletedTask;
                }
            });

        Assert.False(await service.LoadGameAsync(archivePath));
        Assert.False(lifecycleBoundaryReached);
        Assert.Equal(liveState, await _fs.ReadFileAsync(liveStatePath));
    }

    [Fact]
    public async Task LoadGameAsync_LegacyArchiveWithoutUnifiedResourceRootsIsRejected()
    {
        const string legacyStatePath = "game_state/meta/soul_state.json";
        const string legacyState =
            """
            {
              "soulName": "Наследуемая Душа",
              "currentRealm": "Chaos Sea",
              "currentIncarnation": 3
            }
            """;
        var archivePath = Path.Combine(
            _rootPath,
            "legacy-with-soul-state.zip");
        using (var archive = ZipFile.Open(archivePath, ZipArchiveMode.Create))
        {
            await WriteArchiveEntryAsync(
                archive,
                legacyStatePath,
                legacyState);
        }

        var liveState = await _fs.ReadFileAsync(legacyStatePath);

        Assert.False(await _service.LoadGameAsync(archivePath));
        Assert.Equal(liveState, await _fs.ReadFileAsync(legacyStatePath));
    }

    [Fact]
    public async Task LoadGameAsync_LegacyArchiveWithArbitraryGameStateIsRejectedBeforeLifecycleLease()
    {
        const string liveStatePath = "game_state/world/live_state.json";
        const string liveState = """{ "state": "live" }""";
        await _fs.WriteFileAtomicAsync(liveStatePath, liveState);
        var archivePath = Path.Combine(
            _rootPath,
            "legacy-with-arbitrary-state.zip");
        using (var archive = ZipFile.Open(archivePath, ZipArchiveMode.Create))
        {
            await WriteArchiveEntryAsync(
                archive,
                "game_state/world/fabricated.json",
                """{ "state": "not-a-session" }""");
        }

        var lifecycleBoundaryReached = false;
        var stateManager = new StateManager(
            _fs,
            new GameSettings(),
            NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            _fs,
            stateManager,
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeLoadLeaseAcquisitionAsync = () =>
                {
                    lifecycleBoundaryReached = true;
                    return Task.CompletedTask;
                }
            });

        Assert.False(await service.LoadGameAsync(archivePath));
        Assert.False(lifecycleBoundaryReached);
        Assert.Equal(liveState, await _fs.ReadFileAsync(liveStatePath));
    }

    [Fact]
    public async Task LoadGameAsync_ManifestedArchiveWithTamperedPayloadIsRejectedBeforeLifecycleLease()
    {
        const string liveStatePath = "game_state/world/live_state.json";
        const string liveState = """{ "state": "live" }""";
        await _fs.WriteFileAtomicAsync(liveStatePath, liveState);
        var archivePath = Path.Combine(_rootPath, "tampered-manifested-save.zip");
        await WriteManifestedArchiveAsync(
            archivePath,
            new Dictionary<string, string>
            {
                ["game_state/meta/soul_state.json"] =
                    """
                    {
                      "soulName": "Архивная Душа",
                      "currentRealm": "Chaos Sea",
                      "currentIncarnation": 2
                    }
                    """,
                ["game_state/world/marker.json"] = """{ "state": "expected" }"""
            });
        using (var archive = ZipFile.Open(archivePath, ZipArchiveMode.Update))
        {
            archive.GetEntry("game_state/world/marker.json")!.Delete();
            await WriteArchiveEntryAsync(
                archive,
                "game_state/world/marker.json",
                """{ "state": "tampered" }""");
        }

        var lifecycleBoundaryReached = false;
        var stateManager = new StateManager(
            _fs,
            new GameSettings(),
            NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            _fs,
            stateManager,
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeLoadLeaseAcquisitionAsync = () =>
                {
                    lifecycleBoundaryReached = true;
                    return Task.CompletedTask;
                }
            });

        Assert.False(await service.LoadGameAsync(archivePath));
        Assert.False(lifecycleBoundaryReached);
        Assert.Equal(liveState, await _fs.ReadFileAsync(liveStatePath));
    }

    [Fact]
    public async Task LoadGameAsync_ManifestedArchiveWithTruncatedPayloadIsRejectedBeforeLifecycleLease()
    {
        const string liveStatePath = "game_state/world/live_state.json";
        const string liveState = """{ "state": "live" }""";
        await _fs.WriteFileAtomicAsync(liveStatePath, liveState);
        var archivePath = Path.Combine(
            _rootPath,
            "truncated-manifested-save.zip");
        await WriteManifestedArchiveAsync(
            archivePath,
            new Dictionary<string, string>
            {
                ["game_state/meta/soul_state.json"] =
                    """
                    {
                      "soulName": "Архивная Душа",
                      "currentRealm": "Chaos Sea",
                      "currentIncarnation": 2
                    }
                    """,
                ["game_state/world/marker.json"] =
                    """{ "state": "complete-payload" }"""
            });
        using (var archive = ZipFile.Open(archivePath, ZipArchiveMode.Update))
        {
            archive.GetEntry("game_state/world/marker.json")!.Delete();
            await WriteArchiveEntryAsync(
                archive,
                "game_state/world/marker.json",
                "{}");
        }

        var lifecycleBoundaryReached = false;
        var stateManager = new StateManager(
            _fs,
            new GameSettings(),
            NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            _fs,
            stateManager,
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeLoadLeaseAcquisitionAsync = () =>
                {
                    lifecycleBoundaryReached = true;
                    return Task.CompletedTask;
                }
            });

        Assert.False(await service.LoadGameAsync(archivePath));
        Assert.False(lifecycleBoundaryReached);
        Assert.Equal(liveState, await _fs.ReadFileAsync(liveStatePath));
    }

    [Fact]
    public async Task LoadGameAsync_ManifestedArchiveWithCaseCollidingPayloadIsRejectedBeforeLifecycleLease()
    {
        const string liveStatePath = "game_state/world/live_state.json";
        const string liveState = """{ "state": "live" }""";
        await _fs.WriteFileAtomicAsync(liveStatePath, liveState);
        var archivePath = Path.Combine(
            _rootPath,
            "case-colliding-manifested-save.zip");
        await WriteManifestedArchiveAsync(
            archivePath,
            new Dictionary<string, string>
            {
                ["game_state/meta/soul_state.json"] =
                    """
                    {
                      "soulName": "Архивная Душа",
                      "currentRealm": "Chaos Sea",
                      "currentIncarnation": 2
                    }
                    """
            });
        using (var archive = ZipFile.Open(archivePath, ZipArchiveMode.Update))
        {
            await WriteArchiveEntryAsync(
                archive,
                "GAME_STATE/META/SOUL_STATE.JSON",
                """{ "soulName": "Другая Душа" }""");
        }

        var lifecycleBoundaryReached = false;
        var stateManager = new StateManager(
            _fs,
            new GameSettings(),
            NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            _fs,
            stateManager,
            NullLogger<SaveLoadService>.Instance,
            new SaveLoadServiceHooks
            {
                BeforeLoadLeaseAcquisitionAsync = () =>
                {
                    lifecycleBoundaryReached = true;
                    return Task.CompletedTask;
                }
            });

        Assert.False(await service.LoadGameAsync(archivePath));
        Assert.False(lifecycleBoundaryReached);
        Assert.Equal(liveState, await _fs.ReadFileAsync(liveStatePath));
    }


    /// <summary>
    /// Preserves ordinary by-name read semantics when a hard-link alias is added during metadata consumption.
    /// </summary>
    /// <returns>
    /// Completion after the original archive metadata and both exact file images remain unchanged.
    /// </returns>
    [Fact]
    public async Task GetAvailableSavesAsync_OrdinaryMetadataAcceptsHardLinkWithoutRetry()
    {
        if (!OperatingSystem.IsWindows())
            return;

        var saveDirectory = _fs.ResolvePath("saves/manual_saves");
        var archivePath = Path.Combine(
            saveDirectory,
            "metadata-completion-race.zip");
        using (var archive = ZipFile.Open(archivePath, ZipArchiveMode.Create))
        {
            await WriteArchiveEntryAsync(
                archive,
                "save_metadata.json",
                """
                {
                  "saveName": "metadata completion race",
                  "description": "ordinary hard-link input remains readable",
                  "timestamp": "2026-07-29T00:00:00Z",
                  "turnNumber": 12
                }
                """);
        }

        var aliasPath = Path.Combine(
            _rootPath,
            "metadata-completion-race-alias.zip");
        var openCount = 0;
        var before = File.ReadAllBytes(archivePath);
        var hooks = FileSystemManagerHookTestHelper.WithPathHook(
            "AfterCanonicalReadInitialValidationAsync",
            path =>
            {
                if (path.Replace('\\', '/').Equals("saves/manual_saves/metadata-completion-race.zip", StringComparison.OrdinalIgnoreCase))
                {
                    openCount++;
                    if (openCount == 1)
                    {
                        WindowsHardLinkTestHelper.Create(aliasPath, archivePath);
                    }
                }

                return Task.CompletedTask;
            });
        var raceFs = new FileSystemManager(
            _rootPath,
            NullLogger<FileSystemManager>.Instance,
            PhysicalLoadTransactionOperations.Instance,
            hooks);
        var stateManager = new StateManager(
            raceFs,
            new GameSettings(),
            NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var service = new SaveLoadService(
            raceFs,
            stateManager,
            NullLogger<SaveLoadService>.Instance);

        var save = Assert.Single(await service.GetAvailableSavesAsync());
        Assert.Equal("metadata completion race", save.Metadata!.SaveName);
        Assert.Equal(before.LongLength, save.FileSize);
        Assert.Equal(before, File.ReadAllBytes(archivePath));
        Assert.Equal(before, File.ReadAllBytes(aliasPath));
        Assert.Equal(1, openCount);
    }

    /// <summary>
    /// Verifies that detached load preparation repairs the client-owned player profile before publication.
    /// </summary>
    /// <returns>
    /// A task completing after the load decision, repaired profile and bounded completion time are verified.
    /// </returns>
    [Fact]
    public async Task LoadGameAsync_RepairsClientOwnedProfileMirrorWithoutReacquiringCanonicalLease()
    {
        var archivePath = Path.Combine(_rootPath, "stale_player_soul_mirror.zip");
        using (var archive = ZipFile.Open(archivePath, ZipArchiveMode.Create))
            await WriteStalePlayerSoulProfileArchiveAsync(archive);

        var stopwatch = Stopwatch.StartNew();
        var loaded = await _service.LoadGameAsync(archivePath);
        stopwatch.Stop();
        Assert.True(loaded,
            $"LoadGameAsync returned {loaded} after {stopwatch.Elapsed}." + Environment.NewLine +
            string.Join(Environment.NewLine, _serviceLogger.Errors.Select(error => error.ToString())));

        Assert.True(stopwatch.Elapsed < TimeSpan.FromSeconds(5), $"Load took {stopwatch.Elapsed}.");
        using var doc = JsonDocument.Parse(
            await _fs.ReadFileAsync("game_state/meta/afterlife_entity_profiles.json") ?? "{}");
        var player = doc.RootElement.GetProperty("profiles").EnumerateArray().Single();
        Assert.Equal(0, player.GetProperty("currencies").GetProperty("inkFeathers").GetInt32());
        Assert.Equal(0, player.GetProperty("standardArts").GetProperty("guard").GetInt32());
        Assert.False(player.GetProperty("progressionStrategy").TryGetProperty("lastAutoProgressionCycleKey", out _));
        Assert.Empty(
            Directory.EnumerateFiles(
                _rootPath,
                ".boe-prior-*.quarantine",
                SearchOption.AllDirectories));
    }

    [Fact]
    public async Task LoadGameWithOutcomeAsync_ProfilePreparationRefusesChangedLiveBytesBeforePublication()
    {
        var archivePath = Path.Combine(_rootPath, "stale-player-soul-mirror-conflict.zip");
        using (var archive = ZipFile.Open(archivePath, ZipArchiveMode.Create))
            await WriteStalePlayerSoulProfileArchiveAsync(archive);
        var generation = File.ReadAllBytes(_fs.SessionGenerationPath);
        var before = CaptureSessionSnapshot(_fs.GameSessionPath);
        const string foreignProfile = """{"schemaVersion":1,"profiles":[],"marker":"foreign-live"}""";
        var changed = 0;
        var publications = 0;
        var raceFs = new FileSystemManager(_rootPath, NullLogger<FileSystemManager>.Instance,
            PhysicalLoadTransactionOperations.Instance, new FileSystemManagerHooks
            {
                BeforeCanonicalMutationBoundaryAsync = relativePath =>
                {
                    if (changed == 0 && relativePath == AfterlifeEntityProfileState.StatePath)
                    {
                        File.WriteAllText(_fs.ResolvePath(relativePath), foreignProfile);
                        changed++;
                    }
                    return Task.CompletedTask;
                },
                LocalPublicationObserver = (_, _) => publications++
            });
        var stateManager = new StateManager(raceFs, new GameSettings(), NullLogger<StateManager>.Instance);
        await stateManager.RefreshGameStateAsync();
        var oldSoul = stateManager.CurrentState.SoulName;
        var service = new SaveLoadService(raceFs, stateManager, NullLogger<SaveLoadService>.Instance);

        var result = await service.LoadGameWithOutcomeAsync(archivePath);

        Assert.Equal(LoadReplacementDisposition.NotLoaded, result.Disposition);
        Assert.Equal(1, changed);
        Assert.Equal(0, publications);
        Assert.Null(result.EstablishedGeneration);
        Assert.NotNull(result.Failure);
        Assert.Equal(generation, File.ReadAllBytes(_fs.SessionGenerationPath));
        Assert.Equal(oldSoul, stateManager.CurrentState.SoulName);
        Assert.Equal(foreignProfile, File.ReadAllText(_fs.ResolvePath(AfterlifeEntityProfileState.StatePath)));
        var profilePrefix = AfterlifeEntityProfileState.StatePath + ":";
        Assert.Equal(before.Where(line => !line.StartsWith(profilePrefix, StringComparison.Ordinal)),
            CaptureSessionSnapshot(_fs.GameSessionPath).Where(line => !line.StartsWith(profilePrefix, StringComparison.Ordinal)));
        Assert.False(File.Exists(Path.Combine(raceFs.RuntimeRootPath, "trusted-local-publication-v1", "active.json")));
    }




    [Fact]
    public async Task SaveGameAsync_ExcludesLifecycleTriggers_AndLoadRemovesLegacyTriggerFiles()
    {
        await _fs.WriteFileAtomicAsync("game_state/meta/soul_state.json", """
        {
          "soulName": "Тестовая Душа",
          "currentRealm": "Chaos Sea",
          "currentIncarnation": 5
        }
        """);
        await _fs.WriteFileAtomicAsync("game_state/control/life_transitions.json", """
        { "transitions": [{ "transitionId": "life_transition_1" }] }
        """);
        await _fs.WriteFileAtomicAsync("game_state/control/incarnation_trigger.json", """
        { "triggeredAtTurn": 10 }
        """);
        await _fs.WriteFileAtomicAsync("game_state/control/ascension.json", """
        { "triggeredAtTurn": 11 }
        """);

        Assert.True(await _service.SaveGameAsync("no_lifecycle_triggers", "save/load lifecycle regression"));

        var savePath = Directory.GetFiles(_fs.ResolvePath("saves/manual_saves"), "*.zip").Single();
        using (var archive = ZipFile.OpenRead(savePath))
        {
            Assert.Null(archive.GetEntry("game_state/control/life_transitions.json"));
            Assert.Null(archive.GetEntry("game_state/control/incarnation_trigger.json"));
            Assert.Null(archive.GetEntry("game_state/control/ascension.json"));
        }

        var legacyZip = Path.Combine(_rootPath, "legacy_with_triggers.zip");
        using (var archive = ZipFile.Open(legacyZip, ZipArchiveMode.Create))
        {
            var soulEntry = archive.CreateEntry("game_state/meta/soul_state.json");
            await using (var soulStream = soulEntry.Open())
            await using (var writer = new StreamWriter(soulStream))
            {
                await writer.WriteAsync("""
                {
                  "soulName": "Загруженная Душа",
                  "currentRealm": "Chaos Sea",
                  "currentIncarnation": 6
                }
                """);
            }

            var transitionsEntry = archive.CreateEntry("game_state/control/life_transitions.json");
            await using (var transitionStream = transitionsEntry.Open())
            await using (var writer = new StreamWriter(transitionStream))
            {
                await writer.WriteAsync("""{ "transitions": [{ "transitionId": "stale" }] }""");
            }

            var incarnationEntry = archive.CreateEntry("game_state/control/incarnation_trigger.json");
            await using (var incarnationStream = incarnationEntry.Open())
            await using (var writer = new StreamWriter(incarnationStream))
            {
                await writer.WriteAsync("""{ "triggeredAtTurn": 42 }""");
            }

            var ascensionEntry = archive.CreateEntry("game_state/control/ascension.json");
            await using (var ascensionStream = ascensionEntry.Open())
            await using (var writer = new StreamWriter(ascensionStream))
            {
                await writer.WriteAsync("""{ "triggeredAtTurn": 43 }""");
            }

            await WriteRequiredResourceRootsAsync(archive);
        }

        Assert.True(await _service.LoadGameAsync(legacyZip));
        Assert.False(_fs.FileExists("game_state/control/life_transitions.json"));
        Assert.False(_fs.FileExists("game_state/control/incarnation_trigger.json"));
        Assert.False(_fs.FileExists("game_state/control/ascension.json"));
    }

    private static void AssertEntryLimitBoundary(
        string path,
        long exactLength)
    {
        SaveLoadService.ValidateTrustedArchiveBudget(
            [
                new SaveLoadService.SaveArchiveEntryDescriptor(
                    path,
                    IsDirectory: false,
                    Length: exactLength,
                    CompressedLength: exactLength)
            ]);
        Assert.Throws<InvalidDataException>(() =>
            SaveLoadService.ValidateTrustedArchiveBudget(
                [
                    new SaveLoadService.SaveArchiveEntryDescriptor(
                        path,
                        IsDirectory: false,
                        Length: exactLength + 1,
                        CompressedLength: exactLength + 1)
                ]));
    }

    private static async Task CreateBudgetAttackArchiveAsync(
        string archivePath,
        string attack)
    {
        var budget = SaveLoadService.TrustedArchiveBudget;
        using var archive = ZipFile.Open(
            archivePath,
            ZipArchiveMode.Create);
        switch (attack)
        {
            case "entry-count":
                for (var index = 0;
                     index <= budget.MaxEntryCount;
                     index++)
                {
                    archive.CreateEntry(
                        $"game_state/world/count-{index:D5}.json");
                }

                break;

            case "entry-name-metadata":
                const int nameLength = 64_000;
                var nameCount = checked((int)(
                    budget.MaxTotalEntryNameUtf8Bytes /
                    nameLength + 1));
                for (var index = 0; index < nameCount; index++)
                {
                    archive.CreateEntry(
                        $"{index:D2}-{new string('n', nameLength - 3)}");
                }

                break;

            case "manifest-expanded":
                await WriteRepeatedArchiveBytesAsync(
                    archive,
                    "save_manifest.json",
                    budget.MaxManifestExpandedBytes + 1);
                break;

            case "soul-state-expanded":
                await WriteRepeatedArchiveBytesAsync(
                    archive,
                    "game_state/meta/soul_state.json",
                    budget.MaxSoulStateExpandedBytes + 1);
                break;

            case "single-entry-expanded":
                await WriteRepeatedArchiveBytesAsync(
                    archive,
                    "game_state/world/oversized.bin",
                    budget.MaxEntryExpandedBytes + 1);
                break;

            case "aggregate-expanded":
                var entryCount = checked((int)(
                    budget.MaxTotalExpandedBytes /
                    budget.CompressionRatioGraceExpandedBytes + 1));
                for (var index = 0; index < entryCount; index++)
                {
                    await WriteRepeatedArchiveBytesAsync(
                        archive,
                        $"game_state/world/aggregate-{index:D3}.bin",
                        budget.CompressionRatioGraceExpandedBytes);
                }

                break;

            case "compression-ratio":
                await WriteRepeatedArchiveBytesAsync(
                    archive,
                    "game_state/world/compression-ratio.bin",
                    budget.CompressionRatioGraceExpandedBytes + 1);
                break;

            case "alternate-data-stream":
                await WriteRepeatedArchiveBytesAsync(
                    archive,
                    "game_state/world/state.json:foreign",
                    1);
                break;

            default:
                throw new ArgumentOutOfRangeException(
                    nameof(attack),
                    attack,
                    "Unknown archive-budget attack fixture.");
        }
    }

    private static async Task WriteRepeatedArchiveBytesAsync(
        ZipArchive archive,
        string path,
        long length)
    {
        var entry = archive.CreateEntry(
            path,
            CompressionLevel.Optimal);
        await using var stream = entry.Open();
        var buffer = new byte[64 * 1024];
        long written = 0;
        while (written < length)
        {
            var count = checked((int)Math.Min(
                buffer.LongLength,
                length - written));
            await stream.WriteAsync(buffer.AsMemory(0, count));
            written += count;
        }
    }

    private static async Task WritePaddedSaveMetadataAsync(
        ZipArchive archive,
        long length)
    {
        var entry = archive.CreateEntry(
            "save_metadata.json",
            CompressionLevel.Optimal);
        await using var stream = entry.Open();
        var prefix = Encoding.UTF8.GetBytes(
            """{"saveName":"valid-but-oversized"}""");
        if (length < prefix.LongLength)
            throw new ArgumentOutOfRangeException(nameof(length));

        await stream.WriteAsync(prefix);
        var padding = new byte[64 * 1024];
        Array.Fill(padding, (byte)' ');
        var written = prefix.LongLength;
        while (written < length)
        {
            var count = checked((int)Math.Min(
                padding.LongLength,
                length - written));
            await stream.WriteAsync(padding.AsMemory(0, count));
            written += count;
        }
    }

    private static string[] CaptureSessionSnapshot(string sessionRoot) =>
        Directory
            .EnumerateFiles(
                sessionRoot,
                "*",
                SearchOption.AllDirectories)
            .Select(path =>
                $"{Path.GetRelativePath(sessionRoot, path).Replace('\\', '/')}:" +
                Convert.ToHexString(
                    SHA256.HashData(File.ReadAllBytes(path))))
            .Order(StringComparer.Ordinal)
            .ToArray();

    private static void CreateDirectoryJunction(string junctionPath, string targetPath)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(junctionPath)!);
        using var process = Process.Start(new ProcessStartInfo
        {
            FileName = "cmd.exe",
            UseShellExecute = false,
            CreateNoWindow = true,
            Arguments = $"/d /c mklink /J \"{junctionPath}\" \"{targetPath}\""
        });
        if (process == null)
            throw new InvalidOperationException("Failed to start junction helper.");
        process.WaitForExit();
        if (process.ExitCode != 0)
            throw new InvalidOperationException($"Failed to create test junction: exit code {process.ExitCode}.");
    }

    public void Dispose()
    {
        try
        {
            if (Directory.Exists(_rootPath))
                Directory.Delete(_rootPath, recursive: true);
        }
        catch
        {
            // ignore temp cleanup failures
        }
    }

    private static async Task WriteArchiveEntryAsync(ZipArchive archive, string path, string content)
    {
        var entry = archive.CreateEntry(path);
        await using var stream = entry.Open();
        await using var writer = new StreamWriter(stream);
        await writer.WriteAsync(content);
    }

    private static async Task WriteLegacySoulStateAsync(ZipArchive archive)
    {
        await WriteArchiveEntryAsync(
            archive,
            "game_state/meta/soul_state.json",
            """
            {
              "soulName": "Наследуемая Душа",
              "currentRealm": "Mortal World",
              "currentIncarnation": 1
            }
            """);
        await WriteRequiredResourceRootsAsync(archive);
    }

    private static async Task WriteRequiredResourceRootsAsync(ZipArchive archive)
    {
        var bootstrap = ResourceBootstrapStateBuilder.BuildPristine();
        await WriteArchiveEntryAsync(
            archive,
            ResourceMaterializationContract.DefinitionsPath,
            bootstrap.Definitions!.ToCanonicalJson());
        await WriteArchiveEntryAsync(
            archive,
            ResourceMaterializationContract.StatePath,
            bootstrap.State!.ToCanonicalJson());
        await WriteArchiveEntryAsync(
            archive,
            ResourceMaterializationContract.HistoryPath,
            bootstrap.History!.ToCanonicalJson());
        await WriteArchiveEntryAsync(
            archive,
            CanonicalResourceOwnerAuthorityComposer.AuthorityPath,
            "{\"schemaVersion\":1,\"historicalOwners\":[],\"capacityDrafts\":[]}");
    }

    private static (string Definitions, string State, string History)
        CreateUnknownOwnerResourceRoots()
    {
        var bootstrap = ResourceBootstrapStateBuilder.BuildMortalPlayer(
            incarnationNumber: 3,
            turn: 42,
            permanentStrength: 10,
            permanentConstitution: 20,
            permanentIntelligence: 30,
            permanentWisdom: 40,
            permanentFaith: 50);
        Assert.True(bootstrap.IsValid, string.Join(Environment.NewLine, bootstrap.Issues));
        var state = JsonNode.Parse(bootstrap.State!.ToCanonicalJson())!.AsObject();
        var history = JsonNode.Parse(bootstrap.History!.ToCanonicalJson())!.AsObject();
        foreach (var entry in state["entries"]!.AsArray())
            entry!["resourceOwnerId"] = "player_forged";
        foreach (var transition in history["entries"]!.AsArray())
            transition!["coordinate"]!["resourceOwnerId"] = "player_forged";
        return (
            bootstrap.Definitions!.ToCanonicalJson(),
            state.ToJsonString(),
            history.ToJsonString());
    }

    private static async Task WriteStalePlayerSoulProfileArchiveAsync(
        ZipArchive archive)
    {
        var soulState = JsonNode.Parse(
            """
            {
              "soulName": "Пепельная Искра",
              "currentRealm": "Chaos Sea",
              "currentIncarnation": 7,
              "inkFeathers": { "current": 0, "total": 0 },
              "enlightenment": { "experience": 0, "level": 0 },
              "afterlifeCombatProfile": {
                "spiritFocusTier": 0,
                "artTiers": { "guard": 0, "recover_spiritual_power": 0 }
              }
            }
            """)!.AsObject();
        var profiles = JsonNode.Parse(
            """
            {
              "schemaVersion": 1,
              "profiles": [
                {
                  "actorType": "player_soul",
                  "actorId": "player_soul",
                  "displayName": "Пепельная Искра",
                  "realm": "Chaos Sea",
                  "currencies": { "inkFeathers": 4, "lightSparks": 0 },
                  "progression": {
                    "enlightenment": { "experience": 0, "tier": 0 },
                    "radiance": { "experience": 0, "tier": 0 }
                  },
                  "standardArts": {
                    "guard": 1,
                    "recover_spiritual_power": 1
                  },
                  "progressionStrategy": {
                    "strategyId": "strategy_player",
                    "priorityOrder": [ "guard" ],
                    "lastAutoProgressionCycleKey": "chaos:14"
                  },
                  "progressionLedger": []
                }
              ]
            }
            """)!.AsObject();
        var bootstrap = ResourceBootstrapStateBuilder.BuildPristine();
        Assert.True(
            bootstrap.IsValid,
            string.Join(Environment.NewLine, bootstrap.Issues));
        var plan = await CanonicalResourceQuartetTransaction.ComposeExplicitBootstrapAsync(
            bootstrap.Definitions!,
            bootstrap.State!,
            bootstrap.History!,
            new AfterlifeOwnerResourceAcceptedState(
                Profiles: profiles,
                SoulState: soulState),
            static _ => Task.FromResult<string?>(null));
        Assert.True(plan.IsValid, string.Join(Environment.NewLine, plan.Issues));

        await WriteArchiveEntryAsync(
            archive,
            "game_state/meta/soul_state.json",
            plan.OwnerAfterImages["game_state/meta/soul_state.json"].ToJsonString());
        await WriteArchiveEntryAsync(
            archive,
            AfterlifeEntityProfileState.StatePath,
            plan.OwnerAfterImages[AfterlifeEntityProfileState.StatePath].ToJsonString());
        await WriteArchiveEntryAsync(
            archive,
            ResourceMaterializationContract.DefinitionsPath,
            plan.Definitions.ToCanonicalJson());
        await WriteArchiveEntryAsync(
            archive,
            ResourceMaterializationContract.StatePath,
            plan.StateAfterImage!.ToCanonicalJson());
        await WriteArchiveEntryAsync(
            archive,
            ResourceMaterializationContract.HistoryPath,
            plan.HistoryAfterImage!.ToCanonicalJson());
        await WriteArchiveEntryAsync(
            archive,
            CanonicalResourceOwnerAuthorityComposer.AuthorityPath,
            plan.CanonicalAuthorityJson!);
    }

    private static async Task WriteManifestedArchiveAsync(
        string archivePath,
        IReadOnlyDictionary<string, string> payloads)
    {
        using var archive = ZipFile.Open(archivePath, ZipArchiveMode.Create);
        var manifestEntries = new List<object>();
        foreach (var (path, content) in payloads)
        {
            var bytes = Encoding.UTF8.GetBytes(content);
            var entry = archive.CreateEntry(path);
            await using (var stream = entry.Open())
                await stream.WriteAsync(bytes);
            manifestEntries.Add(new
            {
                path,
                length = bytes.LongLength,
                sha256 = Convert.ToHexString(SHA256.HashData(bytes))
            });
        }

        await WriteArchiveEntryAsync(
            archive,
            "save_manifest.json",
            JsonSerializer.Serialize(
                new
                {
                    schemaVersion = 1,
                    algorithm = "SHA-256",
                    entries = manifestEntries
                }));
    }

}
