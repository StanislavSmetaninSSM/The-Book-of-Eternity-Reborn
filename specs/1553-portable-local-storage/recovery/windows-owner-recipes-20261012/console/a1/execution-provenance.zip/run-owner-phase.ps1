[CmdletBinding()]
param([Parameter(Mandatory)][ValidateSet('console','metadata','owner','bridge','contention')][string]$Recipe,
 [Parameter(Mandatory)][ValidateSet('Prepare','Actual')][string]$Phase,[string]$Attempt='a1')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$root='C:\Temp\boe-win-8c2ecdfa-20261011T234246Z';$repo=Join-Path $root 'repo'
$prefix='owner-'+$Recipe+'-'+$Attempt
$cfg=Get-Content -LiteralPath (Join-Path $root ('evidence\'+$prefix+'-config.json')) -Raw -Encoding UTF8 | ConvertFrom-Json
$phaseDir=Join-Path $root ('evidence\'+$prefix+'-'+$Phase.ToLowerInvariant())
if (Test-Path -LiteralPath $phaseDir) { throw 'Phase reserved: inspect original PID/start/exit before any retry' }
New-Item -ItemType Directory -Path $phaseDir | Out-Null
$statePath=Join-Path $phaseDir 'process-state.json'
$state=[ordered]@{Recipe=$Recipe;Attempt=$Attempt;Phase=$Phase;State='Reserved';WrapperPid=$PID;WrapperStartedUtc=(Get-Process -Id $PID).StartTime.ToUniversalTime().ToString('o');RunnerPid=$null;RunnerStartedUtc=$null;ExitCode=$null;StartedUtc=[datetime]::UtcNow.ToString('o');CompletedUtc=$null;CheckoutHead=$cfg.CheckoutHead;SemanticSourceEquals=$cfg.SemanticSourceEquals;Category=$cfg.Category;CategoryBudgetMinutes=$cfg.CategoryBudgetMinutes;RunnerBudgetMinutes=$cfg.RunnerBudgetMinutes;Stdout=(Join-Path $phaseDir 'stdout.log');Stderr=(Join-Path $phaseDir 'stderr.log')}
function Save-State { $state | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $statePath -Encoding utf8NoBOM }
Save-State
try {
 Set-Location -LiteralPath $repo
 if ((git -c core.longpaths=true -c core.autocrlf=false rev-parse HEAD).Trim() -ne $cfg.CheckoutHead) { throw 'Checkout moved before phase' }
 if (@(git -c core.longpaths=true -c core.autocrlf=false status --porcelain=v1).Count) { throw 'Dirty checkout before phase' }
 $old=Get-Content -LiteralPath (Join-Path $root 'evidence\prepare\process-state.json') -Raw -Encoding UTF8 | ConvertFrom-Json
 $state['Environment']=$old.Environment
 foreach ($entry in $old.Environment.PSObject.Properties) { [Environment]::SetEnvironmentVariable($entry.Name,[string]$entry.Value,'Process') }
 $state['BootUtc']=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o')
 $state['SdkVersion']=(& dotnet --version | Out-String).Trim();$state['IsWindows']=$IsWindows
 if (-not $IsWindows -or $state.SdkVersion -ne '10.0.401') { throw 'Qualified Windows/SDK environment changed' }
 if ($Phase -eq 'Actual') {
  $gate=Get-Content -LiteralPath (Join-Path $root ('evidence\'+$prefix+'-prepare-gate.json')) -Raw -Encoding UTF8 | ConvertFrom-Json
  $inputs=Get-Content -LiteralPath (Join-Path $root ('evidence\'+$prefix+'-inputs-before-actual.json')) -Raw -Encoding UTF8 | ConvertFrom-Json
  if (-not $gate.Accepted -or $gate.CheckoutHead -ne $cfg.CheckoutHead -or $gate.PlannedCases -ne $cfg.ExpectedCases -or -not $inputs.ExactSourceAndDllBytesEqual) { throw 'Exact PlanOnly/source/DLL gate missing' }
  $state['QualifiedProjects']=$gate.QualifiedProjects
 } else { $state['QualifiedProjects']=$cfg.PriorQualifiedProjects }
 $runnerArgs=@('-NoLogo','-NoProfile','-File',(Join-Path $repo 'scripts\test-csharp.ps1'),'-Category',$cfg.Category,'-TimeoutMinutes',[string]$cfg.RunnerBudgetMinutes)
 if ($Phase -eq 'Prepare') { $runnerArgs+='-PlanOnly';if ($cfg.PrepareNoBuild) {$runnerArgs+='-NoBuild'} } else {$runnerArgs+='-NoBuild'}
 $state['Executable']=(Get-Command pwsh).Source;$state['Arguments']=$runnerArgs
 $state['Command']='pwsh -NoLogo -NoProfile -File ./scripts/test-csharp.ps1 -Category '+$cfg.Category+' -TimeoutMinutes '+$cfg.RunnerBudgetMinutes+$(if($Phase -eq 'Prepare'){' -PlanOnly'+$(if($cfg.PrepareNoBuild){' -NoBuild'}else{''})}else{' -NoBuild'})
 $state.State='Launching';Save-State
 $runner=Start-Process -FilePath $state.Executable -ArgumentList $runnerArgs -WorkingDirectory $repo -WindowStyle Hidden -RedirectStandardOutput $state.Stdout -RedirectStandardError $state.Stderr -PassThru
 $state.RunnerPid=$runner.Id;$state.RunnerStartedUtc=$runner.StartTime.ToUniversalTime().ToString('o');$state.State='Running';Save-State
 Write-Output ($state | ConvertTo-Json -Compress -Depth 10)
 $runner.WaitForExit()
 $state.ExitCode=$runner.ExitCode;$state.State='Exited';$state.CompletedUtc=[datetime]::UtcNow.ToString('o')
 $state['ResultDirectories']=@(Get-ChildItem -LiteralPath (Join-Path $repo 'TestResults\test-categories') -Directory | Where-Object {$_.Name -match ('-'+$runner.Id+'-') -and $_.CreationTimeUtc -ge ([datetime]$state.RunnerStartedUtc).ToUniversalTime().AddSeconds(-2)} | ForEach-Object FullName)
 Save-State;Write-Output ($state | ConvertTo-Json -Compress -Depth 10)
 exit $state.ExitCode
} catch {
 $state.State='WrapperFailure';$state['Failure']=$_.Exception.ToString();$state.CompletedUtc=[datetime]::UtcNow.ToString('o');Save-State;throw
}
