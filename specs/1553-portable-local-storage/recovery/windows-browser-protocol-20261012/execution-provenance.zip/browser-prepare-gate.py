import json
import pathlib

root = pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z')
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
state = read(root / 'evidence/browser-prepare/process-state.json')
assert state['State'] == 'Exited' and state['ExitCode'] == 0
assert len(state['ResultDirectories']) == 1
directory = pathlib.Path(state['ResultDirectories'][0])
summary, plan = read(directory / 'summary.json'), read(directory / 'plan.json')
assert summary['PlanOnly'] and summary['ExitCode'] == 0 and summary['Tests']['Executed'] == 0
assert summary['Revision']['Head'] == state['CheckoutHead'] and summary['Revision']['ChangedFiles'] == 0
assert summary['OwnedTreeCleanupSucceeded'] and summary['RuntimeCleanupSucceeded'] and not summary['TimedOut']
assert summary['TimeoutMinutes'] == 8 and summary['Selection']['PlannedCases'] == 30
assert summary['Selection']['PlannedDescriptors'] == 1
assert not any(x['Name'].startswith('Build-') for x in summary['PhaseResults'])
assert len(plan['Descriptors']) == 1
descriptor = plan['Descriptors'][0]
expected = {
    'WindowsFreshBrowser_UsesCurrentDeclaredMembers': 8,
    'WindowsAliasMember_RecordsOneBaselineAndRestoresExactBytes': 2,
    'WindowsPendingProfile_RecoversStandaloneOrDeclaredBytesOrAbsence': 4,
    'WindowsCleanupOnlyProtocol_UsesItsOriginalHandler': 4,
    'WindowsAuthenticOriginalSix_RecoversReceiptAndRetainsNeutralBackup': 2,
    'WindowsProtocolAdmission_PreservesPendingDecisionBeforeRecovery': 8,
    'WindowsNeutralPendingBackup_RecoversWithoutBrowserManifest': 2,
}
actual = {x['Name'].rsplit('.', 1)[-1]: x['Cases'] for x in descriptor['ExpectedMethodCounts']}
assert actual == expected and descriptor['BudgetMinutes'] == 3 and descriptor['EstimatedCases'] == 30
assert descriptor['Exclusive'] and not descriptor['FrontendBuild']
inputs = read(root / 'evidence/browser-inputs-before-actual.json')
assert inputs['InputBytesEqual'] and inputs['Head'] == state['CheckoutHead']
target = root / 'evidence/browser-prepare-gate.json'
assert not target.exists(), 'Browser gate already exists; inspect rather than overwrite'
gate = {'Accepted': True, 'Head': state['CheckoutHead'], 'CompiledSource': state['CompiledSource'],
        'Category': state['Category'], 'PlannedCases': 30, 'Methods': 7, 'ExecutedCases': 0,
        'CategoryBudgetMinutes': 3, 'RunnerBudgetMinutes': 8, 'ResultDirectory': str(directory),
        'MethodCounts': descriptor['ExpectedMethodCounts'], 'PreparationWallTime': summary['WallTime'],
        'NoBuild': True, 'NewBuildExecuted': False, 'InputsReceipt': 'browser-inputs-before-actual.json'}
target.write_text(json.dumps(gate, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(gate))
