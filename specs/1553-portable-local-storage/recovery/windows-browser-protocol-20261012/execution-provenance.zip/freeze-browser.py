import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from datetime import datetime, timezone

root = pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z')
repo = root / 'repo'
directory = repo / 'specs/1553-portable-local-storage/recovery/windows-browser-protocol-20261012'
assert not directory.exists(), 'Carrier already exists; inspect rather than rerun'
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
prepare = read(root / 'evidence/browser-prepare/process-state.json')
actual = read(root / 'evidence/browser-actual/process-state.json')
gate = read(root / 'evidence/browser-prepare-gate.json')
inputs = read(root / 'evidence/browser-inputs-after-actual.json')
process = read(root / 'evidence/browser-post-run-process-readback.json')
assert actual['State'] == 'Exited' and actual['ExitCode'] is not None
assert len(actual['ResultDirectories']) == 1
results = pathlib.Path(actual['ResultDirectories'][0])
summary = read(results / 'summary.json')
assert summary['Revision']['Head'] == inputs['Head'] and summary['Revision']['ChangedFiles'] == 0
assert inputs['InputBytesEqual'] and len(inputs['SourcePins']) == 1629 and len(inputs['DllPins']) == 157
assert not process['ActiveOwnedOperations'] and not process['BrowserRootRemainders'] and not process['WorkerRuntimeRemainders']
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
trx = ET.parse(results / 'portable-browser-protocol-native-windows-integration-001.trx')
cases = []
for result in trx.findall('.//t:UnitTestResult', ns):
    node = result.find('t:Output/t:StdOut', ns)
    error = result.find('t:Output/t:ErrorInfo', ns)
    stdout = node.text if node is not None else ''
    cases.append({'Name': result.get('testName'), 'Outcome': result.get('outcome'),
                  'Duration': result.get('duration'), 'OriginalStdOut': stdout,
                  'OwnedFixtureRemovedReceipt': 'OwnedFixtureRemoved=True' in stdout,
                  'ErrorMessage': error.findtext('t:Message', default='', namespaces=ns) if error is not None else '',
                  'ErrorStackTrace': error.findtext('t:StackTrace', default='', namespaces=ns) if error is not None else ''})
assert len(cases) == 30 and len({x['Name'] for x in cases}) == 30
assert all(x['OwnedFixtureRemovedReceipt'] for x in cases)
counts = Counter(x['Outcome'] for x in cases)
assert counts == {'Passed': 28, 'Failed': 2}
assert summary['Selection']['Complete'] and summary['Selection']['CompletedCases'] == 30
assert summary['OwnedTreeCleanupSucceeded'] and summary['RuntimeCleanupSucceeded']
assert not summary['TimedOut'] and not summary['DuplicateTests'] and summary['TimeoutMinutes'] == 8
failures = [x for x in cases if x['Outcome'] != 'Passed']
assert all('WindowsAuthenticOriginalSix_' in x['Name'] and 'System.IO.IOException' in x['ErrorMessage'] and 'line 190' in x['ErrorStackTrace'] for x in failures)
directory.mkdir(parents=True)
def archive(name, entries):
    path = directory / name
    records = []
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipper:
        for source, key in entries:
            zipper.write(source, key)
            records.append({'Path': key, 'Bytes': source.stat().st_size, 'SHA256': sha(source)})
    with zipfile.ZipFile(path) as zipper:
        assert sorted(zipper.namelist()) == sorted(x['Path'] for x in records)
        for item in records:
            raw = zipper.read(item['Path'])
            assert len(raw) == item['Bytes'] and hashlib.sha256(raw).hexdigest() == item['SHA256']
    return {'Path': name, 'Bytes': path.stat().st_size, 'SHA256': sha(path), 'Entries': records}
archives = []
for phase, state in [('prepare', prepare), ('actual', actual)]:
    result = pathlib.Path(state['ResultDirectories'][0])
    entries = [(p, 'runner/' + p.relative_to(result).as_posix()) for p in sorted(result.rglob('*')) if p.is_file()]
    entries += [(p, 'process/' + p.name) for p in sorted((root / 'evidence' / ('browser-' + phase)).iterdir()) if p.is_file()]
    archives.append(archive(phase + '-original.zip', entries))
provenance = [root / 'browser-inputs.py', root / 'browser-prepare-gate.py', root / 'run-browser-phase.ps1',
    root / 'freeze-browser.py', root / 'evidence/browser-inputs-before-prepare.json',
    root / 'evidence/browser-inputs-before-actual.json', root / 'evidence/browser-inputs-after-actual.json',
    root / 'evidence/browser-prepare-gate.json', root / 'evidence/browser-post-run-process-readback.json',
    root / 'evidence/prepare-gate.json']
archives.append(archive('execution-provenance.zip', [(p, p.relative_to(root).as_posix()) for p in provenance]))
diagnosis = {
    'State': 'ReadOnlyDiagnosis_IndependentReviewPending_NoFixApplied',
    'FirstActualResult': '28 PASS / 2 FAIL; all 30 executed; no timeout; both cleanups complete',
    'FailedBoundary': 'Two WindowsAuthenticOriginalSix rows fail at the physical File.ReadAllBytes(ProfilePath) assertion inside the still-active write lease, Windows.cs:190.',
    'ObservedException': 'System.IO.IOException sharing violation, original TRX/stack preserved',
    'SourceMechanism': [
        'DarenRewardProfileRollbackTransaction.PublishAsync retains its sourceStream in _sourceStream until transaction disposal.',
        'PhysicalFileAuthority.CreateNewWritableFile opens Windows GenericRead|GenericWrite plus DeleteAccess by default; published source handle remains owned.',
        'System.IO.File.ReadAllBytes opens a new reader with FileShare.Read, incompatible with the existing write/delete access.',
        'The source-proven deterministic reader/owner sharing incompatibility is sufficient to explain both observed failures; no new handle trace or repro was executed.'
    ],
    'Classification': 'Fixture/oracle physical-read sharing mismatch; no demonstrated production defect. Source/evidence classification awaits independent review.',
    'ReachedBeforeFailure': 'Pinned unchanged source shows Windows assertion, authentic schema6 transaction/legacy context, profile/member publication and zero common-member assertion completed before the failing read.',
    'NotReached': ['Post-read manifest publicationReceipt/publishedIdentity assertions', 'Neutral backup creation', 'Fresh-object authentic6 recovery and exact restored/retained bytes assertions'],
    'MinimalProposalNotApplied': 'In only the authentic6 held-lease physical-byte assertion, read the actual file through a test-only FileStream(FileMode.Open, FileAccess.Read, FileShare.ReadWrite|FileShare.Delete), copy its bytes and retain Assert.Equal(After,...). Keep product writer shares, original before/after byte oracles, transaction/receipts/recovery and cleanup unchanged. Do not move the assertion after disposal.',
    'RejectedShortcut': 'Replacing the physical-byte assertion with store.ReadExactBytesAsync alone is not proposed: the legacy transaction validates but returns a copied _publishedBytes buffer.',
    'FurtherRuntime': 'HOLD: first actual is immutable; no rerun/fix without coordinator decision.',
    'ProductChanged': False, 'TestChanged': False
}
(directory / 'diagnosis-proposal.json').write_text(json.dumps(diagnosis, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
manifest = {'SchemaVersion': 1, 'RecordedUtc': datetime.now(timezone.utc).isoformat(),
    'State': 'FirstWindowsBrowser28Pass2FailFrozen_ReviewPending', 'TrackedTask': '#1553 / F04-F05 Windows protocol30',
    'CheckoutHead': inputs['Head'], 'CompiledSource': inputs['CompiledSource'],
    'WorkingBranch': '1553-storage-migration-windows-f18-20261011T235650Z',
    'Category': gate['Category'], 'PreparationCommand': prepare['Command'], 'ActualCommand': actual['Command'],
    'PreparationWallTime': gate['PreparationWallTime'], 'PreparationPlannedCases': 30, 'PreparationExecutedCases': 0,
    'Methods': 7, 'MethodCounts': gate['MethodCounts'], 'ActualAttempts': 1,
    'ActualWallTime': summary['WallTime'], 'CategorySeconds': summary['CategoryResults'][0]['Seconds'],
    'CategoryCompletedFlag': summary['CategoryResults'][0]['Completed'], 'SelectionComplete': summary['Selection']['Complete'],
    'CategoryBudgetMinutes': 3, 'RunnerBudgetMinutes': 8, 'Planned': 30, 'Executed': 30, 'Passed': 28, 'Failed': 2,
    'Skipped': 0, 'TimedOut': False, 'DuplicateTests': 0, 'ExitCode': summary['ExitCode'],
    'OwnedTreeCleanupSucceeded': True, 'RuntimeCleanupSucceeded': True, 'StrictCleanupReceipts': 30,
    'BrowserRootRemainders': 0, 'WorkerRuntimeRemainders': 0, 'ActiveOwnedOperations': 0,
    'SourcePinsVerifiedBeforePrepareBeforeActualAndAfterActual': 1629, 'MetadataOnlySourceExclusions': inputs['MetadataOnlyExclusions'],
    'DllPdbPinsVerifiedBeforePrepareBeforeActualAndAfterActual': 157, 'NewBuildExecuted': False,
    'ReusedFreshBuildEvidence': '../windows-f18-native-20261012/manifest.json', 'Cases': cases,
    'Archives': archives, 'DiagnosisProposal': 'diagnosis-proposal.json',
    'Limits': ['Authentic schema6 recovery2 remains UNQUALIFIED; neither is a passing control',
               'Fresh() uses a new FileSystemManager within the same process; no fresh-process cold restart',
               'Protocol component assertions only; no browser DOM/UI, full gameplay or whole migration',
               'No product/test/runner/catalog/budget/security/architecture change or paid game-provider call',
               'F18 native6 prior acceptance and historical ordinary40 FAIL remain unchanged'],
    'ProductSourceChanged': False, 'TestSourceChanged': False}
(directory / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'Target': str(directory), 'Executed': 30, 'Passed': 28, 'Failed': 2,
                  'CleanupReceipts': 30, 'ArchiveEntries': sum(len(x['Entries']) for x in archives),
                  'ArchiveBytes': sum(x['Bytes'] for x in archives), 'FixApplied': False}))
