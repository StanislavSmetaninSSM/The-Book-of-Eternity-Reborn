import hashlib
import json
import pathlib
import subprocess
import sys
from datetime import datetime, timezone

root = pathlib.Path(r'C:\Temp\boe-win-8c2ecdfa-20261011T234246Z')
repo = root / 'repo'
git = ['git', '-c', 'core.longpaths=true', '-c', 'core.autocrlf=false']
head = subprocess.check_output(git + ['rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == '5d9f822195a2d4788dadcf483eee742e3ae7e766'
assert not subprocess.check_output(git + ['status', '--porcelain=v1', '-z'], cwd=repo)
subprocess.run(git + ['diff', '--exit-code', '8c2ecdfaa1003e49bf15ba83693788e9b19dd10f', 'HEAD',
                     '--', '.', ':(exclude)specs/1553-portable-local-storage'], cwd=repo, check=True)
original = json.loads((root / 'evidence/prepare-gate.json').read_text(encoding='utf-8'))
excluded = ['specs/1553-portable-local-storage/plan.md', 'specs/1553-portable-local-storage/tasks.md']
source = [x for x in original['SourcePins'] if x['Path'] not in excluded]
for pin in source + original['DllPins']:
    path = repo / pin['Path']
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert path.stat().st_size == pin['Bytes'] and digest == pin['SHA256'], pin['Path']
target = root / 'evidence' / sys.argv[1]
assert not target.exists(), 'Input receipt exists; inspect before any repeated operation'
record = {'CheckedUtc': datetime.now(timezone.utc).isoformat(), 'Head': head,
          'CompiledSource': original['Head'], 'ReusedFreshPreparation': original['ResultDirectory'],
          'SourcePins': source, 'MetadataOnlyExclusions': excluded, 'DllPins': original['DllPins'],
          'FreshProjectOutputs': original['FreshProjectOutputs'], 'InputBytesEqual': True,
          'SelectedProject': 'integration', 'Category': 'portable-browser-protocol-native-windows',
          'NoRebuildNeeded': True, 'NewBuildExecuted': False}
target.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'Head': head, 'CompiledSource': original['Head'], 'SourcePins': len(source),
                  'DllPdbPins': len(original['DllPins']), 'InputBytesEqual': True, 'Receipt': str(target)}))
