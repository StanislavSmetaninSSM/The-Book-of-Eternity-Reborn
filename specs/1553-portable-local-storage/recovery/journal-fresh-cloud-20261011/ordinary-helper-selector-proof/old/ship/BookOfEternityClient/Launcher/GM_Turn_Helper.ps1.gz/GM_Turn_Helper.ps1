Set-StrictMode -Off

. (Join-Path $PSScriptRoot 'gm_turn_helper_transport.ps1')
$script:BoeGameSessionPath = $null
$script:BoeReadBaselines = [Collections.Generic.Dictionary[string,string]]::new($script:BoePathComparer)

function Initialize-BoeGmTurnHelper {
    param(
        [Parameter(Mandatory = $true)]
        [string]$GameSessionPath
    )

    if($script:BoeHelperFailure){throw $script:BoeHelperFailure}
    $context=Open-BoeHelperScope 'initialize' $GameSessionPath $null
    try {Close-GmParticipatingOperation $context 0}
    finally {Complete-BoeHelperTransport $context}
    $script:BoeGameSessionPath=$context.session
    $script:BoeHelperGeneration=$context.generation
    $script:BoeReadBaselines=[Collections.Generic.Dictionary[string,string]]::new($script:BoePathComparer)
}

function Assert-BoeGmTurnHelperInitialized {
    if ([string]::IsNullOrWhiteSpace($script:BoeGameSessionPath) -or [string]::IsNullOrWhiteSpace($script:BoeHelperGeneration)) {
        throw "GM turn helper is not initialized. Run Initialize-BoeGmTurnHelper -GameSessionPath <path> first."
    }
}

function Resolve-BoeSessionPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath
    )

    Assert-BoeGmTurnHelperInitialized
    if(-not $script:BoeHelperScope){return Invoke-BoeHelperScope -Body {Resolve-BoeSessionPath $RelativePath}}
    $relative=Invoke-BoeHelperRequest @{action='normalize';path=$RelativePath}
    return [IO.Path]::GetFullPath(([IO.Path]::Combine($script:BoeGameSessionPath,$relative.Replace('/',[IO.Path]::DirectorySeparatorChar))))
}

function Read-BoeJson {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Read-BoeJson @boeCallArguments }
    }


    $path = Resolve-BoeSessionPath -RelativePath $RelativePath
    if (!(Test-BoePath -LiteralPath $path)) {
        throw "JSON file does not exist: $RelativePath"
    }

    $bytes = (Read-BoeBytes $path)
    $script:BoeReadBaselines[$path] = Get-BoeSha256Hex -Bytes $bytes
    $json = [System.Text.Encoding]::UTF8.GetString($bytes)
    if ($json.Length -gt 0 -and $json[0] -eq [char]0xFEFF) {
        $json = $json.Substring(1)
    }
    return ConvertFrom-BoeJsonMutable -Json $json
}

function Get-BoeSha256Hex {
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$Bytes
    )

    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([System.BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-', '').ToLowerInvariant()
    }
    finally {
        $sha.Dispose()
    }
}

function ConvertFrom-BoeJsonMutable {
    param(
        [AllowNull()]
        [string]$Json
    )

    if ([string]::IsNullOrWhiteSpace($Json)) {
        return $null
    }

    $convertFromJson = Get-Command ConvertFrom-Json
    if ($convertFromJson.Parameters.ContainsKey("AsHashtable") -and
        $convertFromJson.Parameters.ContainsKey("NoEnumerate")) {
        $parsed = $Json | ConvertFrom-Json -AsHashtable -NoEnumerate
        return ConvertTo-BoeMutableJsonValue -Value $parsed
    }

    try {
        Add-Type -AssemblyName System.Web.Extensions -ErrorAction Stop
        $serializer = New-Object System.Web.Script.Serialization.JavaScriptSerializer
        $serializer.MaxJsonLength = [int]::MaxValue
        return ConvertTo-BoeMutableJsonValue -Value $serializer.DeserializeObject($Json)
    }
    catch {
        Assert-BoeNotStorageFailure $_
        $parsed = $Json | ConvertFrom-Json
        return ConvertTo-BoeMutableJsonValue -Value $parsed
    }
}

function ConvertTo-BoeMutableJsonValue {
    param(
        [AllowNull()]
        [object]$Value
    )

    if ($null -eq $Value) {
        return $null
    }

    if ($Value -is [System.Collections.IDictionary]) {
        $result = [ordered]@{}
        foreach ($key in $Value.Keys) {
            $result[[string]$key] = ConvertTo-BoeMutableJsonValue -Value $Value[$key]
        }

        return $result
    }

    if ($Value -is [System.Array]) {
        $items = New-Object System.Collections.Generic.List[object]
        foreach ($item in $Value) {
            $items.Add((ConvertTo-BoeMutableJsonValue -Value $item))
        }

        return ,([object[]]$items.ToArray())
    }

    if ($Value.GetType().FullName -eq "System.Management.Automation.PSCustomObject") {
        $result = [ordered]@{}
        foreach ($property in $Value.PSObject.Properties) {
            if ($property.MemberType -eq [System.Management.Automation.PSMemberTypes]::NoteProperty) {
                $result[$property.Name] = ConvertTo-BoeMutableJsonValue -Value $property.Value
            }
        }

        return $result
    }

    return $Value
}

function Get-BoeJsonValue {
    param(
        [AllowNull()]
        [object]$Object,

        [Parameter(Mandatory = $true)]
        [string[]]$Names,

        [object]$Default = $null
    )

    if ($null -eq $Object) {
        return $Default
    }

    foreach ($name in @($Names)) {
        if ([string]::IsNullOrWhiteSpace($name)) {
            continue
        }

        if ($Object -is [System.Collections.IDictionary]) {
            if ($Object.Contains($name)) {
                return $Object[$name]
            }

            foreach ($key in $Object.Keys) {
                if ([string]::Equals([string]$key, $name, [System.StringComparison]::OrdinalIgnoreCase)) {
                    return $Object[$key]
                }
            }
        }

        $property = $Object.PSObject.Properties |
            Where-Object { [string]::Equals($_.Name, $name, [System.StringComparison]::OrdinalIgnoreCase) } |
            Select-Object -First 1

        if ($null -ne $property) {
            return $property.Value
        }
    }

    return $Default
}

function Get-BoeJsonArrayItems {
    param(
        [AllowNull()]
        [object]$Value
    )

    if ($null -eq $Value) {
        return
    }

    if ($Value -is [System.Array]) {
        foreach ($item in $Value) {
            $item
        }
        return
    }

    $Value
}

function Set-BoeJsonProperty {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Object,

        [Parameter(Mandatory = $true)]
        [string]$Name,

        [AllowNull()]
        [object]$Value
    )

    if ($Object -is [System.Collections.IDictionary]) {
        $Object[$Name] = $Value
        return
    }

    $property = $Object.PSObject.Properties |
        Where-Object { [string]::Equals($_.Name, $Name, [System.StringComparison]::OrdinalIgnoreCase) } |
        Select-Object -First 1

    if ($null -ne $property) {
        try {
            $property.Value = $Value
            return
        }
        catch {
        Assert-BoeNotStorageFailure $_
            # Fall through and replace unusual member shapes with a JSON-like NoteProperty.
        }
    }

    $Object | Add-Member -NotePropertyName $Name -NotePropertyValue $Value -Force
}

function Add-BoeJsonArrayItem {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Object,

        [Parameter(Mandatory = $true)]
        [string]$PropertyName,

        [Parameter(Mandatory = $true)]
        [object]$Item,

        [string]$UniqueBy = ""
    )

    $existingValue = Get-BoeJsonValue -Object $Object -Names @($PropertyName)
    $existingItems = @(Get-BoeJsonArrayItems -Value $existingValue)
    $nextItems = New-Object System.Collections.Generic.List[object]

    $replacementKey = $null
    if (![string]::IsNullOrWhiteSpace($UniqueBy)) {
        $replacementKey = Get-BoeJsonValue -Object $Item -Names @($UniqueBy)
    }

    foreach ($existingItem in $existingItems) {
        if (![string]::IsNullOrWhiteSpace($UniqueBy) -and $null -ne $replacementKey) {
            $existingKey = Get-BoeJsonValue -Object $existingItem -Names @($UniqueBy)
            if ($null -ne $existingKey -and [string]::Equals([string]$existingKey, [string]$replacementKey, [System.StringComparison]::OrdinalIgnoreCase)) {
                continue
            }
        }

        $nextItems.Add($existingItem)
    }

    $nextItems.Add($Item)
    $arrayValue = [object[]]$nextItems.ToArray()
    Set-BoeJsonProperty -Object $Object -Name $PropertyName -Value $arrayValue

    return ,$arrayValue
}

function Test-BoeJsonTextEquals {
    param(
        [AllowNull()]
        [object]$Left,

        [AllowNull()]
        [object]$Right
    )

    if ($null -eq $Left -or $null -eq $Right) {
        return $false
    }

    return [string]::Equals([string]$Left, [string]$Right, [System.StringComparison]::OrdinalIgnoreCase)
}

function Get-BoeFirstNonEmptyJsonString {
    param(
        [AllowNull()]
        [object]$Object,

        [Parameter(Mandatory = $true)]
        [string[]]$Names
    )

    foreach ($name in @($Names)) {
        $value = Get-BoeJsonValue -Object $Object -Names @($name)
        if ($null -ne $value -and ![string]::IsNullOrWhiteSpace([string]$value)) {
            return [string]$value
        }
    }

    return ""
}

function Get-BoeJsonInt {
    param(
        [AllowNull()]
        [object]$Object,

        [Parameter(Mandatory = $true)]
        [string[]]$Names,

        [int]$Default = 0
    )

    $value = Get-BoeJsonValue -Object $Object -Names $Names
    if ($null -eq $value) {
        return $Default
    }

    try {
        return [int]$value
    }
    catch {
        Assert-BoeNotStorageFailure $_
        $parsed = 0
        if ([int]::TryParse([string]$value, [ref]$parsed)) {
            return $parsed
        }
    }

    return $Default
}

function Test-BoeNpcTradeItemClassCode {
    param(
        [AllowNull()]
        [string]$TradeItemClass
    )

    return $TradeItemClass -in @("Functional", "Material", "FlavorOrUtility")
}

function Get-BoeClampedDouble {
    param(
        [double]$Value,
        [double]$Min,
        [double]$Max
    )

    if ($Value -lt $Min) {
        return $Min
    }

    if ($Value -gt $Max) {
        return $Max
    }

    return $Value
}

function Get-BoePlayerTradeValue {
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Get-BoePlayerTradeValue @boeCallArguments }
    }

    foreach ($relativePath in @("game_state/misc/characteristics.json", "game_state/player/player_status.json", "game_state/core/player_status.json")) {
        try {
            $path = Resolve-BoeSessionPath -RelativePath $relativePath
            if (!(Test-BoePath -LiteralPath $path)) {
                continue
            }

            $root = Read-BoeJson -RelativePath $relativePath
            $modified = Get-BoeJsonInt -Object $root -Names @("modifiedTrade") -Default ([int]::MinValue)
            if ($modified -ne [int]::MinValue) {
                return $modified
            }

            $trade = Get-BoeJsonInt -Object $root -Names @("trade") -Default ([int]::MinValue)
            if ($trade -ne [int]::MinValue) {
                return $trade
            }
        }
        catch {
        Assert-BoeNotStorageFailure $_
            # Try the next canonical source.
        }
    }

    return 10
}

function Get-BoeNpcTradeValue {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Npc
    )

    $characteristics = Get-BoeJsonValue -Object $Npc -Names @("characteristics")
    if ($null -ne $characteristics) {
        $modified = Get-BoeJsonInt -Object $characteristics -Names @("modifiedTrade") -Default ([int]::MinValue)
        if ($modified -ne [int]::MinValue) {
            return $modified
        }

        $standard = Get-BoeJsonInt -Object $characteristics -Names @("standardTrade") -Default ([int]::MinValue)
        if ($standard -ne [int]::MinValue) {
            return $standard
        }

        $trade = Get-BoeJsonInt -Object $characteristics -Names @("trade") -Default ([int]::MinValue)
        if ($trade -ne [int]::MinValue) {
            return $trade
        }
    }

    return 10
}

function Get-BoeNpcPricingReputationModifier {
    param(
        [AllowNull()]
        [string]$PricingTradeTier
    )

    switch ($PricingTradeTier) {
        "Hostile" { return 1.20 }
        "Wary" { return 1.10 }
        "Warm" { return 0.92 }
        "Trusted" { return 0.85 }
        default { return 1.00 }
    }
}

function Get-BoeNpcTradeBuyPrice {
    param(
        [int]$BasePrice,
        [int]$PlayerTrade,
        [int]$NpcTrade,
        [string]$PricingTradeTier
    )

    $tradeDelta = $PlayerTrade - $NpcTrade
    $tradeAdjustment = Get-BoeClampedDouble -Value ([double]$tradeDelta * 0.01) -Min -0.20 -Max 0.20
    $tradeModifier = 1.20 - $tradeAdjustment
    $reputationModifier = Get-BoeNpcPricingReputationModifier -PricingTradeTier $PricingTradeTier
    return [int][Math]::Ceiling([double]$BasePrice * [double]$tradeModifier * [double]$reputationModifier)
}

function Find-BoeNpcTradeRequest {
    param(
        [Parameter(Mandatory = $true)]
        [object]$PendingRoot,

        [Parameter(Mandatory = $true)]
        [string]$RequestId
    )

    foreach ($request in @(Get-BoeJsonArrayItems -Value (Get-BoeJsonValue -Object $PendingRoot -Names @("requests")))) {
        $candidateRequestId = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("requestId")
        if (Test-BoeJsonTextEquals -Left $candidateRequestId -Right $RequestId) {
            return $request
        }
    }

    $singleRequestId = Get-BoeFirstNonEmptyJsonString -Object $PendingRoot -Names @("requestId")
    if (Test-BoeJsonTextEquals -Left $singleRequestId -Right $RequestId) {
        return $PendingRoot
    }

    return $null
}

function Find-BoeCanonicalNpcObject {
    param(
        [Parameter(Mandatory = $true)]
        [object]$NpcRoot,

        [Parameter(Mandatory = $true)]
        [string]$NpcId
    )

    foreach ($arrayName in @("NPCsInScene", "npcs", "UpdateNPCs", "NPCs", "characters", "actors")) {
        foreach ($npc in @(Get-BoeJsonArrayItems -Value (Get-BoeJsonValue -Object $NpcRoot -Names @($arrayName)))) {
            $candidateId = Get-BoeFirstNonEmptyJsonString -Object $npc -Names @("NPCId", "npcId", "id", "initialId")
            if (Test-BoeJsonTextEquals -Left $candidateId -Right $NpcId) {
                return $npc
            }
        }
    }

    return $null
}

function Normalize-BoeNpcTradeItem {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Item,

        [Parameter(Mandatory = $true)]
        [object]$Request,

        [Parameter(Mandatory = $true)]
        [object]$Npc,

        [Parameter(Mandatory = $true)]
        [string]$PricingTradeTier,

        [Parameter(Mandatory = $true)]
        [int]$Index
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Normalize-BoeNpcTradeItem @boeCallArguments }
    }


    $requestProfile = Get-BoeFirstNonEmptyJsonString -Object $Request -Names @("merchantProfile")
    if ([string]::IsNullOrWhiteSpace($requestProfile)) {
        throw "NPC trade request is missing merchantProfile."
    }

    $itemData = Get-BoeJsonValue -Object $Item -Names @("itemData")
    if ($null -eq $itemData) {
        throw "NPC trade item #$Index is missing itemData."
    }

    $itemName = Get-BoeFirstNonEmptyJsonString -Object $itemData -Names @("name")
    if ([string]::IsNullOrWhiteSpace($itemName)) {
        throw "NPC trade item #$Index itemData is missing name."
    }

    $itemId = Get-BoeFirstNonEmptyJsonString -Object $Item -Names @("itemId")
    if ([string]::IsNullOrWhiteSpace($itemId)) {
        $itemId = Get-BoeFirstNonEmptyJsonString -Object $itemData -Names @("itemId", "id")
        if (![string]::IsNullOrWhiteSpace($itemId)) {
            Set-BoeJsonProperty -Object $Item -Name "itemId" -Value $itemId
        }
    }

    if ([string]::IsNullOrWhiteSpace($itemId)) {
        throw "NPC trade item #$Index must define itemId either on the slot or itemData."
    }

    if ([string]::IsNullOrWhiteSpace((Get-BoeFirstNonEmptyJsonString -Object $itemData -Names @("itemId", "id")))) {
        Set-BoeJsonProperty -Object $itemData -Name "itemId" -Value $itemId
    }

    $slotId = Get-BoeFirstNonEmptyJsonString -Object $Item -Names @("slotId")
    if ([string]::IsNullOrWhiteSpace($slotId)) {
        $requestId = Get-BoeFirstNonEmptyJsonString -Object $Request -Names @("requestId")
        $slotId = "$requestId-slot-$Index"
        Set-BoeJsonProperty -Object $Item -Name "slotId" -Value $slotId
    }

    $itemProfile = Get-BoeFirstNonEmptyJsonString -Object $Item -Names @("merchantProfile")
    if ([string]::IsNullOrWhiteSpace($itemProfile)) {
        Set-BoeJsonProperty -Object $Item -Name "merchantProfile" -Value $requestProfile
    }
    elseif (!(Test-BoeJsonTextEquals -Left $itemProfile -Right $requestProfile)) {
        throw "NPC trade item #$Index merchantProfile '$itemProfile' does not match request merchantProfile '$requestProfile'."
    }

    if ($null -eq (Get-BoeJsonValue -Object $Item -Names @("soldOut"))) {
        Set-BoeJsonProperty -Object $Item -Name "soldOut" -Value $false
    }

    $tradeItemClass = Get-BoeFirstNonEmptyJsonString -Object $itemData -Names @("tradeItemClass")
    if ([string]::IsNullOrWhiteSpace($tradeItemClass)) {
        $tradeItemClass = Get-BoeFirstNonEmptyJsonString -Object $Item -Names @("tradeItemClass")
    }

    if ([string]::IsNullOrWhiteSpace($tradeItemClass)) {
        throw "NPC trade item #$Index itemData is missing tradeItemClass. Use Functional, Material, or FlavorOrUtility."
    }

    if (!(Test-BoeNpcTradeItemClassCode -TradeItemClass $tradeItemClass)) {
        throw "NPC trade item #$Index has unsupported tradeItemClass '$tradeItemClass'. Use Functional, Material, or FlavorOrUtility."
    }

    Set-BoeJsonProperty -Object $itemData -Name "tradeItemClass" -Value $tradeItemClass

    $rarity = Get-BoeFirstNonEmptyJsonString -Object $itemData -Names @("quality", "rarity")
    if ([string]::IsNullOrWhiteSpace($rarity)) {
        throw "NPC trade item #$Index itemData is missing quality or rarity."
    }

    $basePrice = Get-BoeJsonInt -Object $itemData -Names @("price") -Default 0
    if ($basePrice -le 0) {
        throw "NPC trade item #$Index itemData.price must be a positive number."
    }

    $baseSellPrice = Get-BoeJsonInt -Object $itemData -Names @("baseSellPrice") -Default -1
    if ($baseSellPrice -lt 0) {
        throw "NPC trade item #$Index itemData.baseSellPrice must be a non-negative number."
    }

    $canonicalPrice = Get-BoeNpcTradeBuyPrice `
        -BasePrice $basePrice `
        -PlayerTrade (Get-BoePlayerTradeValue) `
        -NpcTrade (Get-BoeNpcTradeValue -Npc $Npc) `
        -PricingTradeTier $PricingTradeTier
    Set-BoeJsonProperty -Object $Item -Name "price" -Value $canonicalPrice

    return $Item
}

function Complete-BoeNpcTradeInventoryRequest {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RequestId,

        [Parameter(Mandatory = $true)]
        [object[]]$Items,

        [string]$GenerationTradeTier = "Good",

        [string]$PricingTradeTier = "Neutral"
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'write' -Body { Complete-BoeNpcTradeInventoryRequest @boeCallArguments }
    }


    if ([string]::IsNullOrWhiteSpace($RequestId)) {
        throw "RequestId is required for Complete-BoeNpcTradeInventoryRequest."
    }

    $pendingRoot = Read-BoeJson -RelativePath "game_state/control/pending_npc_trade_inventory_requests.json"
    $request = Find-BoeNpcTradeRequest -PendingRoot $pendingRoot -RequestId $RequestId
    if ($null -eq $request) {
        throw "NPC trade request not found: $RequestId"
    }

    $npcId = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("npcId")
    if ([string]::IsNullOrWhiteSpace($npcId)) {
        throw "NPC trade request '$RequestId' is missing npcId."
    }

    $npcRoot = Read-BoeJson -RelativePath "game_state/npcs/npc_core.json"
    $npc = Find-BoeCanonicalNpcObject -NpcRoot $npcRoot -NpcId $npcId
    if ($null -eq $npc) {
        throw "NPC trade request '$RequestId' references unknown NPC '$npcId'. Same-turn NPCs may expose this identity as initialId; ensure npc_core.json contains NPCId, npcId, id, or initialId."
    }

    $expectedCountRaw = Get-BoeJsonValue -Object $request -Names @("derivedTradeSlotCount") -Default 0
    $expectedCount = [int]$expectedCountRaw
    $itemList = New-Object System.Collections.Generic.List[object]
    $index = 1
    foreach ($item in @($Items)) {
        $itemList.Add((Normalize-BoeNpcTradeItem -Item $item -Request $request -Npc $npc -PricingTradeTier $PricingTradeTier -Index $index))
        $index++
    }

    if ($expectedCount -gt 0 -and $itemList.Count -ne $expectedCount) {
        throw "NPC trade request '$RequestId' expects $expectedCount trade items, but helper received $($itemList.Count)."
    }

    $createdAtWorldDateRaw = Get-BoeJsonValue -Object $request -Names @("createdAtWorldDate") -Default 0
    $refreshAfterWorldDateRaw = Get-BoeJsonValue -Object $request -Names @("refreshAfterWorldDate") -Default 0
    $createdAtTurnRaw = Get-BoeJsonValue -Object $request -Names @("createdAtTurn") -Default 0
    $tradeInventory = [ordered]@{
        tradeCycleId = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("tradeCycleId")
        generatedAtWorldDate = [int]$createdAtWorldDateRaw
        refreshAfterWorldDate = [int]$refreshAfterWorldDateRaw
        generationTradeTier = $GenerationTradeTier
        pricingTradeTier = $PricingTradeTier
        items = [object[]]$itemList.ToArray()
    }

    Set-BoeJsonProperty -Object $npc -Name "tradeInventory" -Value $tradeInventory

    $receipt = [ordered]@{
        requestId = $RequestId
        npcId = $npcId
        npcName = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("npcName")
        tradeCycleId = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("tradeCycleId")
        merchantProfile = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("merchantProfile")
        status = "ready"
        itemCount = $itemList.Count
        resolvedAtTurn = [int]$createdAtTurnRaw
        resolvedAtUtc = [DateTimeOffset]::UtcNow.ToString("O")
    }

    $null = Add-BoeJsonArrayItem -Object $npcRoot -PropertyName "UpdateNpcTradeInventoryReceipts" -Item $receipt -UniqueBy "requestId"
    Write-BoeJson -RelativePath "game_state/npcs/npc_core.json" -Data $npcRoot -Depth 100
}

function Find-BoeGuardianTradeRequest {
    param(
        [Parameter(Mandatory = $true)]
        [object]$PendingRoot,

        [Parameter(Mandatory = $true)]
        [string]$RequestId
    )

    $singleRequestId = Get-BoeFirstNonEmptyJsonString -Object $PendingRoot -Names @("requestId")
    if (Test-BoeJsonTextEquals -Left $singleRequestId -Right $RequestId) {
        return $PendingRoot
    }

    foreach ($request in @(Get-BoeJsonArrayItems -Value (Get-BoeJsonValue -Object $PendingRoot -Names @("requests")))) {
        $candidateRequestId = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("requestId")
        if (Test-BoeJsonTextEquals -Left $candidateRequestId -Right $RequestId) {
            return $request
        }
    }

    return $null
}

function Find-BoeCanonicalGuardianObject {
    param(
        [Parameter(Mandatory = $true)]
        [object]$GuardiansRoot,

        [Parameter(Mandatory = $true)]
        [string]$GuardianId
    )

    foreach ($guardian in @(Get-BoeJsonArrayItems -Value (Get-BoeJsonValue -Object $GuardiansRoot -Names @("guardians")))) {
        $candidateId = Get-BoeFirstNonEmptyJsonString -Object $guardian -Names @("guardianId", "id")
        if (Test-BoeJsonTextEquals -Left $candidateId -Right $GuardianId) {
            return $guardian
        }
    }

    return $null
}

function Get-BoeGuardianExpectedTradeTierCode {
    param([int]$Reputation)

    if ($Reputation -le -51) { return "Hostile" }
    if ($Reputation -le 49) { return "Neutral" }
    if ($Reputation -le 129) { return "Friendly" }
    if ($Reputation -le 229) { return "Devoted" }
    return "Legendary"
}

function Normalize-BoeGuardianTradeTierCode {
    param(
        [AllowNull()]
        [string]$TierCode
    )

    if ([string]::IsNullOrWhiteSpace($TierCode)) {
        return ""
    }

    $trimmed = $TierCode.Trim()
    $slashIndex = $trimmed.LastIndexOf('/')
    if ($slashIndex -ge 0 -and $slashIndex -lt ($trimmed.Length - 1)) {
        $trimmed = $trimmed.Substring($slashIndex + 1).Trim()
    }

    switch ($trimmed.ToLowerInvariant()) {
        "hostile" { return "Hostile" }
        "neutral" { return "Neutral" }
        "friendly" { return "Friendly" }
        "devoted" { return "Devoted" }
        "legendary" { return "Legendary" }
        default { return "" }
    }
}

function Get-BoeGuardianRarityRank {
    param(
        [AllowNull()]
        [string]$Rarity
    )

    switch ([string]$Rarity) {
        "Common" { return 1 }
        "Uncommon" { return 2 }
        "Rare" { return 3 }
        "Epic" { return 4 }
        "Legendary" { return 5 }
        default { return 0 }
    }
}

function Get-BoeGuardianTradeBuyPrice {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Rarity,

        [Parameter(Mandatory = $true)]
        [string]$PricingReputationTier
    )

    switch ($Rarity) {
        "Common" { $basePrice = 30; break }
        "Uncommon" { $basePrice = 70; break }
        "Rare" { $basePrice = 140; break }
        "Epic" { $basePrice = 260; break }
        "Legendary" { $basePrice = 420; break }
        default { $basePrice = 30; break }
    }

    switch ($PricingReputationTier) {
        "Neutral" { $multiplier = 1.15; break }
        "Friendly" { $multiplier = 1.00; break }
        "Devoted" { $multiplier = 0.90; break }
        "Legendary" { $multiplier = 0.80; break }
        default { return [int]::MaxValue }
    }

    return [int][Math]::Ceiling([double]$basePrice * [double]$multiplier)
}

function Test-BoeGuardianRarityAllowedForTradeTier {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Rarity,

        [Parameter(Mandatory = $true)]
        [string]$GenerationReputationTier,

        [int]$RarityBonusStepsApplied = 0
    )

    $maxRank = switch ($GenerationReputationTier) {
        "Hostile" { 0 }
        "Neutral" { Get-BoeGuardianRarityRank -Rarity "Uncommon" }
        "Friendly" { Get-BoeGuardianRarityRank -Rarity "Rare" }
        "Devoted" { Get-BoeGuardianRarityRank -Rarity "Epic" }
        "Legendary" { Get-BoeGuardianRarityRank -Rarity "Epic" }
        default { 0 }
    }

    $effectiveMax = [Math]::Min((Get-BoeGuardianRarityRank -Rarity "Legendary"), $maxRank + [Math]::Max(0, $RarityBonusStepsApplied))
    return (Get-BoeGuardianRarityRank -Rarity $Rarity) -le $effectiveMax
}

function Get-BoeGuardianTradeBonusSignaturePart {
    param(
        [AllowNull()]
        [string]$Signature,

        [int]$Index
    )

    if ([string]::IsNullOrWhiteSpace($Signature)) {
        return 0
    }

    $parts = $Signature.Split('|')
    if ($Index -lt 0 -or $Index -ge $parts.Length) {
        return 0
    }

    $parsed = 0
    if ([int]::TryParse($parts[$Index], [ref]$parsed)) {
        return [Math]::Max(0, $parsed)
    }

    return 0
}

function Normalize-BoeGuardianTradeItem {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Item,

        [Parameter(Mandatory = $true)]
        [object]$Request,

        [Parameter(Mandatory = $true)]
        [string]$GenerationReputationTier,

        [Parameter(Mandatory = $true)]
        [string]$PricingReputationTier,

        [Parameter(Mandatory = $true)]
        [int]$Index
    )

    $relicData = Get-BoeJsonValue -Object $Item -Names @("relicData")
    if ($null -eq $relicData) {
        throw "Guardian trade item #$Index is missing relicData."
    }

    $relicId = Get-BoeFirstNonEmptyJsonString -Object $relicData -Names @("relicId", "id")
    if ([string]::IsNullOrWhiteSpace($relicId)) {
        throw "Guardian trade item #$Index relicData is missing relicId."
    }

    if ([string]::IsNullOrWhiteSpace((Get-BoeFirstNonEmptyJsonString -Object $relicData -Names @("relicId")))) {
        Set-BoeJsonProperty -Object $relicData -Name "relicId" -Value $relicId
    }

    $name = Get-BoeFirstNonEmptyJsonString -Object $relicData -Names @("name")
    if ([string]::IsNullOrWhiteSpace($name)) {
        throw "Guardian trade item #$Index relicData is missing name."
    }

    $rarity = Get-BoeFirstNonEmptyJsonString -Object $relicData -Names @("quality", "rarity")
    if ([string]::IsNullOrWhiteSpace($rarity)) {
        throw "Guardian trade item #$Index relicData is missing quality or rarity."
    }

    $rarity = switch ($rarity) {
        "Common" { "Common" }
        "Uncommon" { "Uncommon" }
        "Rare" { "Rare" }
        "Epic" { "Epic" }
        "Legendary" { "Legendary" }
        default { throw "Guardian trade item #$Index has unsupported rarity '$rarity'. Use Common, Uncommon, Rare, Epic, or Legendary." }
    }

    Set-BoeJsonProperty -Object $relicData -Name "quality" -Value $rarity
    Set-BoeJsonProperty -Object $relicData -Name "rarity" -Value $rarity

    $maxBonusSteps = Get-BoeJsonInt -Object $Request -Names @("effectiveRarityCeilingBonusSteps") -Default 0
    $rarityBonusStepsApplied = Get-BoeJsonInt -Object $Item -Names @("rarityBonusStepsApplied") -Default 0
    if ($rarityBonusStepsApplied -lt 0 -or $rarityBonusStepsApplied -gt $maxBonusSteps) {
        throw "Guardian trade item #$Index rarityBonusStepsApplied must be between 0 and pending request effectiveRarityCeilingBonusSteps ($maxBonusSteps)."
    }

    if (!(Test-BoeGuardianRarityAllowedForTradeTier -Rarity $rarity -GenerationReputationTier $GenerationReputationTier -RarityBonusStepsApplied $rarityBonusStepsApplied)) {
        throw "Guardian trade item #$Index rarity '$rarity' exceeds generationReputationTier '$GenerationReputationTier' with rarityBonusStepsApplied=$rarityBonusStepsApplied."
    }

    $slotId = Get-BoeFirstNonEmptyJsonString -Object $Item -Names @("slotId")
    if ([string]::IsNullOrWhiteSpace($slotId)) {
        $requestId = Get-BoeFirstNonEmptyJsonString -Object $Request -Names @("requestId")
        $slotId = "$requestId-slot-$Index"
        Set-BoeJsonProperty -Object $Item -Name "slotId" -Value $slotId
    }

    Set-BoeJsonProperty -Object $Item -Name "priceInFeathers" -Value (Get-BoeGuardianTradeBuyPrice -Rarity $rarity -PricingReputationTier $PricingReputationTier)
    Set-BoeJsonProperty -Object $Item -Name "rarityBonusStepsApplied" -Value $rarityBonusStepsApplied

    if ($null -eq (Get-BoeJsonValue -Object $Item -Names @("soldOut"))) {
        Set-BoeJsonProperty -Object $Item -Name "soldOut" -Value $false
    }

    if ([string]::IsNullOrWhiteSpace((Get-BoeFirstNonEmptyJsonString -Object $Item -Names @("domainTag")))) {
        Set-BoeJsonProperty -Object $Item -Name "domainTag" -Value "Витрина Хранителя"
    }

    return $Item
}

function Complete-BoeGuardianTradeInventoryRequest {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RequestId,

        [Parameter(Mandatory = $true)]
        [object[]]$Items
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'write' -Body { Complete-BoeGuardianTradeInventoryRequest @boeCallArguments }
    }


    if ([string]::IsNullOrWhiteSpace($RequestId)) {
        throw "RequestId is required for Complete-BoeGuardianTradeInventoryRequest."
    }

    $pendingRoot = Read-BoeJson -RelativePath "game_state/control/pending_guardian_trade_request.json"
    $request = Find-BoeGuardianTradeRequest -PendingRoot $pendingRoot -RequestId $RequestId
    if ($null -eq $request) {
        throw "Guardian trade request not found: $RequestId"
    }

    $guardianId = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("guardianId")
    if ([string]::IsNullOrWhiteSpace($guardianId)) {
        throw "Guardian trade request '$RequestId' is missing guardianId."
    }

    $guardiansRoot = Read-BoeJson -RelativePath "game_state/meta/guardians.json"
    $guardian = Find-BoeCanonicalGuardianObject -GuardiansRoot $guardiansRoot -GuardianId $guardianId
    if ($null -eq $guardian) {
        throw "Guardian trade request '$RequestId' references unknown guardian '$guardianId'."
    }

    $expectedCount = Get-BoeJsonInt -Object $request -Names @("derivedTradeSlotCount") -Default 0
    $currentReputation = Get-BoeJsonInt -Object $request -Names @("currentReputation") -Default 0
    $tradeTier = Get-BoeGuardianExpectedTradeTierCode -Reputation $currentReputation

    $itemList = New-Object System.Collections.Generic.List[object]
    $seenSlotIds = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    $index = 1
    foreach ($item in @($Items)) {
        $normalizedItem = Normalize-BoeGuardianTradeItem -Item $item -Request $request -GenerationReputationTier $tradeTier -PricingReputationTier $tradeTier -Index $index
        $slotId = Get-BoeFirstNonEmptyJsonString -Object $normalizedItem -Names @("slotId")
        if (!$seenSlotIds.Add($slotId)) {
            throw "Guardian trade request '$RequestId' has duplicate slotId '$slotId'."
        }

        $itemList.Add($normalizedItem)
        $index++
    }

    if ($expectedCount -gt 0 -and $itemList.Count -ne $expectedCount) {
        throw "Guardian trade request '$RequestId' expects $expectedCount trade items, but helper received $($itemList.Count)."
    }

    $signature = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("projectBonusSignature")
    $tradeInventory = [ordered]@{
        tradeCycleId = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("returnCycleId")
        generatedAtUtc = [DateTimeOffset]::UtcNow.ToString("O")
        generationReputationTier = $tradeTier
        pricingReputationTier = $tradeTier
        projectBonusSignature = $signature
        upgradedTradeSlots = Get-BoeGuardianTradeBonusSignaturePart -Signature $signature -Index 0
        elevatedTradeSlots = Get-BoeGuardianTradeBonusSignaturePart -Signature $signature -Index 1
        effectiveRarityCeilingBonusSteps = Get-BoeJsonInt -Object $request -Names @("effectiveRarityCeilingBonusSteps") -Default 0
        items = [object[]]$itemList.ToArray()
    }

    Set-BoeJsonProperty -Object $guardian -Name "tradeInventory" -Value $tradeInventory

    $createdAtTurn = Get-BoeJsonInt -Object $request -Names @("createdAtTurn") -Default 0
    $receipt = [ordered]@{
        requestId = $RequestId
        guardianId = $guardianId
        guardianName = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("guardianName")
        abodeId = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("abodeId")
        tradeCycleId = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("returnCycleId")
        status = "ready"
        itemCount = $itemList.Count
        resolvedAtTurn = [int]$createdAtTurn
        resolvedAtUtc = [DateTimeOffset]::UtcNow.ToString("O")
    }

    $null = Add-BoeJsonArrayItem -Object $guardian -PropertyName "tradeInventoryReceipts" -Item $receipt -UniqueBy "requestId"
    $null = Add-BoeJsonArrayItem -Object $guardiansRoot -PropertyName "UpdateGuardianTradeInventoryReceipts" -Item $receipt -UniqueBy "requestId"

    $activeGuardian = Get-BoeJsonValue -Object $guardiansRoot -Names @("activeGuardian")
    if ($null -ne $activeGuardian) {
        $activeGuardianId = Get-BoeFirstNonEmptyJsonString -Object $activeGuardian -Names @("guardianId", "id")
        if (Test-BoeJsonTextEquals -Left $activeGuardianId -Right $guardianId) {
            Set-BoeJsonProperty -Object $activeGuardian -Name "tradeInventory" -Value $tradeInventory
            $null = Add-BoeJsonArrayItem -Object $activeGuardian -PropertyName "tradeInventoryReceipts" -Item $receipt -UniqueBy "requestId"
        }
    }

    Write-BoeJson -RelativePath "game_state/meta/guardians.json" -Data $guardiansRoot -Depth 100
}

function Find-BoeTrainingShowcaseRequest {
    param(
        [Parameter(Mandatory = $true)]
        [object]$PendingRoot,

        [Parameter(Mandatory = $true)]
        [string]$RequestId
    )

    foreach ($request in @(Get-BoeJsonArrayItems -Value (Get-BoeJsonValue -Object $PendingRoot -Names @("requests")))) {
        $candidateRequestId = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("requestId")
        if (Test-BoeJsonTextEquals -Left $candidateRequestId -Right $RequestId) {
            return $request
        }
    }

    $singleRequestId = Get-BoeFirstNonEmptyJsonString -Object $PendingRoot -Names @("requestId")
    if (Test-BoeJsonTextEquals -Left $singleRequestId -Right $RequestId) {
        return $PendingRoot
    }

    return $null
}

function Find-BoeAfterlifeMentorProfile {
    param(
        [Parameter(Mandatory = $true)]
        [object]$ProfilesRoot,

        [Parameter(Mandatory = $true)]
        [string]$ActorId
    )

    foreach ($arrayName in @("profiles", "entityProfiles", "afterlifeEntityProfiles", "actors")) {
        foreach ($profile in @(Get-BoeJsonArrayItems -Value (Get-BoeJsonValue -Object $ProfilesRoot -Names @($arrayName)))) {
            $candidateId = Get-BoeFirstNonEmptyJsonString -Object $profile -Names @("actorId", "actorRef", "guardianId", "id", "initialId")
            if (Test-BoeJsonTextEquals -Left $candidateId -Right $ActorId) {
                return $profile
            }
        }
    }

    return $null
}

function Get-BoeTrainingActorCap {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Actor,

        [Parameter(Mandatory = $true)]
        [string]$RequestKind,

        [Parameter(Mandatory = $true)]
        [string]$TargetKind,

        [Parameter(Mandatory = $true)]
        [string]$TargetId
    )

    if ([string]::Equals($RequestKind, "mortal_teacher_showcase", [System.StringComparison]::OrdinalIgnoreCase)) {
        $teacherProfile = Get-BoeJsonValue -Object $Actor -Names @("teacherProfile")
        foreach ($skill in @(Get-BoeJsonArrayItems -Value (Get-BoeJsonValue -Object $teacherProfile -Names @("skills", "teachableSkills")))) {
            $skillId = Get-BoeFirstNonEmptyJsonString -Object $skill -Names @("skillId", "targetId", "id")
            $skillName = Get-BoeFirstNonEmptyJsonString -Object $skill -Names @("skillName", "displayName", "name")
            if ((Test-BoeJsonTextEquals -Left $skillId -Right $TargetId) -or (Test-BoeJsonTextEquals -Left $skillName -Right $TargetId)) {
                foreach ($capField in @("maxMasteryLevel", "currentMasteryLevel", "masteryLevel", "level", "sourceCap")) {
                    $cap = Get-BoeJsonInt -Object $skill -Names @($capField) -Default 0
                    if ($cap -gt 0) {
                        return $cap
                    }
                }
            }
        }

        return 0
    }

    if (![string]::Equals($RequestKind, "afterlife_teacher_showcase", [System.StringComparison]::OrdinalIgnoreCase)) {
        return 0
    }

    if ([string]::Equals($TargetKind, "spirit_focus", [System.StringComparison]::OrdinalIgnoreCase)) {
        $mentorProfile = Get-BoeJsonValue -Object $Actor -Names @("mentorProfile")
        return Get-BoeJsonInt -Object $mentorProfile -Names @("spiritFocusTier", "focusTier", "sourceCap") -Default 0
    }

    $standardArts = Get-BoeJsonValue -Object $Actor -Names @("standardArts")
    if ($null -ne $standardArts) {
        $cap = Get-BoeJsonInt -Object $standardArts -Names @($TargetId) -Default 0
        if ($cap -gt 0) {
            return $cap
        }
    }

    foreach ($art in @(Get-BoeJsonArrayItems -Value (Get-BoeJsonValue -Object $Actor -Names @("specialArts", "knownSpecialArts", "arts")))) {
        $artId = Get-BoeFirstNonEmptyJsonString -Object $art -Names @("artId", "targetId", "id", "name")
        if (Test-BoeJsonTextEquals -Left $artId -Right $TargetId) {
            foreach ($capField in @("sourceCap", "tier", "currentTier", "maxTier", "level")) {
                $cap = Get-BoeJsonInt -Object $art -Names @($capField) -Default 0
                if ($cap -gt 0) {
                    return $cap
                }
            }
        }
    }

    return 0
}

function Test-BoeTrainingCostHasPositiveValue {
    param(
        [AllowNull()]
        [object]$Cost,

        [Parameter(Mandatory = $true)]
        [string[]]$Names
    )

    if ($null -eq $Cost) {
        return $false
    }

    foreach ($name in @($Names)) {
        if ((Get-BoeJsonInt -Object $Cost -Names @($name) -Default 0) -gt 0) {
            return $true
        }
    }

    return $false
}

function Normalize-BoeTrainingOffer {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Offer,

        [Parameter(Mandatory = $true)]
        [object]$Request,

        [Parameter(Mandatory = $true)]
        [object]$Actor,

        [Parameter(Mandatory = $true)]
        [int]$Index
    )

    $requestId = Get-BoeFirstNonEmptyJsonString -Object $Request -Names @("requestId")
    $requestKind = Get-BoeFirstNonEmptyJsonString -Object $Request -Names @("requestKind")

    $offerId = Get-BoeFirstNonEmptyJsonString -Object $Offer -Names @("offerId", "id")
    if ([string]::IsNullOrWhiteSpace($offerId)) {
        throw "Training showcase request '$requestId' offer #$Index is missing offerId."
    }

    if ([string]::IsNullOrWhiteSpace((Get-BoeFirstNonEmptyJsonString -Object $Offer -Names @("offerId")))) {
        Set-BoeJsonProperty -Object $Offer -Name "offerId" -Value $offerId
    }

    $targetKind = Get-BoeFirstNonEmptyJsonString -Object $Offer -Names @("targetKind", "kind")
    if ([string]::IsNullOrWhiteSpace($targetKind)) {
        throw "Training showcase request '$requestId' offer '$offerId' is missing targetKind."
    }

    Set-BoeJsonProperty -Object $Offer -Name "targetKind" -Value $targetKind

    $targetId = Get-BoeFirstNonEmptyJsonString -Object $Offer -Names @("targetId", "skillId", "artId", "id")
    if ([string]::IsNullOrWhiteSpace($targetId)) {
        throw "Training showcase request '$requestId' offer '$offerId' is missing targetId."
    }

    Set-BoeJsonProperty -Object $Offer -Name "targetId" -Value $targetId

    if ([string]::IsNullOrWhiteSpace((Get-BoeFirstNonEmptyJsonString -Object $Offer -Names @("targetName", "displayName", "name")))) {
        Set-BoeJsonProperty -Object $Offer -Name "targetName" -Value $targetId
    }

    $actorCap = Get-BoeTrainingActorCap -Actor $Actor -RequestKind $requestKind -TargetKind $targetKind -TargetId $targetId
    $sourceCap = Get-BoeJsonInt -Object $Offer -Names @("sourceCap", "maxValue", "teacherCap", "mentorCap") -Default 0
    if ($sourceCap -le 0 -and $actorCap -gt 0) {
        $sourceCap = $actorCap
        Set-BoeJsonProperty -Object $Offer -Name "sourceCap" -Value $sourceCap
    }

    if ($sourceCap -le 0) {
        throw "Training showcase request '$requestId' offer '$offerId' must define positive sourceCap, or the helper must be able to infer it from the teacher/mentor."
    }

    if ($actorCap -gt 0 -and $sourceCap -gt $actorCap) {
        throw "Training showcase request '$requestId' offer '$offerId' sourceCap $sourceCap exceeds teacher/mentor cap $actorCap."
    }

    $targetValue = Get-BoeJsonInt -Object $Offer -Names @("targetValue", "targetTier", "targetMasteryLevel", "targetLevel") -Default 0
    if ($targetValue -le 0) {
        throw "Training showcase request '$requestId' offer '$offerId' must define a positive targetValue."
    }

    Set-BoeJsonProperty -Object $Offer -Name "targetValue" -Value $targetValue

    if ($targetValue -gt $sourceCap) {
        throw "Training showcase request '$requestId' offer '$offerId' targetValue $targetValue exceeds sourceCap $sourceCap."
    }

    $cost = Get-BoeJsonValue -Object $Offer -Names @("cost")
    if ($null -eq $cost) {
        throw "Training showcase request '$requestId' offer '$offerId' is missing cost."
    }

    if ([string]::Equals($requestKind, "mortal_teacher_showcase", [System.StringComparison]::OrdinalIgnoreCase)) {
        if (!(Test-BoeTrainingCostHasPositiveValue -Cost $cost -Names @("money")) -or
            !(Test-BoeTrainingCostHasPositiveValue -Cost $cost -Names @("currentLevelExperiencePercent"))) {
            throw "Training showcase request '$requestId' offer '$offerId' mortal cost must include positive money and currentLevelExperiencePercent."
        }
    }
    elseif ([string]::Equals($requestKind, "afterlife_teacher_showcase", [System.StringComparison]::OrdinalIgnoreCase)) {
        if (!(Test-BoeTrainingCostHasPositiveValue -Cost $cost -Names @("inkFeathers", "lightSparks"))) {
            throw "Training showcase request '$requestId' offer '$offerId' afterlife cost must include positive inkFeathers or lightSparks."
        }
    }

    return $Offer
}

function New-BoeTrainingShowcase {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Request,

        [Parameter(Mandatory = $true)]
        [object[]]$Offers,

        [string]$Summary = ""
    )

    $createdAtTurn = Get-BoeJsonInt -Object $Request -Names @("createdAtTurn") -Default 0
    $showcase = [ordered]@{
        schemaVersion = 1
        requestId = Get-BoeFirstNonEmptyJsonString -Object $Request -Names @("requestId")
        requestKind = Get-BoeFirstNonEmptyJsonString -Object $Request -Names @("requestKind")
        sourceActorId = Get-BoeFirstNonEmptyJsonString -Object $Request -Names @("sourceActorId")
        sourceActorName = Get-BoeFirstNonEmptyJsonString -Object $Request -Names @("sourceActorName")
        sourceActorSnapshotHash = Get-BoeFirstNonEmptyJsonString -Object $Request -Names @("sourceActorSnapshotHash")
        preparedAtTurn = [int]$createdAtTurn
        preparedAtUtc = [DateTimeOffset]::UtcNow.ToString("O")
        offers = [object[]]$Offers
    }

    if (![string]::IsNullOrWhiteSpace($Summary)) {
        $showcase["summary"] = $Summary
    }

    return $showcase
}

function Complete-BoeTrainingShowcaseRequest {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RequestId,

        [Parameter(Mandatory = $true)]
        [object[]]$Offers,

        [string]$Summary = ""
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'write' -Body { Complete-BoeTrainingShowcaseRequest @boeCallArguments }
    }


    if ([string]::IsNullOrWhiteSpace($RequestId)) {
        throw "RequestId is required for Complete-BoeTrainingShowcaseRequest."
    }

    $pendingRoot = Read-BoeJson -RelativePath "game_state/control/pending_training_showcase_requests.json"
    $request = Find-BoeTrainingShowcaseRequest -PendingRoot $pendingRoot -RequestId $RequestId
    if ($null -eq $request) {
        throw "Training showcase request not found: $RequestId"
    }

    $requestKind = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("requestKind")
    $sourceActorId = Get-BoeFirstNonEmptyJsonString -Object $request -Names @("sourceActorId", "teacherId", "mentorId", "npcId", "guardianId")
    if ([string]::IsNullOrWhiteSpace($sourceActorId)) {
        throw "Training showcase request '$RequestId' is missing sourceActorId."
    }

    $rootRelativePath = ""
    $root = $null
    $actor = $null
    $showcaseProperty = ""

    if ([string]::Equals($requestKind, "mortal_teacher_showcase", [System.StringComparison]::OrdinalIgnoreCase)) {
        $rootRelativePath = "game_state/npcs/npc_core.json"
        $root = Read-BoeJson -RelativePath $rootRelativePath
        $actor = Find-BoeCanonicalNpcObject -NpcRoot $root -NpcId $sourceActorId
        if ($null -eq $actor) {
            throw "Training showcase request '$RequestId' references unknown Mortal teacher '$sourceActorId'. Ensure npc_core.json contains NPCId, npcId, id, or initialId for the teacher."
        }

        $showcaseProperty = "trainingShowcase"
    }
    elseif ([string]::Equals($requestKind, "afterlife_teacher_showcase", [System.StringComparison]::OrdinalIgnoreCase)) {
        $rootRelativePath = "game_state/meta/afterlife_entity_profiles.json"
        $root = Read-BoeJson -RelativePath $rootRelativePath
        $actor = Find-BoeAfterlifeMentorProfile -ProfilesRoot $root -ActorId $sourceActorId
        if ($null -eq $actor) {
            throw "Training showcase request '$RequestId' references unknown afterlife mentor '$sourceActorId'. Ensure afterlife_entity_profiles.json contains actorId, actorRef, guardianId, id, or initialId for the mentor."
        }

        $showcaseProperty = "mentorTrainingShowcase"
    }
    else {
        throw "Training showcase request '$RequestId' has unsupported requestKind '$requestKind'. Use this helper for mortal_teacher_showcase and afterlife_teacher_showcase only."
    }

    $offerList = New-Object System.Collections.Generic.List[object]
    $seenOfferIds = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    $index = 1
    foreach ($offer in @($Offers)) {
        $normalizedOffer = Normalize-BoeTrainingOffer -Offer $offer -Request $request -Actor $actor -Index $index
        $offerId = Get-BoeFirstNonEmptyJsonString -Object $normalizedOffer -Names @("offerId")
        if (!$seenOfferIds.Add($offerId)) {
            throw "Training showcase request '$RequestId' has duplicate offerId '$offerId'."
        }

        $offerList.Add($normalizedOffer)
        $index++
    }

    if ($offerList.Count -le 0) {
        throw "Training showcase request '$RequestId' must receive at least one offer."
    }

    $showcase = New-BoeTrainingShowcase -Request $request -Offers ([object[]]$offerList.ToArray()) -Summary $Summary
    Set-BoeJsonProperty -Object $actor -Name $showcaseProperty -Value $showcase
    Write-BoeJson -RelativePath $rootRelativePath -Data $root -Depth 100

    return $showcase
}

function Normalize-BoeRelativePath {
    param(
        [AllowNull()]
        [string]$RelativePath
    )

    if ([string]::IsNullOrWhiteSpace($RelativePath)) {
        return ""
    }

    return $RelativePath.Replace([IO.Path]::DirectorySeparatorChar, '/').TrimStart('/').Trim()
}

function Convert-BoeFullPathToSessionRelativePath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$FullPath
    )

    Assert-BoeGmTurnHelperInitialized

    $full = [System.IO.Path]::GetFullPath($FullPath)
    $sessionRoot = [System.IO.Path]::GetFullPath($script:BoeGameSessionPath).TrimEnd(
        [System.IO.Path]::DirectorySeparatorChar,
        [System.IO.Path]::AltDirectorySeparatorChar)
    $prefix = $sessionRoot + [System.IO.Path]::DirectorySeparatorChar

    if ([string]::Equals($full, $sessionRoot, $script:BoePathComparison)) {
        return ""
    }

    if (!$full.StartsWith($prefix, $script:BoePathComparison)) {
        throw "Path is outside game_session: $FullPath"
    }

    return $full.Substring($prefix.Length).Replace([IO.Path]::DirectorySeparatorChar, '/')
}

function Get-BoePolicyRelativePath {
    param(
        [AllowNull()]
        [string]$Path
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Get-BoePolicyRelativePath @boeCallArguments }
    }


    if ([string]::IsNullOrWhiteSpace($Path)) {
        return ""
    }

    $fullPath=Resolve-BoeSessionPath -RelativePath $Path
    return Convert-BoeFullPathToSessionRelativePath -FullPath $fullPath
}

function Test-BoeClientOwnedRuntimePath {
    param(
        [AllowNull()]
        [string]$RelativePath
    )

    $path = Normalize-BoeRelativePath -RelativePath $RelativePath
    if ([string]::IsNullOrWhiteSpace($path)) {
        return $false
    }

    if ([string]::Equals($path, "input/turn_request.json", [System.StringComparison]::OrdinalIgnoreCase)) {
        return $true
    }

    if ([string]::Equals($path, "game_state/history/chat_log.json", [System.StringComparison]::OrdinalIgnoreCase)) {
        return $true
    }

    if ([string]::Equals($path, "game_state/control/next_life_scenario_core.json", [System.StringComparison]::OrdinalIgnoreCase) -or
        [string]::Equals($path, "lore/current_world/world_directives.json", [System.StringComparison]::OrdinalIgnoreCase)) {
        return $true
    }

    foreach ($clientOwnedPath in @(
        "game_state/control/spiritual_wound_capture_checkpoint.json",
        "game_state/control/pending_spiritual_wound_decisions.json",
        "game_state/wounds/spiritual_wound_opportunity_receipts.json",
        "input/qte_effect_resolution_request.json",
        "output/qte_effect_resolution_receipts.json",
        "ready/qte_effect_resolution_complete.json",
        "game_state/core/system_mods.json",
        "game_state/control/progression_schedule.json",
        "game_state/control/qte_deferred_effect_continuation.json",
        "game_state/resources/resource_definitions.json",
        "game_state/resources/resource_state.json",
        "game_state/resources/resource_history.json",
        "game_state/resources/resource_owner_authority.json",
        "game_state/control/pending_effect_resolutions.json",
        "game_state/effects/effect_identity_index.json"
    )) {
        if ([string]::Equals($path, $clientOwnedPath, [System.StringComparison]::OrdinalIgnoreCase)) {
            return $true
        }
    }

    if ([string]::Equals($path, "game_state/control/pending_turn_snapshot.json", [System.StringComparison]::OrdinalIgnoreCase) -or
        [string]::Equals($path, "game_state/control/pending_turn_snapshot.authority.json", [System.StringComparison]::OrdinalIgnoreCase) -or
        [string]::Equals($path, "game_state/control/pending_turn_snapshot_manifest.json", [System.StringComparison]::OrdinalIgnoreCase) -or
        $path.StartsWith("game_state/control/pending_turn_snapshot/", [System.StringComparison]::OrdinalIgnoreCase)) {
        return $true
    }

    if ([string]::Equals($path, "game_state/control/validation_repair_request.json", [System.StringComparison]::OrdinalIgnoreCase) -or
        [string]::Equals($path, "game_state/control/validation_diagnostic_failure_report.json", [System.StringComparison]::OrdinalIgnoreCase) -or
        [string]::Equals($path, "game_state/control/terminal_protocol_failure_request.json", [System.StringComparison]::OrdinalIgnoreCase) -or
        [string]::Equals($path, "game_state/control/gm_bridge_status.json", [System.StringComparison]::OrdinalIgnoreCase)) {
        return $true
    }

    if ($path.StartsWith("stories/", [System.StringComparison]::OrdinalIgnoreCase) -and
        $path.EndsWith(".jsonl", [System.StringComparison]::OrdinalIgnoreCase)) {
        return $true
    }

    return $false
}

function Get-BoeCurrentRealm {
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Get-BoeCurrentRealm @boeCallArguments }
    }

    Assert-BoeGmTurnHelperInitialized

    $path = Resolve-BoeSessionPath -RelativePath "game_state/meta/soul_state.json"
    if (!(Test-BoePath -LiteralPath $path)) {
        return ""
    }

    $boeJsonText=Read-BoeText $path
    try {
        $state = $boeJsonText | ConvertFrom-Json
        $realm = Get-BoeJsonValue -Object $state -Names @("currentRealm")
        if ($null -eq $realm) {
            return ""
        }

        return [string]$realm
    }
    catch {
        Assert-BoeNotStorageFailure $_
        return ""
    }
}

function Test-BoeAfterlifeRealm {
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Test-BoeAfterlifeRealm @boeCallArguments }
    }

    $realm = Get-BoeCurrentRealm
    return [string]::Equals($realm, "Chaos Sea", [System.StringComparison]::OrdinalIgnoreCase) -or
        [string]::Equals($realm, "Shining Abode", [System.StringComparison]::OrdinalIgnoreCase)
}

function Test-BoeMortalWorldProfilePath {
    param(
        [AllowNull()]
        [string]$RelativePath
    )

    $path = Normalize-BoeRelativePath -RelativePath $RelativePath
    if ([string]::IsNullOrWhiteSpace($path)) {
        return $false
    }

    foreach ($prefix in @(
        "game_state/world/",
        "game_state/npcs/",
        "game_state/factions/",
        "game_state/player/",
        "game_state/inventory/",
        "game_state/combat/",
        "game_state/quests/"
    )) {
        if ($path.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
            return $true
        }
    }

    return $false
}

function Test-BoeRollbackArtifactPath {
    param(
        [AllowNull()]
        [string]$RelativePath
    )

    $path = Normalize-BoeRelativePath -RelativePath $RelativePath
    if ([string]::IsNullOrWhiteSpace($path)) {
        return $false
    }

    return $path.IndexOf(".rollback.", [System.StringComparison]::OrdinalIgnoreCase) -ge 0
}

function Assert-BoeRealmWritableRuntimePath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Assert-BoeRealmWritableRuntimePath @boeCallArguments }
    }


    $policyPath = Get-BoePolicyRelativePath -Path $RelativePath
    if ((Test-BoeMortalWorldProfilePath -RelativePath $policyPath) -and (Test-BoeAfterlifeRealm)) {
        $realm = Get-BoeCurrentRealm
        throw "Path is wrong realm Mortal World profile state while currentRealm is '$realm' and must not be written by the GM helper: $RelativePath"
    }
}

function Assert-BoeGmWritableRuntimePath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Assert-BoeGmWritableRuntimePath @boeCallArguments }
    }


    $policyPath = Get-BoePolicyRelativePath -Path $RelativePath
    if (Test-BoeClientOwnedRuntimePath -RelativePath $policyPath) {
        throw "Path is client-owned runtime state and must not be written by the GM helper: $policyPath (requested: $RelativePath)"
    }

    Assert-BoeRealmWritableRuntimePath -RelativePath $policyPath
}

function Assert-BoeGmFilesModifiedEntries {
    param(
        [AllowNull()]
        [string[]]$FilesModified
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Assert-BoeGmFilesModifiedEntries @boeCallArguments }
    }


    foreach ($entry in @($FilesModified)) {
        $policyPath = Get-BoePolicyRelativePath -Path $entry
        if (Test-BoeClientOwnedRuntimePath -RelativePath $policyPath) {
            throw "filesModified contains client-owned runtime state. Remove this entry and let the client maintain it: $policyPath (requested: $entry)"
        }

        Assert-BoeRealmWritableRuntimePath -RelativePath $policyPath
    }
}

function Test-BoeTerminalSignalPath {
    param(
        [AllowNull()]
        [string]$RelativePath
    )

    $path = Normalize-BoeRelativePath -RelativePath $RelativePath
    return [string]::Equals($path, "ready/turn_complete.json", [System.StringComparison]::OrdinalIgnoreCase) -or
        [string]::Equals($path, "ready/turn_error.json", [System.StringComparison]::OrdinalIgnoreCase)
}

function Read-BoeTerminalSignalOrNull {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Read-BoeTerminalSignalOrNull @boeCallArguments }
    }


    $path = Resolve-BoeSessionPath -RelativePath $RelativePath
    if (!(Test-BoePath -LiteralPath $path)) {
        return $null
    }

    $boeJsonText=Read-BoeText $path
    try {
        return $boeJsonText | ConvertFrom-Json
    }
    catch {
        Assert-BoeNotStorageFailure $_
        throw "Existing terminal signal is unreadable: $RelativePath. Let the client clean stale ready state before writing more runtime data."
    }
}

function Test-BoeTerminalSignalMatchesTurn {
    param(
        [AllowNull()]
        [object]$Signal,

        [Parameter(Mandatory = $true)]
        [object]$TurnRequest
    )

    if ($null -eq $Signal) {
        return $false
    }

    return [string]$Signal.sessionId -eq [string]$TurnRequest.sessionId -and
        [string]$Signal.requestId -eq [string]$TurnRequest.requestId -and
        [int]$Signal.turnNumber -eq [int]$TurnRequest.turnNumber
}

function Assert-BoeNoExistingTerminalSignalForTurn {
    param(
        [Parameter(Mandatory = $true)]
        [object]$TurnRequest,

        [Parameter(Mandatory = $true)]
        [string]$Operation
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Assert-BoeNoExistingTerminalSignalForTurn @boeCallArguments }
    }


    foreach ($terminalPath in @("ready/turn_complete.json", "ready/turn_error.json")) {
        $signal = Read-BoeTerminalSignalOrNull -RelativePath $terminalPath
        if ($null -eq $signal) {
            continue
        }

        if (Test-BoeTerminalSignalMatchesTurn -Signal $signal -TurnRequest $TurnRequest) {
            throw "$Operation blocked: current request already has terminal signal $terminalPath. Do not write stale runtime data after success/error; wait for the client rollback/cleanup cycle and resend a fresh turn if needed."
        }

        throw "$Operation blocked: existing terminal signal $terminalPath belongs to another request. Let the client clean stale ready state before writing more runtime data."
    }
}

function Get-BoeCurrentTurnRequestOrNull {
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Get-BoeCurrentTurnRequestOrNull @boeCallArguments }
    }

    $path = Resolve-BoeSessionPath -RelativePath "input/turn_request.json"
    if (!(Test-BoePath -LiteralPath $path)) {
        return $null
    }

    $boeJsonText=Read-BoeText $path
    try {
        return $boeJsonText | ConvertFrom-Json
    }
    catch {
        Assert-BoeNotStorageFailure $_
        throw "Current input/turn_request.json is unreadable; do not write runtime state until the client repairs or clears the pending turn."
    }
}

function Test-BoeActiveValidationRepairRequestForTurn {
    param(
        [Parameter(Mandatory = $true)]
        [object]$TurnRequest
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Test-BoeActiveValidationRepairRequestForTurn @boeCallArguments }
    }


    $path = Resolve-BoeSessionPath -RelativePath "game_state/control/validation_repair_request.json"
    if (!(Test-BoePath -LiteralPath $path)) {
        return $false
    }

    $boeJsonText=Read-BoeText $path
    try {
        $repair = $boeJsonText | ConvertFrom-Json
        if ($repair.metadataDiagnosticOnly) {
            return $false
        }

        return [string]$repair.sessionId -eq [string]$TurnRequest.sessionId -and
            [string]$repair.requestId -eq [string]$TurnRequest.requestId -and
            [int]$repair.turnNumber -eq [int]$TurnRequest.turnNumber
    }
    catch {
        Assert-BoeNotStorageFailure $_
        return $false
    }
}

function Assert-BoeNoTerminalSignalBeforeRuntimeWrite {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Assert-BoeNoTerminalSignalBeforeRuntimeWrite @boeCallArguments }
    }


    if (Test-BoeTerminalSignalPath -RelativePath $RelativePath) {
        return
    }

    $turn = Get-BoeCurrentTurnRequestOrNull
    if ($null -eq $turn) {
        return
    }

    if (Test-BoeActiveValidationRepairRequestForTurn -TurnRequest $turn) {
        return
    }

    Assert-BoeNoExistingTerminalSignalForTurn -TurnRequest $turn -Operation "Write-BoeJson"
}

function Get-BoeFileSha256 {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Get-BoeFileSha256 @boeCallArguments }
    }


    if (!(Test-BoePath -LiteralPath $Path)) {
        return ""
    }

    return (Get-BoeSha256Hex -Bytes (Read-BoeBytes $Path)).ToUpperInvariant()
}

function ConvertTo-BoeCanonicalJsonString {
    param(
        [AllowNull()]
        $Value
    )

    if ($null -eq $Value) {
        return "null"
    }

    if ($Value -is [System.Management.Automation.PSCustomObject]) {
        $parts = @()
        foreach ($property in @($Value.PSObject.Properties | Sort-Object Name)) {
            $name = ConvertTo-Json -InputObject $property.Name -Compress
            $propertyValue = ConvertTo-BoeCanonicalJsonString -Value $property.Value
            $parts += "${name}:$propertyValue"
        }

        return "{" + ($parts -join ",") + "}"
    }

    if ($Value -is [System.Collections.IDictionary]) {
        $parts = @()
        foreach ($key in @($Value.Keys | Sort-Object)) {
            $name = ConvertTo-Json -InputObject ([string]$key) -Compress
            $propertyValue = ConvertTo-BoeCanonicalJsonString -Value $Value[$key]
            $parts += "${name}:$propertyValue"
        }

        return "{" + ($parts -join ",") + "}"
    }

    if (($Value -is [System.Collections.IEnumerable]) -and !($Value -is [string])) {
        $items = @()
        foreach ($item in $Value) {
            $items += ConvertTo-BoeCanonicalJsonString -Value $item
        }

        return "[" + ($items -join ",") + "]"
    }

    return ConvertTo-Json -InputObject $Value -Compress
}

function Get-BoeComparableFileSignature {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Get-BoeComparableFileSignature @boeCallArguments }
    }


    if (!(Test-BoePath -LiteralPath $Path)) {
        return ""
    }

    if ([string]::Equals([System.IO.Path]::GetExtension($Path), ".json", [System.StringComparison]::OrdinalIgnoreCase)) {
        $raw = Read-BoeText $Path
        try {
            $parsed = ConvertFrom-Json -InputObject $raw
            return "json:" + (ConvertTo-BoeCanonicalJsonString -Value $parsed)
        }
        catch {
        Assert-BoeNotStorageFailure $_
            # Invalid JSON still needs deterministic comparison; fall back to byte identity.
        }
    }

    return "sha256:" + (Get-BoeFileSha256 -Path $Path)
}

function Get-BoeRawMortalWorldProfileMutations {
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Get-BoeRawMortalWorldProfileMutations @boeCallArguments }
    }

    if (!(Test-BoeAfterlifeRealm)) {
        return @()
    }

    $snapshotRoot = Resolve-BoeSessionPath -RelativePath "game_state/control/pending_turn_snapshot"
    if (!(Test-BoePath -LiteralPath $snapshotRoot)) {
        return @()
    }

    $violations = @()
    $seenCurrentPaths = [Collections.Generic.Dictionary[string,bool]]::new($script:BoePathComparer)
    foreach ($prefix in @(
        "game_state/world",
        "game_state/npcs",
        "game_state/factions",
        "game_state/player",
        "game_state/inventory",
        "game_state/combat",
        "game_state/quests"
    )) {
        $root = Resolve-BoeSessionPath -RelativePath $prefix
        if (!(Test-BoePath -LiteralPath $root)) {
            continue
        }

        foreach ($file in Get-BoeFiles -LiteralPath $root) {
            $relativePath = Convert-BoeFullPathToSessionRelativePath -FullPath $file.FullName
            if (!(Test-BoeMortalWorldProfilePath -RelativePath $relativePath)) {
                continue
            }

            if (Test-BoeRollbackArtifactPath -RelativePath $relativePath) {
                continue
            }

            $seenCurrentPaths[$relativePath] = $true
            $snapshotPath = [IO.Path]::Combine($snapshotRoot,$relativePath.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
            if (!(Test-BoePath -LiteralPath $snapshotPath)) {
                $violations += [pscustomobject]@{
                    path = $relativePath
                    reason = "new forbidden Mortal World profile file"
                }
                continue
            }

            $currentSignature = Get-BoeComparableFileSignature -Path $file.FullName
            $snapshotSignature = Get-BoeComparableFileSignature -Path $snapshotPath
            if (![string]::Equals($currentSignature, $snapshotSignature, [System.StringComparison]::Ordinal)) {
                $violations += [pscustomobject]@{
                    path = $relativePath
                    reason = "changed from pending-turn snapshot"
                }
            }
        }
    }

    $snapshotRootFull = [System.IO.Path]::GetFullPath($snapshotRoot).TrimEnd(
        [System.IO.Path]::DirectorySeparatorChar,
        [System.IO.Path]::AltDirectorySeparatorChar)
    $snapshotPrefix = $snapshotRootFull + [System.IO.Path]::DirectorySeparatorChar

    foreach ($prefix in @(
        "game_state/world",
        "game_state/npcs",
        "game_state/factions",
        "game_state/player",
        "game_state/inventory",
        "game_state/combat",
        "game_state/quests"
    )) {
        $snapshotPrefixRoot = [IO.Path]::Combine($snapshotRoot,$prefix.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        if (!(Test-BoePath -LiteralPath $snapshotPrefixRoot)) {
            continue
        }

        foreach ($snapshotFile in Get-BoeFiles -LiteralPath $snapshotPrefixRoot) {
            $snapshotFull = [System.IO.Path]::GetFullPath($snapshotFile.FullName)
            if (!$snapshotFull.StartsWith($snapshotPrefix, $script:BoePathComparison)) {
                continue
            }

            $relativePath = Normalize-BoeRelativePath -RelativePath $snapshotFull.Substring($snapshotPrefix.Length)
            if (!(Test-BoeMortalWorldProfilePath -RelativePath $relativePath)) {
                continue
            }

            if (Test-BoeRollbackArtifactPath -RelativePath $relativePath) {
                continue
            }

            if ($seenCurrentPaths.ContainsKey($relativePath)) {
                continue
            }

            $currentPath = Resolve-BoeSessionPath -RelativePath $relativePath
            if (!(Test-BoePath -LiteralPath $currentPath)) {
                $violations += [pscustomobject]@{
                    path = $relativePath
                    reason = "deleted from pending-turn snapshot"
                }
            }
        }
    }

    return $violations
}

function Assert-BoeNoRawMortalWorldProfileMutations {
    param(
        [string]$Operation = "GM turn helper completion"
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Assert-BoeNoRawMortalWorldProfileMutations @boeCallArguments }
    }


    $violations = @(Get-BoeRawMortalWorldProfileMutations)
    if ($violations.Count -eq 0) {
        return
    }

    $details = ($violations |
        Select-Object -First 12 |
        ForEach-Object { "$($_.path) ($($_.reason))" }) -join "; "
    if ($violations.Count -gt 12) {
        $details += "; ..."
    }

    $realm = Get-BoeCurrentRealm
    throw "$Operation blocked: raw wrong-realm Mortal World profile mutations detected while currentRealm is '$realm'. Restore or remove these changes before completing the turn: $details"
}

function Test-BoeFilesModifiedContainsPath {
    param(
        [AllowNull()]
        [string[]]$FilesModified,

        [Parameter(Mandatory = $true)]
        [string]$RelativePath
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Test-BoeFilesModifiedContainsPath @boeCallArguments }
    }


    $target = Normalize-BoeRelativePath -RelativePath $RelativePath
    foreach ($entry in @($FilesModified)) {
        $policyPath = Get-BoePolicyRelativePath -Path $entry
        if ([string]::Equals($policyPath, $target, [System.StringComparison]::OrdinalIgnoreCase)) {
            return $true
        }
    }

    return $false
}

function Test-BoeGuardianLooksLikeSystemPreset {
    param(
        [AllowNull()]
        [object]$Guardian
    )

    if ($null -eq $Guardian) {
        return $false
    }

    $originType = Get-BoeJsonValue -Object $Guardian -Names @("originType")
    if ($null -ne $originType -and [string]::Equals([string]$originType, "system_preset", [System.StringComparison]::OrdinalIgnoreCase)) {
        return $true
    }

    $sourcePreset = Get-BoeJsonValue -Object $Guardian -Names @("sourcePreset")
    if ($null -eq $sourcePreset) {
        return $false
    }

    $presetId = Get-BoeJsonValue -Object $sourcePreset -Names @("presetId")
    return ![string]::IsNullOrWhiteSpace([string]$presetId)
}

function Test-BoeGuardianRootLooksLikeClientOwnedSystemSeed {
    param(
        [AllowNull()]
        [object]$Root
    )

    if ($null -eq $Root) {
        return $false
    }

    $pending = Get-BoeJsonValue -Object $Root -Names @("pendingGuardianCreation")
    if ($null -ne $pending) {
        return $false
    }

    $activeGuardian = Get-BoeJsonValue -Object $Root -Names @("activeGuardian")
    if (Test-BoeGuardianLooksLikeSystemPreset -Guardian $activeGuardian) {
        return $true
    }

    foreach ($guardian in @(Get-BoeJsonArrayItems -Value (Get-BoeJsonValue -Object $Root -Names @("guardians")))) {
        if (Test-BoeGuardianLooksLikeSystemPreset -Guardian $guardian) {
            return $true
        }
    }

    return $false
}

function Test-BoeTurnHasAuthorizedGuardianMutation {
    param(
        [Parameter(Mandatory = $true)]
        [object]$TurnRequest
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Test-BoeTurnHasAuthorizedGuardianMutation @boeCallArguments }
    }


    $playerAction = [string](Get-BoeJsonValue -Object $TurnRequest -Names @("playerAction") -Default "")
    foreach ($marker in @(
        "[SYSTEM_GUARDIAN_ATTRACTION]",
        "[PLAYER_GUARDIAN_FOUNDATION]",
        "[GUARDIAN_TRADE_REQUEST]",
        "[CHAOS_SEA_TRAVEL]",
        "[GUARDIAN_PROVOCATION]",
        "UpdateGuardians",
        "processGacha",
        "startGuardianProjects",
        "completeGuardianProjects",
        "guardianThoughtJournalUpdates",
        "guardianSocialJournalUpdates",
        "guardianPowerEvents"
    )) {
        if ($playerAction.IndexOf($marker, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
            return $true
        }
    }

    foreach ($controlPath in @(
        "game_state/control/system_guardian_attraction.json",
        "game_state/control/pending_player_guardian_foundation.json",
        "game_state/control/pending_guardian_trade_request.json"
    )) {
        $fullPath = Resolve-BoeSessionPath -RelativePath $controlPath
        if (Test-BoePath -LiteralPath $fullPath) {
            return $true
        }
    }

    return $false
}

function Assert-BoeNoUnauthorizedSystemGuardianBootstrapMutation {
    param(
        [Parameter(Mandatory = $true)]
        [object]$TurnRequest,

        [AllowNull()]
        [string[]]$FilesModified
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Assert-BoeNoUnauthorizedSystemGuardianBootstrapMutation @boeCallArguments }
    }


    $turnNumber = [int](Get-BoeJsonValue -Object $TurnRequest -Names @("turnNumber") -Default 0)
    if ($turnNumber -ne 1 -or !(Test-BoeAfterlifeRealm)) {
        return
    }

    $snapshotPath = Resolve-BoeSessionPath -RelativePath "game_state/control/pending_turn_snapshot/game_state/meta/guardians.json"
    if (!(Test-BoePath -LiteralPath $snapshotPath)) {
        return
    }

    $boeJsonText=Read-BoeText $snapshotPath
    try {
        $snapshotRoot = $boeJsonText | ConvertFrom-Json
        if (!(Test-BoeGuardianRootLooksLikeClientOwnedSystemSeed -Root $snapshotRoot)) {
            return
        }
    }
    catch {
        Assert-BoeNotStorageFailure $_
        return
    }

    if (Test-BoeTurnHasAuthorizedGuardianMutation -TurnRequest $TurnRequest) {
        return
    }

    if (Test-BoeFilesModifiedContainsPath -FilesModified $FilesModified -RelativePath "game_state/meta/guardians.json") {
        throw "Complete-BoeTurn blocked: first Chaos Sea system Guardian bootstrap treats game_state/meta/guardians.json as a client-owned Guardian mirror. Do not list guardians.json in FilesModified unless the turn has an authorized Guardian mutation contract."
    }

    $currentPath = Resolve-BoeSessionPath -RelativePath "game_state/meta/guardians.json"
    if (!(Test-BoePath -LiteralPath $currentPath)) {
        throw "Complete-BoeTurn blocked: first Chaos Sea system Guardian bootstrap deleted game_state/meta/guardians.json. Restore the client-owned system Guardian mirror from pending_turn_snapshot before completing the turn."
    }

    $currentSignature = Get-BoeComparableFileSignature -Path $currentPath
    $snapshotSignature = Get-BoeComparableFileSignature -Path $snapshotPath
    if (![string]::Equals($currentSignature, $snapshotSignature, [System.StringComparison]::Ordinal)) {
        throw "Complete-BoeTurn blocked: first Chaos Sea system Guardian bootstrap changed game_state/meta/guardians.json without an authorized Guardian mutation contract. Restore the client-owned system Guardian mirror from pending_turn_snapshot and persist first-meeting memory through afterlife_chronicles instead."
    }
}

function Convert-BoePlayerFacingLineBreakArtifacts {
    param(
        [AllowNull()]
        [object]$Value
    )

    if ($Value -isnot [string] -or [string]::IsNullOrEmpty([string]$Value)) {
        return $Value
    }

    $text = ([string]$Value).Replace('`r`n', "`n").Replace('`n`n', "`n`n")
    $backtick = [char]0x60
    $protectedBackticks = New-Object 'bool[]' $text.Length
    $lineStart = 0
    while ($lineStart -lt $text.Length) {
        $lineEnd = $lineStart
        while ($lineEnd -lt $text.Length -and $text[$lineEnd] -ne [char]13 -and $text[$lineEnd] -ne [char]10) {
            $lineEnd++
        }

        $positions = [System.Collections.Generic.List[int]]::new()
        for ($scan = $lineStart; $scan -lt $lineEnd; $scan++) {
            if ($text[$scan] -eq $backtick) {
                $positions.Add($scan)
            }
        }

        for ($positionIndex = $positions.Count - 1; $positionIndex -ge 0; $positionIndex--) {
            $closingPosition = $positions[$positionIndex]
            $isCandidate = $closingPosition + 1 -lt $text.Length -and $text[$closingPosition + 1] -cin @('n', 'r')
            if ($protectedBackticks[$closingPosition] -or $isCandidate) {
                continue
            }

            for ($openingIndex = $positionIndex - 1; $openingIndex -ge 0; $openingIndex--) {
                $openingPosition = $positions[$openingIndex]
                if ($protectedBackticks[$openingPosition]) {
                    continue
                }

                $protectedBackticks[$openingPosition] = $true
                $protectedBackticks[$closingPosition] = $true
                break
            }
        }

        $lineStart = $lineEnd + 1
    }

    $builder = [System.Text.StringBuilder]::new($text.Length)
    for ($index = 0; $index -lt $text.Length; $index++) {
        if ($text[$index] -ne $backtick) {
            [void]$builder.Append($text[$index])
            continue
        }

        if (-not $protectedBackticks[$index] -and
            $index + 1 -lt $text.Length -and
            $text[$index + 1] -cin @('n', 'r')) {
            [void]$builder.Append("`n")
            $index++
            continue
        }

        [void]$builder.Append($text[$index])
    }

    return $builder.ToString()
}

function Normalize-BoePlayerFacingOutputPayload {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath,

        [Parameter(Mandatory = $true)]
        [object]$Data
    )

    $normalizedPath = $RelativePath.Replace([IO.Path]::DirectorySeparatorChar, '/').TrimStart('/').ToLowerInvariant()
    if ($normalizedPath -eq 'output/narrative_response.json') {
        $response = Get-BoeJsonValue -Object $Data -Names @('response')
        if ($response -is [string]) {
            Set-BoeJsonProperty -Object $Data -Name 'response' -Value (Convert-BoePlayerFacingLineBreakArtifacts -Value $response)
        }
        return $Data
    }

    if ($normalizedPath -ne 'output/interface_updates.json') {
        return $Data
    }

    $dialogueOptions = Get-BoeJsonValue -Object $Data -Names @('dialogueOptions')
    if ($null -eq $dialogueOptions) {
        return $Data
    }

    $normalizedOptions = @()
    foreach ($option in @($dialogueOptions)) {
        if ($option -is [string]) {
            $normalizedOptions += ,(Convert-BoePlayerFacingLineBreakArtifacts -Value $option)
            continue
        }

        if ($null -ne $option) {
            foreach ($propertyName in @('text', 'inputValue')) {
                $propertyValue = Get-BoeJsonValue -Object $option -Names @($propertyName)
                if ($propertyValue -is [string]) {
                    Set-BoeJsonProperty -Object $option -Name $propertyName -Value (Convert-BoePlayerFacingLineBreakArtifacts -Value $propertyValue)
                }
            }
        }
        $normalizedOptions += ,$option
    }

    Set-BoeJsonProperty -Object $Data -Name 'dialogueOptions' -Value ([object[]]$normalizedOptions)
    return $Data
}

function Write-BoeJson {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath,

        [Parameter(Mandatory = $true)]
        [object]$Data,

        [int]$Depth = 100,

        [switch]$AllowClientOwnedRuntimeWrite,

        # Optional exact read witnesses, rechecked under this writer's existing lock.
        [System.Collections.IDictionary]$ExpectedReadWitnesses
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'write' -Body { Write-BoeJson @boeCallArguments }
    }


    # Resolve first: all policy decisions and witnesses name the actual target.
    $path=Resolve-BoeSessionPath -RelativePath $RelativePath
    $RelativePath=Convert-BoeFullPathToSessionRelativePath $path
    if (!$AllowClientOwnedRuntimeWrite) {
        Assert-BoeGmWritableRuntimePath -RelativePath $RelativePath
    }
    Assert-BoeNoTerminalSignalBeforeRuntimeWrite -RelativePath $RelativePath
    $effectiveDepth=[Math]::Max(1,[Math]::Min($Depth,100))
    $normalizedData=Normalize-BoePlayerFacingOutputPayload -RelativePath $RelativePath -Data $Data
    $json=$normalizedData | ConvertTo-Json -Depth $effectiveDepth
    $desiredBytes=[Text.UTF8Encoding]::new($false).GetBytes($json+[Environment]::NewLine)
    $expected=[Collections.Generic.Dictionary[string,object]]::new($script:BoePathComparer)
    if($script:BoeReadBaselines.ContainsKey($path)){$expected[$path]=$script:BoeReadBaselines[$path]}
    if($null -ne $ExpectedReadWitnesses){
        foreach($witness in $ExpectedReadWitnesses.Keys){
            $name=Resolve-BoeSessionPath $witness
            $hash=$ExpectedReadWitnesses[$witness]
            if($hash -ceq 'missing'){$hash=$null}
            if($expected.ContainsKey($name) -and $expected[$name] -cne $hash){throw 'Conflicting exact helper read witnesses.'}
            $expected[$name]=$hash
        }
    }
    [void](Invoke-BoeHelperRequest @{action='publish';path=$RelativePath;bytes=[Convert]::ToBase64String($desiredBytes);expected=$expected} -OnCommitted {
        $script:BoeReadBaselines[$path]=Get-BoeSha256Hex -Bytes $desiredBytes
    })
}

function Get-BoeCurrentTurnRequest {
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Get-BoeCurrentTurnRequest @boeCallArguments }
    }

    $path = Resolve-BoeSessionPath -RelativePath "input/turn_request.json"
    if (!(Test-BoePath -LiteralPath $path)) {
        throw "Current input/turn_request.json is missing. The daemon may have already closed this wait cycle; do not write a stale terminal signal."
    }

    return Read-BoeText $path | ConvertFrom-Json
}

function Get-BoeExactJsonPropertyNames {
    param(
        [AllowNull()]
        [object]$Object
    )

    if ($null -eq $Object) {
        return @()
    }

    if ($Object -is [System.Collections.IDictionary]) {
        return @($Object.Keys | ForEach-Object { [string]$_ })
    }

    return @($Object.PSObject.Properties |
        Where-Object { $_.MemberType -eq [System.Management.Automation.PSMemberTypes]::NoteProperty } |
        ForEach-Object { [string]$_.Name })
}

function Get-BoeExactJsonValue {
    param(
        [AllowNull()]
        [object]$Object,

        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    if ($null -eq $Object) {
        return $null
    }

    if ($Object -is [System.Collections.IDictionary]) {
        foreach ($key in $Object.Keys) {
            if ([string]::Equals([string]$key, $Name, [System.StringComparison]::Ordinal)) {
                return $Object[$key]
            }
        }
        return $null
    }

    $property = $Object.PSObject.Properties |
        Where-Object {
            $_.MemberType -eq [System.Management.Automation.PSMemberTypes]::NoteProperty -and
            [string]::Equals($_.Name, $Name, [System.StringComparison]::Ordinal)
        } |
        Select-Object -First 1
    if ($null -eq $property) {
        return $null
    }

    return $property.Value
}

function Test-BoeExactJsonNameInSet {
    param(
        [AllowNull()]
        [string]$Name,

        [Parameter(Mandatory = $true)]
        [string[]]$Candidates
    )

    foreach ($candidate in @($Candidates)) {
        if ([string]::Equals($Name, $candidate, [System.StringComparison]::Ordinal)) {
            return $true
        }
    }

    return $false
}

function Assert-BoeClosedJsonObject {
    param(
        [AllowNull()]
        [object]$Object,

        [Parameter(Mandatory = $true)]
        [string]$Context,

        [Parameter(Mandatory = $true)]
        [string[]]$RequiredNames,

        [string[]]$OptionalNames = @()
    )

    if ($null -eq $Object -or
        ($Object -isnot [System.Collections.IDictionary] -and
         $Object.GetType().FullName -ne "System.Management.Automation.PSCustomObject")) {
        throw "$Context must be one JSON object."
    }

    $actualNames = @(Get-BoeExactJsonPropertyNames -Object $Object)
    foreach ($actualName in $actualNames) {
        if (!(Test-BoeExactJsonNameInSet -Name $actualName -Candidates @($RequiredNames + $OptionalNames))) {
            throw "$Context contains forbidden field '$actualName'."
        }
    }

    foreach ($requiredName in @($RequiredNames)) {
        if (!(Test-BoeExactJsonNameInSet -Name $requiredName -Candidates $actualNames)) {
            throw "$Context is missing required field '$requiredName'."
        }
    }
}

function Get-BoeRequiredQteText {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Object,

        [Parameter(Mandatory = $true)]
        [string]$Name,

        [Parameter(Mandatory = $true)]
        [string]$Context
    )

    $value = Get-BoeExactJsonValue -Object $Object -Name $Name
    if ($value -isnot [string] -or [string]::IsNullOrWhiteSpace($value)) {
        throw "$Context.$Name must be one non-empty string."
    }

    return [string]$value
}

function Test-BoeFiniteJsonNumber {
    param(
        [AllowNull()]
        [object]$Value
    )

    if ($Value -is [single]) {
        return ![single]::IsNaN($Value) -and ![single]::IsInfinity($Value)
    }
    if ($Value -is [double]) {
        return ![double]::IsNaN($Value) -and ![double]::IsInfinity($Value)
    }

    return $Value -is [byte] -or
        $Value -is [sbyte] -or
        $Value -is [int16] -or
        $Value -is [uint16] -or
        $Value -is [int32] -or
        $Value -is [uint32] -or
        $Value -is [int64] -or
        $Value -is [uint64] -or
        $Value -is [decimal]
}

function Complete-BoeQteEffectResolution {
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [object[]]$Receipts
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'write' -Body { Complete-BoeQteEffectResolution @boeCallArguments }
    }


    $requestPath = "input/qte_effect_resolution_request.json"
    $request = Read-BoeJson -RelativePath $requestPath
    $requestFields = @(
        "schemaVersion",
        "requestKind",
        "sessionId",
        "sessionGeneration",
        "continuationId",
        "requestId",
        "waveId",
        "waveOrdinal",
        "acceptedSourceTurn",
        "qteId",
        "selectedTerminalFingerprint",
        "pendingStateFingerprint",
        "fullTurnFingerprint",
        "semanticTurnFingerprint",
        "safePacket"
    )
    Assert-BoeClosedJsonObject `
        -Object $request `
        -Context $requestPath `
        -RequiredNames $requestFields

    if ([int](Get-BoeExactJsonValue -Object $request -Name "schemaVersion") -ne 1) {
        throw "$requestPath.schemaVersion must be 1."
    }
    $requestKind = Get-BoeRequiredQteText -Object $request -Name "requestKind" -Context $requestPath
    if (![string]::Equals(
            $requestKind,
            "qte_deferred_effect_resolution",
            [System.StringComparison]::Ordinal)) {
        throw "$requestPath.requestKind must be qte_deferred_effect_resolution."
    }

    $textCorrelationNames = @(
        "sessionId",
        "sessionGeneration",
        "continuationId",
        "requestId",
        "waveId",
        "qteId",
        "selectedTerminalFingerprint",
        "pendingStateFingerprint",
        "fullTurnFingerprint",
        "semanticTurnFingerprint"
    )
    $correlation = [ordered]@{}
    foreach ($name in $textCorrelationNames) {
        $correlation[$name] = Get-BoeRequiredQteText -Object $request -Name $name -Context $requestPath
    }
    foreach ($fingerprintName in @(
        "selectedTerminalFingerprint",
        "pendingStateFingerprint",
        "fullTurnFingerprint",
        "semanticTurnFingerprint"
    )) {
        if ($correlation[$fingerprintName] -notmatch '^sha256:[0-9a-f]{64}$') {
            throw "$requestPath.$fingerprintName must be one lowercase SHA-256 fingerprint."
        }
    }

    $sessionGeneration = $correlation.sessionGeneration
    $waveOrdinal = [int](Get-BoeExactJsonValue -Object $request -Name "waveOrdinal")
    $acceptedSourceTurn = [int](Get-BoeExactJsonValue -Object $request -Name "acceptedSourceTurn")
    if ($waveOrdinal -lt 0 -or $acceptedSourceTurn -lt 0) {
        throw "$requestPath contains an invalid wave ordinal or accepted source turn."
    }

    $safePacket = Get-BoeExactJsonValue -Object $request -Name "safePacket"
    Assert-BoeClosedJsonObject `
        -Object $safePacket `
        -Context "$requestPath.safePacket" `
        -RequiredNames @("schemaVersion", "kind", "requests")
    if ([int](Get-BoeExactJsonValue -Object $safePacket -Name "schemaVersion") -ne 2 -or
        ![string]::Equals(
            [string](Get-BoeExactJsonValue -Object $safePacket -Name "kind"),
            "bounded_resource_resolution",
            [System.StringComparison]::Ordinal)) {
        throw "$requestPath.safePacket must use the current bounded_resource_resolution schema."
    }

    $safeRequests = @(Get-BoeJsonArrayItems -Value (
        Get-BoeExactJsonValue -Object $safePacket -Name "requests"))
    if ($safeRequests.Count -lt 1 -or $safeRequests.Count -gt 64) {
        throw "$requestPath.safePacket.requests must contain between 1 and 64 requests."
    }

    $allowedByRequest = [System.Collections.Generic.Dictionary[string, object]]::new(
        [System.StringComparer]::Ordinal)
    foreach ($safeRequest in $safeRequests) {
        Assert-BoeClosedJsonObject `
            -Object $safeRequest `
            -Context "$requestPath.safePacket.requests[]" `
            -RequiredNames @(
                "requestId",
                "sourceLabel",
                "targetLabel",
                "resourceLabel",
                "operationLabel",
                "allowedResults",
                "requiredCompanions",
                "fullTurnResubmissionRequired",
                "instruction"
            )
        $safeRequestId = Get-BoeRequiredQteText `
            -Object $safeRequest `
            -Name "requestId" `
            -Context "$requestPath.safePacket.requests[]"
        if ($allowedByRequest.ContainsKey($safeRequestId)) {
            throw "$requestPath.safePacket.requests contains duplicate requestId '$safeRequestId'."
        }

        $allowedKinds = New-Object System.Collections.Generic.List[string]
        foreach ($allowedResult in @(Get-BoeJsonArrayItems -Value (
            Get-BoeExactJsonValue -Object $safeRequest -Name "allowedResults"))) {
            Assert-BoeClosedJsonObject `
                -Object $allowedResult `
                -Context "$requestPath.safePacket.requests[$safeRequestId].allowedResults[]" `
                -RequiredNames @("resultKind") `
                -OptionalNames @("amountInstruction")
            $allowedKind = Get-BoeRequiredQteText `
                -Object $allowedResult `
                -Name "resultKind" `
                -Context "$requestPath.safePacket.requests[$safeRequestId].allowedResults[]"
            if ($allowedKind -notin @("narrated_no_state_change", "resource_delta")) {
                throw "$requestPath safe packet contains unsupported result kind '$allowedKind'."
            }
            $allowedKinds.Add($allowedKind)
        }
        if ($allowedKinds.Count -lt 1) {
            throw "$requestPath safe request '$safeRequestId' has no allowed result."
        }
        $allowedByRequest.Add($safeRequestId, [string[]]$allowedKinds.ToArray())
    }

    $receiptArray = @($Receipts)
    if ($receiptArray.Count -ne $allowedByRequest.Count) {
        throw "Receipts must contain exactly one result for every published QTE effect request."
    }
    $seenReceiptIds = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::Ordinal)
    $closedReceipts = New-Object System.Collections.Generic.List[object]
    foreach ($rawReceipt in $receiptArray) {
        $receipt = ConvertTo-BoeMutableJsonValue -Value $rawReceipt
        Assert-BoeClosedJsonObject `
            -Object $receipt `
            -Context "Receipts[]" `
            -RequiredNames @("requestId", "resultKind", "reason") `
            -OptionalNames @("amount")
        $receiptRequestId = Get-BoeRequiredQteText -Object $receipt -Name "requestId" -Context "Receipts[]"
        $resultKind = Get-BoeRequiredQteText -Object $receipt -Name "resultKind" -Context "Receipts[]"
        $reason = Get-BoeRequiredQteText -Object $receipt -Name "reason" -Context "Receipts[]"
        if (!$seenReceiptIds.Add($receiptRequestId)) {
            throw "Receipts contains duplicate requestId '$receiptRequestId'."
        }
        if (!$allowedByRequest.ContainsKey($receiptRequestId)) {
            throw "Receipts contains stale or unknown requestId '$receiptRequestId'."
        }
        if (!(Test-BoeExactJsonNameInSet `
                -Name $resultKind `
                -Candidates ([string[]]$allowedByRequest[$receiptRequestId]))) {
            throw "Receipt '$receiptRequestId' uses resultKind '$resultKind' outside the published safe packet."
        }

        $amountNames = @(Get-BoeExactJsonPropertyNames -Object $receipt)
        $hasAmount = Test-BoeExactJsonNameInSet -Name "amount" -Candidates $amountNames
        if ([string]::Equals($resultKind, "resource_delta", [System.StringComparison]::Ordinal)) {
            if (!$hasAmount) {
                throw "Receipt '$receiptRequestId' with resource_delta must contain amount."
            }
            $rawAmount = Get-BoeExactJsonValue -Object $receipt -Name "amount"
            if (!(Test-BoeFiniteJsonNumber -Value $rawAmount)) {
                throw "Receipt '$receiptRequestId'.amount must be a finite decimal number."
            }
            try {
                $amount = [decimal]$rawAmount
            }
            catch {
        Assert-BoeNotStorageFailure $_
                throw "Receipt '$receiptRequestId'.amount must be a finite decimal number."
            }
        }
        elseif ($hasAmount) {
            throw "Receipt '$receiptRequestId' must omit amount for narrated_no_state_change."
        }

        $closedReceipt = [ordered]@{
            requestId = $receiptRequestId
            resultKind = $resultKind
        }
        if ($hasAmount) {
            $closedReceipt.amount = $amount
        }
        $closedReceipt.reason = $reason
        $closedReceipts.Add($closedReceipt)
    }

    foreach ($safeRequestId in $allowedByRequest.Keys) {
        if (!$seenReceiptIds.Contains($safeRequestId)) {
            throw "Receipts is missing requestId '$safeRequestId'."
        }
    }

    $response = [ordered]@{
        schemaVersion = 1
        requestKind = "qte_deferred_effect_resolution"
        sessionId = $correlation.sessionId
        sessionGeneration = $sessionGeneration
        continuationId = $correlation.continuationId
        requestId = $correlation.requestId
        waveId = $correlation.waveId
        waveOrdinal = $waveOrdinal
        acceptedSourceTurn = $acceptedSourceTurn
        qteId = $correlation.qteId
        selectedTerminalFingerprint = $correlation.selectedTerminalFingerprint
        pendingStateFingerprint = $correlation.pendingStateFingerprint
        fullTurnFingerprint = $correlation.fullTurnFingerprint
        semanticTurnFingerprint = $correlation.semanticTurnFingerprint
        effectResolutionReceipts = [object[]]$closedReceipts.ToArray()
    }
    $responsePath = "output/qte_effect_resolution_receipts.json"
    Write-BoeJson `
        -RelativePath $responsePath `
        -Data $response `
        -Depth 30 `
        -AllowClientOwnedRuntimeWrite

    $responseFullPath = Resolve-BoeSessionPath -RelativePath $responsePath
    $ready = [ordered]@{
        schemaVersion = 1
        requestKind = "qte_deferred_effect_resolution"
        sessionId = $correlation.sessionId
        sessionGeneration = $sessionGeneration
        continuationId = $correlation.continuationId
        requestId = $correlation.requestId
        waveId = $correlation.waveId
        waveOrdinal = $waveOrdinal
        acceptedSourceTurn = $acceptedSourceTurn
        qteId = $correlation.qteId
        pendingStateFingerprint = $correlation.pendingStateFingerprint
        receiptsFingerprint = "sha256:" + (Get-BoeSha256Hex -Bytes ((Read-BoeBytes $responseFullPath)))
        timestamp = [DateTimeOffset]::UtcNow.ToString("O")
        status = "success"
    }
    Write-BoeJson `
        -RelativePath "ready/qte_effect_resolution_complete.json" `
        -Data $ready `
        -Depth 20 `
        -AllowClientOwnedRuntimeWrite
}

function Assert-BoeCurrentPendingSnapshotContext {
    param(
        [Parameter(Mandatory = $true)]
        [object]$TurnRequest
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'read' -Body { Assert-BoeCurrentPendingSnapshotContext @boeCallArguments }
    }


    $manifestPath = Resolve-BoeSessionPath -RelativePath "game_state/control/pending_turn_snapshot.json"
    if (!(Test-BoePath -LiteralPath $manifestPath)) {
        throw "Current game_state/control/pending_turn_snapshot.json is missing. The client no longer has active pending-turn authority; do not write a stale terminal signal."
    }

    $authorityPath = Resolve-BoeSessionPath -RelativePath "game_state/control/pending_turn_snapshot.authority.json"
    if (!(Test-BoePath -LiteralPath $authorityPath)) {
        throw "Current game_state/control/pending_turn_snapshot.authority.json is missing. The client no longer has active pending-turn authority; do not write a stale terminal signal."
    }

    $manifest = Read-BoeText $manifestPath | ConvertFrom-Json
    $manifestSessionId = [string]$manifest.sessionId
    $manifestRequestId = [string]$manifest.requestId
    $manifestTurnNumber = [int]$manifest.turnNumber

    if ($manifestSessionId -ne [string]$TurnRequest.sessionId -or
        $manifestRequestId -ne [string]$TurnRequest.requestId -or
        $manifestTurnNumber -ne [int]$TurnRequest.turnNumber) {
        throw "Current pending_turn_snapshot context does not match input/turn_request.json; do not write a stale terminal signal."
    }
}

function Complete-BoeTurn {
    param(
        [string[]]$FilesModified = @()
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'write' -Body { Complete-BoeTurn @boeCallArguments }
    }


    Assert-BoeGmFilesModifiedEntries -FilesModified $FilesModified
    Assert-BoeNoRawMortalWorldProfileMutations -Operation "Complete-BoeTurn"
    $turn = Get-BoeCurrentTurnRequest
    Assert-BoeCurrentPendingSnapshotContext -TurnRequest $turn
    Assert-BoeNoExistingTerminalSignalForTurn -TurnRequest $turn -Operation "Complete-BoeTurn"
    Assert-BoeNoUnauthorizedSystemGuardianBootstrapMutation -TurnRequest $turn -FilesModified $FilesModified
    $signal = [ordered]@{
        sessionId = [string]$turn.sessionId
        requestId = [string]$turn.requestId
        turnNumber = [int]$turn.turnNumber
        timestamp = [DateTimeOffset]::UtcNow.ToString("O")
        status = "success"
        filesModified = @($FilesModified)
    }

    Write-BoeJson -RelativePath "ready/turn_complete.json" -Data $signal -Depth 20 -AllowClientOwnedRuntimeWrite
}

function Fail-BoeTurn {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ErrorMessage
    )
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'write' -Body { Fail-BoeTurn @boeCallArguments }
    }


    $turn = Get-BoeCurrentTurnRequest
    Assert-BoeCurrentPendingSnapshotContext -TurnRequest $turn
    Assert-BoeNoExistingTerminalSignalForTurn -TurnRequest $turn -Operation "Fail-BoeTurn"
    $signal = [ordered]@{
        sessionId = [string]$turn.sessionId
        requestId = [string]$turn.requestId
        turnNumber = [int]$turn.turnNumber
        timestamp = [DateTimeOffset]::UtcNow.ToString("O")
        status = "error"
        error = $ErrorMessage
    }

    Write-BoeJson -RelativePath "ready/turn_error.json" -Data $signal -Depth 20 -AllowClientOwnedRuntimeWrite
    throw "GM turn failed: $ErrorMessage"
}

function Assert-BoeSpiritualContinuationRawJson {
    param([string]$Json, [switch]$RepairRequest)

    # Windows PowerShell 5.1 has no System.Text.Json. Validate raw tokens before
    # mutable object conversion can discard duplicate names or their exact case.
    if ($null -eq ('BoeSpiritualContinuationRawJson' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

/// <summary>
/// Checks raw JSON syntax and continuation key uniqueness before object conversion.
/// </summary>
public sealed class BoeSpiritualContinuationRawJson
{
    private readonly string json;
    private readonly bool repairRequest;
    private int offset;

    /// <summary>
    /// Retains one raw input and its envelope mode for a bounded parse.
    /// </summary>
    /// <param name="json">
    /// Raw JSON to validate without producing mutable objects.
    /// </param>
    /// <param name="repairRequest">
    /// Whether only the request's optional continuation subtree uses closed transport keys.
    /// </param>
    private BoeSpiritualContinuationRawJson(string json, bool repairRequest)
    {
        this.json = json ?? "";
        this.repairRequest = repairRequest;
    }

    /// <summary>
    /// Rejects invalid syntax, duplicate continuation keys and outer envelope case aliases.
    /// </summary>
    /// <param name="json">
    /// Raw request or response JSON; empty input is invalid.
    /// </param>
    /// <param name="repairRequest">
    /// <see langword="true"/> for a repair request; <see langword="false"/> for the closed response envelope itself.
    /// </param>
    public static void Validate(string json, bool repairRequest)
    {
        var parser = new BoeSpiritualContinuationRawJson(json, repairRequest);
        parser.Value(!repairRequest, 0);
        parser.Space();
        if (parser.offset != parser.json.Length) throw new FormatException("Trailing JSON content.");
    }

    /// <summary>
    /// Consumes one complete JSON value while retaining property names at each object depth.
    /// </summary>
    /// <param name="strict">
    /// Whether duplicate or case-alias property names are forbidden in this subtree.
    /// </param>
    /// <param name="depth">
    /// Current nesting depth; more than 64 levels is rejected.
    /// </param>
    private void Value(bool strict, int depth)
    {
        Space();
        if (depth > 64 || offset >= json.Length) throw new FormatException("Invalid continuation JSON depth or value.");
        char token = json[offset];
        if (token == '{')
        {
            offset++;
            Space();
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (Take('}')) return;
            do
            {
                Space();
                string name = Text();
                bool envelope = repairRequest && depth == 0 &&
                    string.Equals(name, "spiritualWoundContinuation", StringComparison.OrdinalIgnoreCase);
                if ((strict || envelope) && !names.Add(name)) throw new FormatException("Duplicate continuation JSON key: " + name);
                if (envelope && name != "spiritualWoundContinuation") throw new FormatException("Incorrect continuation envelope case.");
                Space();
                if (!Take(':')) throw new FormatException("Expected JSON property separator.");
                Value(strict || envelope, depth + 1);
                Space();
                if (Take('}')) return;
            } while (Take(','));
            throw new FormatException("Expected JSON object delimiter.");
        }
        if (token == '[')
        {
            offset++;
            Space();
            if (Take(']')) return;
            do
            {
                Value(strict, depth + 1);
                Space();
                if (Take(']')) return;
            } while (Take(','));
            throw new FormatException("Expected JSON array delimiter.");
        }
        if (token == '"') { Text(); return; }
        var literal = Regex.Match(json.Substring(offset), @"\A(?:true|false|null|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)");
        if (!literal.Success) throw new FormatException("Invalid JSON literal.");
        offset += literal.Length;
    }

    /// <summary>
    /// Decodes one JSON string so escaped property names share the same uniqueness checks.
    /// </summary>
    /// <returns>
    /// The decoded string, with invalid escapes and control characters rejected.
    /// </returns>
    private string Text()
    {
        if (!Take('"')) throw new FormatException("Expected JSON string.");
        var text = new StringBuilder();
        while (offset < json.Length)
        {
            char value = json[offset++];
            if (value == '"') return text.ToString();
            if (value < 32) throw new FormatException("Unescaped JSON control character.");
            if (value != '\\') { text.Append(value); continue; }
            if (offset == json.Length) break;
            char escape = json[offset++];
            switch (escape)
            {
                case '"': case '\\': case '/': text.Append(escape); break;
                case 'b': text.Append('\b'); break;
                case 'f': text.Append('\f'); break;
                case 'n': text.Append('\n'); break;
                case 'r': text.Append('\r'); break;
                case 't': text.Append('\t'); break;
                case 'u':
                    if (offset + 4 > json.Length || !Regex.IsMatch(json.Substring(offset, 4), @"\A[0-9a-fA-F]{4}\z"))
                        throw new FormatException("Invalid JSON Unicode escape.");
                    text.Append((char)Convert.ToInt32(json.Substring(offset, 4), 16));
                    offset += 4;
                    break;
                default: throw new FormatException("Invalid JSON escape.");
            }
        }
        throw new FormatException("Unterminated JSON string.");
    }

    /// <summary>
    /// Consumes one expected delimiter at the current position.
    /// </summary>
    /// <param name="value">
    /// Exact delimiter to match.
    /// </param>
    /// <returns>
    /// <see langword="true"/> when the delimiter was consumed; otherwise <see langword="false"/> without advancing.
    /// </returns>
    private bool Take(char value)
    {
        if (offset >= json.Length || json[offset] != value) return false;
        offset++;
        return true;
    }

    /// <summary>
    /// Skips only the whitespace characters permitted by JSON.
    /// </summary>
    private void Space()
    {
        while (offset < json.Length && (json[offset] == ' ' || json[offset] == '\t' ||
            json[offset] == '\r' || json[offset] == '\n')) offset++;
    }
}
'@
    }
    [BoeSpiritualContinuationRawJson]::Validate($Json, [bool]$RepairRequest)
}

function Get-BoeContinuationText {
    param([object]$Object, [string]$Name)
    $value = Get-BoeExactJsonValue -Object $Object -Name $Name
    if ($value -isnot [string] -or [string]::IsNullOrWhiteSpace($value)) {
        throw "Continuation $Name must be a nonempty string."
    }
    return $value
}

function Get-BoeContinuationInteger {
    param([object]$Object, [string]$Name)
    $value = Get-BoeExactJsonValue -Object $Object -Name $Name
    if (($value -isnot [int] -and $value -isnot [long]) -or $value -lt [int]::MinValue -or $value -gt [int]::MaxValue) {
        throw "Continuation $Name must be an integer."
    }
    return [int]$value
}

function Assert-BoeContinuationStringArray {
    param([AllowNull()][object]$Value)
    if ($Value -isnot [System.Collections.IList]) { throw 'Continuation field must be an array.' }
    $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::Ordinal)
    foreach ($entry in $Value) {
        if ($entry -isnot [string] -or [string]::IsNullOrWhiteSpace($entry) -or !$seen.Add($entry)) {
            throw 'Continuation array requires unique nonempty strings.'
        }
    }
}

function Assert-BoeSpiritualContinuationRequest {
    param([object]$Request)
    Assert-BoeClosedJsonObject -Object $Request -Context 'spiritualWoundContinuation' -RequiredNames @(
        'schemaVersion', 'continuationId', 'phase', 'offer', 'sceneTextSource', 'dependentDraftFields')
    if ((Get-BoeContinuationInteger $Request 'schemaVersion') -ne 1) { throw 'Unsupported continuation schemaVersion.' }
    $null = Get-BoeContinuationText $Request 'continuationId'
    $phase = Get-BoeContinuationText $Request 'phase'
    if ($phase -cne 'decision' -and $phase -cne 'dependent_draft') { throw 'Unsupported continuation phase.' }
    $scene = $Request.sceneTextSource
    Assert-BoeClosedJsonObject -Object $scene -Context 'sceneTextSource' -RequiredNames @('path', 'field')
    if ((Get-BoeContinuationText $scene 'path') -cne 'output/narrative_response.json' -or
        (Get-BoeContinuationText $scene 'field') -cne 'response') { throw 'Continuation scene source must be the existing narrative response.' }
    $fields = $Request.dependentDraftFields
    if ($fields -isnot [System.Collections.IList]) { throw 'dependentDraftFields must be an array.' }
    $seen = [System.Collections.Generic.Dictionary[string, object]]::new([System.StringComparer]::Ordinal)
    foreach ($field in $fields) {
        Assert-BoeClosedJsonObject -Object $field -Context 'dependentDraftFields[]' -RequiredNames @('path', 'jsonPointer')
        $path = Get-BoeContinuationText $field 'path'
        $pointer = Get-BoeContinuationText $field 'jsonPointer'
        if ($path.StartsWith('/') -or $path.Contains('\') -or $path.Contains(':') -or
            @($path.Split('/') | Where-Object { $_ -eq '' -or $_ -eq '.' -or $_ -eq '..' }).Count -ne 0 -or
            !$pointer.StartsWith('/') -or $pointer -match '~(?:[^01]|$)') {
            throw 'Invalid dependent draft field.'
        }
        if (!$seen.ContainsKey($path)) { $seen[$path] = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::Ordinal) }
        if (!$seen[$path].Add($pointer)) { throw 'Duplicate dependent draft field.' }
    }
    if ($phase -ceq 'dependent_draft') {
        if ($null -ne $Request.offer) { throw 'Dependent correction cannot offer a new decision.' }
        return
    }
    if ($fields.Count -ne 0) { throw 'Decision requests cannot permit dependent edits.' }
    $offer = $Request.offer
    Assert-BoeClosedJsonObject -Object $offer -Context 'offer' -RequiredNames @('opportunityRef', 'minimumSeverityRank',
        'requiredSeverityRank', 'maximumSeverityRank', 'target', 'cause', 'allowedLocationKinds', 'allowedDecisions')
    foreach ($name in @('opportunityRef', 'target', 'cause')) { $null = Get-BoeContinuationText $offer $name }
    $minimum = Get-BoeContinuationInteger $offer 'minimumSeverityRank'
    $maximum = Get-BoeContinuationInteger $offer 'maximumSeverityRank'
    if ($minimum -lt 1 -or $minimum -gt 5 -or $maximum -lt 1 -or $maximum -gt 4) { throw 'Invalid severity bounds.' }
    $required = $offer.requiredSeverityRank
    if ($null -ne $required) {
        $required = Get-BoeContinuationInteger $offer 'requiredSeverityRank'
        if ($required -lt $minimum -or $required -gt $maximum) { throw 'Required severity is outside the offer.' }
    }
    Assert-BoeContinuationStringArray $offer.allowedLocationKinds
    if ($offer.allowedLocationKinds.Count -eq 0) { throw 'The offer requires a location kind.' }
    foreach ($kind in $offer.allowedLocationKinds) {
        if (@('anatomical', 'systemic', 'mental', 'spiritual_axis', 'other') -cnotcontains $kind) { throw 'Unsupported location kind.' }
    }
    Assert-BoeContinuationStringArray $offer.allowedDecisions
    $expected = @('none')
    if ($null -ne $required) { $expected = @('materialize') }
    elseif ($minimum -le $maximum) { $expected = @('none', 'materialize') }
    if ($offer.allowedDecisions.Count -ne $expected.Count) { throw 'Decisions do not match the offer bounds.' }
    for ($index = 0; $index -lt $expected.Count; $index++) {
        if ($offer.allowedDecisions[$index] -cne $expected[$index]) { throw 'Decisions do not match the offer bounds.' }
    }
}

function Assert-BoeSpiritualContinuationResponse {
    param([object]$Request, [object]$Response)
    Assert-BoeClosedJsonObject -Object $Response -Context 'continuation response' -RequiredNames @('schemaVersion', 'continuationId', 'woundDecisions')
    if ((Get-BoeContinuationInteger $Response 'schemaVersion') -ne 1) { throw 'Unsupported response schemaVersion.' }
    if ((Get-BoeContinuationText $Response 'continuationId') -cne $Request.continuationId) { throw 'Continuation correlation does not match.' }
    $decisions = $Response.woundDecisions
    if ($decisions -isnot [System.Collections.IList]) { throw 'woundDecisions must be an array.' }
    $expectedCount = if ($Request.phase -ceq 'decision') { 1 } else { 0 }
    if ($decisions.Count -ne $expectedCount) { throw 'The response has the wrong decision count for its phase.' }
    foreach ($decision in $decisions) {
        $kind = Get-BoeContinuationText $decision 'decision'
        if ($kind -ceq 'none') {
            Assert-BoeClosedJsonObject -Object $decision -Context 'woundDecisions[]' -RequiredNames @('opportunityRef', 'decision')
        }
        elseif ($kind -ceq 'materialize') {
            Assert-BoeClosedJsonObject -Object $decision -Context 'woundDecisions[]' -RequiredNames @('opportunityRef', 'decision', 'woundRef', 'proposal')
            $null = Get-BoeContinuationText $decision 'woundRef'
            Assert-BoeClosedJsonObject -Object $decision.proposal -Context 'proposal' -RequiredNames @(
                'classification', 'display', 'severity', 'complications', 'consequenceDefinitions', 'treatment', 'recovery')
        }
        else { throw 'Unsupported GM decision.' }
        if ((Get-BoeContinuationText $decision 'opportunityRef') -cne $Request.offer.opportunityRef -or
            $Request.offer.allowedDecisions -cnotcontains $kind) { throw 'Decision does not belong to the current offer.' }
    }
}

function Complete-BoeValidationRepair {
    param([AllowNull()][string]$SpiritualWoundContinuationJson)
    if(-not $script:BoeHelperScope){
        $boeCallArguments=@{}+$PSBoundParameters
        return Invoke-BoeHelperScope -Mode 'write' -Body { Complete-BoeValidationRepair @boeCallArguments }
    }


    $requestPath = 'game_state/control/validation_repair_request.json'
    $readyPath = 'game_state/control/validation_repair_ready.json'
    $requestFullPath = Resolve-BoeSessionPath -RelativePath $requestPath
    $readyFullPath = Resolve-BoeSessionPath -RelativePath $readyPath
    $requestBytes = (Read-BoeBytes $requestFullPath)
    $witnesses = @{}
    $witnesses[$requestPath] = Get-BoeSha256Hex -Bytes $requestBytes
    $witnesses[$readyPath] = if ((Test-BoePath -LiteralPath $readyFullPath)) {
        Get-BoeSha256Hex -Bytes ((Read-BoeBytes $readyFullPath))
    } else { 'missing' }
    $requestJson = [System.Text.Encoding]::UTF8.GetString($requestBytes).TrimStart([char]0xFEFF)
    Assert-BoeSpiritualContinuationRawJson -Json $requestJson -RepairRequest
    $repair = ConvertFrom-BoeJsonMutable -Json $requestJson
    if ($repair.metadataDiagnosticOnly) {
        throw "validation_repair_request.json uses diagnostic-only metadata. Do not write validation_repair_ready.json from this request."
    }

    $hasContinuation = Test-BoeExactJsonNameInSet -Name 'spiritualWoundContinuation' -Candidates @(Get-BoeExactJsonPropertyNames $repair)
    $response = $null
    if ($hasContinuation) {
        if ($witnesses[$readyPath] -cne 'missing') {
            throw 'A continuation Ready is already awaiting client consumption. Do not replace or delete it.'
        }
        Assert-BoeSpiritualContinuationRequest -Request $repair.spiritualWoundContinuation
        if ($repair.fullTurnResubmissionRequired -isnot [bool] -or $repair.fullTurnResubmissionRequired) {
            throw 'Continuation cannot require full-turn resubmission.'
        }
        if (!$PSBoundParameters.ContainsKey('SpiritualWoundContinuationJson') -or [string]::IsNullOrWhiteSpace($SpiritualWoundContinuationJson)) {
            throw 'The current continuation requires an explicit response.'
        }
        Assert-BoeSpiritualContinuationRawJson -Json $SpiritualWoundContinuationJson
        $response = ConvertFrom-BoeJsonMutable -Json $SpiritualWoundContinuationJson
        Assert-BoeSpiritualContinuationResponse -Request $repair.spiritualWoundContinuation -Response $response
    }
    elseif ($PSBoundParameters.ContainsKey('SpiritualWoundContinuationJson')) {
        throw 'Continuation response is forbidden on ordinary repair.'
    }

    Assert-BoeNoRawMortalWorldProfileMutations -Operation "Complete-BoeValidationRepair"

    $signal = [ordered]@{
        sessionId = [string]$repair.sessionId
        requestId = [string]$repair.requestId
        turnNumber = [int]$repair.turnNumber
        timestamp = [DateTimeOffset]::UtcNow.ToString("O")
        status = "success"
    }

    if ($hasContinuation) { $signal.spiritualWoundContinuation = $response }
    Write-BoeJson -RelativePath $readyPath -Data $signal -Depth 100 -ExpectedReadWitnesses $witnesses
}
