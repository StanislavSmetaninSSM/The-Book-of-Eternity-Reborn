from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path('/workspace/1553-storage-migration-cloud-20261008-recovery-61d3a7f');root=Path(__file__).parent
frozen='7d5766309a6877ccee2892aa284927cfe5fc24aa'
for arm in ['old','fixed']:
    base=root/arm;base.mkdir(exist_ok=False);src=base/'source';launcher=src/'BookOfEternityClient/Launcher';launcher.mkdir(parents=True)
    ship=base/'ship';owned=ship/'BookOfEternityClient/Launcher';owned.mkdir(parents=True)
    for name in ['GM_Turn_Helper.ps1','gm_turn_helper_transport.ps1','gm_main_operation.ps1']:
        raw=(repo/'BookOfEternityClient/Launcher'/name).read_bytes();(launcher/name).write_bytes(raw);(owned/name).write_bytes(raw)
    rel='tests/fixtures/LinuxGameChains/helper_admission_observer.ps1';p=src/rel;p.parent.mkdir(parents=True)
    p.write_bytes(subprocess.check_output(['git','-C',str(repo),'show',frozen+':'+rel]) if arm=='old' else (repo/rel).read_bytes())
    rel='tests/fixtures/LinuxGameChains/prepare_helper_observation.py';code=subprocess.check_output(['git','-C',str(repo),'show',frozen+':'+rel]).decode() if arm=='old' else (repo/rel).read_text()
    (src/rel).write_text(code);ns={};exec(compile(code,str(src/rel),'exec'),ns)
    out=base/'out';out.mkdir();ns['prepare'](src,out,ship)
(root/'relay-apply-response.ps1').write_bytes((repo/'tools/gm-relay/relay-apply-response.ps1').read_bytes())
bootstrap='''# Probe-only bootstrap: real shipped functions; no Initialize-BoeGmTurnHelper invocation.
. $global:ProbeGmSource
$script:BoeGameSessionPath=$SessionPath
$script:BoeHelperGeneration='0123456789abcdef0123456789abcdef'
$global:BoeMainOperationContext=$null
function Get-Content {
    param($LiteralPath, [switch]$Raw, $Encoding)
    $global:InertContentCalls++
    if ($LiteralPath -ceq $global:ProbeRequestArgument) { return '{"Kind":"turn","Witnesses":{}}' }
    if ($LiteralPath -ceq $global:ProbeResponseArgument) { return '{"Completion":"turn","Writes":[{"Path":"game_state/control/probe.json","ExpectedSHA256":"missing"}]}' }
    throw 'Unexpected probe payload read; stopped before any filesystem fallback.'
}
function Start-BoeHelperProcess {
    param([string]$Root, [AllowNull()][string]$ExpectedGeneration)
    $global:InertStartCalls++
    if ($script:BoeAdmissionProbe) {
        $scope=$script:BoeAdmissionProbe.ScopeId;$rows=$script:BoeAdmissionProbe.Rows
        Begin-BoeAdmissionObservation 'read' $script:BoeGameSessionPath $ExpectedGeneration $RequestPath
        $global:RepeatUnchanged=($scope -ceq $script:BoeAdmissionProbe.ScopeId -and $rows -eq $script:BoeAdmissionProbe.Rows)
    }
    $start=[Diagnostics.ProcessStartInfo]::new('DO-NOT-EXECUTE-INERT')
    Configure-BoeAdmissionFailureCapture $start
    Configure-BoeAdmissionFailureCapture $start
    $global:InertConfiguredNonce=$start.Environment['BOE_TEST_HELPER_FAILURE_NONCE']
    throw [InvalidOperationException]::new('SELECTOR-INERT-START: no Process.Start/read/protocol/game')
}
'''
session=root/'harness/game_session';bp=session/'game_state/control/gm_turn_helper.bootstrap.ps1';bp.parent.mkdir(parents=True);bp.write_text(bootstrap)
paths={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
(root/'construction.json').write_text(json.dumps({'FrozenSHA':frozen,'FixedSourceSHA':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD']).decode().strip(),'ExactOriginalsInvoked':['real unchanged relay-apply-response.ps1 typed params/line30','real GM AssertInitialized/Resolve','real prepared Invoke/Open','exact old/fixed Begin/Write/Configure'],'InterceptedFunctions':['Start-BoeHelperProcess: inert PSI + Configure then throw before any Process.Start/context/stdout/stdio protocol','Get-Content: two immutable in-memory request/response JSON values, no payload filesystem access'],'SetupOnly':'Bootstrap is probe-only: dot-sources exact GM, supplies initialized session/generation scalars; never calls product Initialize. Source imports/setup files are outside admission; no original game/managed/native/helper process or protocol runs.','FilesSHA256':paths},indent=2)+'\n')
print(json.dumps({'Constructed':str(root),'Files':len(paths),'GameInvocations':0,'HelperInvocations':0}))
