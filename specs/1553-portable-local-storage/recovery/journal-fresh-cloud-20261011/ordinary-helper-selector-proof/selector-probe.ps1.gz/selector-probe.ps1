$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$consumer=Join-Path $root 'relay-apply-response.ps1'
$session=Join-Path $root 'harness/game_session'
$firstQueue=Join-Path $root 'harness/queue-1'
$request=Join-Path $firstQueue 'request-1-3929525909394c43b919eba2877d00a1/request.json'
$results=[Collections.Generic.List[object]]::new()
function Invoke-SelectorProbe {
    param([string]$Arm,[string]$Case,[AllowNull()][string]$RequestPath,[bool]$ExpectedSelected,[switch]$Foreign,[switch]$Initialize)
    $global:ProbeGmSource=Join-Path $root "$Arm/ship/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1"
    $global:ProbeRequestArgument=$RequestPath;$global:ProbeResponseArgument='INERT-RESPONSE-NOT-A-FILE'
    $global:InertContentCalls=0;$global:InertStartCalls=0;$global:InertConfiguredNonce=$null;$global:RepeatUnchanged=$null;$global:FrozenProbe=$null
    $env:BOE_TEST_HELPER_ADMISSION_OBSERVER_DIR=Join-Path $root "$Arm/out/helper-admission-observation"
    $env:BOE_TEST_HELPER_TARGET_CONSUMER_SCRIPT=if($Foreign){Join-Path $root 'foreign-consumer.ps1'}else{$consumer}
    $env:BOE_TEST_HELPER_TARGET_FIRST_QUEUE=$firstQueue
    Remove-Item Env:BOE_TEST_HELPER_FAILURE_NONCE -ErrorAction SilentlyContinue
    $beforeFiles=@([IO.Directory]::GetFiles($env:BOE_TEST_HELPER_ADMISSION_OBSERVER_DIR)).Count
    $failure=$null
    try {
        if($Initialize){
            $SessionPath=$session
            . (Join-Path $session 'game_state/control/gm_turn_helper.bootstrap.ps1')
            Open-BoeHelperScope 'initialize' $session $null
        }else{
            # Real full consumer script, not a copied selector/Resolve model.
            & $consumer -SessionPath $session -RequestPath $RequestPath -ResponsePath $global:ProbeResponseArgument
        }
    }catch{$failure=@{Type=$_.Exception.GetType().FullName;Text=$_.Exception.ToString();Stack=$_.ScriptStackTrace}}
    $afterFiles=@([IO.Directory]::GetFiles($env:BOE_TEST_HELPER_ADMISSION_OBSERVER_DIR)).Count
    $probe=$global:FrozenProbe
    $selected=$null -ne $probe
    $rows=if($probe){@($probe.Events | ForEach-Object {$_})}else{@()}
    $row=@{Arm=$Arm;Case=$Case;ActualRequestArgument=$RequestPath;ExpectedSelected=$ExpectedSelected;ActualSelected=$selected;
        ScopeId=$(if($probe){$probe.ScopeId}else{$null});MatchedRequestPath=$(if($probe){$probe.MatchedRequestPath}else{$null});
        SentinelStarts=$global:InertStartCalls;InertPayloadReads=$global:InertContentCalls;ConfiguredNonce=$global:InertConfiguredNonce;
        RepeatDidNotRecapture=$global:RepeatUnchanged;Events=$rows;ObserverFilesBefore=$beforeFiles;ObserverFilesAfter=$afterFiles;
        OriginalSentinelException=$global:FrozenSentinelException;ConsumerCatch=$failure;
        Limit='Pure selector/scope proof: no Process.Start/stdout-read/protocol/game. Original functions run up to inert start only; no actual helper admission, read timing, disposal or ordinary outcome proved.'}
    $actual=@($rows | Where-Object { $_.Phase -ceq 'launch-begin' }).Count
    $configured=@($rows | Where-Object { $_.Phase -ceq 'managed-failure-capture-configured' }).Count
    $row['ProofPassed']=($selected -eq $ExpectedSelected -and $global:InertStartCalls -eq 1 -and $beforeFiles -eq 0 -and $afterFiles -eq 0 -and $global:FrozenSentinelException.Text.Contains('SELECTOR-INERT-START'))
    if($ExpectedSelected){$row.ProofPassed=$row.ProofPassed -and $actual -eq 1 -and $configured -eq 1 -and $global:RepeatUnchanged -eq $true -and $probe.MatchedRequestPath -ceq [IO.Path]::GetFullPath($RequestPath) -and $probe.NonceConfigured -and $probe.Rows -eq 2 -and $probe.Errors -eq 0}
    else{$row.ProofPassed=$row.ProofPassed -and $actual -eq 0 -and $configured -eq 0 -and -not $global:InertConfiguredNonce}
    [void]$results.Add($row)
}
# Interception gains only memory snapshot and exception freezing AFTER original Begin/Configure.
$bootstrap=Join-Path $session 'game_state/control/gm_turn_helper.bootstrap.ps1'
$text=[IO.File]::ReadAllText($bootstrap)
$anchor="    throw [InvalidOperationException]::new('SELECTOR-INERT-START: no Process.Start/read/protocol/game')"
$replacement=@'
    $global:FrozenProbe=$script:BoeAdmissionProbe
    $sentinel=[InvalidOperationException]::new('SELECTOR-INERT-START: no Process.Start/read/protocol/game')
    try { throw $sentinel } catch { $global:FrozenSentinelException=@{Type=$_.Exception.GetType().FullName;Text=$_.Exception.ToString();Stack=$_.ScriptStackTrace}; throw }
'@
if(-not $text.Contains($anchor)){throw 'Probe-only sentinel source anchor absent'}
[IO.File]::WriteAllText($bootstrap,$text.Replace($anchor,$replacement))
Invoke-SelectorProbe old frozen-correct $request $false
Invoke-SelectorProbe fixed corrected-correct $request $true
Invoke-SelectorProbe fixed metadata-relative 'input/turn_request.json' $false
Invoke-SelectorProbe fixed wrong-queue (Join-Path $root 'harness/queue-2/request-1-3929525909394c43b919eba2877d00a1/request.json') $false
Invoke-SelectorProbe fixed wrong-ordinal (Join-Path $firstQueue 'request-2-3929525909394c43b919eba2877d00a1/request.json') $false
Invoke-SelectorProbe fixed wrong-filename (Join-Path $firstQueue 'request-1-3929525909394c43b919eba2877d00a1/other.json') $false
Invoke-SelectorProbe fixed foreign-consumer $request $false -Foreign
Invoke-SelectorProbe fixed blank-argument ' ' $false
Invoke-SelectorProbe fixed initialize-excluded $request $false -Initialize
$report=@{SourceSHA='1f11c1795f25ecd969db699e60a3e882c6cdc368';CausalOldSelected=$results[0].ActualSelected;CausalFixedSelected=$results[1].ActualSelected;Cases=@($results);Proofs=@($results).Count;Passed=@($results|Where-Object ProofPassed).Count;ProjectTests=0;ManagedHelperInvocations=0;GameInvocations=0;NativeInvocations=0;PerformanceClaim=$false}
[IO.File]::WriteAllText((Join-Path $root 'selector-probe-result.json'),(ConvertTo-Json -InputObject $report -Depth 20),[Text.UTF8Encoding]::new($false))
$report|ConvertTo-Json -Depth 20
if($report.Passed -ne $report.Proofs){exit 1}
