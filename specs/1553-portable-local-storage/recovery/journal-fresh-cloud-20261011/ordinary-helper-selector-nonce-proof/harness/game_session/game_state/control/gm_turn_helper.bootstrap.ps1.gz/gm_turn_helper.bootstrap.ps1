# Probe-only bootstrap: real shipped functions; no Initialize-BoeGmTurnHelper invocation.
. $global:ProbeGmSource
$script:BoeGameSessionPath=$SessionPath
$script:BoeHelperGeneration='0123456789abcdef0123456789abcdef'
$global:BoeMainOperationContext=$null
function Get-Content {
    param($LiteralPath, [switch]$Raw, $Encoding)
    $global:InertContentCalls++
    if ($LiteralPath -ceq $global:ProbeRequestArgument) { return '{"Kind":"turn","Witnesses":{}}' }
    if ($LiteralPath -ceq $global:ProbeResponseArgument) { return '{"Completion":"turn","Writes":[{"Path":"game_state/control/probe.json","ExpectedSHA256":"missing"}]}' }
    throw 'Unexpected probe payload read; stopped before any filesystem fallback.'
}
function Start-BoeHelperProcess {
    param([string]$Root, [AllowNull()][string]$ExpectedGeneration)
    $global:InertStartCalls++
    if ($script:BoeAdmissionProbe) {
        $scope=$script:BoeAdmissionProbe.ScopeId;$rows=$script:BoeAdmissionProbe.Rows
        Begin-BoeAdmissionObservation 'read' $script:BoeGameSessionPath $ExpectedGeneration $RequestPath
        $global:RepeatUnchanged=($scope -ceq $script:BoeAdmissionProbe.ScopeId -and $rows -eq $script:BoeAdmissionProbe.Rows)
    }
    $start=[Diagnostics.ProcessStartInfo]::new('DO-NOT-EXECUTE-INERT')
    Configure-BoeAdmissionFailureCapture $start
    $global:InertConfiguredNonce=$start.Environment['BOE_TEST_HELPER_FAILURE_NONCE']
    $global:FrozenProbe=$script:BoeAdmissionProbe
    $parsedNonce=[Guid]::Empty
    $global:FirstNonceGuidN=[Guid]::TryParseExact($global:InertConfiguredNonce,'N',[ref]$parsedNonce) -and
        $global:InertConfiguredNonce -cmatch '^[0-9a-f]{32}$'
    $global:FirstNonceMatchesProbe=($null -ne $global:FrozenProbe -and
        $global:InertConfiguredNonce -ceq $global:FrozenProbe.FailureNonce)
    # A second candidate launch gets a separate inert PSI: never mutate the selected one.
    $second=[Diagnostics.ProcessStartInfo]::new('DO-NOT-EXECUTE-INERT-SECOND')
    $second.Environment['BOE_TEST_HELPER_FAILURE_NONCE']='inherited-must-be-removed'
    Configure-BoeAdmissionFailureCapture $second
    $global:SecondPSINonce=$second.Environment['BOE_TEST_HELPER_FAILURE_NONCE']
    $global:FirstPSINonceAfterSecond=$start.Environment['BOE_TEST_HELPER_FAILURE_NONCE']
    $sentinel=[InvalidOperationException]::new('SELECTOR-INERT-START: no Process.Start/read/protocol/game')
    try { throw $sentinel } catch { $global:FrozenSentinelException=@{Type=$_.Exception.GetType().FullName;Text=$_.Exception.ToString();Stack=$_.ScriptStackTrace}; throw }
}
