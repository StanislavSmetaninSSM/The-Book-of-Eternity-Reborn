# Compact Mortal Skill Progression Template

Use this before Mortal World turns that teach, unlock, practice, use, or improve player skills.

## Mortal skill progression rule

- An attribute-only check is allowed when the fiction is just "try with Strength/Intelligence/Perception/etc." and no durable technique, craft, combat move, or knowledge skill is learned.
- Prose-only learning is not enough when the fiction says the player learned, trained, practiced, unlocked, or repeatedly applied a concrete skill.
- Fresh Mortal bootstrap creates no skills from player prose. Treat `playerAuthoredStart` as narrative context only. Only explicit GM-authored active and passive skills may enter canonical state: record each setting-aware skill decision in `mortal_bootstrap_scaffold.json.structuredGmAuthority.playerSkills` and write the matching active/passive skill plus active mastery state; never use genre or keyword inference.
- If the player learns durable knowledge, perception, craft, social, or utility expertise, write `passiveSkillChanges` with a complete passive skill object.
- If the player learns a usable combat move or activated technique, write `activeSkillChanges` with a complete active skill object and initialize/update its mastery through `skillMasteryChanges`.
- If the player uses an already-known active skill, update `skillMasteryChanges`; do not write mastery for a skill that is not already present in `game_state/player/skills_active.json` or added in the same turn.
- If `game_state/control/pending_training_showcase_requests.json` contains requestKind `afterlife_teacher_showcase` for a system or freeform Guardian actor, treat the existing Guardian profile in `game_state/meta/afterlife_entity_profiles.json` as client-created authority. Prefer `Complete-BoeTrainingShowcaseRequest -RequestId '<requestId>' -Offers <offers> -Summary '<player-facing summary>'` after dot-sourcing `game_state/control/gm_turn_helper.bootstrap.ps1`; it fills `mentorTrainingShowcase`, copies the requested `sourceActorSnapshotHash`, validates positive costs/caps, and leaves the fulfilled request for client cleanup after accepted turn/view refresh. Manual fallback is `afterlifeEntityProfileUpdates` with `mentorTrainingShowcase`; afterlife standard-art and `spirit_focus` mentor prices are client-owned and normalized to the current cost policy if missing or mismatched. Do not create a second Guardian, do not replace the profile with a bare stub, and do not charge the player.
- If `game_state/control/pending_training_showcase_requests.json` contains requestKind `mortal_training_skill_evolution`, the client has already charged the paid lesson. Current clients use this pending path for mastery-threshold/effect changes; an ordinary first purchase of a new Mortal skill from a fresh showcase is applied locally at mastery level 1. Resolve the pending request by writing the complete updated Mortal skill surface; do not charge money/XP again and do not leave the level-up/effect change as prose only. For these requests, follow `details.targetKind`: the client may normalize a generic showcase offer such as `skill_mastery` into `active_skill_mastery` or `passive_skill_mastery`; legacy/repaired requests may still carry `active_skill_unlock` or `passive_skill_unlock`. Active targets require `activeSkillChanges` plus matching `skillMasteryChanges`; passive targets require `passiveSkillChanges` only, not invented active skills or active mastery entries.
- `trainingPurchaseReceipts` are client-owned historical audit records. Do not rewrite an old receipt only because the teacher profile changed after the paid lesson.
- Do not imply a mechanical skill in player-facing prose unless the corresponding state is updated or the prose clearly says this is only early practice, not a learned skill yet.

## Files and response fields

- Player active skills: `game_state/player/skills_active.json` from `activeSkillChanges` / `removeActiveSkills`.
- Player passive skills: `game_state/player/skills_passive.json` from `passiveSkillChanges` / `removePassiveSkills`.
- Active skill mastery: `game_state/player/skill_mastery.json` from `skillMasteryChanges`.
- Level/stat progression is separate; use the progression and stat-point surfaces only when the player actually gains level/points.

## Passive training example

Use this for durable expertise that helps checks but is not a button-like combat action.

```json
{
  "passiveSkillChanges": [
    {
      "skillName": "Чтение свидетельских меток",
      "skillDescription": "Искра учится различать домовые печати, свидетельские метки и порядок подписей в архивных лентах.",
      "rarity": "Common",
      "type": "KnowledgeBased",
      "group": "Архивное дело",
      "masteryLevel": 1,
      "maxMasteryLevel": 5,
      "playerStatBonus": "Помогает проверкам Интеллекта и Восприятия при чтении архивных печатей.",
      "structuredBonuses": [
        {
          "targetType": "skill",
          "skillName": "Архивное дело",
          "valueType": "flat",
          "value": 1,
          "condition": "чтение печатей, свидетельских меток и порядка подписей",
          "source": "Чтение свидетельских меток",
          "summary": "Архивное дело +1 при разборе печатей и свидетельских меток"
        }
      ],
      "knowledgeDomain": "архивные печати и свидетельские метки",
      "effectDetails": "Не заменяет взрослого доступа к нижнему хранилищу, но делает вопросы точнее."
    }
  ]
}
```

## Active skill plus mastery example

Use this for a named action the player can deliberately perform in combat or a contest.

```json
{
  "activeSkillChanges": [
    {
      "skillName": "Быстрый выпад",
      "skillDescription": "Короткая атака тонким клинком по открывшейся цели.",
      "rarity": "Common",
      "actionCost": "Fast",
      "scalingCharacteristic": "dexterity",
      "scalesValue": true,
      "scalesDuration": false,
      "scalesChance": false,
      "combatEffect": {
        "isActivatedEffect": true,
        "actionName": "Быстрый выпад",
        "actionDescription": "Колючий удар стилетом в уязвимое место.",
        "damageType": "piercing",
        "baseDamage": 8,
        "range": "melee",
        "actionCost": "Fast",
        "actionPointCost": 1,
        "cooldown": 0,
        "duration": 0,
        "scalesValue": true,
        "scalesDuration": false,
        "scalesChance": false
      }
    }
  ],
  "skillMasteryChanges": [
    {
      "skillName": "Быстрый выпад",
      "newMasteryLevel": 1,
      "newCurrentMasteryProgress": 0,
      "newMasteryProgressNeeded": 5,
      "masteryLeveledUp": true
    }
  ]
}
```

## Output discipline

- Mention the new or improved skill in the narrative response in player-facing Russian.
- Include the changed skill files in `Complete-BoeTurn -FilesModified`.
- If this was only a single lesson toward future learning, say that explicitly and do not create a skill yet.
- If a later turn repeats the same training and the character now crosses the learning threshold, create/update the skill then.

