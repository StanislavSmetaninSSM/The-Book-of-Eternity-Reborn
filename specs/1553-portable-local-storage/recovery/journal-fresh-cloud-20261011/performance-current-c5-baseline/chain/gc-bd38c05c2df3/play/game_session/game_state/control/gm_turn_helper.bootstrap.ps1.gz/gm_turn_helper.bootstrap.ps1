# Init binds the existing session generation; each helper call owns a short admitted scope.
# After a storage-uncertain/transport-loss failure, retain evidence and stop this helper session; do not retry or re-Initialize it.
. '/tmp/gc-bd38c05c2df3/ship/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/gc-bd38c05c2df3/play/game_session'

