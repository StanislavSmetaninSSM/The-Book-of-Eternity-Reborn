$ErrorActionPreference='Stop'
$actual='/tmp/gc-6cac4a346d5c/queue-1/request-1-3929525909394c43b919eba2877d00a1/request.json'
$initialQueue='/tmp/gc-6cac4a346d5c/queue-1'
$matchedRequestPath=[IO.Path]::GetFullPath($actual)
$requestDirectory=[IO.Path]::GetDirectoryName($matchedRequestPath)
[ordered]@{
    PowerShellVersion=$PSVersionTable.PSVersion.ToString(); InputRequestPath=$actual;
    InputFirstQueue=$initialQueue; FullPath=$matchedRequestPath;
    ExactRequestJsonName=([IO.Path]::GetFileName($matchedRequestPath) -ceq 'request.json');
    ExactFirstRequestDirectory=([IO.Path]::GetFileName($requestDirectory) -cmatch '^request-1-[0-9a-f]{32}$');
    ExactInitialQueue=([IO.Path]::GetDirectoryName($requestDirectory) -ceq $initialQueue);
    NoPathNormalizationChange=($matchedRequestPath -ceq $actual);
    LiteralSelectorWouldRejectPath=([IO.Path]::GetFileName($matchedRequestPath) -cne 'request.json' -or [IO.Path]::GetFileName($requestDirectory) -cnotmatch '^request-1-[0-9a-f]{32}$' -or [IO.Path]::GetDirectoryName($requestDirectory) -cne $initialQueue);
    Limit='Pure evaluation of original literal path predicates on frozen RequestPath and source-derived initial queue; no frame, env snapshot, filesystem lookup or game/helper execution'
}|ConvertTo-Json
