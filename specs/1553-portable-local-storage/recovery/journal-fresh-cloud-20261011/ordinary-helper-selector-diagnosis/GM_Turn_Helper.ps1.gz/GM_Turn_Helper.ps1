. (Join-Path $PSScriptRoot 'helper_admission_observer.ps1')
function Open-BoeHelperScope {
    param([string]$Mode,[string]$SessionPath,[AllowNull()][string]$ExpectedGeneration)
    Record-SelectorInputs $Mode
    Begin-BoeAdmissionObservation $Mode $SessionPath $ExpectedGeneration
}
function Invoke-BoeHelperScope {
    param([string]$Mode='read',[scriptblock]$Body)
    Open-BoeHelperScope $Mode $SessionPath $null
}
function Resolve-BoeSessionPath {
    param([Parameter(Mandatory=$true)][string]$RelativePath)
    return Invoke-BoeHelperScope -Body {Resolve-BoeSessionPath $RelativePath}
}
