$script:BoeAdmissionObserverTargetClaimed=$false
$script:BoeAdmissionProbe=$null
$script:SelectorTrace=$null
function Write-BoeAdmissionObservation { param($Context,[string]$Phase,[hashtable]$Data=@{}) }
function Record-SelectorInputs {
    param([string]$Mode)
    $stack=@(Get-PSCallStack)
    $callers=@($stack | Where-Object { $_.ScriptName -ceq $env:BOE_TEST_HELPER_TARGET_CONSUMER_SCRIPT -and $_.ScriptLineNumber -eq 30 })
    $trace=[ordered]@{
        PowerShellVersion=$PSVersionTable.PSVersion.ToString(); Mode=$Mode;
        Claimed=$script:BoeAdmissionObserverTargetClaimed;
        ObserverRoot=$PSScriptRoot;
        ExpectedHelperScript=(Join-Path $PSScriptRoot 'GM_Turn_Helper.ps1');
        ConsumerScript=$env:BOE_TEST_HELPER_TARGET_CONSUMER_SCRIPT;
        FirstQueue=$env:BOE_TEST_HELPER_TARGET_FIRST_QUEUE;
        ObserverDirectory=$env:BOE_TEST_HELPER_ADMISSION_OBSERVER_DIR;
        CallerMatchCount=$callers.Count;
        HelperMatchCount=@($stack|Where-Object { $_.FunctionName -ceq 'Resolve-BoeSessionPath' -and $_.ScriptName -ceq (Join-Path $PSScriptRoot 'GM_Turn_Helper.ps1') }).Count;
        Stack=@($stack|ForEach-Object { @{Function=$_.FunctionName;Script=$_.ScriptName;Line=$_.ScriptLineNumber} });
        DirectVisibleRequestPath=(Get-Variable RequestPath -ValueOnly -ErrorAction SilentlyContinue);
        VariablesContainsRequestPath=$null;VariableKeys=@();VariableValue=$null;VariableType=$null;FrameError=$null
    }
    if($callers.Count) {
        try {
            $variables=$callers[0].GetFrameVariables()
            $trace.VariableKeys=@($variables.Keys)
            $trace.VariablesContainsRequestPath=$variables.ContainsKey('RequestPath')
            if($variables.ContainsKey('RequestPath')) {
                $trace.VariableValue=$variables['RequestPath'].Value
                $trace.VariableType=$variables['RequestPath'].Value.GetType().FullName
            }
        } catch {$trace.FrameError=$_.Exception.ToString()}
    }
    $script:SelectorTrace=$trace
}
function Begin-BoeAdmissionObservation {
    param([string]$Mode, [string]$SessionPath, [AllowNull()][string]$ExpectedGeneration)
    try {
        if ($Mode -cne 'read' -or $script:BoeAdmissionObserverTargetClaimed -or
            -not $env:BOE_TEST_HELPER_ADMISSION_OBSERVER_DIR) { return }
        $stack = @(Get-PSCallStack)
        if (-not @($stack | Where-Object { $_.ScriptName -ceq $env:BOE_TEST_HELPER_TARGET_CONSUMER_SCRIPT -and
            $_.ScriptLineNumber -eq 30 }).Count) { return }
        if (-not @($stack | Where-Object { $_.FunctionName -ceq 'Resolve-BoeSessionPath' -and
            $_.ScriptName -ceq (Join-Path $PSScriptRoot 'GM_Turn_Helper.ps1') }).Count) { return }
        $matchedRequestPath=$null
        if ($env:BOE_TEST_HELPER_TARGET_FIRST_QUEUE) {
            $caller=@($stack | Where-Object { $_.ScriptName -ceq $env:BOE_TEST_HELPER_TARGET_CONSUMER_SCRIPT -and $_.ScriptLineNumber -eq 30 })[0]
            $variables=$caller.GetFrameVariables()
            if (-not $variables.ContainsKey('RequestPath') -or $variables['RequestPath'].Value -isnot [string]) { return }
            $matchedRequestPath=[IO.Path]::GetFullPath($variables['RequestPath'].Value)
            $requestDirectory=[IO.Path]::GetDirectoryName($matchedRequestPath)
            if ([IO.Path]::GetFileName($matchedRequestPath) -cne 'request.json' -or
                [IO.Path]::GetFileName($requestDirectory) -cnotmatch '^request-1-[0-9a-f]{32}$' -or
                [IO.Path]::GetDirectoryName($requestDirectory) -cne $env:BOE_TEST_HELPER_TARGET_FIRST_QUEUE) { return }
        }
        $script:BoeAdmissionObserverTargetClaimed = $true
        $stem = Join-Path $env:BOE_TEST_HELPER_ADMISSION_OBSERVER_DIR "consumer-$PID"
        $script:BoeAdmissionProbe = [pscustomobject]@{ ScopeId=[Guid]::NewGuid().ToString('N');
            HelperPid=$null; LinuxStarttime=$null; BootId=$null; Attached=$false;
            LinuxIdentityAttempted=$false; LinuxIdentityFailure=$null; MatchedRequestPath=$matchedRequestPath;
            Events=[Collections.Generic.List[object]]::new(); Frame=$null; Stderr=$null;
            FailureNonce=[Guid]::NewGuid().ToString('N'); NonceConfigured=$false;
            EventPath="$stem.jsonl"; FramePath="$stem-seq0.txt"; StderrPath="$stem-stderr.txt";
            SummaryPath="$stem-summary.json"; Rows=0; Bytes=0; Dropped=0; Errors=0; Truncated=$false }
        Write-BoeAdmissionObservation $null 'launch-begin' @{ Session=$SessionPath; ExpectedGeneration=$ExpectedGeneration; FailureNonce=$script:BoeAdmissionProbe.FailureNonce;
            MatchedRequestPath=$matchedRequestPath; FirstQueue=$env:BOE_TEST_HELPER_TARGET_FIRST_QUEUE;
            ConsumerScript=$env:BOE_TEST_HELPER_TARGET_CONSUMER_SCRIPT;
            CallStack=@($stack | ForEach-Object { @{ Function=$_.FunctionName; Script=$_.ScriptName; Line=$_.ScriptLineNumber } }) }
    } catch { if ($script:BoeAdmissionProbe) { $script:BoeAdmissionProbe.Errors++ } }
}

