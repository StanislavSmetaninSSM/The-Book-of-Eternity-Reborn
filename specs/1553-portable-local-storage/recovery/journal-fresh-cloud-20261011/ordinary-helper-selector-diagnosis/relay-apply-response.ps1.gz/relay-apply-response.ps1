param([Parameter(Mandatory)][string]$SessionPath,[Parameter(Mandatory)][string]$RequestPath,[Parameter(Mandatory)][string]$ResponsePath)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'GM_Turn_Helper.ps1')
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
# Pure selector scope probe: no project I/O, process, protocol or game.
$full = Resolve-BoeSessionPath -RelativePath 'game_state/meta/guardian_thought_journal.json'
$script:SelectorTrace['ExactFrozenBeginSelected']=[bool]$script:BoeAdmissionProbe
$script:SelectorTrace['ExactFrozenBeginMatchedRequestPath']=$(if($script:BoeAdmissionProbe){$script:BoeAdmissionProbe.MatchedRequestPath}else{$null})
$script:SelectorTrace|ConvertTo-Json -Depth 8
