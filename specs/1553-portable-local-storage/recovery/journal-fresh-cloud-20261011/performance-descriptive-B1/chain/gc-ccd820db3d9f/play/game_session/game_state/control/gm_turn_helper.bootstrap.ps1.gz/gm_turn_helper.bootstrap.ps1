# Init binds the existing session generation; each helper call owns a short admitted scope.
# After a storage-uncertain/transport-loss failure, retain evidence and stop this helper session; do not retry or re-Initialize it.
. '/tmp/gc-ccd820db3d9f/ship/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/gc-ccd820db3d9f/play/game_session'

