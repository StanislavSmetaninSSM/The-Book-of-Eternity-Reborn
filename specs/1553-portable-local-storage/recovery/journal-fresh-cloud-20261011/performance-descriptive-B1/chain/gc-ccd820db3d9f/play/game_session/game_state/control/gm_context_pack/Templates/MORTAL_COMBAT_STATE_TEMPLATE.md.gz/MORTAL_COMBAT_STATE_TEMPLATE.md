# Compact Mortal combat state template

Use this before Mortal World turns that resolve open combat, create an enemy exchange, award combat XP, update active-skill mastery from a combat action, or change health/energy/poise because of a fight.

## Player-facing rule

- `/бой` must remain useful after a player-facing combat scene.
- If the fight is still active, write enemies/allies plus a combat log.
- If the fight ended in the same turn, still write `game_state/combat/combat_log.json` with the recent exchange and outcome so `/бой` can explain what just happened.
- Do not leave a visible enemy, duel, ambush, monster, guard, or protective shadow only in prose when XP, active-skill mastery, or combat resources changed.

## Canonical files

- `game_state/combat/combat_log.json`: recent combat summary for `/бой`; always write this for explicit combat.
- `game_state/combat/enemies.json`: active, defeated, fled, or suppressed opponents when the enemy remains tactically relevant.
- `game_state/combat/allies.json`: allies who participated tactically or whose state matters.
- `game_state/player/skill_mastery.json`: active skill practice/progress when a known active skill was used.
- `game_state/player/experience.json`: ordinary Mortal combat XP.
- `game_state/core/player_status.json`: health/energy/poise/status changes.

## Minimal ended-in-one-turn combat log

If the fight is over and no enemy remains active, it is valid to write only a combat log. Keep it player-facing and specific:

```json
{
  "combat_log_markdown": "Открытый бой с клятвенной тенью завершён: «Быстрый выпад» пробил ядро защитного узла. Тень рассеялась, но удар стоил энергии и оставил усталость."
}
```

## Active enemy shape guidance

When the opponent remains relevant, keep enough structure for `/бой`:

- id/name/displayName
- type/archetype or short role
- read-only common health/poise projections when supplied by the client; never persist current/maximum values in the combatant object
- status: active, defeated, fled, suppressed, restrained, or comparable canonical/readable state
- actions[] with at least one useful combat action if it can still act
- resistances and the read-only player-facing active effect projection when meaningful; never author a runtime effect carrier or remaining lifetime
- player-facing description of what the enemy is doing

## Output checklist

- If the narrative says "открытый бой", "вступает в бой", "бой с ...", or shows a concrete enemy exchange, write `combat_log.json`.
- If XP is awarded, update `experience.json` using `MORTAL_EXPERIENCE_LEVEL_TEMPLATE.md`.
- If an active skill was used, update `skill_mastery.json` using `MORTAL_SKILL_PROGRESSION_TEMPLATE.md` and keep the accepted-turn evidence aligned with `skillMasteryChanges`.
- Include every touched combat/player file in `Complete-BoeTurn -FilesModified`.
- If validation repair is requested with `mortal_combat_state_repair`, repair the existing combat scene; do not delete XP/mastery/status changes to avoid the combat state.

