# Init binds the existing session generation; each helper call owns a short admitted scope.
# After a storage-uncertain/transport-loss failure, retain evidence and stop this helper session; do not retry or re-Initialize it.
. '/tmp/gc-59862c3742e8/ship/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/gc-59862c3742e8/play/game_session'

