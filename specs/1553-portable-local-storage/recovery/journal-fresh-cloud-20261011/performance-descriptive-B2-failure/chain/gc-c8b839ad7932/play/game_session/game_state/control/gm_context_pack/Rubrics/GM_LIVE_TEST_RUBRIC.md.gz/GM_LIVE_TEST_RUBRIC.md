# GM Live-Test Rubric

Use this during harness live tests. The goal is not only to finish a turn; record whether the harness made the GM's work bounded, safe, and easy.

- Issue: #1290
- Trajectory ledger: `game_state/control/gm_trajectory_ledger.jsonl`
- Worker audit: `game_state/control/gm_worker_audit.jsonl`
- Structured notes: `game_state/control/gm_live_test_notes.jsonl`

## Dimensions

### turn_success
Valid output, player-facing narrative, correct command lifecycle, and exactly one terminal signal.

### harness_containment
No implementation-code browsing, no raw wrong-realm writes, no direct worker canonical writes.

### friction
Time to first valid turn, repair loops, missing-tool moments, context pack size/read volume.

### delegation
Whether a worker was used or should have been used; proposal quality and apply/reject outcome.

### experience_memory
Whether retrieved lessons, safe probes, and compact templates were used and helped.

### follow_up_generation
Repeated GM difficulty becomes a harness, validator/normalizer, rollback/tool issue, or explicit no-change rationale.

## Structured Note Shape

Append one JSON object per line to `game_state/control/gm_live_test_notes.jsonl` when a notable success, friction point, missing tool, delegation decision, or follow-up appears.

```json
{
  "noteId": "gmlivetest_<short_id>",
  "recordId": "gmtraj_<id or unknown>",
  "requestId": "<request id or empty>",
  "turnNumber": 0,
  "realm": "MortalWorld|ChaosSea|ShiningAbode|Unknown",
  "dimension": "turn_success|harness_containment|friction|delegation|experience_memory|follow_up_generation",
  "severity": "info|warning|blocker",
  "observation": "<what happened>",
  "harnessFollowUp": "<tool/validator/rollback/template/worker change, issue ref, or no-change rationale>",
  "issueRef": "#<issue number or empty>",
  "createdAtUtc": "<ISO 8601 UTC timestamp>"
}
```

Repeated difficulty should become a harness issue, validator/normalizer issue, rollback/tool issue, worker-packet issue, or explicit no-change rationale.

