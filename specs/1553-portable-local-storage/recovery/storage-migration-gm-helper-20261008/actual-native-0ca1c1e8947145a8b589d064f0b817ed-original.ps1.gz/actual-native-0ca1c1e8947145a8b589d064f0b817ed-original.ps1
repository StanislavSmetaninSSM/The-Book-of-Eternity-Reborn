$ErrorActionPreference = 'Stop'
. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-spiritual-helper-ea1ac112660a430b95c5797c719feb55/request-race/game_session'
$failure = ''; try { Complete-BoeValidationRepair -SpiritualWoundContinuationJson '{"schemaVersion":1,"continuationId":"swc_current","woundDecisions":[{"opportunityRef":"current_offer","decision":"none"}]}' } catch { $failure = $_.Exception.Message }
[IO.File]::WriteAllText('/tmp/boe-spiritual-helper-ea1ac112660a430b95c5797c719feb55/request-race/result.json', (ConvertTo-Json -InputObject @{ failure = $failure }), [Text.UTF8Encoding]::new($false))
