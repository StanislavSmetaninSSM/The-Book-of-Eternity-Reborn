. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
. '/workspace/boe-1553-storage-migration/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/boe-1553-storage-migration/TestResults/native-terminal/707f3c812dc648be860072bfdda41bc7' -TestSupport '/workspace/boe-1553-storage-migration/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-gm-qte-effect-helper-string-amount-b504282940bc431589e49df19622abc2/game_session'
$receipts = @([pscustomobject]@{ requestId = 'resource_resolution_001'; resultKind = 'resource_delta'; amount = '3'; reason = 'Кровотечение усиливается.' })
Complete-BoeQteEffectResolution -Receipts $receipts