. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-gm-qte-effect-helper-7530b67058ef4b8798e1df23c57cc4ee/game_session'
$script:BoeQteWriteOrder = [System.Collections.Generic.List[string]]::new()
$script:BoeQteOriginalWriteJson = ${function:Write-BoeJson}
function Write-BoeJson {
    param(
        [Parameter(Mandatory = $true)] [string]$RelativePath,
        [Parameter(Mandatory = $true)] [object]$Data,
        [int]$Depth = 100,
        [switch]$AllowClientOwnedRuntimeWrite
    )
    $script:BoeQteWriteOrder.Add($RelativePath)
    & $script:BoeQteOriginalWriteJson @PSBoundParameters
}
$receipts = @([pscustomobject]@{ requestId = 'resource_resolution_001'; resultKind = 'resource_delta'; amount = 3; reason = 'Кровотечение усиливается.' })
Complete-BoeQteEffectResolution -Receipts $receipts
[System.IO.File]::WriteAllLines('/tmp/boe-gm-qte-effect-helper-7530b67058ef4b8798e1df23c57cc4ee/write-order.txt', $script:BoeQteWriteOrder, [System.Text.UTF8Encoding]::new($false))