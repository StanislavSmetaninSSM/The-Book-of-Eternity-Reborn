. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-gm-qte-effect-helper-string-amount-af3f50b08c9e48b8b286401204d831f5/game_session'
$receipts = @([pscustomobject]@{ requestId = 'resource_resolution_001'; resultKind = 'resource_delta'; amount = '3'; reason = 'Кровотечение усиливается.' })
Complete-BoeQteEffectResolution -Receipts $receipts