$ErrorActionPreference = 'Stop'
. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
. '/workspace/boe-1553-storage-migration/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/boe-1553-storage-migration/TestResults/native-terminal/464a73c43b30455e96500f5d5fb8a4c2' -TestSupport '/workspace/boe-1553-storage-migration/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-spiritual-helper-0efcd3b36d6a495d88d4e2f16604e43f/request-race/game_session'
$failure = ''; try { Complete-BoeValidationRepair -SpiritualWoundContinuationJson '{"schemaVersion":1,"continuationId":"swc_current","woundDecisions":[{"opportunityRef":"current_offer","decision":"none"}]}' } catch { $failure = $_.Exception.Message }
[IO.File]::WriteAllText('/tmp/boe-spiritual-helper-0efcd3b36d6a495d88d4e2f16604e43f/request-race/result.json', (ConvertTo-Json -InputObject @{ failure = $failure }), [Text.UTF8Encoding]::new($false))
