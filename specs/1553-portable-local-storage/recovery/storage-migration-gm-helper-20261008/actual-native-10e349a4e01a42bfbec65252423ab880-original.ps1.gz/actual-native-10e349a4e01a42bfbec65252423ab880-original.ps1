$ErrorActionPreference = 'Stop'
. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-spiritual-helper-2538997a44c5418a8b6769dfa1a48312/request-race/game_session'
$failure = ''; try { Complete-BoeValidationRepair -SpiritualWoundContinuationJson '{"schemaVersion":1,"continuationId":"swc_current","woundDecisions":[{"opportunityRef":"current_offer","decision":"none"}]}' } catch { $failure = $_.Exception.Message }
[IO.File]::WriteAllText('/tmp/boe-spiritual-helper-2538997a44c5418a8b6769dfa1a48312/request-race/result.json', (ConvertTo-Json -InputObject @{ failure = $failure }), [Text.UTF8Encoding]::new($false))
