$ErrorActionPreference = 'Stop'
. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
. '/workspace/boe-1553-storage-migration/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/boe-1553-storage-migration/TestResults/native-terminal/33ce37ae0e43450e9c2ff90b7d85fa47' -TestSupport '/workspace/boe-1553-storage-migration/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/none/game_session'
$failure = ''; try { Complete-BoeValidationRepair -SpiritualWoundContinuationJson '{"schemaVersion":1,"continuationId":"swc_current","woundDecisions":[{"opportunityRef":"current_offer","decision":"none"}]}' } catch { $failure = $_.Exception.Message }
[IO.File]::WriteAllText('/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/none/result.json', (ConvertTo-Json -InputObject @{ failure = $failure }), [Text.UTF8Encoding]::new($false))
. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
. '/workspace/boe-1553-storage-migration/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/boe-1553-storage-migration/TestResults/native-terminal/33ce37ae0e43450e9c2ff90b7d85fa47' -TestSupport '/workspace/boe-1553-storage-migration/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/materialize/game_session'
$failure = ''; try { Complete-BoeValidationRepair -SpiritualWoundContinuationJson '{"schemaVersion":1,"continuationId":"swc_current","woundDecisions":[{
 "opportunityRef":"current_offer","decision":"materialize","woundRef":"will_fracture",
 "proposal":{"classification":{"woundType":"Fractured will","locationProfile":{"kind":"mental","readableLocus":"will"}},
  "display":{"name":"Fractured will","description":"Pressure disrupted concentration.","visibleSymptoms":["uncertainty"],
   "prognosis":"Healing restores the will.","visibility":"known_to_player","acquisitionNarration":"The guardian''s will fractured."},
  "severity":"I","complications":[],"consequenceDefinitions":[],
  "treatment":{"diagnosisPaths":[],"routes":[],"knownRouteIds":[],"completedRouteIds":[]},
  "recovery":{"mode":"requires_stabilization","clockKind":"afterlife_safe_cycle","cadence":1,
   "currentStepProgress":0,"currentStepThreshold":3,"lastTickKey":null,"blockers":["not_stabilized"],
   "carryOverflow":true,"deteriorationPolicy":null}}}]}' } catch { $failure = $_.Exception.Message }
[IO.File]::WriteAllText('/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/materialize/result.json', (ConvertTo-Json -InputObject @{ failure = $failure }), [Text.UTF8Encoding]::new($false))
. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
. '/workspace/boe-1553-storage-migration/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/boe-1553-storage-migration/TestResults/native-terminal/33ce37ae0e43450e9c2ff90b7d85fa47' -TestSupport '/workspace/boe-1553-storage-migration/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/guaranteed-materialize/game_session'
$failure = ''; try { Complete-BoeValidationRepair -SpiritualWoundContinuationJson '{"schemaVersion":1,"continuationId":"swc_current","woundDecisions":[{
 "opportunityRef":"current_offer","decision":"materialize","woundRef":"will_fracture",
 "proposal":{"classification":{"woundType":"Fractured will","locationProfile":{"kind":"mental","readableLocus":"will"}},
  "display":{"name":"Fractured will","description":"Pressure disrupted concentration.","visibleSymptoms":["uncertainty"],
   "prognosis":"Healing restores the will.","visibility":"known_to_player","acquisitionNarration":"The guardian''s will fractured."},
  "severity":"I","complications":[],"consequenceDefinitions":[],
  "treatment":{"diagnosisPaths":[],"routes":[],"knownRouteIds":[],"completedRouteIds":[]},
  "recovery":{"mode":"requires_stabilization","clockKind":"afterlife_safe_cycle","cadence":1,
   "currentStepProgress":0,"currentStepThreshold":3,"lastTickKey":null,"blockers":["not_stabilized"],
   "carryOverflow":true,"deteriorationPolicy":null}}}]}' } catch { $failure = $_.Exception.Message }
[IO.File]::WriteAllText('/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/guaranteed-materialize/result.json', (ConvertTo-Json -InputObject @{ failure = $failure }), [Text.UTF8Encoding]::new($false))
. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
. '/workspace/boe-1553-storage-migration/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/boe-1553-storage-migration/TestResults/native-terminal/33ce37ae0e43450e9c2ff90b7d85fa47' -TestSupport '/workspace/boe-1553-storage-migration/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/none-only/game_session'
$failure = ''; try { Complete-BoeValidationRepair -SpiritualWoundContinuationJson '{"schemaVersion":1,"continuationId":"swc_current","woundDecisions":[{"opportunityRef":"current_offer","decision":"none"}]}' } catch { $failure = $_.Exception.Message }
[IO.File]::WriteAllText('/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/none-only/result.json', (ConvertTo-Json -InputObject @{ failure = $failure }), [Text.UTF8Encoding]::new($false))
. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
. '/workspace/boe-1553-storage-migration/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/boe-1553-storage-migration/TestResults/native-terminal/33ce37ae0e43450e9c2ff90b7d85fa47' -TestSupport '/workspace/boe-1553-storage-migration/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/dependent/game_session'
$failure = ''; try { Complete-BoeValidationRepair -SpiritualWoundContinuationJson '{"schemaVersion":1,"continuationId":"swc_current","woundDecisions":[]}' } catch { $failure = $_.Exception.Message }
[IO.File]::WriteAllText('/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/dependent/result.json', (ConvertTo-Json -InputObject @{ failure = $failure }), [Text.UTF8Encoding]::new($false))
. '/workspace/boe-1553-storage-migration/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
. '/workspace/boe-1553-storage-migration/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/boe-1553-storage-migration/TestResults/native-terminal/33ce37ae0e43450e9c2ff90b7d85fa47' -TestSupport '/workspace/boe-1553-storage-migration/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/ordinary/game_session'
$failure = ''; try { Complete-BoeValidationRepair } catch { $failure = $_.Exception.Message }
[IO.File]::WriteAllText('/tmp/boe-spiritual-helper-2187f060c7694b7bb822f03a5bf0d059/ordinary/result.json', (ConvertTo-Json -InputObject @{ failure = $failure }), [Text.UTF8Encoding]::new($false))
