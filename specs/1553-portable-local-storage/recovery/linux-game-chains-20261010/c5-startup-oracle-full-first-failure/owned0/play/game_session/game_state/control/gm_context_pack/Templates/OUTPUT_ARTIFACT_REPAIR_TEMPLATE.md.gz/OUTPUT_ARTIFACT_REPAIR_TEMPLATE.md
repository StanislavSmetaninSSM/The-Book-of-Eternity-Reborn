# Output-only accepted turn repair

Use this template only in validation repair mode when
`validation_repair_request.json.harnessRepairPackets[].kind` is
`accepted_turn_output_artifact_repair`, especially for
`accepted_turn_stale_player_facing_output_after_canonical_repair` or
`narrative_response_technical_repair_leak`.

## Required flow

1. Dot-source `game_state/control/gm_turn_helper.bootstrap.ps1`.
2. Read `game_state/control/validation_repair_request.json`.
3. Read the current canonical state only as needed to align player-facing prose/options with the already repaired state.
4. Treat `harnessRepairPackets[].targetFiles` as an exact allowlist. A file absent from targetFiles must not be rewritten.
5. Rewrite only listed output artifacts:
   - `output/narrative_response.json`
   - `output/interface_updates.json`
   - `output/debug_logs.json`
6. When `output/debug_logs.json` is absent from `targetFiles`, preserve its full Actor Brain and exact `Изменения состояния` journal/ledger surfaces unchanged.
7. Do not touch canonical game_state files unless the current repair request still lists canonical state errors.
8. If the same current request lists canonical errors, complete every listed canonical write before rewriting any dependent player-facing output. The client retains the original canonical target set across every later output-only retry. Output must be strictly newer than the latest actual write of every retained target; equal timestamps are stale. Repair-loop start/request time is not a freshness boundary, and an unobservable target write fails closed.
9. Finish with `Complete-BoeValidationRepair` as the last command.

## Narrative response must stay diegetic

`output/narrative_response.json.response` is player-facing prose. Never mention
JSON, validation, repair, canonical state, arrays, file paths, field names,
storage mechanics, or that a technical state write succeeded. Keep such details
only in `output/debug_logs.json` or repair evidence.

## Minimal shapes

`output/narrative_response.json`:

```json
{
  "response": "<fresh player-facing narrative for the same accepted turn>",
  "timestamp": "<ISO 8601 UTC timestamp>"
}
```

`output/interface_updates.json`:

```json
{
  "dialogueOptions": [
    {
      "text": "<clean visible option>",
      "inputValue": "<optional exact input>"
    }
  ],
  "timestamp": "<ISO 8601 UTC timestamp>"
}
```

`output/debug_logs.json` (only when it is listed in `targetFiles`):

```json
{
  "gm_thoughts_markdown": "## NPC Scope\n- Mode: Scene-local | World-progression | Guardian-centric | Mixed\n- Relevant actors: <actors or нет>\n- Why relevant: <short reason>\n- Actors outside scope: <actors or нет>\n- Why outside scope: <short reason>\n\n## Actor Brain 2.0\n### <actor if any>\n- Текущая локация: ...\n- Ситуация: ...\n- Данные профиля: ...\n- Мотивация: ...\n- Ограничения: ...\n- Мысли: ...\n- Варианты стратегий:\n  1. <strategy>. Выгода: ... Риск: ...\n  2. <strategy>. Выгода: ... Риск: ...\n- Выбранная стратегия: ...\n- Почему альтернативы отвергнуты: ...\n- Действия: ...\n- Изменения состояния: ...",
  "timestamp": "<ISO 8601 UTC timestamp>"
}
```

## Rules

- This is output-only repair. Do not create a new turn, reroll dice, advance time, change rewards, or rewrite canonical state.
- Preserve the accepted player action and already repaired story meaning.
- If the old narrative/options contradict repaired canonical state, rewrite the text/options to match current canonical state.
- Preserve the original canonical target set named by the mixed repair even when a later request lists only output files. If any retained target is rewritten again, rewrite dependent output again after that latest write.
- If `output/debug_logs.json` is not listed in `targetFiles`, do not rewrite it.
- If `output/debug_logs.json` is listed, preserve its full Actor Brain blocks. Never shorten profile inputs, motivation, constraints, strategy alternatives with `Выгода:`/`Риск:`, chosen strategy, rejected alternatives, actions, or exact `Изменения состояния`.
- Preserve the exact memory surface already used: Mortal NPC `NPCJournals[].journalEntries[]`; Guardian `guardianThoughtJournalUpdates` or `UpdateGuardians.addMusings`; resident `residentThoughtJournalUpdates`; existing afterlife entity `ledger/progressionLedger`; existing Shining faction `shiningFactionChronicleUpdates`. Never replace one with generic `state unchanged` wording.
- If the accepted scope was genuinely actorless, preserve that actorless explanation and do not invent an actor.
- Keep player-facing `text` clean; put exact machine input in `inputValue` only when needed.
- Use actual paragraph breaks. Never place literal PowerShell newline tokens such as backtick+n or backtick+r+backtick+n in player-facing output; the helper/validator normalization is only a safety fallback.
- Do not write `ready/turn_complete.json` in validation repair mode.
- Do not search implementation source for output schema. This template and `validation_repair_request.json` are enough.

## Terminal rule

```powershell
Complete-BoeValidationRepair
```

