# Init binds the existing session generation; each helper call owns a short admitted scope.
# After a storage-uncertain/transport-loss failure, retain evidence and stop this helper session; do not retry or re-Initialize it.
. '/tmp/gc-f32e447d185f/ship/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/gc-f32e447d185f/play/game_session'

