import fcntl,json,os,pty,socket,subprocess,termios,time,urllib.request
from pathlib import Path
own=Path('/tmp/gc-1cb8b503c7dc');master,slave=pty.openpty();log=(own/'dashboard-diagnostic-host.log').open('wb')
with socket.socket() as s:s.bind(('127.0.0.1',0));url='http://127.0.0.1:'+str(s.getsockname()[1])
def child():os.setsid();fcntl.ioctl(slave,termios.TIOCSCTTY,0);os.tcsetpgrp(slave,os.getpid())
p=subprocess.Popen(['dotnet',str(own/'ship/BookOfEternityClient/BookOfEternityClient.dll'),str(own/'play'),'--web','--web-url',url],stdin=slave,stdout=log,stderr=subprocess.STDOUT,preexec_fn=child);os.close(slave)
try:
 deadline=time.monotonic()+12
 while True:
  assert p.poll() is None
  try:
   with urllib.request.urlopen(url+'/api/lifecycle/dashboard',timeout=1) as r:data=json.load(r)
   break
  except (OSError,urllib.error.URLError):assert time.monotonic()<deadline;time.sleep(.05)
 (own/'dashboard-diagnostic.json').write_text(json.dumps(data,ensure_ascii=False,indent=2));print(json.dumps(data['validation'],ensure_ascii=False))
finally:
 os.write(master,b'\x03');p.wait(timeout=12);log.close();os.close(master);assert p.returncode==0;print('diagnostic host normal exit0')
