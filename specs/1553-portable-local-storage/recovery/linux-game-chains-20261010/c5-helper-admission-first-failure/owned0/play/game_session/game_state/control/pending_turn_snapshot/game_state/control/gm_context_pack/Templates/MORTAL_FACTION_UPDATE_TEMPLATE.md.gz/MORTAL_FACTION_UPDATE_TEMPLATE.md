# Compact Mortal World Faction Update Template

Use this before creating or repairing Mortal World factions in `game_state/factions/faction_core.json` or sidecar faction files.

## Mortal faction identity repair

Validation issue kinds usually mean one of three things:

- `faction_full_object_unknown_faction_id`: a full `factions[]` object claims a permanent `factionId` that does not exist in canonical `faction_core.json`.
- `canonical_faction_sidecar_unknown_faction_id`: a sidecar entry references a faction that is not present in canonical `factions[]`.
- `faction_command_unknown_faction_id`: a response command targeted a faction id that is not canonical.

## Choose exactly one correction path

1. Reference an existing canonical factionId.
   - Use this when a sidecar or bounded command was meant to update an already existing faction.
   - Replace the bad id with the exact `factionId` from `game_state/factions/faction_core.json`.
   - If an existing identity was resent through full `factionDataChanges`, remove that full resend and express only the intended bounded command; do not relabel it as a creation.

2. Create the missing faction.
   - Use this only when the story really introduced a durable faction.
   - Use the complete `factionDataChanges[]` creation carrier before sidecars reference it.
   - Keep the id stable, lowercase/snake-like, and based on the faction, not on one scene line.

3. Remove or retarget the invalid sidecar.
   - Use this when the sidecar was speculative, duplicate, or belonged to a faction that should not exist.
   - Remove only the invalid sidecar entry, or retarget it to an existing canonical factionId.

## Repair packet authority

- In validation repair mode, `harnessRepairPackets[].targetFiles` is the exact writable allowlist. Do not edit an unlisted root even when it is related to the same faction.
- A Mortal faction location-control defect may name the exact affected location authority together with `game_state/world/current_location.json` and/or `game_state/world/world_map.json`. Repair only the roots actually listed.
- Preserve every unrelated faction, location, sidecar, receipt, and chronicle. Complete the whole listed faction bundle before signaling repair completion.

## Faction Materialization v1 creation carrier

```json
{
  "factionDataChanges": [
    {
      "factionId": null,
      "initialId": "faction_<stable_slug>",
      "isNewFaction": true,
      "name": "<Russian faction name>",
      "description": "<what the faction wants and why it matters>",
      "image_prompt": "<setting-aware visual prompt>",
      "factionColor": "#6F7958",
      "purpose": "<durable purpose>",
      "currentAgenda": "<current concrete agenda>",
      "principles": ["<principle>"],
      "memory": {
        "summary": "<durable memory>",
        "lastUpdatedTurn": 1,
        "enduringFacts": [],
        "openThreads": []
      },
      "governance": {
        "model": "<governance model>",
        "decisionProcess": "<decision process>"
      },
      "leadership": {
        "leadershipState": "vacant",
        "summary": "<leadership summary>",
        "leaderNpcIds": []
      },
      "powerProfile": {
        "military": 0,
        "economic": 0,
        "social": 0,
        "covert": 0,
        "logistics": 0,
        "stability": 0,
        "arcane_tech": 0,
        "exploration": 0
      },
      "ranks": {"branches": []},
      "structuredBonuses": [],
      "resources": {"metaResources": [], "strategicGoods": []},
      "relations": [],
      "activeProjects": [],
      "completedProjects": [],
      "controlledTerritories": [],
      "customStates": [],
      "scribeChronicle": ["#1 — <first durable faction event>"],
      "isPlayerFaction": false,
      "isPlayerMember": false,
      "playerRank": null,
      "playerBranch": null,
      "playerStrategyDirective": null,
      "reputation": 0,
      "reputationDescription": null,
      "level": 1,
      "experience": 0,
      "experienceForNextLevel": 100,
      "developmentArchetype": "<archetype>",
      "materialization": {
        "schemaVersion": 1,
        "materializationId": "mat_faction_<stable_slug>_turn_1",
        "factionType": "mortal_faction",
        "factionId": "faction_<stable_slug>",
        "materializedAtTurn": 1,
        "state": "complete",
        "capabilities": {
          "hasFormalHierarchy": false,
          "usesFactionResources": false,
          "maintainsRelations": false,
          "runsProjects": false,
          "holdsTerritoryOrInfluence": false,
          "supportsPlayerMembership": false,
          "usesCustomMechanics": false
        },
        "sections": {
          "hierarchy": {"state": "empty_by_design", "reason": "<why no ranks exist>"},
          "resources": {"state": "empty_by_design", "reason": "<why no common resources exist>"},
          "relations": {"state": "empty_by_design", "reason": "<why no relations exist>"},
          "projects": {"state": "empty_by_design", "reason": "<why no projects exist>"},
          "territoryAndInfluence": {"state": "empty_by_design", "reason": "<why no territory is controlled>"},
          "playerMembership": {"state": "empty_by_design", "reason": "<why membership is unavailable>"},
          "customStates": {"state": "empty_by_design", "reason": "<why no custom mechanics exist>"}
        }
      }
    }
  ]
}
```

Do not use this full carrier for an existing identity. Every existing faction must already have its accepted `materialization` envelope; receipt-less canonical state is invalid and is not promoted or migrated at runtime.

## Ordinary existing faction update

Use bounded `factionCoreChanges` only for semantic core groups. Keep rank/resource/project/chronicle mutations on their dedicated arrays.

```json
{
  "factionCoreChanges": [
    {
      "factionId": "faction_<existing_id>",
      "reason": "<why the semantic core changed>",
      "purposeAndPrinciples": {
        "purpose": "<complete current purpose>",
        "currentAgenda": "<new current agenda>",
        "principles": ["<complete current principle>"]
      },
      "progressionAndPower": {
        "level": 2,
        "experience": 0,
        "experienceForNextLevel": 140,
        "developmentArchetype": "<archetype>",
        "customArchetypePriorities": null,
        "powerProfile": {
          "military": 0,
          "economic": 0,
          "social": 0,
          "covert": 0,
          "logistics": 0,
          "stability": 0,
          "arcane_tech": 0,
          "exploration": 0
        }
      },
      "governanceAndLeadership": {
        "governance": {
          "model": "<governance model>",
          "decisionProcess": "<decision process>"
        },
        "leadership": {
          "leadershipState": "vacant",
          "summary": "<leadership summary>",
          "leaderNpcIds": []
        }
      }
    }
  ],
  "factionRankChanges": [],
  "factionResourceChanges": [],
  "factionProjectUpdates": [],
  "factionChronicleUpdates": []
}
```

Preserve existing ranks, branches, chronicles, relations, projects, resources, reputation, and the historical materialization envelope. Do not delete unrelated faction data to silence one identity error.

