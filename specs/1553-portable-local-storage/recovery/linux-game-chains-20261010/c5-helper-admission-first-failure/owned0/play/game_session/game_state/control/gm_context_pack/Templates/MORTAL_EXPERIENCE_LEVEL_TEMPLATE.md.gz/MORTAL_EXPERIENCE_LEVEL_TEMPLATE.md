# Compact Mortal experience and level template

Use this before Mortal World turns that award ordinary XP, resolve combat rewards, cross a level threshold, or need a controlled level-up test.

## Mortal experience rule

- Mortal XP lives in `game_state/player/experience.json`.
- Fresh Mortal bootstrap creates an empty structural file and does not assign a default level, XP threshold, or progression curve.
- On the first setting-aware progression decision, record the first complete progression tuple by adding an entry to `mortal_bootstrap_scaffold.json.structuredGmAuthority.playerProgression` with `canonicalPath: game_state/player/experience.json` and a non-empty `values` object containing every applicable `playerLevel`, `level`, `currentExperience`, `experience`, `totalExperience`, `experienceForNextLevel`, and `experienceGained` value exactly as written to canonical state.
- If a Mortal World scene grants XP, update the XP file in the same turn and include `game_state/player/experience.json` in `Complete-BoeTurn -FilesModified`.
- If updated `totalExperience >= experienceForNextLevel`, the level-up is not materialized yet. Advance `playerLevel` and `level`, then set `experienceForNextLevel` to the next threshold above `totalExperience`; otherwise validation will request repair.
- Do not leave a meaningful victory, completed objective, or combat reward prose-only when the scene clearly grants mechanical progress.
- Do not directly award stat points for ordinary level-up. The client-owned level-up/stat allocation flow grants stat points after it detects a higher `playerLevel`/`level`.
- Do not edit or remove `game_state/player/stat_points.json.levelUpStatPointsAwardedThroughLevel`; it is the client-owned restart-safe marker that prevents duplicate level-up stat-point awards.
- `statsIncreased` is for training a characteristic under Training Cap, not for distributing level-up points.

## Level-up metadata

The client detects level-up by comparing the new `playerLevel` or `level` in `experience.json` against the previous known level.

Keep both `playerLevel` and `level` synchronized when possible:

```json
{
  "playerLevel": 2,
  "level": 2,
  "currentExperience": 10,
  "experience": 10,
  "totalExperience": 110,
  "experienceForNextLevel": 150,
  "experienceGained": 25
}
```

If the turn does not cross a threshold, keep `playerLevel`/`level` unchanged and only advance counters:

```json
{
  "playerLevel": 1,
  "level": 1,
  "currentExperience": 35,
  "experience": 35,
  "totalExperience": 35,
  "experienceForNextLevel": 100,
  "experienceGained": 15
}
```

## Combat reward discipline

- Ordinary Mortal World combat may use `activeSkillChanges`, `skillMasteryChanges`, and `experienceGained` together when the scene used a known active skill and awarded XP.
- Skill mastery is separate from XP: update `skillMasteryChanges` for used active skills, and update `experience.json` for character-level progress.
- Explain the reward in player-facing Russian, but keep mechanical counters in `experience.json`.
- If the player should level now during a live test, ensure the final `totalExperience` crosses the old `experienceForNextLevel`, set the resulting `playerLevel`/`level` to the next level, and move `experienceForNextLevel` beyond the final `totalExperience`.

## Output checklist

- Read the current `game_state/player/experience.json` first.
- Write the updated `experience.json` atomically through the GM turn helper.
- Include `game_state/player/experience.json` in `Complete-BoeTurn -FilesModified`.
- Do not edit `game_state/player/stat_points.json` for ordinary level-up; the client handles stat points after turn acceptance.
- If `stat_points.json` exists, preserve its client-owned `levelUpStatPointsAwardedThroughLevel` marker.

