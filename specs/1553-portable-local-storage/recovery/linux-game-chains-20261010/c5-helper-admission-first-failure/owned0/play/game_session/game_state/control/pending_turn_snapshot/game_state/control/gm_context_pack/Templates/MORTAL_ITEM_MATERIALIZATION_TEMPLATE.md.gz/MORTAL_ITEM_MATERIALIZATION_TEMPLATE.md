# Compact Mortal Item Materialization Template

Use this before every durable ordinary Mortal item creation, repair, transfer,
split/merge/discard, storage move, or NPC trade. Soul Relics and afterlife
artifacts use their afterlife contracts instead.

## Choose exactly one new-root route

| route | sourceAuthority.kind | exact authority |
| --- | --- | --- |
| player_acquisition | turn_outcome | current accepted turn outcome |
| npc_acquisition | npc_inventory_add | exact NPCInventoryAdds owner/entry |
| new_npc_inventory | new_npc | exact genuinely-new NPC creationRef |
| loot_acquisition | loot_template | derived validated loot template key |
| craft_output | craft_request | pending craft request ID |
| trade_output | npc_trade_receipt | exact trade request/receipt and unique slotId |
| quest_reward | quest_reward | exact canonical quest/reward authority |
| storage_placement | location_storage | exact existing location/storage authority |

## Complete raw new root

- `existedId = null`; omit `itemId`, `id`, `initialId`, and
  `materializationReceipt`.
- Add one turn-unique top-level `creationRef`; repeat it exactly in the
  envelope. For trade output it equals the unique current-schema `slotId`.
- Supply every semantic field: name/description/image_prompt/type/group,
  quality/rarity/price/count/weight/volume,
  bonuses/effects/structuredBonuses/combatEffect/customProperties and both
  mechanical-summary fields, equipment fields, container fields including
  `contentsPath`, consumption, readable/sentient fields, disassembly, bond,
  Fate Card, and quest-link fields.
- Add the exact envelope fields: schemaVersion=1, unique materializationId,
  realm=Mortal, route, sourceTurn, sourceAuthority{kind,authorityId},
  creationRef, state=complete, and `materialization.sections`.
- Declare all twelve sections: presentation, physical, mechanics, equipment,
  container, consumption, readableOrSentient, craftingAndDisassembly,
  bondsAndFateCards, questRole, provenance, ownershipAndPlacement.
- If the item owns durability, charges, ammunition, fuel, doses, or another
  sealed bounded reserve, declare `resourceMaterialization.resources[]` with
  exact `resourceKey` and positive `maximum`; never add a direct item value.
- `empty_by_design` needs a non-empty in-world reason and the canonical empty
  field shape. `populated` must have matching structured semantic evidence.

Do not create `itemId`, `materializationReceipt`,
`game_state/inventory/item_identity_index.json`, seals, transitions,
retirement, or lineage. The client seals the item only after raw validation.
Receipt-less canonical state is invalid; the game has not shipped and there is
no runtime promotion/migration path.

## Existing physical item

Resolve exact ordinal `itemId`. A transfer removes one source copy, creates one
destination copy, and preserves envelope, receipt, and unrelated semantics.
Canonical `contentsPath` is null or an ordered permanent-parent-item-ID chain;
same-turn raw parents use `creationRef` and are rewritten by the client. A
GM-authored item must not add `isCarried`, `currentLocationId`, or
`currentLocationName`: they are not placement authority. Exact route
destination, carrier, and `contentsPath` govern placement. A
split keeps the source ID and creates a client-derived child; merge keeps the
selected survivor; full discard retires as destroyed.

## Repair

For `mortal_item_materialization_repair`, write only the exact GM-owned targets
listed in `harnessRepairPackets[].targetFiles`. Never repair a protected ID,
receipt, seal, index, transition, carrier history, or lineage. Protected or
unresolved authority is a client rollback, not permission for whole-file
rewrites. For complete worked JSON, open
`Examples/E_CLI_Mortal_Item_Materialization.txt`.

