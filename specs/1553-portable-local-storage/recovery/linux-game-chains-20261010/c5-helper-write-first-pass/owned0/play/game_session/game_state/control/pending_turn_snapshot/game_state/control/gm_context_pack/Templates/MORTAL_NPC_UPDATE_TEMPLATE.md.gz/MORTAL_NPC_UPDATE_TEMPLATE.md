# Compact Mortal World NPC Update Template

Use this before creating or repairing Mortal World NPCs in `game_state/npcs/npc_core.json`.

## When to use

- A Mortal World turn introduces a named NPC who is present, speaks, gives a clue, changes state, or changes relationship.
- Role-identifiable visible, speaking, acting, clue-giving, or directly addressed scene actors are NPC candidates even when their personal name is unknown. Use a stable role-based visible name such as `Агент дома Виренто`, then update/rename later when the player learns the real name.
- Validation reports `mortal_relevant_actor_missing_persistence`, `npc_full_object_missing_required_fields`, `npc_attitude_relationship_tier_mismatch`, `npc_invalid_cultural_stance`, `npc_same_turn_initial_location_requires_null_current_location`, `npc_journal_unknown_npc_reference`, `missing_actor_current_location`, or object/nullability errors under `game_state/npcs/npc_core.json`.

## Actor Materialization v1

- Every genuinely new significant NPC must carry one immutable `materialization` envelope in its full `NPCsInScene`/`UpdateNPCs` object.
- Bind it to the exact `actorType:actorId` pair. Mortal NPCs use `actorType: mortal_npc`; a same-turn new NPC uses the same stable `initialId` as `materialization.actorId`.
- Never infer skills, inventory, teaching, trade, combat capability, or identity from a display name, prose, occupation, or setting genre. Names, archetype prose, item types, and genre keywords never grant mechanics. Materialize only structured facts justified by the current world and scene.
- `capabilities` must agree with the full NPC object. Every required entry under `sections` is either `populated` or `empty_by_design`; `empty_by_design` requires a concise in-world reason and keeps the governed real canonical empty field physically present in its exact empty array/object/null shape.
- First materialization requires 3-5 `personalityTraits`; each trait includes `value` as a JSON integer from 1 through 10.
- A new Mortal `UpdateNPCs` actor requires exactly one non-empty location authority: a known canonical `currentLocationId` with null `initialLocationId`, or a valid same-turn `initialLocationId` with null `currentLocationId`. Never omit both or populate both.
- For an already materialized existing NPC, preserve the original envelope byte-for-byte. Apply later changes through a dedicated delta/command surface or bounded `NPCCoreChanges`; do not resend or regenerate `materialization`.
- For a legacy promotion, add the first complete envelope and change only the role fields that establish the newly gained capability: `teacherProfile` for teaching, `tradeState` for trade, `activeSkills`/`passiveSkills` for combat, or `plans`/`currentActivity`/`completedActivities` for first Actor Brain scope. Preserve every unrelated pre-turn field. Include schema-required `inventory` only when it is semantically identical to the validated pre-turn inventory snapshot. Inventory additions, changes, and removals remain dedicated-command-only.
- Never emit two current Mortal actor records under the same effective same-turn identity. `tradeInventory` and `trainingShowcase` are not legacy-promotion fields: change stock only for the exact pending NPC trade request plus matching ready receipt, and change a showcase only for the exact pending `mortal_teacher_showcase` request. Prefer the GM helper; a manual training fallback is a narrow `UpdateNPCs` patch containing only exact identity/display fields and the request-bound `trainingShowcase`.

## Ordinary existing core changes

- `NPCCoreChanges` is a Mortal-only non-carrier command mapped to `game_state/npcs/npc_core.json`. It targets one exact existing permanent `NPCId`; never target by name or `initialId`.
- Every entry needs a non-empty in-world/mechanical `reason` and at least one non-empty mutation group. Values are absolute resulting values, not expressions or prose math.
- Include only groups that actually change. Omit every unused optional group; never emit an empty object or array as a placeholder.
- Allowed groups are exactly `profile`, `location`, `progression`, `characteristicValues`, `factionAffiliationsToUpsert`, `fateCardsToAdd`, and `fateCardIdsToRemove`. Unknown members and protected identity/name/materialization/inventory/equipment/skill/relationship/journal/goal/quest/activity/mask/custom-state/teacher/trade fields are forbidden.
- `characteristicValues` may use only keys already owned by the actor or explicit current-world characteristic authority. Carrying and progression formulas also come only from explicit current-world authority; keep setting-owned nullable results null when no authority exists.
- Unlock cards through `NPCFateCardUnlocks`. Add only complete new initially locked cards and remove only validated pre-turn locked/unrealized cards through `NPCCoreChanges`.

```json
{
  "NPCCoreChanges": [
    {
      "NPCId": "exact_existing_permanent_npc_id",
      "reason": "non-empty in-world and mechanical justification",
      "profile": {
        "worldview": "absolute replacement from the current story"
      }
    }
  ]
}
```

## Scene NPC location rules

- Put scene-local present NPCs in `NPCsInScene`.
- NPCsInScene is only for actors physically present in currentLocationData. Voices behind a door, guards in a nearby corridor, people near nearbyExitLocationId, route pressure, and exit pressure are not scene NPCs for the current room; keep them in narrative, current location memory, quest/faction/location memory, or Actors outside scope. A genuinely new durable off-screen actor may use a complete `UpdateNPCs` object at its own location; an existing actor moves only through `NPCCoreChanges.location`.
- If `currentLocationData.locationId` is a known permanent id, set `currentLocationId` to that id and set `initialLocationId` to `null`.
- If the current scene is a same-turn new location (`currentLocationData.locationId = null` with `currentLocationData.initialId`), set `initialLocationId` to that exact initial id and set `currentLocationId` to `null`.
- Keep `currentLocationName` as the visible current location name.
- For a genuinely new NPC, use `NPCId: null` plus non-empty `initialId`; do not invent a permanent NPCId before the client materializes it.
- Identity continuity is strict: same-turn initialId must not collide with a validated pre-turn permanent NPCId. Restore that actor's permanent NPCId instead of disguising it as a new actor.
- `inventory` inside the full NPC object is allowed for a genuinely new NPC's initial carried inventory. The only existing-identity exception is the unchanged snapshot required for a legacy promotion; every mutation uses `NPCInventoryAdds`, `NPCInventoryUpdates`, or `NPCInventoryRemovals`.
- Use canonical `culturalStance`: `Conformist`, `Pragmatist`, or `Dissident`.
- Keep `relationshipLevel` numeric. For neutral/unknown NPCs use `0` and `attitude: "Neutral"`.
- Nullable string fields must be either a real string or JSON `null`, not `{}` and not missing when validator names them.
- Object-shaped fields must stay objects: `progressionTrackers`, `goals`, `relationshipLock`, `personalityTraits[]` entries.
- `activeSkills` and `passiveSkills` must contain full skill objects, not string names. Put the visible name in `skillName`/`displayName`; active skills need action/combat fields, passive skills need type/group/bonus fields.

## NPC journal notes

Use `game_state/npcs/npc_journals.json` when the player can later inspect what the NPC thought, noticed, promised, hid, or remembered.

For a relevant NPC that receives a player action or makes a decision, append a fresh first-person current-turn entry in the same accepted turn. Never edit an old `journalEntries[]` object to imitate a new thought.

NPC journal shape is not the same as inventory item journal shape:

```json
{
  "NPCJournals": [
    {
      "npcId": "npc_<stable_slug>",
      "npcName": "<visible Russian name>",
      "lastJournalNote": "<latest player-facing note>",
      "journalEntries": [
        {
          "entryId": "npc_thought_<stable_current_turn_id>",
          "description": "<concise first-person thought: what I noticed, feared, concluded, or intend>",
          "timestamp": "<ISO 8601 UTC timestamp>",
          "event": "<short optional event label>",
          "emotionalImpact": "<optional emotional shift>",
          "relationshipChange": "<optional relationship shift>"
        }
      ]
    }
  ]
}
```

## Minimal safe NPC scene object

The `characteristics` object below is a setting-defined placeholder. Copy the actual keys from current-world canonical characteristic authority; never reuse a universal list. If current-world authority supplies no carrying formula or compatible item weights, keep `maxWeight` and `totalWeight` null.

```json
{
  "NPCId": null,
  "initialId": "npc_<stable_slug>",
  "npcName": "<visible Russian name>",
  "name": "<same visible Russian name>",
  "role": "<short role in this scene>",
  "image_prompt": "<English image prompt>",
  "rarity": "Common",
  "worldview": "<one sentence>",
  "personalityArchetype": "<stable_snake_case>",
  "culturalStance": "Pragmatist",
  "race": "Человек",
  "class": "<social/combat role>",
  "appearanceDescription": "<visible appearance>",
  "history": "<relevant known background>",
  "progressionType": "static_social_npc",
  "initialLocationId": null,
  "currentLocationId": "<currentLocationData.locationId for known current location>",
  "currentLocationName": "<current location name>",
  "age": 30,
  "level": 1,
  "experience": 0,
  "experienceForNextLevel": 100,
  "relationshipLevel": 0,
  "attitude": "Neutral",
  "playerCompanionDirective": "not_companion",
  "culturalLayer": "<world/culture/faction context>",
  "personalityTraits": [
    {
      "traitId": "trait_<npc_slug>_<short>",
      "name": "<trait name>",
      "summary": "<short trait summary>",
      "traitName": "<same trait name>",
      "description": "<short description>",
      "value": 5,
      "valueDescription": "<how it matters in play>"
    },
    {
      "traitId": "trait_<npc_slug>_<short_2>",
      "name": "<second trait name>",
      "summary": "<short second trait summary>",
      "traitName": "<same second trait name>",
      "description": "<short second description>",
      "value": 5,
      "valueDescription": "<how the second trait matters in play>"
    },
    {
      "traitId": "trait_<npc_slug>_<short_3>",
      "name": "<third trait name>",
      "summary": "<short third trait summary>",
      "traitName": "<same third trait name>",
      "description": "<short third description>",
      "value": 5,
      "valueDescription": "<how the third trait matters in play>"
    }
  ],
  "maxWeight": null,
  "totalWeight": null,
  "isOverloaded": false,
  "progressionTrackers": {
    "active": [],
    "completed": [],
    "summary": "No mechanical progression tracker changed in this scene."
  },
  "plans": "<immediate plan or empty string>",
  "personalQuests": [],
  "relationshipLock": {
    "isLocked": false,
    "lockState": "none",
    "reason": "",
    "breakthroughQuestId": null
  },
  "characteristics": {
    "setting_defined_characteristic_key": 0
  },
  "activeSkills": [],
  "passiveSkills": [],
  "equippedItems": {},
  "fateCards": [],
  "inventory": [],
  "goals": {
    "primary": {
      "goalId": "goal_<npc_slug>_<short>",
      "title": "<goal title>",
      "status": "active",
      "summary": "<why it matters now>"
    },
    "shortTerm": "<current scene aim>",
    "longTerm": "<longer aim>"
  },
  "sceneStatus": "present",
  "turn": 0,
  "lastSeenAtUtc": "<ISO 8601 UTC timestamp>",
  "materialization": {
    "schemaVersion": 1,
    "materializationId": "mat_npc_<stable_slug>_turn_0",
    "actorType": "mortal_npc",
    "actorId": "npc_<stable_slug>",
    "materializedAtTurn": 0,
    "state": "complete",
    "capabilities": {
      "canFight": false,
      "canTeach": false,
      "canTrade": false,
      "ownsItems": false
    },
    "sections": {
      "skills": { "state": "empty_by_design", "reason": "Персонаж не демонстрирует оформленных навыков в этой сцене." },
      "inventory": { "state": "empty_by_design", "reason": "У персонажа нет значимых переносимых предметов." },
      "fateCards": { "state": "empty_by_design", "reason": "Связанный узел судьбы ещё не проявился." },
      "personalQuests": { "state": "empty_by_design", "reason": "Личная задача персонажа пока не возникла." },
      "relationships": { "state": "populated" }
    }
  }
}
```

If the NPC is only background color and does not act, speak, give clues, receive a player action, or change state, do not put them in `Relevant actors`; move them to `Actors outside scope` instead of creating a partial NPC object.

