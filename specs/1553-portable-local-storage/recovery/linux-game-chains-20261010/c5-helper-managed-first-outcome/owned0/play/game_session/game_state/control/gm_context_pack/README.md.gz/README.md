# GM Session Context Pack

This folder is generated for the current live game session.

Start here instead of browsing repository implementation code.

- Read context_pack_manifest.json first.
- Bootstrap scope: read only context_pack_manifest.json and README.md.
- Do not open copied guides/examples during bootstrap; they are large and route-specific.
- Use Probes/GM_SAFE_PROBES.md for bounded read-only context questions before implementation source.
- Use Templates/* before opening large copied examples for common turn, repair, progression, Mortal World NPC updates, Mortal World faction updates, Mortal World location transitions, Mortal World skill progression, Mortal World experience and level progression, Mortal World combat state, actor reasoning, and tempoAdvantage shapes.
- Use Lessons/GM_EXPERIENCE_LESSONS.md as short hints only; validators and current templates remain authoritative.
- Ordinary turn prompts may include an inline RLM PRE-TURN LESSONS digest when relevant; use that compact digest before writing state.
- Use Rubrics/GM_LIVE_TEST_RUBRIC.md during live tests to record harness friction and follow-up notes in game_state/control/gm_live_test_notes.jsonl.
- Open large copied docs only when a per-turn, repair, or terminal-failure prompt explicitly names them.
- Use '/tmp/gc-7a41532db940/play/game_session/game_state/control/gm_turn_helper.bootstrap.ps1' for safe JSON writes and terminal signals.
- During normal play or validation repair, do not read implementation code such as BookOfEternityClient/**/*.cs.
- If validation repair is requested, use game_state/control/validation_repair_request.json, especially harnessRepairPackets[].

