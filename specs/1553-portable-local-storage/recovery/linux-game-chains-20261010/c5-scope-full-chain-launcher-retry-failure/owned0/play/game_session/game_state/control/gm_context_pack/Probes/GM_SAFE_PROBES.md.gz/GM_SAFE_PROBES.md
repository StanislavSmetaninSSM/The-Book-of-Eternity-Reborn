# GM Safe Probes

Safe GM probes are read-only context surfaces. Prefer them before repository source; if a needed fact is missing, record a missing harness surface instead of treating implementation source as normal workflow.

Mutation policy: read-only unless a probe explicitly routes through an existing validated apply or rollback gate.
Missing harness surface rule: if the probe set lacks a fact, record that gap instead of making implementation source the normal route.

## current_realm_mode_summary
Identify the active realm, turn mode, request metadata, and progression contour without broad state spelunking.
- Source authority: input/turn_request.json, game_state/meta/soul_state.json, game_state/meta/shining_abode_state.json
- Limitations: Does not authorize writes; validators and pending/control files remain authoritative.

## active_pending_contracts
List active pending/control contracts the GM must close or respect this turn.
- Source authority: game_state/control/pending_*.json, game_state/control/*_request.json, game_state/control/progression_schedule.json
- Limitations: Summarizes contracts only; use compact templates and contract matrix for exact output shape.

## validation_issue_summary
Explain current validation issues, repair packets, and allowed repair targets without source-code archaeology.
- Source authority: game_state/control/validation_repair_request.json, game_state/control/terminal_protocol_failure_request.json
- Limitations: Does not replace validation; repair only listed files and use helper terminal functions.

## allowed_output_templates
Point to compact executable templates for common output shapes.
- Source authority: Templates/TURN_OUTPUT_TEMPLATE.md, Templates/VALIDATION_REPAIR_TEMPLATE.md, Templates/PROGRESSION_REPORT_TEMPLATE.json, Templates/ACTOR_REASONING_TEMPLATE.md, Templates/MORTAL_NPC_UPDATE_TEMPLATE.md, Templates/MORTAL_FACTION_UPDATE_TEMPLATE.md, Templates/MORTAL_ITEM_MATERIALIZATION_TEMPLATE.md, Templates/MORTAL_LOCATION_TRANSITION_TEMPLATE.md, Templates/MORTAL_SKILL_PROGRESSION_TEMPLATE.md, Templates/MORTAL_EXPERIENCE_LEVEL_TEMPLATE.md, Templates/MORTAL_COMBAT_STATE_TEMPLATE.md, Templates/AFTERLIFE_CHRONICLE_TEMPLATE.md, Templates/AFTERLIFE_TEMPO_ADVANTAGE_TEMPLATE.json
- Limitations: Templates are shape guidance; current validators are final authority.

## rollback_status
Show rollback baseline and auto-rollback diagnostics before the GM attempts manual undo.
- Source authority: game_state/control/pending_turn_snapshot.json, game_state/control/pending_turn_snapshot.authority.json, game_state/control/validation_auto_rollback_report.json
- Limitations: Any future restore action must route through an explicit validated rollback/apply gate, not ad hoc file edits.

## worker_role_summary
List enabled worker roles and proposal-only task types without giving workers canonical write authority.
- Source authority: config.json:GmWorkerBridgeProfiles, game_state/control/gm_worker_audit.jsonl, worker_proposals/inbox
- Limitations: Worker proposals are suggestions until the apply gate accepts them.


