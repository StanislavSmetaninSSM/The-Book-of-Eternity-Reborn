# Afterlife Combat Terminology Glossary

The spiritual conflict danger declaration is mandatory: put `dangerMode` in the selected `conflictState`/`activeConflict`/`conflictSeed` of `mode=start`, canonical `activeConflict`, and every `recentConflicts[]` proof. Use exactly `training`, `controlled`, `hostile`, or `annihilation`: lowercase JSON strings without surrounding whitespace. There is no implicit mode or old-save fallback. Ordinary exchanges and partial `activeConflictAfter`/`conflictStateAfter` replacements may omit the field and preserve the accepted declaration; explicit echoes must match exactly, including in the update root and exchange `before`/`after`. `resolve` and `repair_cancel` copy that declaration into the terminal proof and cannot replace it. During a validated turn, every retained same-ID active/recent occurrence is compared with the signed pre-turn declarations; a missing, invalid or conflicting baseline fails closed, and a later duplicate cannot hide a change. Legal removal from the bounded recent-history window is unchanged. Do not infer escalation after a roll or submit a boolean as escalation authority. This declaration/persistence stage does not implement accepted escalation, wound production or healing. The declared wound ceilings remain training 0, controlled II, hostile/annihilation IV; wounds are optional GM choices within validated limits, and soul dissipation remains separately authorized and always optional.

**Effect Materialization v1:** terminology below follows the shared active-effect contract in `OtherGuides/Effect_Materialization_Contract.md`.

This glossary fixes the Russian player/GM labels for afterlife combat terms. Canonical JSON field names, enum values, command tags, and validation ids stay in English; UI and GM-facing prose should show the Russian label first and keep the canonical term nearby when it matters for authoring JSON.

Unified resource boundary: `spiritual_action_points`, `gacha_attempts`, and `blessing_rerolls` are client-owned entries in `game_state/resources/resource_state.json`, with immutable evidence in `game_state/resources/resource_history.json`, exact afterlife `resourceOwnerBindings`, and client-owned `game_state/resources/resource_owner_authority.json`. Definitions/state/history/owner-authority are one guarded quartet; the GM never authors them, and missing/stale authority outside explicit bootstrap fails closed without migration or self-heal. Persisted `actionEconomy`, per-return numeric gacha counters, and numeric blessing mirrors are forbidden. The GM uses projected values and the existing audit/result surfaces. Ink Feathers, Light Sparks, progression, relationships, faction accounting, and spiritual power/strain/shield remain specialized rather than becoming resources. The blessing contract is `blessing_rerolls + freeShape/freeRetune`; the booleans remain typed entitlements. A blessing card's client-generated transient `rerollAllocation` contains exactly `resourceKey = blessing_rerolls` and a non-negative integer `amount`; Mortal bootstrap consumes it into the common ledger and replaces it with the exact client-owned `rerollResourceBinding`. Neither field is GM-authored. No migration or raw fallback exists.

| Canonical term | Russian label | Use in play |
|---|---|---|
| afterlife spiritual conflict | духовный конфликт посмертия | The whole afterlife combat-like contest system in `Chaos Sea` or ordinary active `Shining Abode`. |
| afterlife spiritual action | духовное действие посмертия | A player action inside an already active conflict; `/spiritual_action` only adds an explicit routing tag. |
| afterlife spiritual combat log | журнал духовного боя | Read-only player-facing log of active `exchangeLog[]` and resolved `recentConflicts[]`; shown through `/spiritual_combat_log`. |
| Spiritual Arts | духовные искусства | Client-owned afterlife combat upgrades stored in `soul_state.afterlifeCombatProfile.artTiers`. |
| Spirit Focus | Средоточие Души | Client-owned progression tier in `soul_state.afterlifeCombatProfile.spiritFocusTier`; it supplies the registered maximum for the player's `spiritual_action_points` resource when a spiritual conflict starts, but is not itself a resource. |
| exchange | обмен действиями | One resolved beat inside an active conflict; written through `afterlifeSpiritualConflictUpdate.mode=exchange`. |
| resolve | завершение конфликта | Terminal closure of an active conflict; written through `mode=resolve` and moved into `recentConflicts[]`. |
| repair_cancel | repair-отмена / ремонтная отмена | Non-reward cleanup of malformed or impossible conflict state. |
| diceAudit | аудит кубиков | Required visible-dice proof for contested exchanges and contested terminal resolutions. |
| rollMode | режим броска | Part of `diceAudit`: records Преимущество / Помеха per side through `effectiveMode`, `advantageSources[]`, and `disadvantageSources[]`. Supports `normal`, `advantage`, `great_advantage`, `disadvantage`, and `dire_disadvantage`. |
| combatConditions | боевые условия | Dedicated `combatConditions[]` layer for visible or private afterlife spiritual-combat buffs/debuffs. Kinds are `mark`, `ward`, `burden`, `opening`, and `vow`; each entry needs target, source, affected operations, duration/uses, `counterplay`, and summary. Visible active combatConditions appear in player-facing conflict/log output; hidden/gm_only combatConditions stay private. They modify only legal axes such as `rollMode`, `conflictPosition`, `controlState`, side strain, `tempoAdvantage`, `counterPayoff`, `actionCostAudit`, or `specialArtAudit.effectNote`; no generic passive stat stacking. |
| mark | метка | A `combatConditions[]` kind that makes a named target easier to pressure, track, bind, or punish through a legal audited axis such as condition-backed rollMode or vulnerability in `specialArtAudit.effectNote`. |
| ward | оберег | A `combatConditions[]` kind that protects a side/actor or makes a listed operation safer/costlier for the opposition through `rollMode`, `actionCostAudit`, `tempoAdvantage`, or a documented special-art effect note. |
| burden | бремя | A `combatConditions[]` kind that makes a target's listed operation harder, costlier, riskier, or more punishable through `actionCostAudit`, disadvantage sources, strain risk, or `counterPayoff`. |
| opening | брешь | A `combatConditions[]` kind that exposes a temporary weakness for a named operation; it should be consumed by a specific follow-up, a condition-backed rollMode source, a counter payoff, or an audited position/strain change. |
| vow | обет | A `combatConditions[]` kind that records a spiritual promise, law, or oath as a bounded combat condition with counterplay; it may protect, constrain, or punish only through the same legal axes as other conditions. |
| counterplay | ответ на условие | Required source-owned text/list on every active `combatConditions[]` entry explaining how the target can answer it. The GM requests lifecycle only through `effectChanges[]`; the client materializes/advances the carrier and exposes accepted contributions through `afterlifeSpiritualConflictPreview.conditionMechanics`. Expired/consumed entries do not keep active effects. |
| selection | выбор кубика | Field on `diceUsed[]`: `selected` is the die used for totals and criticals, `discarded` is rolled but ignored because of Преимущество / Помеха. |
| difficultyAudit | аудит сложности | Part of `diceAudit` and `rewardAudit` when `game_state/core/game_settings.json.difficulty` is readable; records selected difficulty, opposition modifier, and reward multiplier. |
| rewardAudit | аудит награды | Required proof when a resolved victorious conflict grants Ink Feathers or Light Sparks. |
| criticalResult | аудит критического исхода | Required normalization proof when natural 20/1 changes the margin-derived `outcomeBand`. |
| counterPayoff | выигрыш контрприёма | Required measurable payoff for a `counter` with success/partial_success/countered: either `counterPayoff`, improved `conflictPosition`, or worsened `oppositionSideStrain`. |
| matchupAudit | аудит сопоставления действий | Required on new/current contested exchanges with `diceAudit`; records the player's operation, opposition operation, resolution lane, risk profile, and rationale for the tactical matchup. |
| controlState | состояние контроля / оков | Canonical control axis for afterlife spiritual combat. It is separate from strain and position: `level`, `controllerSide`, `controlId`, `sourceOperation`, `restrictedOperations`, and `summary` record who controls whom and what actions are restricted. Missing/null means no active control for legacy entries. `sourceOperation=binding|force_binding|force_incarnation|break_binding|incarnation_resistance|counter|guard|repair`; it is not a free operation id. |
| tempoAdvantage | темповое окно защиты | One-use Преимущество created by successful `guard` against direct `pressure` / forced pressure. It is stored under `activeConflict` and exchange `before/after` snapshots, then consumed by the next eligible non-terminal combat action through `rollMode.player.advantageSources[]`. |
| controlState.level | уровень контроля | `none` / нет контроля, `hindered` / стеснён, `bound` / скован, `locked` / запечатан. |
| operationType | тип операции | Mechanical type of an exchange/resolution, such as `pressure`, `guard`, or `force_incarnation`. |
| outcome | исход | Mechanical outcome of an exchange, such as `success`, `blocked`, `countered`, or `no_effect`. |
| side strain | напряжение стороны | `playerSideStrain` / `oppositionSideStrain`; tracks pressure on each side, not hit points. |
| conflictPosition | позиция конфликта | Current advantage state from `opposition_dominant` to `player_dominant`. |
| direct_duel | прямой поединок | Player side lead acts directly against opposition lead. |
| assisted_duel | поединок с поддержкой | Player is still lead, but supporters contribute minor bonuses/fictional leverage. |
| champion_duel | поединок чемпиона | A stronger ally/champion can be the lead contestant while the player supports. |
| forced incarnation | принудительное воплощение | Coercive Guardian attempt to send the soul into a life; not the same as voluntary `TriggerIncarnation`. |
| guardian_forced | принудительное Хранителем | Canonical trigger source for forced incarnation; requires strict conflict/provocation proof. |
| retainedRadianceRank | сохранённый ранг Сияния | Radiance rank retained after returning from Shining Abode to Chaos Sea. |
| enlightenmentRank | ранг Просветления | Chaos Sea progression rank used for afterlife conflict authority and art gates. |
| radianceRank | ранг Сияния | Shining Abode progression rank used for afterlife conflict authority and art gates. |
| art tier | уровень искусства | Upgrade tier of a spiritual art; ranks cap the maximum tier that can be purchased. |
| spiritual_resilience / spiritual_healing | Духовная стойкость / Духовное исцеление | Required ordinary `standardArts` scalar integer 0..5 entries in every complete current afterlife profile. They are visible at zero, are not `{tier, experience}` objects, and have no independent art experience. Player authority lives in `soul_state.afterlifeCombatProfile.artTiers`; `player_soul.standardArts` is only its mirror. Духовная стойкость is passive and is not an `operationType`; Духовное исцеление becomes an operation only with its separate healing handler. |
| Source of Light | Источник Света | Full-Radiance Shining capstone scene closed through `pending_source_of_light_capstone.json`. |
| light_incarnate | Воплощение Света | Soul-owned capstone passive that adds explicit player-side dice modifiers in afterlife spiritual conflicts. |
| Incarnated Light | Воплощенный Свет | One-per-soul Soul Relic `source_of_light_incarnated_light`; in Mortal lives it gives characteristic bonuses through Soul Relic effects. |
| afterlife entity profiles | Профили сущностей посмертия | Read-only/player-visible profile sidecar `game_state/meta/afterlife_entity_profiles.json`; GM updates it through `afterlifeEntityProfileUpdates` when significant afterlife actors are created, revealed, or materially changed. The reserved `player_soul` entry is only a partial mirror for player-owned wallet/progression/ordinary arts; the client refreshes those fields from `soul_state.json` and `shining_abode_state.json`. |
| player_soul profile identity | профиль души игрока | Reserved afterlife entity identity: the player profile uses `actorType=player_soul` and `actorId/actorRef=player_soul`; non-player profiles must not use `actorId=player_soul`. In an afterlife spiritual conflict, the player lead may be written as `actorType=player_soul`, `player`, or `soul` with `actorId=player_soul`; it reads ordinary Spiritual Art and Spirit Focus authority from `soul_state.afterlifeCombatProfile`, not from profile auto-progression, and does not need `actorArtTierSnapshot` / `artAuthoritySource`. |
| supportRole | роль поддержки | Canonical role field for `playerSide.supporters[]` and `oppositionSide.supporters[]` inside afterlife spiritual conflicts. Write this directly (`witness`, `safety_anchor`, `ritual_anchor`, etc.); legacy `role` may be normalized into `supportRole` on start, but it is not the preferred authoring shape. |
| afterlifeEntityProfileUpdates | обновления профилей сущностей посмертия | GM-authored response surface for `profiles[]` entries with `actorType`, `actorId`, `currencies`, `progression`, `standardArts`, `specialArts`, `customStates`, `soulDissipationTier`, and `progressionStrategy`. For `actorType=player_soul`, do not use this surface to grant Ink Feathers, Light Sparks, ordinary `standardArts`, enlightenment/radiance progression, or automatic `progressionStrategy`; those fields are overwritten from client-owned state. |
| afterlifeEntityCustomStateChanges | изменения кастомных состояний сущностей посмертия | GM-authored response surface for targeted `customStates` maintenance on a known profile: `statesToAddOrUpdate[]` adds/replaces full state objects, while `statesToRemove[]` deletes ended states so they do not persist forever. The target profile must exist in `profiles[]` or same-turn `afterlifeEntityProfileUpdates[]`; unknown targets and empty operations are repair-blocking. |
| afterlifeEntityProgressionOverrides | принудительная прокачка сущности посмертия | GM-authored override surface for cases where the living world logic should not follow deterministic `progressionStrategy`; each override needs `cycleKey`, `reason`, `summary`, non-empty explicit deltas, and produces `progressionLedger`. `currencyDeltas` accepts only `inkFeathers` / `lightSparks`; `progressionExperienceDeltas` accepts only `enlightenment` / `radiance`. |
| afterlifeSpecialArtLearningReceipts | квитанции обучения особым духовным искусствам | GM-authored receipt surface for roleplay training that teaches the player an entity's `specialArts[]`; each receipt names the teacher, player, `artId`, `learnedAtTurn`, `trainingConditionSatisfied=true`, `roleplayEvidence`, and summary. Teacher profile, player profile, source `specialArts[].artId`, and `canTeachPlayer=true` are mandatory. A learned special art always starts at tier 0; `initialTier` is optional compatibility data only when it is exactly `0`, not GM-authored progression. |
| specialArts | особые духовные искусства | Named variants of standard spiritual actions. Each entry has owner identity matching the enclosing entity profile, `baseOperation`, `costMultiplierPercent`, `upgradeCost`, `effectSummary`, and, if teachable, `trainingConditions`. `upgradeCost` must be non-empty, use only `inkFeathers`/`lightSparks`, and include at least one positive value. |
| specialArts[].combatEffect | боевой эффект особого искусства | Structured afterlife-only combat contract beside `effectSummary`. Current/new teachable entries use `summary`, `trigger`, `mechanicalAxis`, `allowedPayoff`, `limit`, and `auditRequirement` to state when the art matters, which legal axis it can touch (`rollMode`, `conflictPosition`, `controlState`, `sideStrain`, `tempoAdvantage`, `counterPayoff`, `spiritual_action_points`, `actionCostAudit`, or `combatConditions`), and what `specialArtAudit.effectNote` / `specialArtAudits[].effectNote` must record. Resource effects use the unified `spiritual_action_points` axis and prove their cost through `actionCostAudit`; `actionEconomy` is forbidden. It preserves `baseOperation` and never creates Mortal HP/status effects or unlimited passive bonuses. Combat-useful Predvechnye special-art examples must show the unique combat effect beyond the base operation changing an audited result, not just naming a Guardian art as flavor. |
| soulDissipationProof | доказательство развеивания души | Terminal proof inside `recentConflicts[]` for final soul death after a resolved spiritual conflict. Requires actor/target identity, `dissipationTier`, `targetStabilityCoefficient`, turn, victory proof, and explicit GM motivation. |
| targetStabilityCoefficient | коэффициент устойчивости души | Target resistance against final soul death: `max(enlightenment.tier, radiance.tier)` clamped to `0..4`. Развеивание души is legal only when `soulDissipationTier` is strictly greater. |
| terminalGameOver | окончательная смерть души | Player-only terminal marker in `soul_state.json` after legal soul dissipation. Message must be exactly: `Вы мертвы. Ваша душа окончательно развеяна. Загрузите последнее сохранение и попробуйте снова`. |
| specialArtAudit / specialArtAudits | аудит особого духовного искусства / аудиты особых духовных искусств | Required on a conflict exchange that uses a special art: use either `specialArtAudit` for one used art or `specialArtAudits[]` for one object per art when both player and opposition use named special arts in the same exchange; never write both fields on one exchange. Each audit records `artId`, owner identity, `baseOperation`, `costMultiplierPercent`, and `effectNote` describing how the GM applied the special effect. |
| progressionLedger | журнал прокачки сущности посмертия | Audit trail in each afterlife profile. It records deterministic income/spending/upgrades or a GM override for a specific cycle, including `lastAutoProgressionCycleKey` on the strategy. |

## Spiritual Art Names

| Art id | Russian label | Mechanical meaning |
|---|---|---|
| `pressure` | Давление | Direct spiritual pressure against the opposing lead contestant. |
| `counter` | Контрприём | Countering or reversing an incoming operation. |
| `guard` | Защита | Preventing incoming strain or consequence against the player's side. |
| `maneuver` | Манёвр | Shifting `conflictPosition` without raw overpowering. |
| `break_binding` | Разрыв оков | Resisting or breaking spiritual bindings and forced handoffs. |
| `binding` | Наложение оков | Imposing a bounded spiritual bind after winning leverage. |
| `incarnation_resistance` | Сопротивление воплощению | Resisting `guardian_forced` incarnation attempts. |
| `champion_coordination` | Координация чемпиона | Improving side-vs-side support when an ally is the lead contestant. |

## Player Commands

| Command | Russian alias | Use |
|---|---|---|
| `/spiritual_conflict` | `/духовный_конфликт` | Shows the active afterlife spiritual conflict, sides, `conflictPosition`, side strain, exchange count, and full JSON audit. |
| `/spiritual_combat_log` | `/журнал_духовного_боя` | Shows the afterlife combat log: active `exchangeLog[]`, resolved `recentConflicts[]`, dice, position/strain deltas, rewards, and full JSON audit. |
| `/spiritual_combat_help` | `/духовный_бой` | Shows the player-facing combat guide: commands, tactics, Spiritual Arts, position, dice, bounded criticals, rewards, and upgrades. |
| `/spiritual_action` | `/духовное_действие` | Sends one explicit tagged action inside an active conflict. Ordinary roleplay prose is still valid when it clearly acts inside the active conflict. |
| `/spiritual_arts` | `/духовные_искусства` | Shows ranks, art tiers, `Средоточие Души`, upgrade costs, and performs client-owned Spiritual Art / Spirit Focus upgrades. |
| `/afterlife_profiles` | `/профили_загробья` | Shows player-facing Профили сущностей посмертия: actor type, resources, progression, `standardArts`, `specialArts`, visible `fateCards[]`, `customStates`, visible goals/activity summaries, known mask/persona summaries, `soulDissipationTier`, danger warnings, non-player `progressionStrategy`, non-player `lastAutoProgressionCycleKey`, and latest non-player `progressionLedger` entry. The `player_soul` profile displays mirrored player-owned currency/progression/ordinary arts and authoritative learned `specialArts[]`; full raw profile JSON, `gmThoughtsSummary`, hidden Fate Cards, and unrevealed mask internals are diagnostics only, available through `ShowGmThoughts` or browser advanced mode. |

## Spiritual Art Operation Rules

These are mechanical rules, not flavor synonyms. If a player writes prose, classify it into one primary operation and keep the state delta inside that operation's allowed lane.

| Art / operation | Valid use | May change | Must not do | Example |
|---|---|---|---|---|
| `pressure` / Давление | Directly challenge the opposing lead contestant. | Mainly `oppositionSideStrain`; optionally terminal resolve after a later valid close. | Do not treat it as a free `conflictPosition` maneuver or binding. | "I press on the Guardian's broken oath" can move opposition strain `clear -> strained`. |
| `guard` / Защита | Prevent or reduce incoming strain/consequence against the player side; even a setback guard against direct `pressure` mitigates so `playerSideStrain` worsens by at most one rank. A full success against direct pressure creates `tempoAdvantage`: one-use Преимущество for the next eligible spiritual action. | `playerSideStrain`, blocked consequence, defensive `incomingAction` audit, `tempoAdvantage` on full success. | Do not damage opposition strain directly; use `counter` for reversal. The tempo window does not apply to recovery, withdrawal, surrender, or negotiation. | "I shield the soul-fracture" can keep player strain from worsening and create a tempo window for the next pressure/maneuver/binding/counter. |
| `counter` / Контрприём | React to a concrete incoming operation. | `incomingAction`, blocked/countered audit, and a measured payoff on success/partial_success/countered: `counterPayoff`, better `conflictPosition`, worse `oppositionSideStrain`, or reversed/weakened existing opposition `controlState`. | Cannot be used without `incomingAction`; cannot be a standalone `pressure`; cannot create fresh player control from none; successful/partial_success/countered counters cannot only heal `playerSideStrain`. | "As he binds me, I turn the thread back" must name the incoming bind/pressure and show the reversal. |
| `maneuver` / Манёвр | Shift advantage without raw overpowering. | `conflictPosition`. | Successful maneuver must not directly change `playerSideStrain` or `oppositionSideStrain`, and cannot bypass active opposition `controlState` without first weakening/removing that control. | `contested -> player_advantaged` without strain damage. |
| `binding` / `force_binding` / Наложение оков | Control after leverage. Requires `player_advantaged`, `player_dominant`, setup, or `decisive_player_success`; `force_binding` requires strong leverage and a broader payoff. | `controlState`: create or strengthen player control only when active opposition control is absent; `force_binding` must restrict at least two distinct operations. | Cannot be spammed from neutral `contested` on ordinary success; cannot answer active opposition control; cannot be recorded as strain or position only; failed binding/force_binding outcomes (`blocked`, `countered`, `setback`) leave `controlState` unchanged on both sides, including player-control rewrites and opposition anti-control deltas. | After gaining advantage, the soul seals the opponent's route: `controlState.level none -> hindered`; force binding might restrict both `maneuver` and `binding`. |
| `break_binding` / Разрыв оков | Answer an existing binding, forced handoff, or coercive lock. | `controlState`: weaken, remove, or reverse opposition control; legacy forced handoff state if present. | Not a generic attack or defense against ordinary pressure; success must change the control/coercion state. Same-level narrowing of opposition `restrictedOperations` counts as weakened `controlState`; equal/reordered sets do not count. | Break a name-seal: `controlState.level bound -> hindered` or `bound -> none`. |
| `incarnation_resistance` / Сопротивление воплощению | Resist `force_incarnation` / `guardian_forced`. | forced-incarnation proof state, resistance audit, possibly forced-incarnation `controlState`. | Not a replacement for `guard` against ordinary pressure or `break_binding` against ordinary binding control; failed incarnation_resistance outcomes leave forced-incarnation `controlState` unchanged. | Resist a Guardian trying to throw the soul into a life. |
| `champion_coordination` / Координация чемпиона | Support a `champion_duel` where an ally is lead contestant. | champion-side support modifier, `conflictPosition`, side support audit. | Cannot be used in `direct_duel` as if the player were lead. | The soul guides an allied Guardian's strike while staying supporter. |
| `recover_spiritual_power` / Собрать Средоточие | Spend the turn gathering spiritual focus and restoring ОД. | `spiritual_action_points` through `actionCostAudit`. | Not an attack, not a defense against direct pressure, not a way to ignore incoming control. | Recovering against guard/passive can restore +3 ОД; recovering into pressure/control is punished and restores only 0..1 ОД. |

## Action Economy / ОД

ОД are afterlife-only spiritual action points. They are not Mortal HP, stamina, energy, or combat resources.

- `actionEconomy` is forbidden as persisted conflict state. Current/maximum ОД come from exact `spiritual_action_points` projections over `game_state/resources/resource_state.json` and immutable `resource_history.json`.
- On `mode=start`, the player maximum is registered from `soul_state.afterlifeCombatProfile.spiritFocusTier`; the player owner is `afterlife_actor/player_soul`, while the opposition scoped owner is bound by `activeConflict.resourceOwnerBindings.opposition.resourceOwnerId`.
- Every new/current exchange that spends or restores ОД must carry `actionCostAudit.player`: `operationType`, `baseCost`, `minCost`, `artTier`, `effectiveCost`, `before`, and `after`.
- Every new/current exchange that resolves an active costed opposition operation must also carry `actionCostAudit.opposition` in the same shape. The opposition operation is taken from `incomingAction.finalOperationType` when present; otherwise use `incomingAction.operationType` or the matching `matchupAudit.oppositionOperation`. `finalOperationType` is authoritative: do not fall back to stale `incomingAction.operationType` for `matchupAudit`, `actionCostAudit.opposition`, or non-player special-art costs.
- Ordinary base formula: `effectiveCost = max(minCost, baseCost - artTier)`; applicable wound burdens are additional. The two special wound-cost cases below define recovery and forced incarnation.
- Except for the prescribed `force_incarnation` wound audit below, `actionCostAudit.player.artTier` comes from the validated pre-turn soul profile. `actionCostAudit.opposition.artTier` comes from the validated pre-turn afterlife entity profile for the opposition lead actor, with the pre-turn `oppositionSide.leadContestant.actorArtTierSnapshot` used only as compatibility fallback.
- Special arts multiply the acting side's standard cost. A player-owned special art that powers the player's operation must add `actionCostAudit.player.specialArtId`, `specialCostMultiplierPercent`, `standardEffectiveCost`, and the multiplied `effectiveCost`; a non-player/incoming special art that powers the opposition operation must add the same fields under `actionCostAudit.opposition`.
- Base/min costs: `pressure 3/1`, `guard 2/1`, `counter 4/2`, `maneuver 3/1`, `binding 4/2`, `force_binding 5/2`, `break_binding 3/1`, `incarnation_resistance 3/1`, `champion_coordination 2/1`, `recover_spiritual_power 0/0`.
- `recover_spiritual_power` restores ОД up to the acting side's projected resource maximum: success +3, partial_success +2, punished recovery +0..1.
- Every `actionCostAudit.<side>.before/after` must match the validated action arithmetic from the exact resource projection. For burdened recovery, `after` is the action-only capped result, not a promise about the ledger after causal reactions. The client, not the GM, writes the ledger/history result.
- If a side has no current-turn `actionCostAudit.<side>`, no resource mutation is emitted. Do not edit ОД, the resource ledger, or `resourceOwnerBindings` directly. Terminal/free player operations (`withdraw`, `surrender`, `negotiate`) must not include `actionCostAudit.player`; fake terminal/free audits are invalid.
- Punished recovery happens against `pressure`, `maneuver`, `binding`, `force_binding`, or `force_incarnation`; strong timing is against `guard`, `counter`, `none`, or `passive`.
- `withdraw`, `surrender`, and `negotiate` remain legal at 0 ОД unless a later contract explicitly changes terminal choice rules.

### spiritual_wound_special_action_costs_v1

Special wound costs (`spiritual_wound_special_action_costs_v1`) apply equally to player and opposition and only to the exact acting owner's applicable `spiritual_action_cost_burden`. For `recover_spiritual_power`, pay the burden first; insufficient funds reject the action, and failure still pays. Apply ordinary 3/2/0 recovery or opposed 0..1 recovery to the post-payment balance, capped by the maximum. `actionCostAudit.after` is the action-only result: the client records Spend, drains its causal reactions, then requests Gain for the original capped amount `after - (before - effectiveCost)`. Never net the mutations or enlarge that request after a reaction; the final ledger can differ from `after`. For `force_incarnation`, positive burden is the only cost: require exactly `operationType`, `baseCost`, `minCost`, `artTier`, `effectiveCost`, `before`, `after`, with `baseCost=0, minCost=0, artTier=0` and `effectiveCost` equal to the owned burden sum. Here zero artTier is an audit convention, not the actor's art level. No burden means no force audit and no payment; incarnation admission/control is unchanged. See the worked `spiritual_wound_special_action_costs_v1` fragments in `Examples/E_CLI_Afterlife_Turns.txt`.

For example, maximum 6, before 4, burden 1 and successful recovery gives audit
`after=6` and a fixed Gain request of 3. A Spend-triggered loss of 1 produces
4→3→2→5; a triggered gain of 1 produces 4→3→4→6 with only 2 of the requested 3
applied. At before 6, the original capped Gain request is only 1 even if a
reaction lowers the balance. With before 1, burden 1 and failed recovery,
`after=0`: payment remains real even though the net change is negative. With
before 0, the same burden makes recovery unavailable. Without a burden the
ordinary recovery path remains unchanged.

For an unchanged, unexecuted `force_incarnation` action, a newly installed wound
may require a previously absent seven-field side audit (or an absent
`actionCostAudit` root containing only qualifying sides). Its original effective
operation must still be force incarnation, including `incomingAction.finalOperationType`
precedence. Preserve the completed prefix, action, actor, dice and existing
sibling audits. No null/scalar replacement, extra fields or special-art fields
are permitted. Shape alone grants no authority: the client proves the exact
actor's positive burden, amount and affordability, including cold replay.

The inverse correction is permitted only for an unchanged, unexecuted force
action whose previously prescribed seven-field audit is now stale after finite-use
expiry. The actual next owner reconstruction must prove zero burden. Remove only
that side audit. Remove the empty audit root only if no sibling remains; preserve
sibling audits, non-force audits and any root that still contains them. Keeping the stale
positive audit requests dependent repair, not payment; a fake zero audit is also
invalid. Removing the audit while a positive burden remains is rejected as missing
required evidence. The completed prefix, action, actor and dice remain frozen;
this grants no permission to remove arbitrary or extra-field audits. Cold replay
repeats the same shape and owner checks.

Completed actions never acquire either presence exception or pay twice. This cost rule
adds no wound profile or reaction graph and does not enable live C4 publication.

## Средоточие Души / Spirit Focus

`Средоточие Души` is permanent client-owned progression for maximum ОД. It is upgraded through `/spiritual_arts`; the GM reads the resulting `soul_state.afterlifeCombatProfile.spiritFocusTier`, but must not author it directly, invent upgrade receipts, or mutate it in an accepted turn. Spiritual Art tiers reduce action costs through `artTier`; `Средоточие Души` increases the maximum ОД reserve.

| `spiritFocusTier` | Max ОД | Player meaning |
|---:|---:|---|
| 0 | 6 | Базовый запас души |
| 1 | 7 | Короткий обмен без истощения |
| 2 | 8 | Устойчивость в затяжном споре |
| 3 | 10 | Тактический запас для дорогих приемов |
| 4 | 12 | Сильное средоточие для длинного боя |
| 5 | 15 | Мастерский запас духовной силы |

Upgrade costs use the same local currency pattern as Spiritual Arts: Ink Feathers in Chaos Sea or, in ordinary active Shining Abode, Light Sparks. Current costs are `Ink Feathers = 100 + nextTier * 100` and `Light Sparks = 8 + nextTier * 4`.

## Tactical Matchup Matrix

Every new/current contested exchange with `diceAudit` must also include `matchupAudit`. This is the "rock-paper-scissors" layer: the GM still narrates freely, but the state delta must follow one primary mechanical lane.

`matchupAudit` required fields:
- `playerOperation`: the player's primary operation, matching `exchange.operationType`.
- `oppositionOperation`: the opposition's primary answer, incoming operation, or `none`/`passive`; if `incomingAction.finalOperationType` is present, this must match that final operation, not stale `incomingAction.operationType`; otherwise it must match `incomingAction.operationType`.
- `primaryResolutionLane`: the lane that decides the exchange; for ordinary player-led exchanges it matches `operationType`.
- `riskProfile`: one of `offensive_pressure`, `safe_defense`, `risky_reversal`, `position_play`, `control_leverage`, `anti_control`, `champion_support`, `recovery_timing`, or `terminal_choice`.
- `matchupRationale`: one or two sentences explaining why this lane, not GM preference, decides the result.

| Player operation | Strong against | Countered by | Required gameplay effect |
|---|---|---|---|
| `pressure` / Давление | `maneuver`, passive repositioning, exposed guard. | `guard`, `counter`, stronger opposing pressure. | Worsen `oppositionSideStrain`; cannot improve `conflictPosition` or add binding/control state. |
| `guard` / Защита | `pressure`, immediate consequence, unsafe direct clash. | `maneuver`, leverage-backed binding, eventual position loss if used passively. | Reduce/prevent `playerSideStrain` or consequence; cannot worsen `oppositionSideStrain` or improve `conflictPosition`. |
| `counter` / Контрприём | Named incoming `pressure`, binding/control, or coercive direct action. | `maneuver`, withdrawal, surrender, negotiate, `none`/`passive`; it also fails hard on bad rolls. | Requires `incomingAction`; success/partial_success/countered needs payoff; setback needs downside (`playerSideStrain`, worse `conflictPosition`, or `counterBackfire`). |
| `maneuver` / Манёвр | Passive guard, waiting, positional weakness. | `pressure`, opposing maneuver, binding/control. | Move `conflictPosition`; cannot directly change side strain or bypass active opposition `controlState`. |
| `binding` / `force_binding` / Наложение оков | Opponent after leverage or decisive success. | `break_binding`, counter-control, lack of leverage. | Add/advance `controlState` only after advantage, setup, or decisive success. |
| `break_binding` / Разрыв оков | Binding, forced handoff, coercive lock. | Stronger control, dominant opposition position. | Remove/weaken/reverse `controlState`; same-level narrowing of opposition `restrictedOperations` counts as weakened `controlState`; equal/reordered sets do not count. |
| `incarnation_resistance` / Сопротивление воплощению | `force_incarnation` / `guardian_forced`. | Winning forced-incarnation pressure after the player loses/surrenders/concedes. | Resist forced lifecycle handoff only; voluntary incarnation is not combat. |
| `champion_coordination` / Координация чемпиона | `champion_duel` where an ally is lead. | Pressure against the champion side, disrupted support, invalid side model. | Improve champion-side support/position; cannot replace direct-duel actions. |
| `recover_spiritual_power` / Собрать Средоточие | `guard`, `counter`, `none`, `passive`. | `pressure`, `maneuver`, `binding`, `force_binding`, `force_incarnation`. | Restore `spiritual_action_points` through `actionCostAudit`; capped by the projected maximum; punished timing restores only 0..1 ОД. |

## Position Modifiers

`conflictPosition` is not flavor. Derive the effective starting position under `spiritual_wound_position_v1` below; without applicable wound burdens it equals canonical `before.conflictPosition`. For a non-`contested` effective rank, `diceAudit.modifierBreakdown` must include exactly one explicit modifier with exact matching `position`; do not split, duplicate, blank, omit, or add extra `conflict_position` entries:

| Effective starting position | Required modifier |
|---|---|
| `player_advantaged` | `modifierBreakdown.player[]` contains `{ "modifierType": "conflict_position", "source": "conflictPosition", "position": "player_advantaged", "value": 2 }` |
| `player_dominant` | `modifierBreakdown.player[]` contains the same shape with `position="player_dominant"` and `value=4` |
| `opposition_advantaged` | `modifierBreakdown.opposition[]` contains the same shape with `position="opposition_advantaged"` and `value=2` |
| `opposition_dominant` | `modifierBreakdown.opposition[]` contains the same shape with `position="opposition_dominant"` and `value=4` |

Effective `contested` means zero `conflict_position` entries. The modifier uses the effective starting rank; the canonical before-state remains unchanged and the after-state records the ordinary action result. Do not split or duplicate the modifier.

## Преимущество / Помеха

Преимущество and Помеха are visible dice modes inside `diceAudit`, not hidden GM judgment. `rollMode.<side>.advantageSources[]` lists why a side has Преимущество; `rollMode.<side>.disadvantageSources[]` lists why a side has Помеха; `effectiveMode` records the final mode after cancellation.

- `advantage` / Преимущество rolls exactly 2d20 for that side and uses the highest selected die.
- `great_advantage` / Великое Преимущество rolls exactly 3d20 for that side and uses the highest selected die.
- `disadvantage` / Помеха rolls exactly 2d20 for that side and uses the lowest selected die.
- `dire_disadvantage` / Тяжкая Помеха rolls exactly 3d20 for that side and uses the lowest selected die.
- Source arrays accept legacy non-empty strings as ordinary `advantage` / `disadvantage`, or objects with `summary`/`source`/`sourceId`, `level`, and optional `sourceType`. Valid positive levels are `advantage|great_advantage`; valid negative levels are `disadvantage|dire_disadvantage`.
- Step cancellation uses the strongest positive source and strongest negative source: `great_advantage + disadvantage => advantage`, `great_advantage + dire_disadvantage => normal`, `advantage + dire_disadvantage => disadvantage`, and `advantage + disadvantage => normal`.
- Multiple sources in the same direction do not stack. Two ordinary Преимущества stay ordinary Преимущество; they do not become Великое Преимущество.
- Critical success/failure uses only the selected die. A discarded natural 20 or natural 1 has no critical effect.

`tempoAdvantage` from successful Защита is consumed as an ordinary or great positive source:

```json
{
  "sourceType": "guard_tempo_window",
  "sourceId": "tempo_guard_001",
  "level": "advantage",
  "summary": "Темповое окно после успешной защиты."
}
```

## Сложность Игры / Difficulty Audit

When `game_state/core/game_settings.json.difficulty` is readable, current/new contested afterlife dice must include `difficultyAudit`. Difficulty is a transparent pressure source, not hidden GM permission to change outcomes.

| Difficulty | Russian label | Opposition modifier | Reward multiplier |
|---|---|---:|---:|
| `normal` | Нормальная | `+0` | `100%` |
| `hard` | Тяжёлая | `+1` | `125%` |
| `impossible` | Невозможная | `+2` | `150%` |

`difficultyAudit` must include `difficulty`, `source="game_state/core/game_settings.json.difficulty"`, `oppositionModifier`, and `rewardMultiplierPercent`. The opposition side's `modifierBreakdown` must contain exactly the canonical `game_difficulty` total; the player side must not receive a difficulty modifier. The largest difficulty modifier (`+2`) is below position dominance (`+4`) and `light_incarnate` lead bonus (`+8`), so difficulty raises risk and rewards without making dice dominate strategy.

## Control State

`controlState` is the mechanical meaning of оковы / контроль. It does not deal strain and does not move position by itself; it restricts action freedom and creates leverage for later exchanges.

Canonical shape:

```json
{
  "level": "hindered",
  "controllerSide": "player",
  "controlId": "control_example_001",
  "sourceOperation": "binding",
  "restrictedOperations": [ "maneuver", "binding" ],
  "summary": "The soul pins the opponent's route through the current."
}
```

Rules:

- Missing or `null` `controlState` is legacy-compatible and means `none`.
- In a new/current exchange where active `controlState` already exists or the exchange creates/changes active control, write both `before.controlState` and `after.controlState`; if there is no active control on one side of the snapshot, write `null` or `{ "level": "none" }` instead of omitting the field.
- Active control must use `level=hindered|bound|locked`, `controllerSide=player|opposition`, non-empty `controlId`, `sourceOperation=binding|force_binding|force_incarnation|break_binding|incarnation_resistance|counter|guard|repair`, non-empty `restrictedOperations`, and `summary`; `sourceOperation` is not a free operation id.
- `binding` / `force_binding` on success/partial success must create or strengthen player control only after active opposition control is absent: `none -> hindered`, `hindered -> bound`, or `bound -> locked`.
- If opposition `controlState.restrictedOperations` names a spiritual operation, that operation cannot succeed until the control is answered first through `break_binding`, a valid `counter`, `incarnation_resistance` for forced-incarnation control, negotiation, surrender, or a failed/blocked restricted attempt.
- Failed binding/force_binding outcomes (`blocked`, `countered`, `setback`) leave player `controlState` unchanged, including same-level `controlId`/`restrictedOperations` rewrites.
- `force_binding` requires strong leverage: `player_dominant`, ready setup, or `decisive_player_success`.
- Successful `force_binding` must have a broader control payoff than ordinary `binding`: `restrictedOperations` contains at least two distinct supported operation ids.
- `break_binding` on success/partial success must weaken, remove, or reverse opposition control.
- Same-level narrowing of opposition `restrictedOperations` counts as weakened `controlState`; equal/reordered sets do not count.
- Failed incarnation_resistance outcomes leave forced-incarnation `controlState` unchanged.
- `pressure` must not create or change `controlState`.
- `maneuver` cannot improve `conflictPosition` while opposition control is active unless the control is first answered through `break_binding`, valid `counter`, `incarnation_resistance` for forced-incarnation control, negotiation, surrender, or concession.
- `guard` may stop a new incoming control from being applied, but it does not remove existing control.

## Conflict Reward Audit

Afterlife conflict rewards are mechanical, not flavor. A reward is allowed only for a resolved contested player victory with `diceAudit.outcomeBand = player_success` or `decisive_player_success`.

| Realm | Currency | Russian label | State delta |
|---|---|---|---|
| `Chaos Sea` | `ink_feathers` | Чернильные Перья | `metaStateUpdates.inkFeatherChanges.add` must equal `rewardAudit.finalAmount`. |
| `Shining Abode` | `light_sparks` | Искры Света | `shining_abode_state.json.lightSparks` must increase by `rewardAudit.finalAmount`. |

`rewardAudit` must include `realm`, `currency`, `baseAmount`, `opposingLeadStrength`, `sideModel`, `startingConflictPosition`, `challengeTier`, `outcomeMultiplierPercent`, `riskMultiplierPercent`, `riskReason`, `difficultyAudit` when readable game difficulty exists, `finalAmount`, and `narrativeReason`. Reward formula: `finalAmount = clamp(baseAmount * challengeTier * outcomeMultiplierPercent * riskMultiplierPercent * difficultyAudit.rewardMultiplierPercent / 1_000_000, 0, realmCap)`, where difficulty reward multiplier is `100/125/150` for `normal`/`hard`/`impossible`. For current-turn rewards against a validated pre-turn active conflict, `sideModel`, `startingConflictPosition`, and `opposingLeadStrength` are anchored to that pre-turn conflict; opposing strength is max standard art/authority value in `oppositionSide.leadContestant.actorArtTierSnapshot` + 1. No reward is allowed for `repair_cancel`, `no_effect`, voluntary withdrawal/surrender, pure negotiation/no-contest, duplicate reward for the same `conflictId`, wrong realm, or wrong currency.

## Critical Result Audit

Natural 20 / натуральная 20 and natural 1 / натуральная 1 are bounded criticals. Bounded criticals are symmetric: a favorable critical for the player (player-side natural 20 or opposition-side natural 1) raises a worse margin result only to ordinary `player_success`, while an unfavorable critical for the player (player-side natural 1 or opposition-side natural 20) lowers a better margin result only to ordinary `opposition_success`. Opposed criticals cancel and use the margin band. A critical does not create `decisive_player_success` or `decisive_opposition_success` by itself; decisive outcomes still require the margin to already reach the decisive threshold.

When a critical changes the margin-derived band, `diceAudit.criticalResult` must include `playerNaturalRoll`, `oppositionNaturalRoll`, `marginOutcomeBand`, `normalizedOutcomeBand`, `scaleLimit`, and `narrativeConstraint`. `scaleLimit` is the "no impossible mosquito victory" field: it explains the maximum plausible effect for this action, power gap, side model, and current conflict position.

## spiritual_wound_position_v1

A wound's position burden is a penalty to the effective starting position for the
exact actor's matching operation. It does not repeatedly degrade the saved
`conflictPosition`. Ranks are -2/-1/0/+1/+2 in the order shown below. Compute
`effective = clamp(canonicalBefore + oppositionBurden - playerBurden, -2, 2)`:
sum each accepted component once and combine both sides before clamping.
Equal opposing burdens cancel. Other participants, other operations and ended
effects contribute nothing; ambiguous ownership must not be assumed to mean zero.

Use the effective token in the existing `conflict_position.position` modifier:
one +2/+4 row on the advantaged/dominant side, no row at effective contested.
Use the same effective rank for binding/force-binding positional prerequisites;
setup and decisive-success alternatives remain unchanged. Canonical before/after,
actual maneuver movement, strain and control restrictions remain ordinary rules.
An inserted wound affects only later matching exchanges; expiry or healing removes
future burden without rewriting history or improving saved position. See
`OtherGuides/Wound_Materialization_Contract.md` and the worked
`spiritual_wound_position_v1` fragments in `Examples/E_CLI_Afterlife_Turns.txt`.

## State Value Labels

| Canonical value | Russian label |
|---|---|
| `opposition_dominant` | противник доминирует |
| `opposition_advantaged` | преимущество противника |
| `contested` | спорная позиция |
| `player_advantaged` | преимущество игрока |
| `player_dominant` | игрок доминирует |
| `clear` | устойчиво |
| `strained` | напряжено |
| `fractured` | надломлено |
| `overwhelmed` | подавлено |
| `broken` | сломлено |
| `active` | активен |
| `concession_pending` | уступка ожидает закрытия |
| `surrender_pending` | сдача ожидает закрытия |
| `retreat_pending` | отступление ожидает закрытия |
| `ready_to_resolve` | готов к завершению |
| `resolved` | завершён |
| `repair_cancelled` | отменён repair-путём |

## Authoring Rule

Use Russian terms for player-facing explanations and prose, but never translate the JSON keys or enum values inside canonical state. Example: write "обмен действиями (exchange)", then persist `"mode": "exchange"` and `"operationType": "guard"`.
