import sys,time
from pathlib import Path
sys.path.insert(0,sys.argv.pop(1))
import relay_cli
original=relay_cli.read_bounded
queue=Path(sys.argv[sys.argv.index('--queue')+1])
def read(path,limit=1048576):
    data=original(path,limit)
    if path.name=='pending_turn_snapshot.authority.json' and list(queue.glob('request-*/reply.json')):
        (queue/'before-snapshot').write_text('paused')
        deadline=time.monotonic()+4
        while not (queue/'release-read').exists():
            if time.monotonic()>deadline:raise TimeoutError('Own read barrier deadline')
            time.sleep(.01)
    return data
relay_cli.read_bounded=read
sys.exit(relay_cli.main())
