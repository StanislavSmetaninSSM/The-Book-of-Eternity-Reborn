﻿. '/tmp/reusable-relay-42289e59a1654b3ca4101dc08ed21492/ship/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/reusable-relay-42289e59a1654b3ca4101dc08ed21492/root/game_session'
