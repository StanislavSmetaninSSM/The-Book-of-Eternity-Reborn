﻿. '/tmp/reusable-relay-4eb3eeaf1ad0483981eea51abc3ea5fa/ship/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/reusable-relay-4eb3eeaf1ad0483981eea51abc3ea5fa/root/game_session'
