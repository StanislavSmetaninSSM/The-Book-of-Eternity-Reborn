. '/workspace/final-ci-restore/checkout/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/rr-1ea6d9119e34485c9b679a0a479354d5/game_session'
