function Read-BoeJson { param($RelativePath) @{} }
function Resolve-BoeSessionPath { param($RelativePath) Join-Path $env:RELAY_TEST_SESSION $RelativePath }
function Write-BoeJson { param($RelativePath,$Data,$ExpectedReadWitnesses)
 [IO.File]::WriteAllText((Join-Path $env:RELAY_TEST_SESSION 'child-entered'), 'entered')
 if ($env:RELAY_TEST_HOLD -eq '1') { Start-Sleep -Seconds 2 }
 [IO.File]::AppendAllText((Join-Path $env:RELAY_TEST_SESSION 'applied'), 'once') }
function Complete-BoeTurn { param($FilesModified) }
function Complete-BoeValidationRepair { param($FilesModified) }
