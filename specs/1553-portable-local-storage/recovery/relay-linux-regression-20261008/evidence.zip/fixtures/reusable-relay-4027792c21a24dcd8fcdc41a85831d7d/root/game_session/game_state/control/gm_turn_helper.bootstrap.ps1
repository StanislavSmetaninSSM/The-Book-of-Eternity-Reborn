﻿. '/tmp/reusable-relay-4027792c21a24dcd8fcdc41a85831d7d/ship/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/reusable-relay-4027792c21a24dcd8fcdc41a85831d7d/root/game_session'
