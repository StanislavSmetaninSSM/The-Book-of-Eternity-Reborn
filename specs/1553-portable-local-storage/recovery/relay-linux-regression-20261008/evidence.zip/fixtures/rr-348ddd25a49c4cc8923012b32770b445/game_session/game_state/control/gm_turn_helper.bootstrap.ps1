. '/workspace/final-ci-restore/checkout/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/rr-348ddd25a49c4cc8923012b32770b445/game_session'
