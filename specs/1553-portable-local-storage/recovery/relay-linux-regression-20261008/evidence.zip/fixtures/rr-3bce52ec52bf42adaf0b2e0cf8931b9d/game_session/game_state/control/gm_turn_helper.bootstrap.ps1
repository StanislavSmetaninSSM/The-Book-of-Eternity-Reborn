. '/workspace/final-ci-restore/checkout/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/rr-3bce52ec52bf42adaf0b2e0cf8931b9d/game_session'
