"""Owner-authorized one genuine turn in an ordinary disposable console game.

Run only beneath the independently compiled guardian --live-turn (300s).
Package is already deployed below fresh base/game_session/_runtime. No scripted
GM, Ready override, query/gate answer, prompt replay, auth/config/history copy.
"""
import errno, fcntl, hashlib, json, os, pty, re, select, socket, struct, subprocess, sys, termios, time, uuid
from pathlib import Path

def current_client_failure(text):
    return any(marker in text for marker in ['Мир не смог безопасно завершить действие.', 'Ход прервался', '❌ Ошибка:'])

class PhaseWait:
    """Progress can renew an idle bound, never the original work deadline."""
    def __init__(self, now, total_deadline, idle_seconds=45):
        self.total_deadline=total_deadline;self.idle_seconds=idle_seconds
        self.last_progress=now;self.signature=None
    def observe(self, now, signature):
        changed=signature!=self.signature
        if changed:self.signature=signature;self.last_progress=now
        if now>=self.total_deadline:raise TimeoutError('Original overall work bound')
        if now-self.last_progress>=self.idle_seconds:raise TimeoutError('No observable phase progress for45s')
        return changed

def retain_turn_delivery(result,delivery,binding):
    if not delivery or delivery.get('disposition')!='submission-observed' or delivery.get('inputBindingId')!=binding:return False
    if delivery.get('operationKind')=='turn' and delivery.get('operationRevision')=='live':
        if 'OriginalTurnDelivery' not in result:result['OriginalTurnDelivery']=dict(delivery)
        return result['OriginalTurnDelivery']==delivery
    if delivery.get('operationKind')=='repair':
        repairs=result.setdefault('RepairDeliveries',[])
        if not any(p['operationId']==delivery['operationId'] for p in repairs):repairs.append(dict(delivery))
    return False

def close_relay_execution(queue,seconds):
    # Correlation/quiescence receipt only; original owner is still required for stop.
    request=queue/'close-request.json'
    if not request.exists():request.write_text(json.dumps({'RequestedMonotonic':time.monotonic()})+'\n')
    deadline=time.monotonic()+seconds
    while time.monotonic()<deadline:
        closed=queue/'closed.json'
        if closed.exists():
            proof=json.loads(closed.read_text())
            return all(proof.get(k) is True for k in ['ExecutionDisabled','ChildExited','IoDrained'])
        pump(.02)
    return False

if len(sys.argv)==2 and sys.argv[1]=='--check-phase-wait':
    # Inert driver checks; no package, processes, clipboard, CLI or game data.
    w=PhaseWait(0,210);w.observe(0,'preparing');w.observe(44,'snapshot');w.observe(88,'request')
    for now in range(100,210):w.observe(now,now)
    try:w.observe(210,'more progress')
    except TimeoutError as e:assert str(e)=='Original overall work bound'
    else:raise AssertionError('Progress extended the original total bound')
    w=PhaseWait(0,210);w.observe(0,'preparing');w.observe(44,'preparing')
    try:w.observe(45,'preparing')
    except TimeoutError as e:assert 'No observable phase progress' in str(e)
    else:raise AssertionError('Idle phase had no bound')
    w=PhaseWait(0,210);w.observe(0,'preparing');w.observe(9,'snapshot');w.observe(20,'request')
    assert current_client_failure('❌ Ошибка: Main run metadata or original owner admission is unavailable.'), 'Current main-menu error must stop preparation before a timeout'
    print(json.dumps({'InertDriverChecks':4,'Passed':4,'ProcessesStarted':0,'RuntimeTestsExecuted':0}));sys.exit(0)
out = Path(sys.argv[1]).resolve()
base = out / 'play'; session = base / 'game_session'; ship = session / '_runtime'
assert session.is_dir() and ship.is_dir() and not (session / 'config.json').exists()
assert not (session / 'game_state').exists()
assert os.environ.get('TERM') == 'dumb'
controlled_refusal = len(sys.argv)==3 and sys.argv[2]=='--controlled-provider-refusal'
relay_mode = len(sys.argv)==3 and sys.argv[2]=='--codex-relay'
total_seconds,work_seconds,client_cleanup_seconds,provider_seconds=(300,230,255,150) if relay_mode else (270,210,230,170)
relay_queue=out/'queue'
assert len(sys.argv)==2 or controlled_refusal or relay_mode, 'Only the fixed inert fixture mode is admitted'
binary = (out/'configured-neutral-cli') if controlled_refusal else Path('/workspace/qualification-1553-opencode-install/package/node_modules/opencode-linux-x64-baseline/bin/opencode')
if not controlled_refusal and not relay_mode:assert hashlib.sha256(binary.read_bytes()).hexdigest() == '77b2cfe4b97df6f15c3673b22100b9f79c711f25ecb9bf513bb82526b15d24fa'
pipe = 'og-' + uuid.uuid4().hex[:12]
quote = lambda v: "'" + str(v).replace("'", "''") + "'"
command = '& ' + quote(binary) + (' --driver-refusal-fixture' if controlled_refusal else ' --mini --pure --no-replay -m opencode/ling-3.1-flash-free')
if relay_mode:
    relay_queue.mkdir()
    command='& '+quote('/usr/bin/python3')+' '+quote(out/'relay/codex-gm-relay.py')+' --session '+quote(session)+' --queue '+quote(relay_queue)+' --model gpt-6.1-sol'
env = {k:v for k,v in os.environ.items() if not k.upper().startswith('OPENCODE_')}
for key, folder in [('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data'),('XDG_STATE_HOME','state'),('XDG_CACHE_HOME','cache'),('TMPDIR','tmp')]:
    path=out/folder;path.mkdir();env[key]=str(path)
for key in ['OPENCODE_DISABLE_PROJECT_CONFIG','OPENCODE_DISABLE_AUTOUPDATE','OPENCODE_DISABLE_EXTERNAL_SKILLS','OPENCODE_DISABLE_CLAUDE_CODE']:env[key]='1'
install = out if controlled_refusal or relay_mode else binary.parents[4]
env.update(NPM_CONFIG_USERCONFIG=str(install/'empty-user.npmrc'),NPM_CONFIG_GLOBALCONFIG=str(install/'empty-global.npmrc'),NPM_CONFIG_CACHE=str(out/'npm-cache'),NPM_CONFIG_IGNORE_SCRIPTS='true')
(session/'config.json').write_text(json.dumps({
    'Language':'ru','MusicEnabled':False,'SoundEnabled':False,'GenerateSceneImages':False,'ShowImagesInConsole':False,
    'GmBridgeEnabled':True,'GmBridgeBackend':'OwnedTerminal','GmMainOwnerBackend':'NativeLineage','GmBridgeAutoStart':False,
    'GmBridgePipeNameOverride':pipe,'GmCliLaunchCommand':command,'GmBridgeShellWorkingDirectory':str(session),'GmWorkerBridgeProfiles':[],
    'GmCliInputProfile':{'TerminalPresentation':'synchronized-mini-v1','DraftObservation':'external-editor-v1','DraftDirectory':env['TMPDIR'],
        'StartupBannerLines':['','█▀▀█  OpenCode','█  █  '+str(session),'▀▀▀▀',''],'AutomaticSubmissionLimit':1,
        'IdleMarker':' BUILD','WorkingMarker':'interrupt','ObservationTimeoutMilliseconds':15000}
},indent=2,ensure_ascii=False)+'\n')
if controlled_refusal or relay_mode:
    settings=json.loads((session/'config.json').read_text())
    settings['GmCliInputProfile']={'IdleMarker':'NEUTRAL READY','PromptPrefix':'> ','WorkingMarker':'NEUTRAL WORKING','ObservationTimeoutMilliseconds':1800}
    if relay_mode:settings['GmCliInputProfile'].update(PromptPrefix='RELAY> ',BlockedMarkers=['RELAY ERROR'],ObservationTimeoutMilliseconds=15000)
    (session/'config.json').write_text(json.dumps(settings,indent=2,ensure_ascii=False)+'\n')
start=time.monotonic(); peers=[]; journal=[]; original=None; original_record=None; shutdown_attempts=0;cleaning=False;client_exit_attempted=False;client_failure_offset=None;active_phase_deadline=None
offset=0 # Defined even when the first client startup observation fails.
result={'AcceptedGameTurns':0,'GenuineActionsSent':0,'GateAnswers':0,'QueryAnswers':0,'ConfiguredModel':'opencode/ling-3.1-flash-free',
        'ConfiguredCommand':command,'ConfiguredCwd':str(session),'NoReadyOverride':True,'OrdinaryNewGame':False,'LogicalLifecycleVerified':False}
if relay_mode:result.update(ConfiguredModel='codex-agent/gpt-6.1-sol-test-relay',TestRelay=True,OpenCodeProviderCalls=0,RelayQueue=str(relay_queue))
if controlled_refusal:result.update(ConfiguredModel='fixed-inert-no-provider',ControlledRefusal=True,ProviderCalls=0)
action='Я осторожно осматриваю берег Моря Хаоса и спрашиваю моего Хранителя, где я оказался.'
class Terminal:
    def __init__(self,name,args,captured_output=False):
        self.name=name;self.master,self.slave=pty.openpty();self.capture=bytearray();self.echo=bytearray();self.eof=False;self.captured_output=captured_output
        fcntl.ioctl(self.slave,termios.TIOCSWINSZ,struct.pack('HHHH',25,100,0,0));self.initial=termios.tcgetattr(self.slave)
        def own():
            os.setsid();fcntl.ioctl(self.slave,termios.TIOCSCTTY,0);os.tcsetpgrp(self.slave,os.getpid())
        self.process=subprocess.Popen(args,cwd=ship,env=env,stdin=self.slave,
            stdout=subprocess.PIPE if captured_output else self.slave,
            stderr=subprocess.STDOUT if captured_output else self.slave,preexec_fn=own)
        self.streams={self.master:'echo' if captured_output else 'output'}
        if captured_output:self.streams[self.process.stdout.fileno()]='output'
        self.closed_streams=set()
        peers.append(self);journal.append({'At':elapsed(),'Entrypoint':name,'Argv':args,'OriginalPid':self.process.pid,
            'OutputMode':'captured-pipe' if captured_output else 'original-pty','StdinMode':'original-controlling-pty'})
    def send(self,data,phase):
        assert elapsed()<(total_seconds if cleaning else work_seconds) and self.process.poll() is None
        assert active_phase_deadline is None or time.monotonic()<active_phase_deadline
        journal.append({'At':elapsed(),'Terminal':self.name,'Phase':phase,'Input':data.decode('utf-8')})
        assert os.write(self.master,data)==len(data), 'Ambiguous partial foreground write; never replay'
    def text(self,offset=0):
        return re.sub(r'\x1b\[[0-9;? ]*[A-Za-z~]','',self.capture[offset:].decode('utf-8',errors='replace'))
def elapsed():return round(time.monotonic()-start,3)
def pump(delay=.02):
    fds=[fd for p in peers for fd in p.streams if fd not in p.closed_streams]
    readable=select.select(fds,[],[],delay)[0] if fds else []
    for p in peers:
        for fd,kind in p.streams.items():
            if fd not in readable:continue
            try:b=os.read(fd,65536)
            except OSError as ex:
                if fd!=p.master or ex.errno!=errno.EIO:raise
                b=b''
            if not b:p.closed_streams.add(fd)
            target=p.echo if kind=='echo' else p.capture
            if b:journal.append({'At':elapsed(),'Terminal':p.name,'ObservedStream':kind,'ByteStart':len(target),'ByteEnd':len(target)+len(b)})
            target.extend(b)
            if len(target)>4194304:raise RuntimeError('Bounded foreground capture exceeded4MiB')
        p.eof=len(p.closed_streams)==len(p.streams)
    if elapsed()>total_seconds:raise TimeoutError('Driver total bound')
def until(test,seconds,label):
    deadline=min(start+(total_seconds if cleaning else work_seconds),time.monotonic()+seconds)
    if active_phase_deadline is not None:deadline=min(deadline,active_phase_deadline)
    while not test():
        if time.monotonic()>deadline:raise TimeoutError(label)
        pump()
def fresh(p,marker,offset,seconds=12):
    def observed():
        if marker in p.text(offset):return True
        if p.process.poll() is not None:raise RuntimeError(p.name+' exited before '+marker)
        return False
    until(observed,seconds,p.name+': '+marker)
def answer(p,marker,text,offset):
    fresh(p,marker,offset);offset=len(p.capture);p.send((text+'\r').encode(),'answer '+marker);return offset
def rpc(payload,seconds=2):
    assert payload['command'] in ['status','diagnostics','shutdown']
    item={'At':elapsed(),'RPC':payload,'Attempted':True};journal.append(item)
    with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as s:
        s.settimeout(.5);s.connect(str(out/'tmp'/('CoreFxPipe_'+pipe)));s.sendall(json.dumps(payload).encode()+b'\n');s.setblocking(False)
        reply=bytearray();deadline=time.monotonic()+seconds
        while time.monotonic()<deadline:
            pump()
            if not select.select([s],[],[],0)[0]:continue
            b=s.recv(8192)
            if not b:raise EOFError('Original response lost; never retry an operation')
            reply.extend(b)
            if len(reply)>524288:raise RuntimeError('RPC bound')
            if reply.endswith(b'\n'):
                item['Response']=json.loads(reply);return item['Response']
        raise TimeoutError('Original RPC outcome unknown; never replay')
def read_json(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def staging_signature():
    # Metadata only in this disposable game's staging namespace. Exclude live
    # daemon/bridge health files and all CLI XDG/auth/session state.
    paths=list((session/'game_state').rglob('*.rollback.*'))
    pending=session/'game_state/control/pending_turn_snapshot'
    if pending.exists():paths+=list(pending.rglob('*'))
    paths += [session/'game_state/control/pending_turn_snapshot.json',
        session/'game_state/control/pending_turn_snapshot.authority.json']
    rows=[]
    for p in paths:
        try:
            s=p.stat()
            if p.is_file():rows.append((str(p.relative_to(session)),s.st_size,s.st_mtime_ns))
        except FileNotFoundError:pass # An observed staging cleanup/replacement.
    return tuple(sorted(rows))
def bootstrap_signature():
    paths=[session/'game_state/control/gm_turn_helper.bootstrap.ps1']
    pack=session/'game_state/control/gm_context_pack'
    if pack.exists():paths+=list(pack.rglob('*'))
    rows=[]
    for p in paths:
        try:
            s=p.stat()
            if p.is_file():rows.append((str(p.relative_to(session)),s.st_size,s.st_mtime_ns))
        except FileNotFoundError:pass
    return tuple(sorted(rows))
def preparation_phase(test,label,peer,bootstrap=False,offset=0):
    global client_failure_offset
    phase=PhaseWait(time.monotonic(),start+work_seconds)
    while True:
        if time.monotonic()>=phase.total_deadline:raise TimeoutError('Original overall work bound: '+label)
        if peer.process.poll() is not None:raise RuntimeError(peer.name+' exited during '+label)
        if bootstrap and any(marker in peer.text() for marker in ['Participating canonical mutation refused.',
            'Original participating admission unavailable','Original operation established a result but continuation is unconfirmed']):
            journal.append({'At':elapsed(),'ObservedPhase':'daemon failure before cleanup'})
            raise RuntimeError('Actual daemon bootstrap failure observed before cleanup')
        if peer.name=='client' and current_client_failure(peer.text(offset)):
            client_failure_offset=offset
            journal.append({'At':elapsed(),'ObservedPhase':'current client failure during '+label})
            raise RuntimeError('Actual current client preparation failure')
        if test():
            journal.append({'At':elapsed(),'ObservedPhase':label+' completed'});return
        signature=(len(peer.capture),bootstrap_signature() if bootstrap else staging_signature())
        if phase.observe(time.monotonic(),signature):
            journal.append({'At':elapsed(),'ObservedPhase':label+' progress','CapturedBytes':len(peer.capture),
                'PreparationFiles':len(signature[1]),'PreparationBytes':sum(r[1] for r in signature[1])})
        pump(.1)
def current_request(offset):
    global client_failure_offset
    phase=PhaseWait(time.monotonic(),start+work_seconds)
    waiting=False
    while True:
        text=client.text(offset)
        if client.process.poll() is not None:raise RuntimeError('Client exited during current preparation')
        if 'Мир не смог безопасно завершить действие.' in text or 'Ход прервался' in text:
            client_failure_offset=offset
            journal.append({'At':elapsed(),'ObservedPhase':'client-failure-before-captured-request'})
            raise RuntimeError('Current client reported a real failure before captured request')
        if time.monotonic()>=phase.total_deadline:raise TimeoutError('Original overall work bound')
        request_path=session/'input/turn_request.json'
        if request_path.exists():
            journal.append({'At':elapsed(),'ObservedPhase':'current-request-present'})
            return
        if 'Мастер игры размышляет...' in text and not waiting:
            journal.append({'At':elapsed(),'ObservedPhase':'waiting-ui-without-captured-request'})
            waiting=True # Observation only: never authority to submit/replay.
        signature=(len(client.capture),staging_signature())
        if phase.observe(time.monotonic(),signature):
            journal.append({'At':elapsed(),'ObservedPhase':'preparation-progress','ClientBytes':len(client.capture),
                'StagingFiles':len(signature[1]),'StagingBytes':sum(r[1] for r in signature[1])})
        pump(.1)
def fresh_main(client,offset):
    fresh(client,'Продолжить',offset)
    until(lambda:re.search(r'8\.\s*[^\r\n]*Выход',client.text(offset)) is not None,8,'fresh eight-item main menu')
def fresh_player(client,offset,seconds=12):
    fresh(client,'Ваш ход',offset,seconds);fresh(client,'🌊 > ',offset,seconds)
def exit_client(client):
    global client_exit_attempted
    assert not client_exit_attempted, 'Do not replay an ambiguous UI close sequence'
    client_exit_attempted=True
    offset=len(client.capture);client.send(b'/options\r','current prompt: game menu');fresh(client,'Игровое меню',offset)
    offset=len(client.capture);client.send(b'4\r','observed game menu: exit to menu');fresh_main(client,offset)
    client.send(b'8\r','observed eight-item main menu: exit');until(lambda:client.process.poll() is not None,8,'client normal exit')
    assert client.process.returncode==0
import http.client,concurrent.futures,threading,traceback
web=None;client=bridge=daemon=None;client_wait=False;client_prompt=False
http_rows=[];web_stopped=False
result.update(Diagnostic='bounded live HTTP baseline',ModelRequests=0,NewGameInitialized=False,UiBrowserQualified=False,HttpFixIncluded=False)
env['ASPNETCORE_ENVIRONMENT']='Development' # Isolated process diagnostics only; no system configuration.
def request_http(path,stage,barrier=None):
    if barrier:barrier.wait(timeout=5)
    at=time.monotonic();connection=http.client.HTTPConnection('127.0.0.1',31460,timeout=8)
    row={'Stage':stage,'Path':path,'StartedAt':round(at-start,6)}
    try:
        connection.request('GET',path);response=connection.getresponse();body=response.read(1048577)
        if len(body)>1048576:raise RuntimeError('HTTP response exceeded1MiB')
        row.update(Status=response.status,Body=body.decode('utf8','replace'),ContentType=response.getheader('Content-Type'))
    except Exception as ex:row.update(Error=type(ex).__name__+': '+str(ex))
    finally:connection.close()
    row['DurationSeconds']=round(time.monotonic()-at,6);http_rows.append(row);return row
paths=['/api/session','/api/game-screen','/api/audio/settings']
def series(stage,rounds,copies=1):
    for i in range(rounds):
        barrier=threading.Barrier(3*copies+1)
        with concurrent.futures.ThreadPoolExecutor(max_workers=3*copies) as workers:
            futures=[workers.submit(request_http,path,stage+'-round'+str(i+1),barrier) for path in paths*copies]
            barrier.wait(timeout=5)
            for future in futures:future.result(timeout=10)
        pump(.05)
        if time.monotonic()-start>190:raise TimeoutError('HTTP work budget reached; original cleanup reserved')
def start_web():
    global web
    web=Terminal('web',['dotnet',str(ship/'BookOfEternityClient/BookOfEternityClient.dll'),str(base),'--web','--web-url','http://127.0.0.1:31460'],captured_output=True)
    def listening():
        if web.process.poll() is not None:raise RuntimeError('Web exited before loopback listen; inspect original web.raw')
        try:
            with socket.create_connection(('127.0.0.1',31460),timeout=.2):return True
        except (ConnectionRefusedError,socket.timeout):return False
    until(listening,25,'actual web loopback listening')
    result['LoopbackHostListening']=True
try:
    client=Terminal('client',['dotnet',str(ship/'BookOfEternityClient/BookOfEternityClient.dll'),str(base),'--plain-output'],captured_output=True)
    fresh(client,'Тренировка QTE',0);offset=len(client.capture);client.send(b'\r','observed NewGame selected')
    offset=answer(client,'Введите имя вашей души:','Облачная HTTP проверка',offset)
    offset=answer(client,'Опишите форму вашей души:','Человеческий силуэт мягкого синего света.',offset)
    offset=answer(client,'Выберите способ создания Хранителя:','1',offset)
    offset=answer(client,'Опишите вашего хранителя:','Спокойный Хранитель маяка на берегу Моря Хаоса.',offset)
    preparation_phase(lambda:(session/'input/turn_request.json').exists(),'ordinary initial request',client,offset=offset);client_wait=True
    result['InitialBootstrapRequest']=read_json(session/'input/turn_request.json');result['OrdinaryNewGame']=True
    fresh(client,'Мастер игры размышляет...',offset,12);pump(.3)
    offset=len(client.capture);client.send(b'\x1b','cancel initial wait before CLI exists')
    preparation_phase(lambda:'Переходный ход отменён.' in client.text(offset) and re.search(r'8\.\s*[^\r\n]*Выход',client.text(offset)) is not None,'ordinary cancellation and main menu',client,offset=offset)
    client_wait=False;assert not(session/'input/turn_request.json').exists();result['NewGameInitialized']=True
    client.send(b'8\r','observed main menu: normal exit before web host');until(lambda:client.process.poll() is not None,8,'original console normal exit');assert client.process.returncode==0
    start_web()
    result['RootPage']=request_http('/','new-game-root-page')
    for path in paths:request_http(path,'new-game-sequential')
    series('new-game-three-parallel',12)
    series('new-game-refresh-three-tabs',6,3)
    launcher=str(ship/'BookOfEternityClient/Launcher/bookofeternity.ps1')
    bridge=Terminal('bridge',['pwsh','-NoLogo','-NoProfile','-File',launcher,'start-bridge','visible','-SessionPath',str(session)])
    record_path=base/'.boe_runtime/gm-runs/main.json';socket_path=out/'tmp'/('CoreFxPipe_'+pipe)
    until(lambda:record_path.exists() and socket_path.exists(),15,'original main record and pipe')
    record=read_json(record_path);status=rpc({'command':'status'});result['OriginalRunningStatus']=status;result['OriginalRunningRecord']=record
    original_record=record['Identity'];original={k[0].lower()+k[1:]:v for k,v in original_record.items()};original['backend']=2
    assert record['Disposition']=='Running' and status['ok'] and status['status']['terminalOwnerRetained'] and not status['status']['terminalUncertain']
    assert status['status']['terminalRunId']==original_record['RunId'] and status['status']['cliLaunchCommand']==command
    def ready():
        s=rpc({'command':'status'})['status'];result['RelayReadiness']=s
        if s['terminalUncertain'] or not s['terminalOwnerRetained']:raise RuntimeError('Original relay authority lost')
        return s['ready'] and s['state']=='Ready'
    until(ready,15,'actual relay observed readiness');result['PersistentRelayReady']=True
    for path in paths:request_http(path,'relay-running-sequential')
    series('relay-running-three-parallel',12)
    assert not list(relay_queue.glob('request-*')),'No model/game prompt was submitted in HTTP diagnosis'
    result['NoRelaySubmit']=True
except Exception as ex:
    result['Failure']=type(ex).__name__+': '+str(ex);result['DriverTrace']=traceback.format_exc()
finally:
    cleaning=True
    # Finish HTTP/host scopes before original relay queue-close and fenced stop.
    if web is not None and web.process.poll() is None:
        try:web.send(b'\x03','normal web ConsoleLifetime stop');until(lambda:web.process.poll() is not None,10,'web normal stop');assert web.process.returncode==0;web_stopped=True
        except Exception as ex:result['WebCleanupFailure']=type(ex).__name__+': '+str(ex)
    result['WebStopped']=web_stopped
    if client is not None and client.process.poll() is None:
        try:client.send(b'\x03','stop original console on preparation failure');until(lambda:client.process.poll() is not None,8,'console stop')
        except Exception as ex:result['ClientCleanupFailure']=type(ex).__name__+': '+str(ex)
    if bridge is not None:
        try:result['RelayExecutionClosed']=close_relay_execution(relay_queue,6);assert result['RelayExecutionClosed']
        except Exception as ex:result['RelayCloseFailure']=type(ex).__name__+': '+str(ex)
    if original is not None:
        try:
            shutdown_attempts+=1;stop=rpc({'command':'shutdown','rootKey':original['rootKey'],'expectedMainIdentity':original},12);result['ShutdownReceipt']=stop;assert stop['ok']
            proof=stop['status']['terminalStop'];assert proof['identity']['runId']==original['runId'] and proof['state']=='stopped-within-scope' and proof['cleanupComplete'] and not proof['authorityRetained']
            until(lambda:bridge.process.poll() is not None,8,'original bridge exit');assert bridge.process.returncode==0
            settled=read_json(record_path);result['StoppedRecord']=settled;assert settled['Disposition']=='Stopped' and settled['Identity']==original_record
            result['LogicalLifecycleVerified']=True
        except Exception as ex:result['CleanupFailure']=type(ex).__name__+': '+str(ex)
    elif bridge is not None:result['CleanupFailure']='Original identity unobserved; guardian physical cleanup cannot logical-success'
    for p in peers:
        if p.process.poll() is not None and p.slave>=0:os.close(p.slave);p.slave=-1
    try:until(lambda:all(p.eof for p in peers),5,'actual process I/O EOF')
    except Exception as ex:result['IoCleanupFailure']=type(ex).__name__+': '+str(ex)
    result['Terminals']={}
    for p in peers:
        try:restored=termios.tcgetattr(p.master)==p.initial
        except OSError:restored=False
        result['Terminals'][p.name]={'ExitCode':p.process.poll(),'EOF':p.eof,'TermiosRestored':restored,'CapturedBytes':len(p.capture)}
        (out/(p.name+'.raw')).write_bytes(p.capture)
        if p.captured_output:(out/(p.name+'-echo.raw')).write_bytes(p.echo);p.process.stdout.close()
        for fd in [p.master,p.slave]:
            if fd>=0:os.close(fd)
    result['ShutdownAttempts']=shutdown_attempts;result['ElapsedSeconds']=elapsed();result['HttpRequests']=len(http_rows)
    result['StatusCounts']={str(s):sum(r.get('Status')==s for r in http_rows) for s in sorted({r['Status'] for r in http_rows if 'Status'in r})}
    result['Http500']=sum(r.get('Status')==500 for r in http_rows)
    (out/'http-responses.json').write_text(json.dumps(http_rows,indent=2,ensure_ascii=False)+'\n')
    (out/'rpc-journal.json').write_text(json.dumps(journal,indent=2,ensure_ascii=False)+'\n')
    (out/'result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:result.get(k) for k in ['NewGameInitialized','PersistentRelayReady','HttpRequests','StatusCounts','Http500','LogicalLifecycleVerified','ShutdownAttempts','Failure','WebCleanupFailure','CleanupFailure','ElapsedSeconds']},ensure_ascii=False))
    sys.exit(0 if result.get('NoRelaySubmit') and result.get('LogicalLifecycleVerified') and web_stopped and not any(k.endswith('Failure') for k in result) else 1)
