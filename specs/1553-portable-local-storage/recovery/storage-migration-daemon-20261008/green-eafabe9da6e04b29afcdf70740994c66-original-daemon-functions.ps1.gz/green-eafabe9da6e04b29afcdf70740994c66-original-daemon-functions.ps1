function New-DefaultGmWorkerBridgeProfiles {
    $runner = 'BookOfEternityClient/Launcher/gm_worker_cli_runner.ps1'
    $codexWorker = 'codex exec -m gpt-5.6-terra -c model_reasoning_effort=high --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check -'

    return @(
        [ordered]@{
            workerId = "validation_repair_codex"
            displayName = "Codex validation repair"
            launchCommand = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -AgentCommand `"$codexWorker`" -TimeoutSeconds 180"
            role = "validation-repair"
            enabled = $false
            launchVisibility = "hidden"
            timeoutSeconds = 210
            maxConcurrentTasks = 1
            permissions = [ordered]@{
                taskTypes = @("validation-repair")
                readPaths = @("game_state/**", "lore/**", "input/**", "ready/**")
                proposalWritePaths = @("game_state/**", "lore/**", "ready/**")
                proposalOnly = $false
                requiresValidation = $true
            }
        },
        [ordered]@{
            workerId = "narrative_draft_codex"
            displayName = "Codex narrative drafter"
            launchCommand = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -AgentCommand `"$codexWorker`" -TimeoutSeconds 120"
            role = "narrative-draft"
            enabled = $false
            launchVisibility = "hidden"
            timeoutSeconds = 150
            maxConcurrentTasks = 1
            permissions = [ordered]@{
                taskTypes = @("narrative-draft")
                readPaths = @("game_state/**", "lore/**", "Rules/**", "TaskGuides/**")
                proposalWritePaths = @()
                proposalOnly = $true
                requiresValidation = $false
            }
        },
        [ordered]@{
            workerId = "analysis_codex"
            displayName = "Codex analysis worker"
            launchCommand = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -AgentCommand `"$codexWorker`" -TimeoutSeconds 120"
            role = "analysis"
            enabled = $false
            launchVisibility = "hidden"
            timeoutSeconds = 150
            maxConcurrentTasks = 1
            permissions = [ordered]@{
                taskTypes = @("analysis")
                readPaths = @("game_state/**", "lore/**", "Rules/**", "TaskGuides/**")
                proposalWritePaths = @()
                proposalOnly = $true
                requiresValidation = $false
            }
        },
        [ordered]@{
            workerId = "guardian_abode_content_codex"
            displayName = "Codex Guardian/Abode content author"
            launchCommand = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -AgentCommand `"$codexWorker`" -TimeoutSeconds 120"
            role = "guardian-abode-content"
            enabled = $false
            launchVisibility = "hidden"
            timeoutSeconds = 150
            maxConcurrentTasks = 1
            permissions = [ordered]@{
                taskTypes = @("guardian-abode-content")
                readPaths = @("game_state/meta/guardians.json", "game_state/meta/guardian_projects.json", "game_state/meta/guardian_abode_residents.json", "game_state/meta/abode_power_journal.json", "game_state/meta/chaos_sea_guardian_politics.json", "game_state/meta/afterlife_chronicles.json", "game_state/control/system_guardian_attraction.json", "game_state/control/afterlife_return_guard.json", "game_state/control/progression_schedule.json", "OtherGuides/Afterlife_Contract_Matrix.md", "Examples/E_CLI_Afterlife_Turns.txt")
                proposalWritePaths = @()
                proposalOnly = $true
                requiresValidation = $false
            }
        },
        [ordered]@{
            workerId = "soul_content_codex"
            displayName = "Codex soul content author"
            launchCommand = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -AgentCommand `"$codexWorker`" -TimeoutSeconds 120"
            role = "soul-content"
            enabled = $false
            launchVisibility = "hidden"
            timeoutSeconds = 150
            maxConcurrentTasks = 1
            permissions = [ordered]@{
                taskTypes = @("soul-content")
                readPaths = @("game_state/meta/soul_state.json", "game_state/meta/afterlife_chronicles.json", "game_state/meta/afterlife_global_flags.json", "game_state/control/progression_schedule.json", "game_state/control/pending_dice_state.json", "OtherGuides/Afterlife_Contract_Matrix.md", "Examples/E_CLI_Afterlife_Turns.txt")
                proposalWritePaths = @()
                proposalOnly = $true
                requiresValidation = $false
            }
        },
        [ordered]@{
            workerId = "inventory_content_codex"
            displayName = "Codex inventory content author"
            launchCommand = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -AgentCommand `"$codexWorker`" -TimeoutSeconds 120"
            role = "inventory-content"
            enabled = $false
            launchVisibility = "hidden"
            timeoutSeconds = 150
            maxConcurrentTasks = 1
            permissions = [ordered]@{
                taskTypes = @("inventory-content")
                readPaths = @("game_state/core/**", "game_state/inventory/**", "game_state/world/**", "game_state/skills/**", "lore/**", "Rules/**", "TaskGuides/**")
                proposalWritePaths = @()
                proposalOnly = $true
                requiresValidation = $false
            }
        },
        [ordered]@{
            workerId = "skill_content_codex"
            displayName = "Codex skill content author"
            launchCommand = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -AgentCommand `"$codexWorker`" -TimeoutSeconds 120"
            role = "skill-content"
            enabled = $false
            launchVisibility = "hidden"
            timeoutSeconds = 150
            maxConcurrentTasks = 1
            permissions = [ordered]@{
                taskTypes = @("skill-content")
                readPaths = @("game_state/core/**", "game_state/player/**", "game_state/skills/**", "game_state/combat/**", "game_state/world/**", "lore/**", "Rules/**", "TaskGuides/**")
                proposalWritePaths = @()
                proposalOnly = $true
                requiresValidation = $false
            }
        },
        [ordered]@{
            workerId = "npc_content_codex"
            displayName = "Codex NPC content author"
            launchCommand = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -AgentCommand `"$codexWorker`" -TimeoutSeconds 120"
            role = "npc-content"
            enabled = $false
            launchVisibility = "hidden"
            timeoutSeconds = 150
            maxConcurrentTasks = 1
            permissions = [ordered]@{
                taskTypes = @("npc-content")
                readPaths = @("game_state/core/**", "game_state/npcs/**", "game_state/factions/**", "game_state/quests/**", "game_state/world/**", "lore/**", "Rules/**", "TaskGuides/**")
                proposalWritePaths = @()
                proposalOnly = $true
                requiresValidation = $false
            }
        }
    )
}
function Convert-RetiredCodexLaunchDefaults {
    param([object]$Config)

    $retiredModel = 'gpt-5' + '.5'
    $currentMain = 'codex -m gpt-5.6-terra -c model_reasoning_effort=high --dangerously-bypass-approvals-and-sandbox'
    $retiredMainQuoted = "codex -m $retiredModel -c model_reasoning_effort=`"high`" --dangerously-bypass-approvals-and-sandbox"
    $retiredMainUnquoted = "codex -m $retiredModel -c model_reasoning_effort=high --dangerously-bypass-approvals-and-sandbox"

    if ($Config.GmCliLaunchCommand -ceq $retiredMainQuoted -or $Config.GmCliLaunchCommand -ceq $retiredMainUnquoted) {
        $Config.GmCliLaunchCommand = $currentMain
    }

    $currentWorker = 'codex exec -m gpt-5.6-terra -c model_reasoning_effort=high --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check -'
    $retiredWorkerQuoted = "codex exec -m $retiredModel -c model_reasoning_effort=`"high`" --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check -"
    $retiredWorkerEscapedQuoted = $retiredWorkerQuoted.Replace('"', '\"')
    $retiredWorkerUnquoted = "codex exec -m $retiredModel -c model_reasoning_effort=high --dangerously-bypass-approvals-and-sandbox --skip-git-repo-check -"

    $runner = 'BookOfEternityClient/Launcher/gm_worker_cli_runner.ps1'
    $standardWorkerIds = @(
        'analysis_codex',
        'guardian_abode_content_codex',
        'inventory_content_codex',
        'narrative_draft_codex',
        'npc_content_codex',
        'skill_content_codex',
        'soul_content_codex'
    )

    foreach ($profile in @($Config.GmWorkerBridgeProfiles)) {
        if ($null -eq $profile -or [string]::IsNullOrWhiteSpace([string]$profile.LaunchCommand)) {
            continue
        }

        $workerId = [string]$profile.WorkerId
        $runnerTimeout = if ($workerId -ceq 'validation_repair_codex') {
            180
        } elseif ($standardWorkerIds -ccontains $workerId) {
            120
        } else {
            $null
        }
        if ($null -eq $runnerTimeout) {
            continue
        }

        $currentLaunch = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -AgentCommand `"$currentWorker`" -TimeoutSeconds $runnerTimeout"
        $retiredQuotedLaunch = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -AgentCommand `"$retiredWorkerEscapedQuoted`" -TimeoutSeconds $runnerTimeout"
        $retiredUnquotedLaunch = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -AgentCommand `"$retiredWorkerUnquoted`" -TimeoutSeconds $runnerTimeout"
        if ($profile.LaunchCommand -ceq $retiredQuotedLaunch -or $profile.LaunchCommand -ceq $retiredUnquotedLaunch) {
            $profile.LaunchCommand = $currentLaunch
        }
    }

    return $Config
}
function Get-GameConfig {
    $configPath = Join-Path $GameSessionPath "config.json"
    $defaults = [ordered]@{
        GmBridgeEnabled = $true
        GmBridgeBackend = "ConPTYBridge"
        GmCliLaunchCommand = 'codex -m gpt-5.6-terra -c model_reasoning_effort=high --dangerously-bypass-approvals-and-sandbox'
        GmBridgeShellWorkingDirectory = ""
        GmBridgeAutoStart = $false
        GmBridgePipeNameOverride = ""
        GmWorkerBridgeProfiles = New-DefaultGmWorkerBridgeProfiles
    }

    if (!(Test-GmDaemonPath $configPath)) {
        return [pscustomobject]$defaults
    }

    try {
        $loaded = Get-GmDaemonText $configPath | ConvertFrom-Json
        foreach ($key in @($defaults.Keys)) {
            if ($null -eq $loaded.$key) {
                $loaded | Add-Member -NotePropertyName $key -NotePropertyValue $defaults[$key] -Force
            }
        }

        return (Convert-RetiredCodexLaunchDefaults -Config $loaded)
    }
    catch {
        Assert-GmNotDaemonReadFailure $_
        return [pscustomobject]$defaults
    }
}
function Get-GmBridgeStatus {
    if (!(Test-GmDaemonPath $BridgeStatusFile)) {
        return $null
    }

    try {
        $status = Get-GmDaemonText $BridgeStatusFile | ConvertFrom-Json
        if ($null -eq $status.helperPid) {
            return $status
        }

        try {
            $null = Get-Process -Id ([int]$status.helperPid) -ErrorAction Stop
            return $status
        }
        catch {
        Assert-GmNotDaemonReadFailure $_
            # PID liveness is diagnostic; it never authorizes canonical deletion.
            return $null
        }
    }
    catch {
        Assert-GmNotDaemonReadFailure $_
        return $null
    }
}
function Ensure-GmBridgeStarted {
    $config = Get-GameConfig
    if (-not $config.GmBridgeEnabled -or $config.GmBridgeBackend -notin @('ConPTYBridge','OwnedTerminal')) {
        return
    }

    if (-not $config.GmBridgeAutoStart -or $script:BridgeAutoStartAttempted) {
        return
    }

    $script:BridgeAutoStartAttempted = $true

    if (!(Test-Path $BridgeControlScript)) {
        Write-Log "  -> GM bridge control script not found. Auto-start skipped." -Level "WARN" -Color Yellow
        return
    }

    try {
        & $BridgeControlScript start-bridge -SessionPath $GameSessionPath | Out-Null
        Write-Log "  -> Requested GM bridge auto-start" -Color DarkGray
    }
    catch {
        Assert-GmNotDaemonReadFailure $_
        Write-Log "  -> GM bridge auto-start failed: $_" -Level "WARN" -Color Yellow
    }
}
function Read-GmPromptPending {
    param([string]$Path)
    $file=Get-GmDaemonFileObservation $Path
    if($file.kind -cne 'File'){throw (New-GmDaemonReadFailure 'Pending daemon file is absent or not regular.' $null)}
    $bytes=[Convert]::FromBase64String([string]$file.bytes)
    [pscustomobject]@{Hash=([string]$file.hash).ToUpperInvariant();Observation=$file;LastWriteTimeUtc=[datetime]$file.lastWriteTimeUtc;
        Request=([Text.Encoding]::UTF8.GetString($bytes).TrimStart([char]0xFEFF) | ConvertFrom-Json)}
}
function Test-GmPromptSourceCurrent {
    param([string]$Path, [string]$Hash)
    if (-not $Path) { return $true }
    try { return [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData((Get-GmDaemonFileBytes $Path))) -ceq $Hash }
    catch {
        Assert-GmNotDaemonReadFailure $_; return $false }
}
function Get-GmPromptContentHash {
    param([object]$Payload)
    $prefix = if ($Payload.appendEnter) { "1`n" } else { "0`n" }
    return [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($prefix + [string]$Payload.text)))
}
function New-GmPromptOperation {
    param([string]$Message, [string]$PendingPath = '', [string]$OperationKind = 'turn', [string]$OperationRevision = 'live', [string]$ExpectedSourceHash = '')
    $sourceHash = ''
    if ($PendingPath) {
        $sourceHash = if ($ExpectedSourceHash) { $ExpectedSourceHash } else { (Read-GmPromptPending $PendingPath).Hash }
        if (-not (Test-GmPromptSourceCurrent $PendingPath $sourceHash)) { return $null }
    }
    $key = $OperationKind + '|' + $OperationRevision + '|' + $PendingPath + '|' + $sourceHash
    if (-not $PendingPath) { $key += '|' + [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($Message))) }
    if ($null -eq $script:GmPromptOperations) { $script:GmPromptOperations = @{} }
    if ($script:GmPromptOperations.ContainsKey($key)) { return $script:GmPromptOperations[$key] }
    $status = Get-GmBridgeStatus
    if (-not $status -or [string]::IsNullOrWhiteSpace([string]$status.inputBindingId)) { return $null }
    $operation = [pscustomobject]@{
        PayloadJson = ([ordered]@{ command='dispatchPrompt'; operationId=[guid]::NewGuid().ToString('N');
            operationKind=$OperationKind; operationRevision=$OperationRevision; inputBindingId=[string]$status.inputBindingId;
            text=$Message; appendEnter=$true } | ConvertTo-Json -Depth 6 -Compress)
        PendingPath=$PendingPath; SourceHash=$sourceHash; LastDelivery=$null; MayHaveReached=$false
    }
    # A live owner retains all possibly delivered identities. Overflow never evicts or rebinds them.
    if ($script:GmPromptOperations.Count -ge 256) { return $null }
    $script:GmPromptOperations[$key] = $operation
    return $operation
}
function New-GmPromptDelivery {
    param([object]$Operation, [string]$Disposition, [string]$Reason)
    $p = if ($Operation) { $Operation.PayloadJson | ConvertFrom-Json } else { $null }
    return [pscustomobject]@{ operationId=[string]$p.operationId; operationKind=[string]$p.operationKind;
        operationRevision=[string]$p.operationRevision; inputBindingId=[string]$p.inputBindingId;
        contentHash=(Get-GmPromptContentHash $p); disposition=$Disposition; phase='terminal'; reason=$Reason }
}
function Test-GmPromptDeliveryIdentity {
    param([object]$Operation, [object]$Delivery)
    $p = $Operation.PayloadJson | ConvertFrom-Json
    return $Delivery -and $Delivery.operationId -ceq $p.operationId -and $Delivery.operationKind -ceq $p.operationKind -and
        $Delivery.operationRevision -ceq $p.operationRevision -and $Delivery.inputBindingId -ceq $p.inputBindingId -and
        $Delivery.contentHash -ceq (Get-GmPromptContentHash $p)
}
function Invoke-GmPromptControl {
    param([object]$Operation, [string]$Command = 'dispatchPrompt')
    $payload = $Operation.PayloadJson | ConvertFrom-Json
    $payload.command = $Command
    $json = $payload | ConvertTo-Json -Depth 6 -Compress
    try {
        # No transport exception proves zero input after invoking a launcher. Never automatically replay it.
        if ($Command -eq 'dispatchPrompt') { $Operation.MayHaveReached = $true }
        $raw = & $BridgeControlScript dispatch-operation $json -SessionPath $GameSessionPath
        $response = ($raw -join "`n") | ConvertFrom-Json
        if (-not (Test-GmPromptDeliveryIdentity $Operation $response.promptDelivery)) { throw 'Mismatched prompt delivery identity.' }
        return $response.promptDelivery
    }
    catch {
        Assert-GmNotDaemonReadFailure $_; return (New-GmPromptDelivery $Operation 'unknown-outcome' 'launcher-or-transport-ambiguous') }
}
function Send-ToGmBridge {
    param([string]$Message, [switch]$AllowNotReady, [object]$Operation)
    $config = Get-GameConfig
    if (-not $config.GmBridgeEnabled -or $config.GmBridgeBackend -notin @('ConPTYBridge','OwnedTerminal')) { return $null }
    Ensure-GmBridgeStarted
    if (-not $Operation) { $Operation = New-GmPromptOperation -Message $Message -OperationKind 'automatic' }
    if (-not $Operation) { return (New-GmPromptDelivery $null 'not-written' 'retention-full') }
    if ($script:GmPromptInputPaused) { return (New-GmPromptDelivery $Operation 'unknown-outcome' 'automatic-input-paused') }
    if ($Operation.LastDelivery -and $Operation.LastDelivery.disposition -ne 'not-written') { return $Operation.LastDelivery }
    if (!(Test-Path $BridgeControlScript)) { return (New-GmPromptDelivery $Operation 'not-written' 'control-missing') }
    # Dormant AllowNotReady uses this same operation; it cannot bypass the bridge's positive idle/draft check.
    $delivery = Invoke-GmPromptControl -Operation $Operation
    $Operation.LastDelivery = $delivery
    if ($delivery.disposition -in @('draft-uncertain','unknown-outcome') -or -not $delivery.disposition) { $script:GmPromptInputPaused = $true }
    return $delivery
}
function Write-Log {
    param([string]$Message, [string]$Level = "INFO", [ConsoleColor]$Color = [ConsoleColor]::White)
    $timestamp = Get-Date -Format "HH:mm:ss"
    $logLine = "[$timestamp][$Level] $Message"
    Write-Host $logLine -ForegroundColor $Color
    if ($LogFile) {
        try {
            $relativeLog=[IO.Path]::GetRelativePath([IO.Path]::GetFullPath($GameSessionPath),[IO.Path]::GetFullPath($LogFile)).Replace("\","/")
            if ($relativeLog.StartsWith("../") -or [IO.Path]::IsPathRooted($relativeLog)) { Add-Content -LiteralPath $LogFile -Value $logLine -Encoding UTF8 -ErrorAction SilentlyContinue }
            else { Write-GmCanonicalText -SessionPath $GameSessionPath -Path $LogFile -Value $logLine -Append }
        } catch {
        Assert-GmNotDaemonReadFailure $_ }
    }
}
function Write-DaemonJsonFileBestEffort {
    param([string]$Path,[object]$Payload,[int]$Depth=8)
    try {
        Write-GmCanonicalText -SessionPath $GameSessionPath -Path $Path -Value ($Payload | ConvertTo-Json -Depth $Depth)
        return $true
    } catch {
        Assert-GmNotDaemonReadFailure $_
        # Bounded volatile diagnostics survive a closed/lost operation. They are
        # not another canonical writer and cannot authorize continuation.
        $script:LastUnpublishedDaemonDiagnostic = [pscustomobject]@{path=$Path;payload=$Payload}
        return $false
    }
}
function Write-DaemonStatus {
    param(
        [string]$Status = "running",
        [object]$FatalError = $null,
        [string]$Reason = "",
        [Nullable[int]]$CurrentTurnNumber = $null,
        [Nullable[int]]$TurnElapsedSeconds = $null
    )

    $payload = [ordered]@{
        status = $Status
        pid = $PID
        sessionPath = $GameSessionPath
        startedAtUtc = $script:StartTime.ToUniversalTime().ToString("o")
        heartbeatAtUtc = (Get-Date).ToUniversalTime().ToString("o")
        command = $script:DaemonCommandLine
        turnTimeoutSeconds = $TurnTimeout
        turnCount = $script:TurnCount
        errorCount = $script:ErrorCount
    }

    if (-not [string]::IsNullOrWhiteSpace($Reason)) {
        $payload.reason = $Reason
    }

    if ($null -ne $CurrentTurnNumber) {
        $payload.currentTurnNumber = $CurrentTurnNumber
    }

    if ($null -ne $TurnElapsedSeconds) {
        $payload.turnElapsedSeconds = $TurnElapsedSeconds
    }

    if ($null -ne $script:DaemonLastLoopError) {
        $payload.lastLoopError = $script:DaemonLastLoopError
    }

    if ($null -ne $FatalError) {
        $payload.fatalError = New-DaemonErrorPayload -ErrorRecord $FatalError -Phase "fatal"
    }

    [void](Write-DaemonJsonFileBestEffort -Path $DaemonStatusFile -Payload $payload -Depth 8)
}
function New-GmDispatchDiagnostics {
    param(
        [string]$Status = "not_dispatched",
        [int]$Attempts = 0,
        [int]$BusyRetries = 0,
        [bool]$Timeout = $false
    )

    return [pscustomobject]@{
        Status = $Status
        Attempts = $Attempts
        BusyRetries = $BusyRetries
        Timeout = $Timeout
    }
}
function Send-ToCliWindow {
    param(
        [string]$Message, [object]$Operation
    )

    $config = Get-GameConfig
    if ($config.GmBridgeEnabled -and $config.GmBridgeBackend -in @('ConPTYBridge','OwnedTerminal')) {
        return (Send-ToGmBridge -Message $Message -Operation $Operation)
    }

    if (-not ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT)) { throw 'Linux requires the configured owned bridge; no window/clipboard transport fallback.' }
    # Explicit Windows desktop transport only; bridge delivery never falls back.
    Set-Clipboard -Value $Message
    Write-Log "  -> Clipboard: command copied" -Color DarkGray

    if (-not $AutoPaste) {
        [Console]::Beep(800, 200)
        [Console]::Beep(1000, 200)
        Write-Log "  -> Command copied to clipboard. Paste it manually into the CLI window using the method your terminal supports." -Color Yellow
        return "clipboard"
    }

    $target = Resolve-CliTarget
    if (-not $target) {
        Write-Log "  -> No bound CLI window found. Command left in clipboard." -Level "WARN" -Color Yellow
        [Console]::Beep(400, 300)
        return "unbound"
    }

    try {
        [Win32Window]::ShowWindow($target.WindowHandle, [Win32Window]::SW_RESTORE) | Out-Null
        Start-Sleep -Milliseconds 200
        [Win32Window]::SetForegroundWindow($target.WindowHandle) | Out-Null
        Start-Sleep -Milliseconds 350
        Write-Log "  -> Activated target via $($target.Description)" -Color DarkGray

        if ($PasteMode -eq "CtrlV") {
            [System.Windows.Forms.SendKeys]::SendWait("^v")
            Write-Log "  -> Paste sent via Ctrl+V" -Color DarkGray
        }
        elseif ($PasteMode -eq "ShiftInsert") {
            [System.Windows.Forms.SendKeys]::SendWait("+{INSERT}")
            Write-Log "  -> Paste sent via Shift+Insert" -Color DarkGray
        }
        else {
            if (-not (Invoke-RightClickPaste -WindowHandle $target.WindowHandle)) {
                throw "RightClick paste failed: could not target window coordinates."
            }
            Write-Log "  -> Paste sent via RightClick" -Color DarkGray
        }
        Start-Sleep -Milliseconds 250
        [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
        Write-Log "  -> Enter sent" -Color DarkGray

        Write-Log "  -> Sent to CLI window" -Color Green
        return "sent"
    }
    catch {
        Assert-GmNotDaemonReadFailure $_
        Write-Log "  -> SendKeys failed: $_. Command in clipboard." -Level "WARN" -Color Yellow
        return "failed"
    }
}
function Dispatch-WithRetry {
    param([string]$Message, [string]$PendingPath = '', [switch]$ReturnDetails, [int]$MaxWaitSeconds = 0,
        [string]$OperationKind = 'turn', [string]$OperationRevision = 'live', [object]$Operation, [string]$ExpectedSourceHash = '')
    $attempts = 0; $busyRetries = 0; $startedAt = Get-Date
    $config = Get-GameConfig
    $bridge = $config.GmBridgeEnabled -and $config.GmBridgeBackend -in @('ConPTYBridge','OwnedTerminal')
    if ($bridge -and -not $Operation) {
        if ($PendingPath -and !(Test-GmDaemonPath $PendingPath)) { return (Complete-GmPromptDispatch 'cancelled' $null $ReturnDetails 0 0) }
        if (-not $ExpectedSourceHash -and $PendingPath) { $ExpectedSourceHash = (Read-GmPromptPending $PendingPath).Hash }
        if (-not (Test-GmPromptSourceCurrent $PendingPath $ExpectedSourceHash)) { return (Complete-GmPromptDispatch 'cancelled' $null $ReturnDetails 0 0) }
        Ensure-GmBridgeStarted
        $Operation = New-GmPromptOperation -Message $Message -PendingPath $PendingPath -OperationKind $OperationKind -OperationRevision $OperationRevision -ExpectedSourceHash $ExpectedSourceHash
        if (-not $Operation) { return (Complete-GmPromptDispatch 'bridge-not-written' (New-GmPromptDelivery $null 'not-written' 'binding-unavailable-or-retention-full') $ReturnDetails 0 0) }
    }
    while ($true) {
        $hash = if ($Operation) { $Operation.SourceHash } else { $ExpectedSourceHash }
        if (-not (Test-GmPromptSourceCurrent $PendingPath $hash)) {
            if ($Operation -and $Operation.MayHaveReached -and $Operation.LastDelivery.disposition -notin @('not-written','queued-cancelled')) {
                $null = Invoke-GmPromptControl -Operation $Operation -Command 'cancelPrompt'
                $script:GmPromptInputPaused = $true
                $delivery = New-GmPromptDelivery $Operation 'unknown-outcome' 'pending-source-replaced-after-dispatch'
                $Operation.LastDelivery = $delivery
                return (Complete-GmPromptDispatch 'bridge-unknown-outcome' $delivery $ReturnDetails $attempts $busyRetries)
            }
            return (Complete-GmPromptDispatch 'cancelled' $null $ReturnDetails $attempts $busyRetries)
        }
        $attempts++
        $dispatch = Send-ToCliWindow -Message $Message -Operation $Operation
        # An old remote callback cannot complete a replacement pending packet.
        if (-not (Test-GmPromptSourceCurrent $PendingPath $hash)) {
            if ($dispatch -isnot [string] -and $dispatch.disposition -in @('not-written','queued-cancelled')) {
                return (Complete-GmPromptDispatch 'cancelled' $dispatch $ReturnDetails $attempts $busyRetries)
            }
            if ($Operation -and $Operation.MayHaveReached) { $null = Invoke-GmPromptControl -Operation $Operation -Command 'cancelPrompt' }
            $script:GmPromptInputPaused = $true
            $delivery = New-GmPromptDelivery $Operation 'unknown-outcome' 'pending-source-replaced-during-dispatch'
            if ($Operation) { $Operation.LastDelivery = $delivery }
            return (Complete-GmPromptDispatch 'bridge-unknown-outcome' $delivery $ReturnDetails $attempts $busyRetries)
        }
        if ($dispatch -is [string]) {
            # Untyped bridge failures cannot authorize a retry, even for legacy collaborators.
            $status = if ($dispatch -like 'bridge-*') { 'bridge-unknown-outcome' } else { $dispatch }
            if ($status -eq 'bridge-unknown-outcome') { $script:GmPromptInputPaused = $true }
            return (Complete-GmPromptDispatch $status $null $ReturnDetails $attempts $busyRetries)
        }
        $delivery = $dispatch
        if (-not $Operation -or -not (Test-GmPromptDeliveryIdentity $Operation $delivery)) {
            $script:GmPromptInputPaused = $true
            return (Complete-GmPromptDispatch 'bridge-unknown-outcome' $delivery $ReturnDetails $attempts $busyRetries)
        }
        $Operation.LastDelivery = $delivery
        switch ([string]$delivery.disposition) {
            'submission-observed' { return (Complete-GmPromptDispatch 'sent' $delivery $ReturnDetails $attempts $busyRetries) }
            'queued-cancelled' { return (Complete-GmPromptDispatch 'cancelled' $delivery $ReturnDetails $attempts $busyRetries) }
            'not-written' {
                if ($delivery.reason -notin @('busy','not-ready')) { return (Complete-GmPromptDispatch 'bridge-not-written' $delivery $ReturnDetails $attempts $busyRetries) }
                $busyRetries++
                if ($MaxWaitSeconds -le 0 -or ((Get-Date)-$startedAt).TotalSeconds -ge $MaxWaitSeconds) {
                    return (Complete-GmPromptDispatch 'bridge-dispatch-timeout' $delivery $ReturnDetails $attempts $busyRetries)
                }
                Start-Sleep -Seconds 1
            }
            default {
                $script:GmPromptInputPaused = $true
                return (Complete-GmPromptDispatch 'bridge-unknown-outcome' $delivery $ReturnDetails $attempts $busyRetries)
            }
        }
    }
}
function Complete-GmPromptDispatch {
    param([string]$Status, [object]$Delivery, [bool]$Details, [int]$Attempts, [int]$BusyRetries)
    if (-not $Details) { return $Status }
    $result = New-GmDispatchDiagnostics -Status $Status -Attempts $Attempts -BusyRetries $BusyRetries -Timeout:($Status -eq 'bridge-dispatch-timeout')
    $result | Add-Member -NotePropertyName PromptDelivery -NotePropertyValue $Delivery -Force
    return $result
}
function Test-GmPromptDispatchPaused {
    param([object]$Dispatch)
    return $Dispatch.Status -in @('bridge-unknown-outcome','bridge-not-written','cancelled')
}
function Get-QteEffectResolutionRequestKey {
    param([psobject]$Request)

    if ($null -eq $Request) {
        return ""
    }

    return @(
        [string]$Request.sessionId,
        [string]$Request.sessionGeneration,
        [string]$Request.continuationId,
        [string]$Request.requestId,
        [string]$Request.waveId,
        [string]$Request.waveOrdinal,
        [string]$Request.acceptedSourceTurn,
        [string]$Request.qteId
    ) -join "|"
}
function Test-QteEffectResolutionRequestStillCurrent {
    param(
        [string]$RequestPath,
        [string]$ExpectedRequestKey
    )

    if (!(Test-GmDaemonPath $RequestPath) -or [string]::IsNullOrWhiteSpace($ExpectedRequestKey)) {
        return $false
    }

    try {
        $current = Get-GmDaemonText $RequestPath | ConvertFrom-Json
        return [string]::Equals(
            (Get-QteEffectResolutionRequestKey -Request $current),
            $ExpectedRequestKey,
            [System.StringComparison]::Ordinal)
    }
    catch {
        Assert-GmNotDaemonReadFailure $_
        return $false
    }
}
function Test-QteEffectResolutionReadyMatchesRequest {
    param(
        [psobject]$Request,
        [string]$ReadyPath = $QteEffectResolutionReadyFile
    )

    if ($null -eq $Request -or !(Test-GmDaemonPath $ReadyPath)) {
        return $false
    }

    try {
        $ready = Get-GmDaemonText $ReadyPath | ConvertFrom-Json
        if (-not [string]::Equals(
                [string]$ready.status,
                "success",
                [System.StringComparison]::Ordinal) -or
            -not [string]::Equals(
                [string]$ready.requestKind,
                "qte_deferred_effect_resolution",
                [System.StringComparison]::Ordinal)) {
            return $false
        }

        foreach ($field in @(
            "sessionId",
            "sessionGeneration",
            "continuationId",
            "requestId",
            "waveId",
            "qteId",
            "pendingStateFingerprint"
        )) {
            if (-not [string]::Equals(
                    [string]$ready.$field,
                    [string]$Request.$field,
                    [System.StringComparison]::Ordinal)) {
                return $false
            }
        }

        return [int64]$ready.waveOrdinal -eq [int64]$Request.waveOrdinal -and
            [int64]$ready.acceptedSourceTurn -eq [int64]$Request.acceptedSourceTurn
    }
    catch {
        Assert-GmNotDaemonReadFailure $_
        return $false
    }
}
function Build-QteEffectResolutionDispatchMessage {
    param([psobject]$Request)

    $requestId = [string]$Request.requestId
    $waveId = [string]$Request.waveId
    $waveOrdinal = [int64]$Request.waveOrdinal

    return @"
Resolve bounded QTE effect receipt wave $waveOrdinal (requestId=$requestId, waveId=$waveId).
This is a receipt-only task and NOT an ordinary turn.
Dot-source '$script:GmTurnHelperBootstrapPath', then read '$GameSessionPath\input\qte_effect_resolution_request.json'.
Use only safePacket.requests from that exact request. Return exactly one receipt for every request, preserve each requestId, choose only a listed allowedResults resultKind, obey its amount instruction, and provide a short in-world reason. Numeric amounts must be JSON numbers, never strings.
Do NOT read input\turn_request.json, create a pending-turn snapshot, run story/progression/life-cycle work, reconstruct hidden mechanics, or inspect repository source.
Do NOT write game state, narrative/interface output, output\qte_effect_resolution_receipts.json, or ready\qte_effect_resolution_complete.json yourself.
Do NOT call Complete-BoeTurn, Fail-BoeTurn, or Complete-BoeValidationRepair. Do not use Write-BoeJson for this packet.
Construct the closed receipt objects in memory and call Complete-BoeQteEffectResolution -Receipts `$receipts as the LAST action. The helper alone copies exact correlation, validates the closed response, writes output\qte_effect_resolution_receipts.json, and writes ready\qte_effect_resolution_complete.json last.
After that helper call, stop immediately and do not report or write anything else.
"@
}
function Read-QteDaemonEligibility {
    param([string]$RequestPath)
    $batch=Get-GmDaemonSnapshot -Paths @($RequestPath,$QteEffectResolutionReadyFile)
    return Invoke-GmDaemonSnapshotView $batch {
        if(-not (Test-GmDaemonPath $RequestPath)){return $null}
        $pending=Read-GmPromptPending $RequestPath
        return [pscustomobject]@{Pending=$pending;ReadyMatches=(Test-QteEffectResolutionReadyMatchesRequest -Request $pending.Request -ReadyPath $QteEffectResolutionReadyFile)}
    }
}
function Process-QteEffectResolutionRequest {
    param([string]$RequestPath)
    Invoke-GmParticipatingConsumer $GameSessionPath { Process-QteEffectResolutionRequestCore -RequestPath $RequestPath }
}
function Process-QteEffectResolutionRequestCore {
    param([string]$RequestPath)

    if ($script:IsProcessing) { return }
    $script:IsProcessing = $true

    try {
        Start-Sleep -Milliseconds 150
        $eligibility=Read-QteDaemonEligibility $RequestPath
        if($null -eq $eligibility){return}
        $pendingSnapshot = $eligibility.Pending
        $request = $pendingSnapshot.Request
        if (-not [string]::Equals(
                [string]$request.requestKind,
                "qte_deferred_effect_resolution",
                [System.StringComparison]::Ordinal) -or
            $null -eq $request.safePacket) {
            throw "Invalid dedicated QTE effect-resolution request."
        }

        $requestKey = Get-QteEffectResolutionRequestKey -Request $request
        if ([string]::IsNullOrWhiteSpace($requestKey.Replace("|", ""))) {
            throw "Dedicated QTE effect-resolution request has no correlation authority."
        }

        if ($eligibility.ReadyMatches) {
            Write-Log "  Found correlated QTE effect-resolution ready marker; waiting for client consumption." -Color DarkGray
            return
        }

        $startedAt = Get-Date
        $acceptedSourceTurn = if ($null -ne $request.acceptedSourceTurn) {
            [int]$request.acceptedSourceTurn
        } else {
            -1
        }
        Write-Host ""
        Write-Log "QTE effect receipt wave $($request.waveOrdinal) for source turn #$acceptedSourceTurn" -Level "QTE" -Color Cyan

        $message = Build-QteEffectResolutionDispatchMessage -Request $request
        $dispatchMaxWaitSeconds = if ($TurnTimeout -gt 0 -and $TurnTimeout -lt $script:BridgeDispatchMaxWaitSeconds) {
            $TurnTimeout
        } else {
            $script:BridgeDispatchMaxWaitSeconds
        }
        $dispatch = Dispatch-WithRetry `
            -Message $message `
            -PendingPath $RequestPath -ExpectedSourceHash $pendingSnapshot.Hash `
            -OperationKind qte-effect -OperationRevision $requestKey `
            -ReturnDetails `
            -MaxWaitSeconds $dispatchMaxWaitSeconds
        if (Test-GmPromptDispatchPaused $dispatch) {
            Write-Log "  QTE effect receipt request was cancelled before dispatch." -Level "WARN" -Color Yellow
            return
        }
        if ($dispatch.Status -eq "bridge-dispatch-timeout") {
            $script:ErrorCount++
            Write-Log "  GM bridge did not accept the QTE receipt packet; dedicated authority remains pending for retry." -Level "ERROR" -Color Red
            return
        }

        $elapsed = 0
        while ($TurnTimeout -le 0 -or $elapsed -lt $TurnTimeout) {
            if (Test-QteEffectResolutionReadyMatchesRequest `
                    -Request $request `
                    -ReadyPath $QteEffectResolutionReadyFile) {
                $duration = ((Get-Date) - $startedAt).TotalSeconds
                Write-Log "  QTE effect receipt wave ready ($([math]::Round($duration, 1))s)" -Level "QTE" -Color Green
                return
            }

            Start-Sleep -Seconds 1
            $elapsed++

            if (-not (Test-QteEffectResolutionRequestStillCurrent `
                    -RequestPath $RequestPath `
                    -ExpectedRequestKey $requestKey)) {
                Write-Log "  QTE effect receipt wait closed because client authority was removed or replaced." -Level "WARN" -Color Yellow
                return
            }

            if ($elapsed % 15 -eq 0 -and
                (Test-GmBridgeReturnedIdleWithoutTerminalSignal -ElapsedSeconds $elapsed)) {
                Write-Log "  GM bridge returned idle without the correlated QTE ready marker; preserving the original delivery without replay." -Level "WARN" -Color Yellow
                $operation = New-GmPromptOperation -Message $message -PendingPath $RequestPath -ExpectedSourceHash $pendingSnapshot.Hash -OperationKind qte-effect -OperationRevision $requestKey
                if ($operation) { $operation.LastDelivery = Invoke-GmPromptControl -Operation $operation -Command 'promptStatus' }
                $script:GmPromptInputPaused = $true
                return
            }

            if ($elapsed % 60 -eq 0) {
                Write-Log "  Waiting for QTE effect receipts... (${elapsed}s)" -Color DarkGray
                Update-DaemonProcessingHeartbeat `
                    -TurnNumber $acceptedSourceTurn `
                    -ElapsedSeconds $elapsed
            }
        }

        Write-Log "  QTE effect receipt wait reached the configured timeout; dedicated authority remains pending." -Level "WARN" -Color Yellow
    }
    catch {
        Assert-GmNotDaemonReadFailure $_
        $script:ErrorCount++
        Write-Log "  QTE effect receipt dispatch error: $_" -Level "ERROR" -Color Red
    }
    finally {
        Write-DaemonStatus -Status "running" -Reason "qte_effect_resolution_processing_finished"
        $script:IsProcessing = $false
    }
}