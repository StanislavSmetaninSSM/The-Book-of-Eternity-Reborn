$ErrorActionPreference = 'Stop'
. '/workspace/The-Book-of-Eternity-Reborn-1559/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'; . '/workspace/The-Book-of-Eternity-Reborn-1559/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/The-Book-of-Eternity-Reborn-1559/TestResults/native-terminal/20e900c1a8a74fa5a6dfb4485939ae0e' -TestSupport '/workspace/The-Book-of-Eternity-Reborn-1559/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-relay-operational-helper-03ebbb931a7446e5a28c5ccb808f43ee/game_session'
$current = Read-BoeJson -RelativePath 'game_state/control/gm_prompt_delivery.json.neighbor'
if ($current.marker -cne 'owned-before') { throw 'Owned before-image prerequisite failed.' }
Write-Output 'GM1559_REAL_HELPER_READ_PREREQUISITE_COMPLETE'
Assert-BoeGmFilesModifiedEntries -FilesModified @('game_state/control/gm_prompt_delivery.json.neighbor')
Write-Output 'GM1559_REAL_HELPER_OPERATION_RETURNED'