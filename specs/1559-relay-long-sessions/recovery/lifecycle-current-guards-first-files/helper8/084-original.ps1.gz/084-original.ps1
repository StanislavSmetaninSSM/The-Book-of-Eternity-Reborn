$ErrorActionPreference = 'Stop'
. '/workspace/The-Book-of-Eternity-Reborn-1559/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-relay-operational-helper-54b102aa2ea543b9a44ca0da4c6498d5/game_session'
$current = Read-BoeJson -RelativePath 'game_state/control/gm_relay_apply_receipt.json.neighbor'
if ($current.marker -cne 'owned-before') { throw 'Owned before-image prerequisite failed.' }
Write-Output 'GM1559_REAL_HELPER_READ_PREREQUISITE_COMPLETE'
Assert-BoeGmFilesModifiedEntries -FilesModified @('game_state/control/gm_relay_apply_receipt.json.neighbor')
Write-Output 'GM1559_REAL_HELPER_OPERATION_RETURNED'