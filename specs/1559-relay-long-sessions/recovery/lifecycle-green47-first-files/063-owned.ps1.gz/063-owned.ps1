$ErrorActionPreference = 'Stop'
. '/workspace/The-Book-of-Eternity-Reborn-1559/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'; . '/workspace/The-Book-of-Eternity-Reborn-1559/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/The-Book-of-Eternity-Reborn-1559/TestResults/native-terminal/69ce742b57e24f9d8965dd0a7f367627' -TestSupport '/workspace/The-Book-of-Eternity-Reborn-1559/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-relay-operational-helper-f60b5d8bccb043748acd15c2c30783d9/game_session'
$current = Read-BoeJson -RelativePath 'game_state/control/gm_relay_apply_receipt.json'
if ($current.marker -cne 'owned-before') { throw 'Owned before-image prerequisite failed.' }
Write-Output 'GM1559_REAL_HELPER_READ_PREREQUISITE_COMPLETE'
Write-BoeJson -RelativePath 'game_state/control/gm_relay_apply_receipt.json' -Data ([ordered]@{ marker = 'gm-after' })
Write-Output 'GM1559_REAL_HELPER_OPERATION_RETURNED'