$ErrorActionPreference = 'Stop'
. '/workspace/The-Book-of-Eternity-Reborn-1559/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'; . '/workspace/The-Book-of-Eternity-Reborn-1559/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/The-Book-of-Eternity-Reborn-1559/TestResults/native-terminal/3caa946f53314f1a8aebe5022634c94c' -TestSupport '/workspace/The-Book-of-Eternity-Reborn-1559/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-relay-operational-helper-eb4f67a4d5c14044a2e70c4cc7c29f61/game_session'
$current = Read-BoeJson -RelativePath 'game_state/control/gm_prompt_delivery.json'
if ($current.marker -cne 'owned-before') { throw 'Owned before-image prerequisite failed.' }
Write-Output 'GM1559_REAL_HELPER_READ_PREREQUISITE_COMPLETE'
Assert-BoeGmFilesModifiedEntries -FilesModified @('game_state/control/gm_prompt_delivery.json')
Write-Output 'GM1559_REAL_HELPER_OPERATION_RETURNED'