$ErrorActionPreference = 'Stop'
. '/workspace/The-Book-of-Eternity-Reborn-1559/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'; . '/workspace/The-Book-of-Eternity-Reborn-1559/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/The-Book-of-Eternity-Reborn-1559/TestResults/native-terminal/d265a6805f74430fb55b2bb8db315854' -TestSupport '/workspace/The-Book-of-Eternity-Reborn-1559/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-relay-operational-helper-61c040b1bf01464d842d44281a7df360/game_session'
$current = Read-BoeJson -RelativePath 'game_state/control/gm_relay_apply_receipt.json.neighbor'
if ($current.marker -cne 'owned-before') { throw 'Owned before-image prerequisite failed.' }
Write-Output 'GM1559_REAL_HELPER_READ_PREREQUISITE_COMPLETE'
Write-BoeJson -RelativePath 'game_state/control/gm_relay_apply_receipt.json.neighbor' -Data ([ordered]@{ marker = 'gm-after' })
Write-Output 'GM1559_REAL_HELPER_OPERATION_RETURNED'