$ErrorActionPreference = 'Stop'
. '/workspace/The-Book-of-Eternity-Reborn-1559/BookOfEternityClient/Launcher/GM_Turn_Helper.ps1'; . '/workspace/The-Book-of-Eternity-Reborn-1559/tests/fixtures/GmTurnHelper/contract-bootstrap.ps1' -Folder '/workspace/The-Book-of-Eternity-Reborn-1559/TestResults/native-terminal/53d585f4fdb04489be96c92f453e3592' -TestSupport '/workspace/The-Book-of-Eternity-Reborn-1559/BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll'
Initialize-BoeGmTurnHelper -GameSessionPath '/tmp/boe-relay-operational-helper-ea95eb216da64d8fb007402a8e5cd0b3/game_session'
$current = Read-BoeJson -RelativePath 'game_state/control/gm_prompt_delivery.json.neighbor'
if ($current.marker -cne 'owned-before') { throw 'Owned before-image prerequisite failed.' }
Write-Output 'GM1559_REAL_HELPER_READ_PREREQUISITE_COMPLETE'
Write-BoeJson -RelativePath 'game_state/control/gm_prompt_delivery.json.neighbor' -Data ([ordered]@{ marker = 'gm-after' })
Write-Output 'GM1559_REAL_HELPER_OPERATION_RETURNED'