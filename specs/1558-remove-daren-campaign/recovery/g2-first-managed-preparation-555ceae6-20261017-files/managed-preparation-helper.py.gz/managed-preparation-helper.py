from pathlib import Path
import sys,subprocess,hashlib,json,datetime,time,re,tempfile,os,shutil
root=Path('/workspace/The-Book-of-Eternity-Reborn-1558')
mode,label,expected=sys.argv[1:4]
assert mode in {'catalog','plan'} and re.fullmatch(r'gm1558-g2-[a-z0-9-]+',label) and re.fullmatch(r'[a-f0-9]{40}',expected)
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==expected and not git('status','--porcelain')
bindingPath=root/'specs/1558-remove-daren-campaign/g2-implementation-source-packet-20261017.json';bindingBytes=bindingPath.read_bytes();binding=json.loads(bindingBytes)
for pin in binding['sourcePins']:assert hashlib.sha256((root/pin['path']).read_bytes()).hexdigest()==pin['sha256'],pin['path']
selection='tests/selections/1558-daren-retirement.json';assert (root/selection).read_bytes()==(root/'tests/selection.json').read_bytes()
ids=[x['category']for x in json.loads((root/selection).read_text())['selections']];assert len(ids)==len(set(ids))==17
out=Path('/tmp/gm1558-implementation-tools')/label;assert not out.exists();out.mkdir(parents=True)
paths=['BookOfEternityClient.Tests/bin/Debug/net8.0/BookOfEternityClient.dll','BookOfEternityClient.Tests/bin/Debug/net8.0/BookOfEternityClient.Tests.dll','BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.dll','BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.IntegrationTests.dll','BookOfEternityClient.Tests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll','BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/BookOfEternityClient.TestSupport.dll','BookOfEternityClient/bin/Debug/net8.0/BookOfEternityClient.dll']
def pin(p,base=root):
 b=p.read_bytes();return dict(path=str(p.relative_to(base)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def binaries():return [pin(root/p)for p in paths if (root/p).is_file()]
def inventory(directory):return [pin(p,directory)for p in sorted(directory.rglob('*'))if p.is_file()]if directory.exists()else[]
frontend=root/'BookOfEternityClient.WebFrontend';dist=frontend/'dist';before=binaries();distBefore=inventory(dist)
resultroot=root/'TestResults/test-categories';old=set(resultroot.iterdir())if resultroot.exists()else set()
prefixes=['boe-daren-retirement-*','boe-gameengine-turnlifecycle-*','boe-original-other-close-*','boe-browser-protocol-*','boe-gm1557-*']
def namespaces():return sorted(str(p)for pattern in prefixes for p in Path(tempfile.gettempdir()).glob(pattern))
namespaceBefore=namespaces();start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
marker=out.parent/(expected+'-g2-'+mode+'.first-launch.json')
with marker.open('x')as f:json.dump(dict(kind='FIRST_G2_PREPARATION_SENTINEL',mode=mode,sourceHead=expected,label=label,createdUtc=start,recordPath=str(out/'record.json')),f,indent=2)
ownedClean=None;previous=None
if mode=='frontend':
 assert len(sys.argv)==5
 setup=json.loads(Path(sys.argv[4]).read_text());assert setup['sourceHead']==expected and setup['nativeExit']==0 and setup['locksBefore']==setup['locksAfter'] and len(setup['installedLocalTools'])==2
 for tool in setup['installedLocalTools']:
  assert hashlib.sha256((root/tool['resolved']['path']).read_bytes()).hexdigest()==tool['resolved']['sha256']
 args=['npm','run','build'];cwd=frontend
else:
 assert len(sys.argv)==5;previous=json.loads(Path(sys.argv[4]).read_text());assert previous['nativeExit']==0
 if previous['sourceHead']!=expected:
  assert mode=='catalog' and previous['mode']=='frontend' and previous['sourceHead']=='110e7ac516789fb923adefde04997c04b4685ed7'
  tree=git('rev-parse',expected+':BookOfEternityClient.WebFrontend').decode().strip();assert tree==git('rev-parse',previous['sourceHead']+':BookOfEternityClient.WebFrontend').decode().strip()=='1ae60672f22452a8df57958215d32a371d2ae8c3'
  oldBinding=Path('/tmp/gm1558-g2-refined-r03-source-recovered-110e7ac5-20261017')/previous['sourceBindingPath'];assert hashlib.sha256(oldBinding.read_bytes()).hexdigest()==previous['sourceBindingSha256']
  for sourcePin in json.loads(oldBinding.read_text())['sourcePins']:
   if sourcePin['path'].startswith('BookOfEternityClient.WebFrontend/'):
    assert hashlib.sha256((root/sourcePin['path']).read_bytes()).hexdigest()==sourcePin['sha256']
  changed=git('diff','--name-only',previous['sourceHead'],expected).decode().splitlines();assert all(x=='BookOfEternityClient/Core/TrustedLocalFilePublication.Journal.cs' or x.startswith('specs/1558-remove-daren-campaign/')for x in changed),changed
 args=['pwsh','-NoLogo','-NoProfile','-File','scripts/test-csharp.ps1'];cwd=root
 if mode=='catalog':
  assert previous['mode']=='frontend' and previous['distAfter']==distBefore and distBefore
  readers=[]
  for p in Path('/proc').iterdir():
   if not p.name.isdigit():continue
   try:
    command=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace');exe=Path(os.readlink(p/'exe')).name;pcwd=os.readlink(p/'cwd')
    if exe in {'dotnet','pwsh','testhost','node','chromium'} and (str(root) in command or pcwd.startswith(str(root))):readers.append(dict(pid=int(p.name),executable=exe,cwd=pcwd,command=command))
   except(FileNotFoundError,ProcessLookupError,PermissionError):pass
  assert not readers,readers
  cleaned=[]
  for project in ['BookOfEternityClient','BookOfEternityClient.Tests','BookOfEternityClient.IntegrationTests','BookOfEternityClient.TestSupport']:
   directory=root/project/'bin/Debug/net8.0';assert directory.parent.parent.parent==root/project and not directory.is_symlink()
   if directory.exists():
    assert directory.resolve()==directory;oldInventory=inventory(directory);shutil.rmtree(directory);assert not directory.exists();cleaned.append(dict(path=str(directory.relative_to(root)),oldFileCount=len(oldInventory),oldManifestSha256=hashlib.sha256(json.dumps(oldInventory,sort_keys=True).encode()).hexdigest()))
  ownedClean=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),readerCensus=readers,oldSevenPins=before,deletedOwnedGeneratedOutputs=cleaned,scope='ONLY four exact generated own1558 bin/Debug/net8.0 directories; prior raw/TestData/diagnostics/userdata/otherworktrees untouched')
  (out/'owned-output-clean.json').write_text(json.dumps(ownedClean,indent=2)+'\n');args+=['-ValidateCatalog']
 else:
  assert previous['mode']=='catalog' and previous['binaryAfter']==before and len(before)==7
  args+=['-SelectionFile',selection,'-PlanOnly','-NoBuild']
print('FIRST_G2_PREPARATION_START',mode,expected,'stdout',out/'stdout.log',flush=True)
with (out/'stdout.log').open('wb')as stream:
 process=subprocess.Popen(args,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT)
 (out/'process.json').write_text(json.dumps(dict(pid=process.pid,argv=args,cwd=str(cwd),startedUtc=start),indent=2)+'\n');native=process.wait()
elapsed=time.monotonic()-clock;after=binaries();distAfter=inventory(dist)
new=sorted(str(p)for p in set(resultroot.iterdir())-old)if resultroot.exists()else[]
j=dict(kind='FIRST_G2_MANAGED_PREPARATION_WITH_RETAINED_EXACT_FRONTEND_110E',mode=mode,label=label,argv=args,cwd=str(cwd),sourceHead=expected,compiledSource=expected if mode!='frontend'else'PRIOR_COMPILED_BASELINE_NOT_REBUILT',productSource=expected,sourceBindingPath=str(bindingPath.relative_to(root)),sourceBindingSha256=hashlib.sha256(bindingBytes).hexdigest(),sourcePinCount=len(binding['sourcePins']),startedUtc=start,finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),wallSeconds=elapsed,nativeExit=native,stdoutPath=str(out/'stdout.log'),stdoutSha256=hashlib.sha256((out/'stdout.log').read_bytes()).hexdigest(),resultDirectories=new,binaryBefore=before,binaryAfter=after,distBefore=distBefore,distAfter=distAfter,ownedOutputCleanRecord=str(out/'owned-output-clean.json')if ownedClean else None,headAfter=git('rev-parse','HEAD').decode().strip(),statusAfter=git('status','--porcelain').decode(),ownedPrefixesBefore=namespaceBefore,ownedPrefixesAfter=namespaces(),firstLaunchSentinel=str(marker),helperText=Path(__file__).read_text(),runtimeScope='ZERO actual test/host/browser/producer/game execution; frontend app+node compiler/bundle or managed BOTH/catalog discovery or exact current GREEN PlanOnly0',previousRecord=sys.argv[4],originalFrontendFailure='specs/1558-remove-daren-campaign/recovery/g2-first-frontend-preparation-stop-ce7cf012-20261017.json',dependencySetupRecord=sys.argv[4]if mode=='frontend'else previous.get('dependencySetupRecord'))
(out/'record.json').write_text(json.dumps(j,indent=2)+'\n');print('FIRST_G2_PREPARATION_EXIT',native,'wall',round(elapsed,3),'record',out/'record.json','results',new,flush=True)
assert j['headAfter']==expected and not j['statusAfter'] and namespaceBefore==j['ownedPrefixesAfter']
for sourcePin in binding['sourcePins']:assert hashlib.sha256((root/sourcePin['path']).read_bytes()).hexdigest()==sourcePin['sha256'],sourcePin['path']
if mode=='frontend' and native==0:assert distAfter and any(p['path']=='index.html'for p in distAfter)and before==after
if mode!='frontend'and native==0:assert len(after)==7 and distBefore==distAfter
if mode=='plan':assert before==after
sys.exit(native)
