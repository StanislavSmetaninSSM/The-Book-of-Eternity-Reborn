from pathlib import Path
import sys,subprocess,json,hashlib,datetime,time,re
root=Path('/workspace/The-Book-of-Eternity-Reborn-1558');frontend=root/'BookOfEternityClient.WebFrontend';label,expected=sys.argv[1:];assert re.fullmatch(r'gm1558-g2-locked-setup-first-[a-z0-9-]+',label)and re.fullmatch('[0-9a-f]{40}',expected)
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==expected and not git('status','--porcelain')
assert not (frontend/'node_modules').exists() and not (frontend/'node_modules').is_symlink()
binding=json.loads((root/'specs/1558-remove-daren-campaign/g2-implementation-source-packet-20261017.json').read_text())
for pin in binding['sourcePins']:assert hashlib.sha256((root/pin['path']).read_bytes()).hexdigest()==pin['sha256'],pin['path']
def one(path):
 b=path.read_bytes();return dict(path=str(path.relative_to(root)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
locks=[one(frontend/p)for p in ['package.json','package-lock.json']]
out=Path('/tmp/gm1558-implementation-tools')/label;assert not out.exists();out.mkdir(parents=True)
start=datetime.datetime.now(datetime.timezone.utc).isoformat();marker=out.parent/(expected+'-g2-owned-locked-dependency-setup.first-launch.json')
with marker.open('x')as f:json.dump(dict(sourceHead=expected,label=label,startedUtc=start,recordPath=str(out/'record.json')),f,indent=2)
versions={tool:subprocess.check_output([tool,'--version'],cwd=frontend,text=True).strip()for tool in ['node','npm']};args=['npm','ci','--include=dev','--no-audit','--no-fund','--cache','/tmp/gm1558-npm-cache-20261017'];clock=time.monotonic();print('FIRST_OWNED_LOCKED_SETUP_START',expected,'stdout',out/'stdout.log',flush=True)
with (out/'stdout.log').open('wb')as log:
 p=subprocess.Popen(args,cwd=frontend,stdout=log,stderr=subprocess.STDOUT);(out/'process.json').write_text(json.dumps(dict(pid=p.pid,argv=args,cwd=str(frontend),startedUtc=start),indent=2)+'\n');code=p.wait()
installed=[]
if code==0:
 assert not (frontend/'node_modules').is_symlink()
 for name,command in [('tsc',['--version']),('vite',['--version'])]:
  local=frontend/'node_modules/.bin'/name;assert local.is_file();target=local.resolve();assert target.is_relative_to(frontend/'node_modules');result=subprocess.run([str(local),*command],cwd=frontend,capture_output=True,text=True);installed.append(dict(binary=str(local.relative_to(root)),resolved=one(target),exit=result.returncode,versionStdout=result.stdout,versionStderr=result.stderr));assert result.returncode==0
j=dict(kind='FIRST_OWN_LOCKFILE_DEPENDENCY_SETUP_NOT_APP_RUNTIME',sourceHead=expected,label=label,argv=args,cwd=str(frontend),startedUtc=start,finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),wallSeconds=time.monotonic()-clock,nativeExit=code,toolVersions=versions,locksBefore=locks,locksAfter=[one(frontend/p)for p in ['package.json','package-lock.json']],installedLocalTools=installed,stdoutPath=str(out/'stdout.log'),stdoutSha256=hashlib.sha256((out/'stdout.log').read_bytes()).hexdigest(),originalFailure='specs/1558-remove-daren-campaign/recovery/g2-first-frontend-preparation-stop-ce7cf012-20261017.json',firstLaunchSentinel=str(marker),headAfter=git('rev-parse','HEAD').decode().strip(),statusAfter=git('status','--porcelain').decode(),helperText=Path(__file__).read_text())
(out/'record.json').write_text(json.dumps(j,indent=2)+'\n');print('FIRST_OWNED_LOCKED_SETUP_EXIT',code,'wall',round(j['wallSeconds'],3),'record',out/'record.json',flush=True);assert locks==j['locksAfter']and j['headAfter']==expected and not j['statusAfter'];sys.exit(code)
