"""FIRST E01 selected managed build/discovery PlanOnly; zero actual tests.
Retain exact successful frontend110/dist113. No catalog, npm, cleanup or runtime.
"""
from pathlib import Path
import sys,json,subprocess,hashlib,datetime,time,re,tempfile,os
R=Path('/workspace/The-Book-of-Eternity-Reborn-1558');FEATURE='specs/1558-remove-daren-campaign/';BIND=FEATURE+'g2-implementation-source-packet-20261017.json'
OLD='555ceae66e10300d3cf76ff849fb110b79b15549';FE='110e7ac516789fb923adefde04997c04b4685ed7';TREE='1ae60672f22452a8df57958215d32a371d2ae8c3'
PRIOR=Path('/tmp/gm1558-implementation-tools/gm1558-g2-catalog-first-555ceae6-20261017t1100z/fresh-package-frontend-docs-manifest.json')
def sha(b):return hashlib.sha256(b).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
def pin(p,base=R):
 b=p.read_bytes();return dict(path=str(p.relative_to(base)),bytes=len(b),sha256=sha(b))
def inv(base):return [pin(p,base)for p in sorted(base.rglob('*'))if p.is_file()]
def ns():return sorted(str(p)for p in Path(tempfile.gettempdir()).glob('boe-*'))
def identity(pid):
 try:
  a=(Path('/proc')/str(pid)/'stat').read_text();at=a[a.rfind(')')+2:].split();args=(Path('/proc')/str(pid)/'cmdline').read_bytes().split(b'\0');b=(Path('/proc')/str(pid)/'stat').read_text();bt=b[b.rfind(')')+2:].split();assert at[19]==bt[19]
  return dict(pid=pid,birthTicks=int(bt[19]),state=bt[0],parentPid=int(bt[1]),argv=[x.decode(errors='replace')for x in args if x],status='EXACT_STAT_CMDLINE_STAT')
 except FileNotFoundError:return dict(pid=pid,status='ABSENT')
assert len(sys.argv)==3
label,expected=sys.argv[1:];assert re.fullmatch(r'gm1558-g2-e01-plan-first-[a-z0-9-]+',label)and re.fullmatch(r'[a-f0-9]{40}',expected)
assert git('rev-parse','HEAD').decode().strip()==expected and not git('status','--porcelain')
assert git('branch','--show-current').decode().strip()=='1558-remove-daren-campaign-20261017'
changed=git('diff','--no-renames','--name-only','db749e462e88edbdc0690f57e68efefa0078e262',expected).decode().splitlines();assert all(p== 'BookOfEternityClient.IntegrationTests/FastBoundaryTestInventories.cs'or p.startswith(FEATURE)for p in changed)
bindingBytes=(R/BIND).read_bytes();binding=json.loads(bindingBytes);assert len(binding['sourcePins'])==274
sourceDigest=sha(json.dumps(binding['sourcePins'],sort_keys=True,separators=(',',':')).encode());assert sourceDigest=='7d3d498b298a5f2ec97efac5782cfebdc9c8e9eed1e7f31ac44bf8b0be0be55f'
for p in binding['sourcePins']:assert sha((R/p['path']).read_bytes())==p['sha256'],p['path']
assert git('rev-parse',expected+':BookOfEternityClient.WebFrontend').decode().strip()==TREE
old=json.loads(PRIOR.read_text());assert sha(PRIOR.read_bytes())=='2ffbfa7a1b248ec4975d460e396b392f68feec81f0bda1fbba5bc3eb98a1a892'
dist=R/'BookOfEternityClient.WebFrontend/dist';distBefore=inv(dist);assert distBefore==old['distFiles']and len(distBefore)==113
assert (R/'tests/selection.json').read_bytes()==(R/'tests/selections/1558-daren-retirement.json').read_bytes()
previous=json.loads(Path('/tmp/gm1558-implementation-tools/gm1558-g2-catalog-first-555ceae6-20261017t1100z/record.json').read_text());paths=[p['path']for p in previous['binaryAfter']]
def bins():return [pin(R/p)for p in paths]
before=bins();assert before==previous['binaryAfter']and len(before)==7
out=Path('/tmp/gm1558-implementation-tools')/label;assert not out.exists();out.mkdir(parents=True)
(out/'source-binding-before.json').write_bytes(bindingBytes)
marker=out.parent/(expected+'-g2-e01-build-plan.first-launch.json');started=utc()
with marker.open('x')as stream:json.dump(dict(kind='FIRST_E01_SELECTED_BUILD_PLANONLY_SENTINEL',actualSource=expected,label=label,createdUtc=started,recordPath=str(out/'record.json')),stream,indent=2)
args=['pwsh','-NoLogo','-NoProfile','-File','scripts/test-csharp.ps1','-SelectionFile','tests/selection.json','-PlanOnly'];results=R/'TestResults/test-categories';existing=set(results.iterdir())if results.exists()else set();nsBefore=ns();clock=time.monotonic();error=None;native=None;proc=None
print('FIRST_E01_PLAN_BUILD_START',expected,'stdout',out/'stdout.log',flush=True)
try:
 with (out/'stdout.log').open('wb')as log:
  proc=subprocess.Popen(args,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);launched=identity(proc.pid);(out/'process.json').write_text(json.dumps(dict(pid=proc.pid,identity=launched,argv=args,startedUtc=started),indent=2)+'\n');native=proc.wait()
except BaseException as failure:error=repr(failure)
new=sorted(str(p)for p in set(results.iterdir())-existing)if results.exists()else[];after=bins();distAfter=inv(dist)
j=dict(kind='FIRST_E01_MANAGED_BUILD_DISCOVERY_PLANONLY_ZEROEXEC_RAW',mode='build-plan',label=label,argv=args,cwd=str(R),actualSource=expected,sourceHead=expected,compiledSource=expected,productSource=expected,previousCompiledSource=OLD,retainedFrontendSource=FE,frontendGitTree=TREE,sourceBindingPath=BIND,sourceBindingSha256=sha(bindingBytes),sourcePinCount=274,sourcePinsDigest=sourceDigest,startedUtc=started,finishedUtc=utc(),wallSeconds=time.monotonic()-clock,nativeExit=native,launchError=error,nativeProcessSettled=bool(proc and proc.poll()is not None),nativeProcessIdentityAfterWait=identity(proc.pid)if proc else None,stdoutPath=str(out/'stdout.log'),stdoutSha256=sha((out/'stdout.log').read_bytes()),resultDirectories=new,binaryBefore=before,binaryAfter=after,distBefore=distBefore,distAfter=distAfter,headAfter=git('rev-parse','HEAD').decode().strip(),statusAfter=git('status','--porcelain').decode(),ownedPrefixesBefore=nsBefore,ownedPrefixesAfter=ns(),firstLaunchSentinel=str(marker),helperText=Path(__file__).read_text(),firstActualFailure='recovery/g2-first-green-stop-d09b18c9-20261017.json',scope='ONE canonical current SelectionFile PlanOnly WITHOUT NoBuild; fresh selected both managed builds/discovery zero tests; retain110 frontend113. No ValidateCatalog/npm/frontend replay/bin clean/actual/provider/browser.')
(out/'record.json').write_text(json.dumps(j,indent=2)+'\n');print('FIRST_E01_PLAN_BUILD_EXIT',native,'wall',round(j['wallSeconds'],3),'record',out/'record.json','results',new,flush=True)
if error:raise RuntimeError(error)
assert j['headAfter']==expected and not j['statusAfter']and nsBefore==j['ownedPrefixesAfter']and distAfter==distBefore and len(after)==7
for p in binding['sourcePins']:assert sha((R/p['path']).read_bytes())==p['sha256'],p['path']
sys.exit(native)
