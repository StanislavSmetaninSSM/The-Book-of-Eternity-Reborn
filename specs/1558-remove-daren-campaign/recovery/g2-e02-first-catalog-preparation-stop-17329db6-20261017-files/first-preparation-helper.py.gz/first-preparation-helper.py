"""Distinct FIRST E02 frontend/build/catalog/full/remaining PlanOnly recorder. ZERO tests."""
from pathlib import Path
import json,hashlib,subprocess,sys,re,datetime,time,tempfile
R=Path('/workspace/The-Book-of-Eternity-Reborn-1558');BIND='specs/1558-remove-daren-campaign/g2-implementation-source-packet-20261017.json';SOURCE_DIGEST='b9264d21b9f5592275efd672651188d58dc4f0ac40e484ad2f2920d6080e8fd9'
def h(b):return hashlib.sha256(b).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
def pin(p,base=R):
 b=p.read_bytes();return dict(path=str(p.relative_to(base)),bytes=len(b),sha256=h(b))
def inv(base):return [pin(p,base)for p in sorted(base.rglob('*'))if p.is_file()]
def ns():return sorted(str(p)for p in Path(tempfile.gettempdir()).glob('boe-*'))
mode,label,expected=sys.argv[1:4];assert mode in {'frontend','catalog','full-plan','remaining-plan'}and re.fullmatch(r'gm1558-g2-e02-[a-z0-9-]+',label)and re.fullmatch(r'[a-f0-9]{40}',expected)
assert git('rev-parse','HEAD').decode().strip()==expected and not git('status','--porcelain')
bindingBytes=(R/BIND).read_bytes();binding=json.loads(bindingBytes);assert len(binding['sourcePins'])==277 and h(json.dumps(binding['sourcePins'],sort_keys=True,separators=(',',':')).encode())==SOURCE_DIGEST
for p in binding['sourcePins']:assert h((R/p['path']).read_bytes())==p['sha256'],p['path']
assert (R/'tests/selection.json').read_bytes()==(R/'tests/selections/1558-daren-retirement.json').read_bytes()
paths=[p['path']for p in binding['sevenFreshBinaries']]
def binaries():return [pin(R/p)for p in paths]
before=binaries();assert len(before)==7
out=Path('/tmp/gm1558-implementation-tools')/label;assert not out.exists();out.mkdir(parents=True);(out/'source-binding-before.json').write_bytes(bindingBytes)
frontend=R/'BookOfEternityClient.WebFrontend';dist=frontend/'dist';distBefore=inv(dist);previous=None
if mode=='frontend':
 assert len(sys.argv)==4 and before==binding['sevenFreshBinaries'];args=['npm','run','build'];cwd=frontend
 assert (frontend/'node_modules/.bin/tsc').exists()and(frontend/'node_modules/.bin/vite').exists()
else:
 assert len(sys.argv)==5;previous=json.loads(Path(sys.argv[4]).read_text());assert previous['sourceHead']==expected and previous['nativeExit']==0 and previous['nativeProcessSettled']and before==previous['binaryAfter']and previous['distAfter']==distBefore
 args=['pwsh','-NoLogo','-NoProfile','-File','scripts/test-csharp.ps1'];cwd=R
 if mode=='catalog':assert previous['mode']=='frontend';args+=['-ValidateCatalog']
 elif mode=='full-plan':assert previous['mode']=='catalog';args+=['-SelectionFile','tests/selection.json','-PlanOnly','-NoBuild']
 else:assert previous['mode']=='full-plan';args+=['-SelectionFile','tests/selections/1558-daren-retirement-remaining-green.json','-PlanOnly','-NoBuild']
start=utc();marker=out.parent/(expected+'-g2-e02-'+mode+'.first-launch.json')
with marker.open('x')as stream:json.dump(dict(kind='FIRST_E02_ZEROEXEC_PREPARATION_SENTINEL',sourceHead=expected,mode=mode,label=label,recordPath=str(out/'record.json'),createdUtc=start),stream,indent=2)
results=R/'TestResults/test-categories';old=set(results.iterdir())if results.exists()else set();namespaceBefore=ns();clock=time.monotonic();native=None;error=None;process=None
print('FIRST_E02_PREPARATION_START',mode,expected,'stdout',out/'stdout.log',flush=True)
try:
 with (out/'stdout.log').open('wb')as stream:
  process=subprocess.Popen(args,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);(out/'process.json').write_text(json.dumps(dict(pid=process.pid,argv=args,cwd=str(cwd),startedUtc=start),indent=2)+'\n');native=process.wait()
except BaseException as failure:error=repr(failure)
new=sorted(str(p)for p in set(results.iterdir())-old)if results.exists()else[];after=binaries();distAfter=inv(dist)
j=dict(kind='FIRST_E02_FRONTEND_SELECTED_BUILD_CATALOG_PLANS_ZEROEXEC_RAW',mode=mode,label=label,argv=args,cwd=str(cwd),sourceHead=expected,actualSource=expected,compiledSource=expected if mode!='frontend'else'f07643a8bf611391caffb5bf21afe2ea1b4db88f',frontendSource=expected,frontendGitTree=git('rev-parse',expected+':BookOfEternityClient.WebFrontend').decode().strip(),sourceBindingPath=BIND,sourceBindingSha256=h(bindingBytes),sourcePinCount=277,sourcePinsDigest=SOURCE_DIGEST,startedUtc=start,finishedUtc=utc(),wallSeconds=time.monotonic()-clock,nativeExit=native,launchError=error,nativeProcessSettled=bool(process and process.poll()is not None),stdoutPath=str(out/'stdout.log'),stdoutSha256=h((out/'stdout.log').read_bytes()),resultDirectories=new,binaryBefore=before,binaryAfter=after,distBefore=distBefore,distAfter=distAfter,headAfter=git('rev-parse','HEAD').decode().strip(),statusAfter=git('status','--porcelain').decode(),ownedPrefixesBefore=namespaceBefore,ownedPrefixesAfter=ns(),firstLaunchSentinel=str(marker),previousRecord=sys.argv[4]if previous else None,helperText=Path(__file__).read_text(),scope='ONE distinct authorized FIRST stage. npm app/node+Vite or managed BOTH/catalog discovery or exact full/remaining PlanOnly-NoBuild; ZERO tests/host/producer/browser. No npmci/version change/bin cleanup/retry. Original failures immutable.')
(out/'record.json').write_text(json.dumps(j,indent=2)+'\n');print('FIRST_E02_PREPARATION_EXIT',mode,native,'wall',round(j['wallSeconds'],3),'record',out/'record.json','results',new,flush=True)
if error:raise RuntimeError(error)
assert j['headAfter']==expected and not j['statusAfter']and namespaceBefore==j['ownedPrefixesAfter']
for p in binding['sourcePins']:assert h((R/p['path']).read_bytes())==p['sha256'],p['path']
if native==0:
 assert len(after)==7
 if mode=='frontend':assert before==after and distAfter and any(x['path']=='index.html'for x in distAfter)
 else:assert distAfter==distBefore
 if mode.endswith('-plan'):assert before==after
sys.exit(native)
