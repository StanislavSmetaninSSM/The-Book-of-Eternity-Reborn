# FR063 pending duplicate pair: genuine-wave seam review

Read-only architecture finding following accepted remainder evidence `2f670f4fd33c726520808c1dc0bb7269163c8338`, recorded at `ed0d1880e5f732c71a2a4929135391eb4565ae81`. No repository edits, Git operations, project execution, provider calls or new agents were performed. The separate capture-fixture writer was not changed or reviewed here.

**Ruling: the two pending-duplicate rows remain BLOCKED as a responsibility/fixture mismatch. There is no lawful drop-in nonempty repair-wave seam under the unchanged original-42 guaranteed-treatment fixture and its current ordinary admission contract.** Do not synthesize a packet, amend the original, relax a parser, remove the rows or call them production regressions. The original 15-case qualification remains OPEN.

The seven capture-affected cases and four previously unrun cases are independent and may proceed only after their actual source/selection gate. This report grants no runtime release.

## Why the current fixture cannot issue that wave

1. `CreateHeldTreatmentPipelineContextAsync` seeds the canonical wound and sources before real `PrepareAsync` and the original-42 rollback snapshot (`MortalWoundTreatmentResourcePublicationLifecycleTests.cs:3029–3085`). The occurrence baseline is explicitly `{schemaVersion:1, occurrences:[]}` at lines4112–4116. The established canonical wound is a documented bootstrap precondition; its existence does not issue a new harm opportunity.

2. The helper then uses the actual accepted-state export, `PrepareGuaranteedRequest`, `CreateGuaranteedAttempt`, strict command parsing/recomposition and `StateDistributor` (`LifecycleTests.cs:3111–3177`). `StateDistributor.cs:163–181,303–360` writes the full treatment command and confirms its held resources. It does not create a wound-repair pending file. The native null read at OrdinaryOwner.cs:24 is therefore consistent with the intended producer path.

3. `MortalWoundTreatmentPersistedRequestCatalog.Parse` accepts a missing pending root and recovers the request from the command (`MortalWoundTreatmentPersistence.cs:104–226`). But once `submittedTreatmentRequests` exists, its parser requires a valid bound repair wave (`:287–301`). `WoundRepairPacketBuilder.PersistenceValidation.cs:50–65` requires one or more packets and equal receipt count; packet/receipt/root identities and complete closed shapes must agree. `ComposePendingRoot` deliberately copies submitted treatment requests only for a nonempty wave (`MortalWoundTreatmentPersistence.cs:2701–2786`). Calling it with empty packets, then adding a request, is invalid.

4. The genuine issue-to-packet path is `WoundResponseInputComposer.AttachRepairContexts` / `TryBuildRepairIssue` (`:530–745`) followed by `WoundRepairPacketBuilder.Build(issues)` (`WoundRepairPacketBuilder.cs:501–604`). The issue projector requires a public materialize decision and exactly one matching `WoundOpportunityAuthority`. It binds the original tuple, opportunity authority, rejected proposal and scene into the private context. A treatment command or an existing canonical wound is not such an opportunity. Guaranteed-treatment refusals in `GameEngine.MortalGuaranteedTreatment.cs` are ordinary validation issues; they do not issue this private context. Recomposition of a treatment command deliberately returns an empty opportunity list (`WoundResponseInputComposer.CommandParsing.cs:325–339`).

5. The real current Mortal opportunity adapter obtains opportunities from the official signed occurrence projection. With the fixture's empty occurrence set, no draft means no opportunity, and an unsolicited materialize draft is refused before a repair opportunity exists (`MortalWoundOpportunityAdapter.cs:44–94`). Changing display fields, scene or treatment requirements cannot turn those diagnostics into genuine acquisition-repair authority.

6. Adding a real QTE occurrence before signing a different original would be a new scenario, not a correction preserving this original. More decisively, this first guaranteed-treatment contour explicitly refuses any unconsumed signed wound occurrence at `ValidationService.ResourceMaterialization.cs:533–537`. It also rejects concurrent resource/effect/party/system work and changed owner images (`:503–558`), and its mechanical-envelope guard refuses any current QTE decision draft (`GameEngine.MortalGuaranteedTreatment.cs:128–143`). Removing the draft after obtaining a packet does not remove the signed occurrence or this refusal. Consuming the occurrence first changes canonical history/receipts and requires a new legitimate turn/request; its earlier packet cannot simply be rebound to the unchanged original-42 treatment request.

These are source-backed limits of the current fixture and admitted contour, not a claim that no future supported combined owner could exist.

## Older persistence fixtures are not the missing provenance

`MortalWoundTreatmentResolverTests.Persistence.cs:2172–2212` builds a real typed repair packet from a rejected proposal. However, its prerequisite helper at `:2216–2267` explicitly constructs a new narrative event/evidence, accepted-event set, binding and opportunity with fixed test identifiers. It preserves the supplied session/request/token while replacing the event authority. That is suitable to its declared lower-level fixture scope; transplanting it here would violate the requested genuine original/source requirement.

The same file explicitly protects the nonempty-wave rule in `PersistedPending_RejectsSubmittedTreatmentWithoutARepairWave` (`:1420`) and `RepairPending_DoesNotCopySubmittedTreatmentWithoutANonEmptyRepairWave` (`:1699`). Its exact command/pending coalescing and divergence cases exercise `MortalWoundTreatmentPersistedRequestCatalog`, including complete graph equality. Those source tests are relevant contract evidence, not new executed coverage in this review and not proof of ordinary production issuance.

## Correct owning boundaries and a practical future fixture

There are three separate responsibilities:

- **Live materialization repair authority:** the genuine QTE occurrence/decision owner. Existing `PrepareMortalDecisionComponentAsync` (`QtePhysicalInjuryConsumerControls.cs:338–374`) produces actual QTE N42 harm/occurrence and stages real signed N43. Its semantic bounds control (`:270–286`) obtains an actionable context from an actual rejected proposal through `ValidateResourceAndMortalQteDecisionAsync`. The full MAIN-GM repair fixture additionally proves live packet dispatch and bounded correction. This is the supported genuine opportunity-to-context/packet seam.
- **Private pending representation and graph recovery:** `WoundRepairPacketBuilder.ComposePendingRoot`, `MortalWoundTreatmentPersistedRequestCatalog.Parse/Coalesce`, and `MortalWoundTreatmentAcceptedStateAuthority.RestorePersistedTreatmentRequests` (`:881–925`). They accept complete, correctly bound representations; they do not create an opportunity merely because a treatment hold exists.
- **Ordinary guaranteed publication:** the new admitted-owner bridge. It supports the proved-empty concurrent contour and the full command-held request. It must not be expanded merely to satisfy an incompatible fixture.

The actual MAIN-GM dispatcher builds public packets and writes `validation_repair_request.json` (`GameEngine.ValidationAndRepair.cs:3930–4025`); its retry capture requires the real rejected QTE input or a matching opportunity command (`:1906–1941`). A treatment-only command has no `parsed.Commands` opportunity entry. A source search found no production call to `ComposePendingRoot` beyond its definition. Consequently, running a genuine public repair loop must not be assumed to publish the separate private pending root.

A future **genuine lower-level pending persistence test**, if separately selected and authorized, would need this explicit footprint:

1. One owned physical root with a treatable canonical wound/provider/resources established before the original, plus real earlier QTE harm producing the occurrence. Do not import another fixture's source, receipt, snapshot or packet.
2. One official next-turn original and matching current generation; issue the full guaranteed treatment request through the existing accepted-state/prepare/resolution/distribution APIs under that exact tuple. Whether that lower-level export can lawfully coexist with the real unconsumed occurrence must be source-proved before implementation; this report does not assume it.
3. Under that same original, submit one otherwise-lawful materialize proposal with a bounded semantic defect. Obtain the actual adapter-issued opportunity and issue context, then build the packet and matching receipt through their existing APIs. Prove source/tuple/generation identity and that the packet excludes private treatment authority.
4. Use `ComposePendingRoot` with that actual nonempty packet wave and the actual parsed treatment command. Validate the complete command/pending/history catalog, then exercise exact-copy coalescing versus a changed copied graph. Preserve the original fingerprints, confirmed hold and canonical state. This is an explicitly component-level persistence assertion, not ordinary acceptance.
5. If the requested assertion is instead **actual ordinary publication with both treatment and unresolved wound-repair work**, that needs a supported combined owner and a real private-pending publication path. Those capabilities are not established by the current contour. They require separate concrete design/source work; neither invoking the private treatment callback directly nor clearing the QTE input establishes them.

No existing single helper currently supplies all five steps. The existing QTE repair controls supply step3's genuine source seam; the treatment helper supplies its own separate request path. Combining their outputs across roots or changing just the tuple is forbidden. A future public packet from an earlier request cannot authorize pending persistence under a different request.

**Immediate disposition:** retain the two original failed rows and their unqualified responsibility explicitly in the ledger. Do not rename a missing-pending success or empty-wave refusal as exact-pending coalescing coverage. Do not change the production parser, guaranteed producer, current admission guards or common publisher. Progress the independently corrected seven capture cases plus four unrun cases after SOURCE approval; preserve the passing native and post-seal evidence.

## Source pins

The following current bytes were read. Entries marked `frozen` match the already-frozen runtime-2d source-pin artifact; additional dependencies were read and hashed here, without project or Git execution.

| Path under repository | Bytes | SHA-256 | Provenance |
|---|---:|---|---|
| BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.cs | 311741 | 06a3377ad0f0574e6d6bb501c446719b03998fda628082a54a90526534f6cee7 | frozen |
| BookOfEternityClient/Services/MortalWoundTreatmentPersistence.cs | 116697 | ca7b36dd5904e02d42de25b365d0fea597e9c7eee3651960d0e32184682070ef | frozen |
| BookOfEternityClient/Services/WoundRepairPacketBuilder.PersistenceValidation.cs | 19426 | 358fcaa3bf9dbdbaffae7cd8d1d4cf9d39e579efdb0a9d5cbb444df5960ad68c | additional |
| BookOfEternityClient/Services/WoundRepairPacketBuilder.cs | 44141 | 4d4b0eb287207011edf9596ae6af2afd4ff7e8f7ee3d7a2889b95f6315c77fdd | frozen |
| BookOfEternityClient/Services/WoundResponseInputComposer.cs | 44094 | 7504daf4fcdff24f69cfec60c991f565fd47bb1727fc0dfc0cb04f3bbabb8b77 | frozen |
| BookOfEternityClient/Services/WoundResponseInputComposer.CommandParsing.cs | 38961 | e63bc86dddb3f83481e703fa58d27bee89f54c88a1d03460c60adcf3dd129ac4 | additional |
| BookOfEternityClient/Core/GameEngine/GameEngine.MortalGuaranteedTreatment.cs | 13560 | fdacf8c145a10b9be5f09f1fde28415969d740e6526c84ab4097d4e9093b4642 | frozen |
| BookOfEternityClient/Services/Validation/ValidationService.ResourceMaterialization.cs | 95821 | 560f146d8210f8347f53f53196054c42ba9406f92cd6ef073b30aa17fb2c7b83 | frozen |
| BookOfEternityClient/Core/GameEngine/GameEngine.MortalQteWoundDecision.cs | 22195 | 7a581df7c052ecee9c4f6943089941a9a5ac957810065890f116b356a743992b | frozen |
| BookOfEternityClient/Core/GameEngine/GameEngine.ValidationAndRepair.cs | 496318 | c967865961aa37163c6460617f6d268c3ff6ed824ae759c9900cd1f3095dde81 | frozen |
| BookOfEternityClient/Services/MortalWoundOpportunityAdapter.cs | 60717 | f0d6124471d259e5ed3007e5b8075d2aa182ca6959424ac39af6dfc73f62018f | frozen |
| BookOfEternityClient/IO/StateDistributor.cs | 33511 | 0ceecfb1f5d517673504e413f138bad5593065791f1f85a222238c7f19a3893d | frozen |
| BookOfEternityClient/Services/MortalWoundTreatmentAcceptedStateAuthority.cs | 96631 | 2c02b391f1cef80e115bc66f2d0c2ada92bc3d694403912bee47b9beb556f535 | frozen |
| BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResolverTests.Persistence.cs | 128889 | 699f85b214e597fcbf46f3861ca19c0ea18ca037dfb8335e31701bdb3a066a18 | additional |
| BookOfEternityClient.IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryConsumerControls.cs | 32833 | 9c7d2f6623b9d194f831350c8d47c3f63c780c0ee8c1d520c580dcd78930f66d | frozen |

FINAL STOPPED.
