# FR063 private capture7 fixture correction

Base verified remote: ed0d1880e5f732c71a2a4929135391eb4565ae81.
Primary: /workspace/1553-storage-migration-cloud-20261008-recovery-61d3a7f.
Tracked #1536/FR063; Linux only, sole source writer retained Sol.

Read requirements first: this brief; actual accepted EVIDENCE at
specs/1536-complete-wound-materialization/recovery/fr063-controls-first-outcome-evidence-review-20261013.md;
your readonly diagnosis /workspace/boe-cloud-tools-20261013/fr063-controls-fixture-failures-readonly-diagnosis.md.

Implement ONLY bounded TEST fixtures/catalog/new exact task selection plus the
dated active plan/tasks entry. No build/test/project/diagnostic/fault execution.
No production/shared old helpers/qualified native/protected QTE change. No agents,
provider calls, main/CI/PR/issues operations. Root owns commit/push after FINALSTOPPED.

1. In MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs,
CaptureOrdinaryTreatmentOwnerBytesAsync and AssertOrdinaryTreatmentOwnerBytesAsync
take HeldTreatmentPipelineContext and call existing held.ReadFileBytesAsync.
Before capture, deduplicate the COMPLETE existing logical path union using
Distinct(StringComparer.Ordinal). Preserve exact absent/null versus bytes.
Update all compile-required callsites (including pending2 signatures only),
retaining all phase ordering, assertions, turnover, underlying mutations and
expected refusal/take boundaries. No early release/lock bypass/raw FS fallback.
Preserve passing PostSeal body, shared Plan/Published, old transaction capture,
NativeCold and shared archive capture byte-exact.

2. Leave pending-duplicate2 setup/body/oracles unchanged except compile-required
helper signature calls. They remain BLOCKED: no actual nonempty repair wave.
No empty-root writer, synthetic packet, copied unrelated helper cohort, parser
relaxation or request/source/authority fabrication.

3. Add one intentional-overlap exact catalog owner for ONLY the four capture-
affected methods (nested2 + current-capability1 + concurrent3 + late-guard1),
7 cases, budget5. Preserve all existing724 catalog nodes/selectors. Exact new
task-local selection combines that owner with existing reflection1/3 budget2
and warm1/1 budget2: 6methods11cases3descriptors, default14 minutes. Passing
native1/postseal1 and blocked pending2 excluded. No runner/global selection edit.
Document responsibility, exclusions, contracts, overlap and fresh preparation.
Expected categories725/methods11567 is provisional until actual discovery.

4. Active plan/tasks entry: accepted evidence10executed1PASS9fixtureFAIL,
remaining4 UNRUN; fix source WIP and mandatory SOURCE/FIXTURE/SELECTION gate;
future retry11, pending2 blocked, original15/fullFR063/T070/#1536 open. Exact
build/discovery/catalog/actual UNRUN. Previous raw packets/history unchanged.

Self-review by source/diff only. Produce report at
/workspace/boe-cloud-tools-20261013/fr063-capture7-fix-source-report.md with
base, exact changed files/helper callsites, bounded change/oracles retained,
catalog selection expected inventory/budgets, checks actually performed,
pending blockers and SHA256 source pins. Return FINAL STOPPED, no project runs.
