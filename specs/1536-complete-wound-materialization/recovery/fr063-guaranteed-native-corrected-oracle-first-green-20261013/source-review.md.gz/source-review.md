# FR-063 native spend predicate — independent focused SOURCE review

Checkpoint: `9532e386e8fa66a84a964f57a49900cc9a0e562e`, compared with `08844dfa7a0cb2a4ad1dbca3224fbb88fc088c40`. Retained Astra XHigh; read-only source inspection, no project execution or repository mutation.

**SOURCE / FIXTURE / SELECTION: ACCEPTED.** No confirmed Critical or Important finding in this correction. This is source acceptance, not a native passing result.

The only code change in `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs:383` adds `row.Turn == 42` to the existing energy Spend `Assert.Single`. I independently reversed that expression and recovered the whole prior file byte-for-byte (candidate SHA256 `8e98458265939f41e0d46317859bfc3729835263bcbc54d45a9b28fb5868e716`). This fixes the demonstrated scope error: accepted ce83 evidence contains the valid old turn-2 Spend8 and exactly one turn-42 Spend2, not two current spends. The preceding current-spend count remains 1; Single, resource/owner, amount, before/after state, Applied outcome and turn assertions remain. The periodic Damage3, wound history, receipt, finalized hold, care, story, transient cleanup and later second-idle assertions are unchanged. No fixture history was removed and no production behavior changed.

The full four-path delta contains only that file, identical 19-line current-status additions to plan/tasks, and the verbatim copy of the previously accepted ce83 evidence review. Both metadata insertions reverse to the complete old documents, including unchanged checkbox lines. The accepted evidence report matches its external original byte-for-byte. Status correctly retains the prior actual FAIL, marks later assertions unreached and all corrected checks UNRUN; it claims no finalized-hold or native qualification.

Selection and scope remain appropriate: matching fresh BOTH preparation 12 methods / 18 cases / 5 descriptors with zero execution, exact native discovery 1 / 1 / 1 and unchanged catalog 724 / 11567; then the single corrected native case. Freeze and review that outcome before the unchanged 14-case remainder. No extra diagnostic run is necessary to establish the already captured historical/current-spend distinction. No repeat of unrelated qualified cohorts or new-root qualification follows from this source verdict.

**FINAL STOPPED for this focused FR-063 review.** The independent #1557 proposed-planning review resumes separately.

