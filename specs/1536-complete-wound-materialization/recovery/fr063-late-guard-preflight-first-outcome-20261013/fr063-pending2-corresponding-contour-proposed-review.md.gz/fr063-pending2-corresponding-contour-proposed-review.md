**Proposed-design verdict: ACCEPTED FOR AUTHORING, with the bounded conditions below.** This is not SOURCE acceptance, runtime release, or pending2 qualification.

The proposal SHA matched `19459d2b…8bfeb`; all 13 listed source fingerprints matched. Remaining source checks used pinned GitHub reads at `fa4fc1e5…`.

- **Responsibility is correct.** FR063 (`spec.md:537`) and the treatment contract (`contracts/mortal-wound-treatment.md:1004–1018`) require complete persisted requests, exact-copy coalescing and conflicting-copy refusal. The proposed component contour exercises that responsibility without claiming ordinary mixed-turn acceptance or a live production pending writer.
- **The pre-existing effect-free wound is permitted.** `WoundMaterializationContract.cs:1708–1736` accepts zero physical consequence slots when the retained care/recovery state supplies real lifecycle impact. Keep `untreated`, `requires_stabilization`, `not_stabilized`, valid route/capability, matching identity/history and empty owned-effect graph. Seed everything before genuine original42; do not reset occurrence/receipt/resource roots afterward.
- **Settle the bootstrap before original42.** The reused resource/seed writers emit compact JSON, while common publication uses indented canonical output. The QTE guard compares tracked bytes (`ValidationService.PlayerAndInventory.cs:308–326`). Follow the existing pre-original settling pattern in `QteStoryAppend.cs:452–459`, including applicable effect/identity/resource roots and canonical NPC receipt shape. Strict schema validity alone does not establish byte-stable QTE setup.
- **The genuine packet seam exists.** Fresh treatment Export/Prepare/reducer → homogeneous treatment-command distribution can coexist at these lower boundaries with readonly `ComposeQteAcceptedResponse`. Keep the treatment command’s scene identical to the acquisition scene. Require the chosen semantic error, genuine private context, actual opportunity match and a nonempty valid packet wave before writing pending. Preserve each owner’s actual event vector; only their genuine turn coordinates are shared.
- **Fresh-lease restoration is supported.** `AcceptedTurnAuthorityRegistry.cs:1927–1964` replaces the expired lease-bound candidate, clears stale local claims and invokes persisted recovery. `2097–2140` explains why restoration beneath the original warm lease is unsuitable. Verify one complete held request and one matching confirmed claim after Export, with no spend, transition, source movement or canonical publication. All capture reads must use the participating lease.
- **Label the changed-copy oracle precisely.** With quantity changed but original seals retained, `MortalWoundTreatmentPersistence.cs:376–404` parses the request before adding it to `Coalesce`. This can prove nested persisted-copy tamper refusal; it does **not** establish that `Coalesce`’s semantic-copy mismatch branch at `:437–451` ran. Require the actual refusal and no reconstructed authority/claim or physical mutation. Do not recompute authority merely to reach a later branch.

The minimal proposed two-row component fixture and exact owner/selection are reasonable. Keep the historical misplaced failures and mandatory persistence obligation open until authored SOURCE review and actual evidence establish the replacement’s scope. New-root/cold-process and ordinary live pending publication remain separate obligations.

**Delivery blocker:** the external report file was not written because the read-only executor call failed with:

`Failed to create unified exec process: exec-server transport disconnected`

No retry, new environment, repository mutation or project execution was attempted. The disposition above is ready for ROOT to preserve at the requested report path.

**FINAL STOPPED.**
