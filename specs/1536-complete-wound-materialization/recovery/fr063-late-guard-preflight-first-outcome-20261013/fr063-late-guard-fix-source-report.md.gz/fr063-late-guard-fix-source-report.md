# FR063 late-guard fixture correction — SOURCE READY, checks UNRUN

Base `fa4fc1e5ded616df54355966c850bab8fe765852`; preserved candidate `14d037d82198659c509066759dcbb02e32b2b5f7`. ROOT reports remote exact/recovery pending and owns all publication/review/project execution. Current readback confirms candidate HEAD and a clean working tree. Author changed only the six paths listed below; ROOT added only the accepted-six-control EVIDENCE report and second transport readback JSON. Mandatory actual Astra SOURCE/FIXTURE/SELECTION is still required. No project execution/Git mutation/agent/provider was used by the writer.

## Bounded correction and supported API

Only the existing Fact `GuaranteedTreatment_ComponentOrdinaryOwnerGuardsAbsentInputAcrossLeaseTurnoverBeforePublication` changes its forbidden naked NormalizeAcceptedMechanicsAsync(backups:null) entry to the bound internal PrevalidateTreatmentResourcePublicationTransactionAsync. Exact InvalidDataException remains required; the full message must equal `Accepted mechanics authority at 'game_state/npcs/npc_skills.json' changed after validation.` The existing observation now retains returned PreflightRefusal.

Actual production coordinator: CanonicalStateNormalizer.MortalItems.cs:1748–1840 binds its owning lease and calls the same preflight at1779, before TryTakeValidatedTreatmentPublication at1803, transaction construction and writes. Preflight AcceptedMechanics.cs:681–702 delegates at683 to sealed before-image checking at551/1184–1205. It rejects the introduced file and invalidates validated common/effect handoffs before take/reduction/publication. BindTo validates the actual active lease; existing InternalsVisibleTo permits the direct API. No private guard bypass, new settlement authority or production change. This component case proves coordinator PREVALIDATION refusal before take, not a completed dispatch/take/transaction publication.

Every old source/admission/signed absence/real lease turnover/introduced-file/raw mismatch/complete capture and subsequent full-byte/request/confirmed-hold/energy2/create-only-history/cleanup assertion and ordering is retained. Reversing ONLY the entry/result-message/observation edits restores the ENTIRE old fixture byte-for-byte, including six qualified controls, pending2, postseal and private helpers. Shared warm/transaction helpers, native and protected QTE remain base-exact. Future actual must establish fullhold/preservation; static source proof is not a PASS claim.

No GM, gameplay or afterlife authored contract changed; no prompt/docs/example/manifest/guard update is needed for this fixture entry/selection change. Genuine-wave pending2 is separately OPEN and unwritten; no synthetic pending wave or parser/source waiver.

## Finite ownership and budgets

Prepend ONLY exact intentional-overlap late-guard owner budget2; ROOT deliberately superseded the readonly budget5 proposal. Old725 nodes are semantically unchanged and their complete raw suffix is exact. No C# method/case added: static catalog726/expected11567 methods awaits real discovery.

New selection joins late1, exact reflected Core1method/3rows, and named warm1method/1case:3methods5cases3descriptors, budgets2+2+2/default11. Late1 alone is1/1/1/default7. Qualified passing6/native1/postseal1 and blockedpending2 are excluded. All old/full/global selections remain byte-exact. Anticipated ROOT-private BOTH6methods8cases4descriptors adds only unit3 for build/discovery and ZERO execution; these are static counts, not new discovery. Required SOURCE review/fresh BOTH/discovery/catalog/runtime remain UNRUN.

Prior EVIDENCE accepted fa4 retains actual7/6PASS1fixture-prerequisiteFAIL,16.9143276s,47chains,243source/11binary PRE/POST before metadata,13observations/seven absent strict roots, no timeout/skip/duplicate. Sourceb3/runtime9fb/evidencefa4 are distinct. Selection11 incomplete; reflection3/warm1 UNRUN. Narrow ordinary13 has8 accepted positives and5 unresolved; original15/fullFR063/T070/#1536 remains OPEN.

## Static checks actually completed after same-tool recovery

The first final static/report invocation failed BEFORE process creation with exec-server transport disconnected. No retry, source accumulation or inferred security cause followed. ROOT recovered the same node/boot, verified all six files survived, and published WIP14d BEFORE long verification. This resumed step writes ONLY this external report; it performs no repository mutation.

```json
{
  "Base": "fa4fc1e5ded616df54355966c850bab8fe765852",
  "PublishedCandidate": "14d037d82198659c509066759dcbb02e32b2b5f7",
  "WorkingTreeClean": true,
  "AuthorSixPathsOnlyPlusRootTwoEvidenceRecords": true,
  "FixtureReversalByteExact": true,
  "AllTestMethodDeclarationsUnchanged": true,
  "AllOld725CategoryNodesSemanticAndRawSuffixExact": true,
  "AllOldSelectionsByteExact": true,
  "ActiveBodiesEqual": true,
  "EntireHistoricalPlanTasksRecoveredByRemovingOnlyNewBody": true,
  "DatedPlanOldBytesPrefixExact": true,
  "CheckboxLinesExact": true,
  "ProtectedPinsMatchBase": true,
  "StaticCatalogCategories": 726,
  "ExpectedDiscoveredMethodsUnchanged": 11567,
  "SelectionMethods": 3,
  "SelectionCasesFromExistingDeclarations": 5,
  "SelectionDescriptors": 3,
  "Budgets": [
    2,
    2,
    2
  ],
  "DefaultBudget": 11,
  "FirstLateGuardMethodsCasesDescriptors": [
    1,
    1,
    1
  ],
  "FirstLateGuardDefaultBudget": 7,
  "PrivateBothPreparationAnticipated": [
    6,
    8,
    4
  ],
  "ProjectExecution": false
}
```

Readonly Git status/rev-parse/show/diff/ls-tree and Python source/JSON assertions were used. Committed-range `git diff --check` passed. Whole fixture reversal, active-body agreement/full old metadata recovery, dated append-prefix, all checkboxes, all old selectors and thirteen named protected files passed. New category IDs are unique, exact owner selects only one Fact; existing reflection/warm selection entries are copied byte/semantic-exact. Nothing built, discovered or executed.

## Six authored file pins

- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs` — `f0b582d3563aed9e1c6f9bc067abe04a7351c639da1ec99465f47c2603ba5a8d`, 23178 bytes.
- `tests/categories.json` — `db3f6957fb092f1eb578fc292b530452c6b7c29f3c5b07d06302c16bbab4adad`, 1873155 bytes.
- `tests/selections/1536-fr063-guaranteed-ordinary-owner-late-guard-retry.json` — `3ceb8585de9729d8bce7e3f0f718308ee2324a3b463b59d35531a43130122057`, 2163 bytes.
- `specs/1536-complete-wound-materialization/plan.md` — `c9e593370cd19cc4b3f49e5ccec9f0309a5eb0983b03f54a35c649d1276ccb5d`, 1367587 bytes.
- `specs/1536-complete-wound-materialization/tasks.md` — `60a48f4ef004ce23d6fd1757ea2e97c1916380725aba2f3473b0111b412a6280`, 868203 bytes.
- `docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md` — `bd6a173965800557133a650714d67a6ca1d2eb24bac3ec350f32b405fefc5486`, 37511 bytes.

## Protected files (candidate equals BASEfa4)

- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.cs` — `06a3377ad0f0574e6d6bb501c446719b03998fda628082a54a90526534f6cee7`, 311741 bytes.
- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs` — `8e98458265939f41e0d46317859bfc3729835263bcbc54d45a9b28fb5868e716`, 33108 bytes.
- `BookOfEternityClient.IntegrationTests/ResourcePendingResolutionIntegrationTests.cs` — `7b75d4ae988d7a33a0f326c6081f89b85277ba7347c9818bcd4529a682f359fc`, 38565 bytes.
- `BookOfEternityClient.IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryFinalization.cs` — `ce955dcb177fd609c240cfe0705a45b5cb792cf4887ba6b6832494d72d543e6f`, 17914 bytes.
- `BookOfEternityClient.IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryConsumerProjection.cs` — `4a3f36abdf021a8f8dad1c0ab4439e43d7a6b577ee509a6540a240171a51db9a`, 8826 bytes.
- `BookOfEternityClient/Services/CanonicalStateNormalizer/CanonicalStateNormalizer.AcceptedMechanics.cs` — `7395c42f57a5e230cc5fbf3964d3bdd50afca8fedd8ed61decb028bf7854ce92`, 57490 bytes.
- `BookOfEternityClient/Services/CanonicalStateNormalizer/CanonicalStateNormalizer.MortalItems.cs` — `6b2de14c772aa509fb04d3b00192ddee491bdc3110f85aafd140ab0e63972c4d`, 82191 bytes.
- `BookOfEternityClient/Services/AcceptedTurnAuthorityRegistry.cs` — `3bacf2c2294c88b10acd0d137c153ba2e219acc93903e74cad155081474d4705`, 256008 bytes.
- `BookOfEternityClient/Services/AcceptedMechanicsPlanCache.cs` — `5befc8c24573d03c211e0bab7b857c90071519f3627f655e2da209b3a7efe675`, 57541 bytes.
- `BookOfEternityClient/Services/AcceptedMechanicsWoundCommonInputComposer.cs` — `aa8fbbe9e1765d7c3381e0f9e85ffa2e82be74a7864e1a460b32097599208751`, 52967 bytes.
- `BookOfEternityClient/Services/Validation/ValidationService.ResourceMaterialization.cs` — `560f146d8210f8347f53f53196054c42ba9406f92cd6ef073b30aa17fb2c7b83`, 95821 bytes.
- `scripts/test-csharp.ps1` — `beb29822a9b3760676766941d9d081cbd2be12835c91a5215adc8aefd48bfff4`, 81688 bytes.
- `tests/selection.json` — `27006455535cc002e981dcffc40a9da07570279270dec10d587c138d906dc239`, 1415 bytes.

## Entire fixture diff

```diff
diff --git a/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs b/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs
index bbdebe1e..cbc1e2ac 100644
--- a/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs
+++ b/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs
@@ -280,15 +280,16 @@ public sealed partial class GameEngineTurnLifecycleTests
             var issues = await validator.ValidateAcceptedTurnRawResourceMaterializationAsync();
             Assert.Contains(issues, issue => issue.FilePath == path && issue.Code == "accepted_mechanics_wound_live_before_image_mismatch");
             await held.AcquireLeaseAsync();
-            await Assert.ThrowsAsync<InvalidDataException>(() => GetPrivateField<CanonicalStateNormalizer>(engine, "_normalizer")
-                .BindTo(held.Lease).NormalizeAcceptedMechanicsAsync(backups: null));
+            var refusal = await Assert.ThrowsAsync<InvalidDataException>(() => GetPrivateField<CanonicalStateNormalizer>(engine, "_normalizer")
+                .BindTo(held.Lease).PrevalidateTreatmentResourcePublicationTransactionAsync());
+            Assert.Equal($"Accepted mechanics authority at '{path}' changed after validation.", refusal.Message);
             await AssertOrdinaryTreatmentOwnerBytesAsync(held, before);
             await AssertConfirmedHeldLiveRegistryProbeAsync(held);
             Assert.True(await ContainsCurrentExactTreatmentRequestAsync(held));
             Assert.Equal(2, await ReadCurrentTreatmentEnergyAsync(held));
             Assert.Single(ReadCurrentTreatmentHistory(held.FileSystem).State!.Transitions);
             WritePhysicalInjuryDiagnostic("fr063_component_ordinary_guard_lease_turnover", new
-                { path, GuardBefore = plan.BeforeImages[path].Existed, Issues = issues, MechanicsAndRequestUnchanged = true });
+                { path, GuardBefore = plan.BeforeImages[path].Existed, Issues = issues, PreflightRefusal = refusal.Message, MechanicsAndRequestUnchanged = true });
         }
         finally { await held.ReleaseLeaseAsync(); }
     }
```

No static issue or source-expansion blocker found. Confirmed-hold/rejection acceptance remains actual-runtime work for ROOT after mandatory SOURCE. FINAL STOPPED.
