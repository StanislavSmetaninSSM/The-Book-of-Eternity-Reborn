# FR063 late guard: real coordinator preflight fixture correction

Base/remote: fa4fc1e5ded616df54355966c850bab8fe765852, clean.
Tracked #1536/FR063, sole retained Sol source writer, same cloud Linux.
Read first this brief, your fr063-late-guard-coordinator-readonly-diagnosis.md,
and actual accepted fr063-capture7-first-outcome-evidence-review.md (all in this directory).
Evidence accepted: six scoped negative controls qualified; guard failed at naked
normalizer coordinator prerequisite. Reflection3/warm1 UNRUN. Native/postseal retained.

Implement only a narrow TEST correction, exact category/selection, active MD2 and
dated-plan status clarification. No project/build/discovery/test/diagnostic/fault
execution, Git mutation, agents/providers, production/shared-helper/QTE/GM changes.
ROOT owns WIP publication after your FINALSTOPPED and mandatory actual Astra SOURCE.

1. In OrdinaryOwner.cs modify ONLY
GuaranteedTreatment_ComponentOrdinaryOwnerGuardsAbsentInputAcrossLeaseTurnoverBeforePublication:
replace direct NormalizeAcceptedMechanicsAsync(backups:null) with existing bound
PrevalidateTreatmentResourcePublicationTransactionAsync(). Keep expected exact
InvalidDataException and require its message names game_state/npcs/npc_skills.json.
Preserve every original source/admission/absent-beforeimage/real-turnover/raw-issue,
capture/hold/request/energy/history/cleanup assertion and ordering. Retain returned
exception detail in the existing guard observation to identify actual boundary.
Do not call a private guard, fabricate coordinator settlement or relax exception.
All six passing bodies, passing native/postseal/shared Plan/Published/capture/old
transaction helpers and production remain exact.

This proves the same real coordinator's sealed-input PREVALIDATION refusal BEFORE
take/publication, not a completed take, dispatch, compensation or publication.
Actual coordinator caller MortalItems.cs1779; preflight683->551->1184 and handoff
invalidation retained. Do not falsely label take executed. Existing fullhold
probe must still pass; if it exposes another issue preserve/report, no weakening.

2. Prepend one intentional-overlap catalog owner ONLY this existing Fact:
fr063-guaranteed-ordinary-owner-late-guard-retry, 1method1case, budget2.
Keep old725 nodes/raw suffix and all old/global selections unchanged.
New task-local selection tests/selections/1536-fr063-guaranteed-ordinary-owner-late-guard-retry.json
combines late1 + exact existing reflection1/3 budget2 + warm1/1 budget2:
3methods5cases3descriptors/default11. Exclude passing6/native1/postseal1 and pending2.
No new method/case; static catalog726/expected11567 until actual discovery.

3. Active plan/tasks: prior actual7/6PASS1prereqFAIL of11, accepted evidence47chains,
243source11binary7absentroots; correctionSOURCEready and new checksUNRUN.
Finite next5 only after SOURCE/fresh BOTH preparation/discovery/catalog. Unit3
remain build/discoveryONLY; anticipated private prep6methods8cases4desc0exec.
Narrow ordinary13 has eight accepted positive cases and five unresolved; full13
and original15 NOT GREEN, mandatory genuine pending2 persistence remains OPEN.
Dateplan append status clarifies actual coordinator-preflight refusal beforetake,
with no erased historicalpromise/checkbox or blanket source gate rewrite.

Expected exact six paths: OrdinaryOwner.cs, categories.json, newselection,
plan.md, tasks.md, datedplan. No other repo edit without reporting necessity first.
Report /workspace/boe-cloud-tools-20261013/fr063-late-guard-fix-source-report.md:
exact diff/files/pins, supported API/causality, unchanged passing paths/oracles,
static owner/budgets/counts, actual checks and UNRUN. FINALSTOPPED; no project run.
