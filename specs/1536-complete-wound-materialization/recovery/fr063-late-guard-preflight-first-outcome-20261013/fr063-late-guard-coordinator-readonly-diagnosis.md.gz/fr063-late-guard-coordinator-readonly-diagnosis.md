# FR063 late-guard coordinator entry — read-only diagnosis

2026-10-13. Evidence checkpoint fa4fc1e5ded616df54355966c850bab8fe765852. Actual runtime/compile source 9fb813df0e7b29db41e0067345edcb5967e2532c, equivalent to accepted capture7 code b3bdd4af7547f5dc28ed03c3580e76f2eef14767. Only this external report was written. No repository/Git/project/build/test/runtime/agent/provider operation was performed. The retained reviewer report `fr063-capture7-first-outcome-evidence-review.md` now records EVIDENCE/status ACCEPTED; this report neither releases authoring nor claims corrected execution.

## Observed boundary

Actual native run 20261013-183414-513-5879-20df29d13f8242f28ae51941bf06581c-categories: 7 executed, 6 PASS, 1 fixture prerequisite FAIL, 16.9143276 seconds, no timeout. The failure is `GuaranteedTreatment_ComponentOrdinaryOwnerGuardsAbsentInputAcrossLeaseTurnoverBeforePublication`, OrdinaryOwner.cs:283. Its prior raw-resource mismatch assertion passed: the sealed-absent npc_skills.json appeared after real lease turnover and validation returned `accepted_mechanics_wound_live_before_image_mismatch` for that exact path.

The failing direct call `.BindTo(held.Lease).NormalizeAcceptedMechanicsAsync(backups:null)` encounters the mandatory held-treatment coordinator guard (AcceptedMechanics.cs:73,589–602) before prevalidation at74. Native exception is InvalidOperationException, not the expected InvalidDataException. All subsequent full-byte, confirmed-hold, persisted-request, energy2 and create-only-history assertions were UNREACHED. This is not a production regression or a publication-refusal RED. Passing six controls remain qualified; reflection3 and warm1 remain UNRUN.

## Existing supported one-API correction

Call the internal supported `CanonicalStateNormalizer.BindTo(held.Lease).PrevalidateTreatmentResourcePublicationTransactionAsync()` instead of naked normalization. BindTo validates the actual active lease and returns an ordinary bound normalizer (CanonicalStateNormalizer.cs:218–229). Integration internals access already exists in BookOfEternityClient.csproj:57–72; no reflection/private-guard bypass/new authority is necessary.

Actual production use is AcceptedTurnCanonicalStateRefresh.NormalizeAndValidateWithPlanAsync, CanonicalStateNormalizer.MortalItems.cs:1748–1840. The coordinator acquires its owning lease and binds its normalizer at1753; it calls this exact preflight at1779 before `TryTakeValidatedTreatmentPublication` at1803, transaction construction at1819, and any treatment normalization/write at1825. Calling the internal preflight on the fixture's already participating lease reproduces its rejection contour without reacquiring a competing lease or calling a standalone publisher.

Preflight at AcceptedMechanics.cs:681–702 delegates first to PrevalidateAcceptedMechanicsBeforeNormalizationAsync at683. That method peeks the retained genuine validated plan, then checks every exact sealed before-image at551. ValidateAcceptedMechanicsBeforeImagesAsync at1184–1205 reads through the same lease; the changed npc_skills path cannot satisfy Existed=false and throws `InvalidDataException("Accepted mechanics authority at 'game_state/npcs/npc_skills.json' changed after validation.")`. The check invalidates the common validated handoff at1198; the enclosing catch at582–585 also invalidates common/effect handoffs. The mismatch is before take, transaction receipt construction, reduction, normalization, canonical writes, spend or hold finalization.

Proposed bounded assertion, not yet authored:

```csharp
var refusal = await Assert.ThrowsAsync<InvalidDataException>(() =>
    GetPrivateField<CanonicalStateNormalizer>(engine, "_normalizer")
        .BindTo(held.Lease)
        .PrevalidateTreatmentResourcePublicationTransactionAsync());
Assert.Equal($"Accepted mechanics authority at '{path}' changed after validation.", refusal.Message);
```

Keep the exact activelease timing, actual introduced-file bytes, raw mismatch assertion, whole captured inventory, and every existing later assertion unchanged. Existing registry invalidation clears common/effect plan slots and validated publication handoff/reservation metadata; it does not call `_treatmentResources.InvalidateAll`, mutate persisted request/canonical files, or finalize/consume the confirmed resource claim (AcceptedTurnAuthorityRegistry.cs:3271–3277,3627–3637,5480–5496,5666–5677; cache:523–575). The runtime must still establish the existing `AssertConfirmedHeldLiveRegistryProbeAsync` against actual request/finalization/G fields and all byte/energy/history oracles; source proof is not a substitute for their future PASS.

Scope wording must say **same production coordinator preflight rejects before take/publication**. It cannot say a take or full transaction publication ran. Generic exception acceptance or merely changing expected exception type would certify the wrong guard. No production guard or private authority change is necessary.

## Minimum future selection and protected scope

One affected existing Fact/one case only, then the already UNRUN reflected-Core theory/three rows and exact shared-fence warm sentinel/one case. Existing capture7 owner cannot select its last Fact without repeating qualified six rows. A separately authorized task-local intentional-overlap late-guard owner (budget5) plus the existing reflection/warm owners (budget2 each) yields 3 methods/5 cases/3 descriptors, default14 minutes; the first late-guard actual may be separate 1/1/1/default10, frozen/reviewed before the other4. No new semantic method/case is needed. If root requires catalog membership, one alias owner alone makes expected categories726/methods11567; actual discovery/catalog must establish counts. Old selectors, capture7 node/rows, passing6/native/postseal/shared helpers remain exact. No row extraction or global runner/filter invention is required.

Corrected code, build/discovery/catalog, and actual preflight/fullhold preservation are UNRUN. Mandatory source/fixture/selection gate and matching fresh preparation remain ROOT-owned. Pending2 is separately OPEN; full original15/FR063/T070/#1536 is not closed.

The independent pending-contour report is `/workspace/boe-cloud-tools-20261013/fr063-pending2-corresponding-contour-readonly-design.md`, SHA256 19459d2b1296e355737c52f5a19524fa4f0b746e8ba2c14a7f1af0411728bfeb. It proposes only a source-supported lower-level genuine-wave fixture; it is not authored, accepted runtime or mixed ordinary publication proof.

## Read source pins

- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs`: fbefee0fb31684d347793c3c264ccc3ec007a9b09c13388e5480bcc128e60337 (23003 bytes)
- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.cs`: 06a3377ad0f0574e6d6bb501c446719b03998fda628082a54a90526534f6cee7 (311741 bytes)
- `BookOfEternityClient/Services/CanonicalStateNormalizer/CanonicalStateNormalizer.AcceptedMechanics.cs`: 7395c42f57a5e230cc5fbf3964d3bdd50afca8fedd8ed61decb028bf7854ce92 (57490 bytes)
- `BookOfEternityClient/Services/CanonicalStateNormalizer/CanonicalStateNormalizer.MortalItems.cs`: 6b2de14c772aa509fb04d3b00192ddee491bdc3110f85aafd140ab0e63972c4d (82191 bytes)
- `BookOfEternityClient/Services/CanonicalStateNormalizer.cs`: af3eed10ef8f253aea0aa4d4b47b3b4690a7ba81dab4163a16aef5c62bc2dab9 (23872 bytes)
- `BookOfEternityClient/Services/AcceptedMechanicsPlanCache.cs`: 5befc8c24573d03c211e0bab7b857c90071519f3627f655e2da209b3a7efe675 (57541 bytes)
- `BookOfEternityClient/Services/AcceptedTurnAuthorityRegistry.cs`: 3bacf2c2294c88b10acd0d137c153ba2e219acc93903e74cad155081474d4705 (256008 bytes)
- `BookOfEternityClient/Services/Validation/ValidationService.ResourceMaterialization.cs`: 560f146d8210f8347f53f53196054c42ba9406f92cd6ef073b30aa17fb2c7b83 (95821 bytes)
- `BookOfEternityClient/BookOfEternityClient.csproj`: b1bafa2fffd26263bc821cd668f20d199a2d08a1a6ed1a4f32c69b95a893d59e (5795 bytes)
- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs`: 8e98458265939f41e0d46317859bfc3729835263bcbc54d45a9b28fb5868e716 (33108 bytes)
- `BookOfEternityClient.IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryFinalization.cs`: ce955dcb177fd609c240cfe0705a45b5cb792cf4887ba6b6832494d72d543e6f (17914 bytes)
- `tests/categories.json`: 4a54b8ebd3c923c700b8b2194766e510eba7efb32ffd5212c8555f0a704206b3 (1870768 bytes)
- `tests/selections/1536-fr063-guaranteed-ordinary-owner-capture7-retry.json`: 3661494b4c43b787af69dfdcd8515895331613182ce74b55c971479794caa61a (2108 bytes)

Native evidence read: external attempt2 actual-error-family-companion.json and actual-root-readback.json, plus the retained independent evidence review. No full GM instructions or unrelated raw logs were printed.

FINAL STOPPED. No implementation release used or source edit made.
