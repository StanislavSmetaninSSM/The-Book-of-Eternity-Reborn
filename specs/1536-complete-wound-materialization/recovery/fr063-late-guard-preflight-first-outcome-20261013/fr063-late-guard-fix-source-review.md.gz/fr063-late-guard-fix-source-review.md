# FR063 late-guard fixture correction — independent SOURCE/FIXTURE/SELECTION review

Reviewer: retained actual Astra XHigh. Published candidate `14d037d82198659c509066759dcbb02e32b2b5f7`, base `fa4fc1e5ded616df54355966c850bab8fe765852`. Scope: the complete supplied eight-path package (six authored fixture/catalog/selection/status paths plus two ROOT evidence/transport records), actual local source, author report and exact preparation selection. No repository edit, Git command/mutation, build, discovery, test, provider or new agent was used. Only the requested external reports were written.

**SOURCE/FIXTURE/SELECTION ACCEPTED. No confirmed Critical or Important defect remains in this bounded correction.** Corrected runtime and the subsequent preservation assertions remain UNRUN. This accepts the real coordinator's component preflight rejection before take/publication; it does not claim a completed coordinator transaction, dispatch, take, compensation or publication.

## Actual entry and causal boundary

`MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs:257–296` retains the genuine held request, actual ordinary-owner admission, sealed absence of `game_state/npcs/npc_skills.json`, real lease turnover, introduced physical file, complete capture and exact raw before-image mismatch assertion. The only entry substitution at lines283–285 calls `BindTo(held.Lease).PrevalidateTreatmentResourcePublicationTransactionAsync()` and requires the exact `InvalidDataException` message naming that path. The returned message is added to the existing observation.

This is an existing accessible API, not a private guard bypass. `CanonicalStateNormalizer.cs:218–229` verifies the active canonical lease and binds the normalizer to it; the integration assembly already has internals access in `BookOfEternityClient.csproj:57–72`.

The actual production coordinator in `Services/CanonicalStateNormalizer/CanonicalStateNormalizer.MortalItems.cs:1748–1828` calls this same preflight at1779 before `TryTakeValidatedTreatmentPublication` at1803 and transaction creation/writes. `CanonicalStateNormalizer.AcceptedMechanics.cs:681–702` first calls the existing preflight at683. Its retained-plan peek and exact before-image check at530–585/1184–1205 read through the bound lease and throw the asserted path-bearing error when Existed=false no longer agrees with the real file. This occurs before the later item-mode check, take and publication. The previous naked-normalizer prerequisite at589–602 is no longer the test's entry.

The old `InvalidDataException` requirement is preserved and strengthened with the exact message. It is not replaced with the previously observed unrelated `InvalidOperationException`. No production condition or admitted authority is relaxed.

## Hold, state and lifecycle preservation

Every original assertion after refusal remains: complete captured byte inventory, live confirmed-hold probe, exact persisted request, energy2, create-only wound history, and owned cleanup. Capture/assert helpers continue using the held context and distinct complete path union. The before-capture point remains after the deliberate npc_skills introduction, so the test also requires refusal to preserve that submitted file rather than silently remove it.

The failing preflight invalidates validated common/effect handoffs (`AcceptedMechanics.cs:584,646–651,1198`), not the confirmed resource hold. Read the relevant registry paths at `AcceptedTurnAuthorityRegistry.cs:3271–3277,3627–3637,5480–5496,5666–5677`: they clear plan/publication reservation metadata without calling the resource registry's global invalidation or writing persisted files. The unchanged live probe at `MortalWoundTreatmentResourcePublicationLifecycleTests.cs:3366–3405` requires ConfirmedHeld, zero changes, and exact operation/request/resource/finalization/generation identities. Its future PASS is still required; this review does not substitute source reasoning for runtime proof.

The correction changes no shared helper, production service, native fixture, post-seal test or six previously passing control bodies. Thus those accepted cases do not require automatic repetition for this fixture-only entry change.

## Independent preservation checks

- Reversing only the entry/message/observation edits reproduces the entire prior OrdinaryOwner file: SHA256 `fbefee0fb31684d347793c3c264ccc3ec007a9b09c13388e5480bcc128e60337`. Current fixture is `f0b582d3563aed9e1c6f9bc067abe04a7351c639da1ec99465f47c2603ba5a8d`, 23178 bytes.
- Removing only the new catalog prefix restores the complete old catalog bytes: SHA256 `4a54b8ebd3c923c700b8b2194766e510eba7efb32ffd5212c8555f0a704206b3`. Current catalog has726 nodes; all old725 nodes/raw suffix are unchanged.
- Compared all243 frozen source pins from the accepted prior outcome:238 still match directly. Only OrdinaryOwner, catalog and the three expected status documents differ. Production/shared/passing fixture inputs remain exact.
- All19 author-report file pins (six authored and thirteen protected) independently match current bytes and lengths. Original causal Fact remains `ce955dcb177fd609c240cfe0705a45b5cb792cf4887ba6b6832494d72d543e6f`.
- The active plan/tasks insertions are identical. The supplied metadata diff only inserts the current status and appends the dated clarification; historical checklists and prior promises are retained.
- Author static report was read after it became available: SHA256 `d04eabc3e62874011725dee82a03356578d314469e41607e4494ff358e91fa70`,11665 bytes. Its claims were checked against the source rather than treated as API proof.

## Exact selection and release limits

The new intentional-overlap owner selects only the existing late-guard Fact, budget2. The task-local selection adds the unchanged exact reflected-Core theory (pending/terminal/unknown, three rows, budget2) and one unchanged held-plan warm/restart sentinel (budget2). Source attributes confirm **3 methods /5 cases /3 integration descriptors, default11**. There is no new method or semantic case. Passing6/native1/postseal1 and mandatory unresolved pending2 are excluded.

The ROOT-private BOTH preparation file has SHA256 `3f6840d9e6f48c7d8c714430daafaf504d03ee852f2dfa1ebdc36b1df823311d`,2698 bytes. It retains those three entries and adds only `c5-original-post-validation-source`'s three named unit Facts for fresh build/discovery: **6 methods /8 cases /4 descriptors, ZERO execution**. This does not authorize actual C5/unit execution. Expected catalog726/11567 remains static until fresh discovery/audit.

ROOT may now run the reviewed fresh matching BOTH preparation, exact5 discovery and catalog audit with zero tests, then only the selected affected late1 plus previously UNRUN reflection3/warm1. The late1 result may be frozen/reviewed separately; a first failed descriptor does not qualify the remaining selection. Freeze native outcomes and source/binary provenance before any correction. No qualifying run or test PASS has occurred for this candidate.

## Metadata and remaining obligations

Current status truthfully preserves prior actual7/6PASS/one coordinator-prerequisiteFAIL, the incomplete selected11, six qualified negatives, native/postseal positives and four UNRUN rows. It names the new boundary as prevalidation before take/publication. The old budget5/default14 consultation is historical; the authored narrow owner uses2/default7 and combined5 uses2+2+2/default11. No budget increase or gameplay/GM change was introduced.

Ordinary13 currently has eight accepted positive cases and five unresolved; neither ordinary13 nor original15 is GREEN. Full FR063/T070/#1536, genuine pending2 persistence and separate new-root qualification remain OPEN. The accepted pending-contour proposal is authoring advice only, not implementation or runtime evidence. No frozen historical failure is relabeled.

The separately requested pending-contour FINAL was saved unchanged to `fr063-pending2-corresponding-contour-proposed-review.md`:3837 bytes, SHA256 `96f26ae1ebd8f0def3876410e57703348ee682ed528a2e38d87d32a5b6f8f834`. Its transport-delivery paragraph is intentionally historical verbatim text; persistence was completed after ROOT confirmed safe same-executor recovery.

**Final verdict: SOURCE/FIXTURE/SELECTION ACCEPTED at14d037d8, limited to this fixture/preflight correction and finite preparation/actual selection. Runtime qualification remains pending.**

FINAL STOPPED.
