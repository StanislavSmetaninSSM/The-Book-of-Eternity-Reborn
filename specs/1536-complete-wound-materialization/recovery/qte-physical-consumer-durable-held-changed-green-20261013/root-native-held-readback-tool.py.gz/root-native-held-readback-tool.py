"""ROOT read-only qualification of two managed native held-retry results."""
import base64, collections, datetime, hashlib, json, pathlib, sys

s = pathlib.Path(sys.argv[1])
read = lambda p: json.loads(p.read_text())
r = read(s / 'actual-root-readback.json')
obs = read(s / 'actual-native-observations.json')
pins = {p['path']: p for p in read(s / 'fresh-binary-pins.json')['files']}
children = [o['Observation'] for o in obs if o['Boundary'] == 'qte_durable_actual_child']
assert len(children) == 2 and {c['materialize'] for c in children} == {False, True}
assert r['tests'] == {'Total': 2, 'Executed': 2, 'Passed': 2, 'Failed': 0}
assert r['selection']['Complete'] and not r['timedOut'] and r['exitCode'] == 0
assert r['skipCount'] == r['duplicateTestIDs'] == 0
receipts = list(r['strictCleanupReceipts'])
nested, rows = [], []
binary_names = {'integration': 'BookOfEternityClient.IntegrationTests.dll',
                'support': 'BookOfEternityClient.TestSupport.dll',
                'runtimeconfig': 'BookOfEternityClient.IntegrationTests.runtimeconfig.json',
                'depsfile': 'BookOfEternityClient.IntegrationTests.deps.json',
                'immutable': 'System.Collections.Immutable.dll'}
for o in children:
    c, ctx = o['Child'], o['ChildContext']
    assert o['changed'] and o['ChildFailure'] is None and c and c['failure'] is None
    assert json.loads(o['ChildResultRaw']) == c and o['ChildLog']
    assert c['processId'] != o['ParentProcessId'] == ctx['parentProcessId']
    assert c['FreshFactory'] and c['handled'] is True and c['secondIdle'] is None
    assert c['actualTurn'] == 42 and c['Stories'] == [42] and c['InputKeyAvailableAfter']
    assert c['generation'] == ctx['parentGeneration']
    assert c['Original']['RequestId'] == ctx['requestId']
    assert c['Original']['SnapshotToken'] == ctx['snapshotToken']
    assert c['Original']['TurnNumber'] == 43
    assert o['MechanicalBefore'] == o['MechanicalAfter'] == c['Before'] == c['After']
    assert c['SubmittedOutputBefore'] == c['SubmittedOutputAfter']
    assert c['Receipt'] and c['Marker']
    marker = json.loads(c['Marker'])
    assert marker['generation'] == c['generation']
    for key, name in binary_names.items():
        pin = pins['BookOfEternityClient.IntegrationTests/bin/Debug/net8.0/' + name]
        assert c['BinaryPins'][key].lower() == pin['sha256']
    for binding in c['LoadedDependencyBindings']:
        path = binding['Path'].split('/BookOfEternityClient.IntegrationTests/', 1)[1]
        pin = pins['BookOfEternityClient.IntegrationTests/' + path]
        assert binding['Sha256'].lower() == pin['sha256']
        assert binding['IsDefaultContext'] and binding['LoadContext'] == 'Default'
    immutable = [b for b in c['LoadedDependencyBindings'] if b['Identity'].startswith('System.Collections.Immutable,')]
    assert len(immutable) == 1 and 'Version=9.0.0.0' in immutable[0]['Identity']
    for path, data in ctx['originalImages'].items():
        b = base64.b64decode(data)
        assert o['OriginalHashes'][path] == {'Exists': True, 'Length': len(b), 'Sha256': hashlib.sha256(b).hexdigest().upper()}
    ready = base64.b64decode(ctx['readyBytes']).decode('utf-8-sig')
    assert o['AvailableChildArtifacts']['ready/turn_complete.json'] == ready
    assert o['AvailableChildArtifacts']['input/turn_request.json'] == base64.b64decode(ctx['originalImages']['input/turn_request.json']).decode('utf-8-sig')
    for line in o['ChildLog'].splitlines():
        try: value = json.loads(line)
        except (ValueError, TypeError): continue
        if isinstance(value, dict) and 'Boundary' in value: nested.append(value)
    child_native = nested[-3:]
    assert [x['Boundary'] for x in child_native] == ['qte_durable_child_owned_entry', 'qte_durable_child_loaded_dependencies', 'qte_durable_child_before_actual_idle']
    entry, loaded, idle = [x['Observation'] for x in child_native]
    assert entry['ProcessId'] == idle['ProcessId'] == c['processId']
    assert entry['AuxiliaryFactoryRoot'] == idle['AuxiliaryFactoryRoot'] == c['AuxiliaryFactoryRoot']
    assert entry['BorrowedDurableRoot'] == idle['BorrowedDurableRoot']
    assert idle['KeyAvailable'] and idle['PlannedRepairCancellation']
    assert idle['generation'] == c['generation'] and idle['TurnNumber'] == 43
    assert idle['RequestId'] == ctx['requestId'] and idle['SnapshotToken'] == ctx['snapshotToken']
    assert idle['MechanicalBefore'] == c['Before'] and idle['SubmittedOutputBefore'] == c['SubmittedOutputBefore']
    assert loaded == c['LoadedDependencyBindings']
    assert len(o['ChildCleanup']) == 1
    receipts.extend(o['ChildCleanup'])
    rows.append({'decision': 'CREATE' if o['materialize'] else 'NONE', 'childPID': c['processId'],
                 'generation': c['generation'], 'original': c['Original'],
                 'handled': True, 'actualTurn': 42, 'stories': [42], 'escapeUnconsumed': True,
                 'mechanicalPathsExact': len(c['Before']), 'submittedOutputPathsExact': len(c['SubmittedOutputBefore']),
                 'originalArtifactHashes': len(o['OriginalHashes']), 'originalAfterPreservation': 'all owning child byte assertions executed and passed',
                 'readyNativeRetainedTextExact': True, 'loadedDependencyBindings': c['LoadedDependencyBindings'],
                 'fullChildLogBytes': len(o['ChildLog'].encode()), 'managedResultRetained': True,
                 'availableArtifactsRetainedBeforeSourceCleanup': True,
                 'auxiliaryFactoryRoot': c['AuxiliaryFactoryRoot'], 'borrowedDurableRoot': entry['BorrowedDurableRoot']})
assert len(receipts) == 4 and len({x['CleanupOwnedRoot'] for x in receipts}) == 4
for receipt in receipts:
    assert receipt['OwnedFixtureRemoved'] and receipt['CleanupFailure'] is None
    assert not pathlib.Path(receipt['CleanupOwnedRoot']).exists()
out = {'source': r['source'], 'compileSource': r['compileSource'], 'run': r['run'],
       'classification': 'CHANGED2_NATIVE_HELD_GREEN_PENDING_INDEPENDENT_EVIDENCE', 'rows': rows,
       'sourcePinsPrePostMatched': r['sourcePinsPrePostMatched'], 'binaryPinsPrePostMatched': r['freshBinaryPinsPrePostMatched'],
       'postReadbackBeforeMetadata': True, 'topNativeObservations': len(obs),
       'nestedNativeObservations': len(nested), 'nestedBoundaries': dict(collections.Counter(x['Boundary'] for x in nested)),
       'strictSourceAndFactoryCleanupReceipts': receipts, 'allFourRootsActuallyAbsent': True,
       'runnerOwnedRuntimeCleanup': [r['runnerOwnedTreeCleanupSucceeded'], r['runnerRuntimeCleanupSucceeded']],
       'historicalFd15': 'cause/managedResult/factoryCleanup UNKNOWN/UNQUALIFIED unchanged',
       'evidenceReview': 'PENDING', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(s / 'actual-native-held-qualification-readback.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
(s / 'actual-nested-native-observations.json').write_text(json.dumps(nested, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: out[k] for k in ['run', 'source', 'compileSource', 'sourcePinsPrePostMatched', 'binaryPinsPrePostMatched', 'topNativeObservations', 'nestedNativeObservations', 'allFourRootsActuallyAbsent']}))
print(json.dumps([{k: row[k] for k in ['decision', 'childPID', 'handled', 'actualTurn', 'stories', 'escapeUnconsumed', 'mechanicalPathsExact', 'submittedOutputPathsExact', 'originalArtifactHashes']} for row in rows]))
