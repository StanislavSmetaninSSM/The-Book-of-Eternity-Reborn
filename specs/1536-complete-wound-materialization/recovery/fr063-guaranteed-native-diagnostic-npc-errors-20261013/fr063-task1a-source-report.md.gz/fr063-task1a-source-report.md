# FR063 Task1a diagnostic SOURCE handoff — 2026-10-13

Authoring base `53aa4dd74fcc861e09587b169628cf6b41d04e90`; existing retained cloud task branch. **FINAL STOPPED READY** for ROOT publication/recovery and mandatory independent SOURCE/FIXTURE/SELECTION. This authoring does not establish a rejection cause, restoration RED or production correction. First native noncompletion EVIDENCE/status accepted7aaaf6dc; its59 original artifacts/231source/11binaries remain immutable. All corrected source acceptance/build/discovery/catalog/native execution remains UNRUN.

## Exact source whitelist/SHA256

- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs` — `33a13a2dc6c9374b5e7a50c99e44073d38854f1fecc702d851a63fabf17bf3c5`
- `specs/1536-complete-wound-materialization/plan.md` — `39c6ba0c213c6e9313693bbfde5b4c1bdd5362727edc49e1510ba52dad049211`
- `specs/1536-complete-wound-materialization/tasks.md` — `22e992f09ca4371c7cd265b68dfe02625b02df9619304de4d45cdd1b22f38d75`
- `docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md` — `c322013b49aed7e0c512f2acfefdab5c4c636da10e4165fa095d181466671b41`

Only four authorized repository paths changed. This requested external report is separate. No production, old fixture/helper, NativeHost, category, selection, runner, CI, GM documentation/example, evidence packet or package/provider/key changes. No project execution/Git mutation/new agent.

## Actual implementation

The child creates its borrowed-root FileSystemManager through the existing internal four-argument constructor (PhysicalLoadTransactionOperations.Instance + FileSystemManagerHooks). Its existing init-only LocalPublicationObserver relays through a local nullable Action. Relay remains null during source/cache/Ready/energy prerequisites, is installed immediately before actualCallerEntered/ordinary late-terminal entry, and is set null first in child finally before result/artifact capture or auxiliary cleanup. No new hook or production instrumentation.

Callback observes only TrustedLocalPublicationPhase.Committed. It reads the still-active existing journal at RuntimeRootPath/trusted-local-publication-v1/active.json using unchanged CleanupPublicationCut.Metadata, selects only the exact resolved validation_repair_request.json member, and verifies Format1. Public image fields are Exists/Bytes/Sha256; length is derived from decoded Bytes, never internal serialized Length. Committed transaction/member/declared presence/derived length/SHA are emitted in order. A declared DELETE records its absent image and returns without a physical missing-file read. No unrelated publication member is changed or used as accepted authority.

PRESENT records the real physical bytes/base64/raw request/length/SHA immediately, checks their exact equality with the declared image, then parses/clones the actual request JSON for structured errors/correlation/repair metadata. The sequence is retained as native boundary stdout and child managed-result RepairPublications, before cancellation cleanup can remove the request. No captured source/request/diagnostic is fed into the engine, no repair output or new Ready/input is authored. Original queued Escape, caller, common cache behavior and timers remain unchanged.

Any observer failure is recorded explicitly with its sequence and exception in stdout/RepairObserverFailure and asserted after actual caller return as a fixture prerequisite failure. It does not throw from the publication callback or change the caller's original input/rollback trajectory. It is never ignored or relabelled as a production RED. All available artifacts/logs/results remain captured by the existing child finally/parent observation before strict owned cleanup.

## Source/API evidence

- Core/FileSystemManager.cs:10–17 declares init-only Action<TrustedLocalPublicationPhase,int> LocalPublicationObserver; constructor602 accepts existing load operations/hooks.
- Core/TrustedLocalFileImage.cs:10–20 declares public Exists/Bytes/Sha256, internal Length. The new code reads only the actual public byte-backed image contract.
- Core/TrustedLocalFilePublication.cs:324 invokes committed observation while active metadata exists; FileSystemManager.TrustedLocalStorage.cs:240 passes the existing hook to PublishWithOutcome.
- IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryConsumerRepair.cs:134–177 is the accepted Format1 exact member/deletion-versus-PRESENT byte/SHA capture pattern reused here. CleanupPublicationCut.Metadata is unchanged.
- GameEngine.ValidationAndRepair.cs:3237–3326 publishes the request before the ordinary wait consumes queued Escape. The diagnostic callback changes neither that loop nor its production settlement.
- Required Core/JSON types and private helpers are already in scope; no new namespace/package/transport/parser framework is required. Source/API checking is not compilation proof.

## Static preservation/inventory

PASS git diff --check and exact four-path status. SequenceMatcher proves every old line is preserved except the original two-argument FileSystemManager constructor line; that one line is replaced by the existing four-argument hooked construction. All other changes are additive diagnostic code/fields/assertion. Parent Fact is byte-exact, publication/helper/oracle suffix is byte-exact; all existing cold prerequisite/caller/Ready/input/completion/history/spend/stabilization/receipt/second-idle/cleanup assertions remain unchanged. One Fact/no theories; exact two actual idle invocations remain; queued Escape remains identical.

PASS relay installed before actual entry/reset first in finally; no GetProperty(Length), public Bytes decoding, ordered sequence/finally retention. Original no Export/Restore/reducer/Compose/direct-validation prelude remains. No cache warm-up, correction or new controls/new-root case.

PASS whole categories.json (721) and one-case selection remain byte-exact; expected inventory11561 and selected1method/1case/1descriptor, category5/default10 and child45s unchanged. NativeHost, ConsumerRepair pattern source, warm held fixture, runner and global selection are exact against base. Original ce955 causal source is protected by the exact four-path whitelist.

PASS active plan/tasks Task1a note agreement; old history tails from Current FR063 first native outcome onward are byte-exact; all spec/dated-plan checkbox lines unchanged. Dated plan only gains a truthful Task1a authoring note; no task closure. Immediate-guidance docs/tests/UI changes remain unimplemented in this diagnostic block.

## Remaining gates and limits

ROOT publishes/readbacks exact diff, verifies actual remote and GitHub-only recovery, then obtains independent retained Astra XHigh SOURCE/FIXTURE/SELECTION. After acceptance, ROOT owns fresh matching selected preparation/exact1/1/1 plan/catalog and only one affected native actual. Freeze full diagnostic raw outcome/pins/cleanup and independently classify EVIDENCE before any fixture correction or production restoration. No accepted cohort rerun is requested.

There is no established broader seam/API blocker. Captured diagnostics are UNRUN: exact rejection cause remains UNRESOLVED. Production restoration is locked. FR063 remains the main task; full T070/FR063/#1536, deferred controls/new-root and wound-guidance runtime gaps stay OPEN.

## Full bounded diff

```diff
diff --git a/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs b/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs
index 4a64408b..d3449566 100644
--- a/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs
+++ b/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs
@@ -125,7 +125,14 @@ public sealed partial class GameEngineTurnLifecycleTests
         var context = JsonNode.Parse(await File.ReadAllTextAsync(contextPath))!.AsObject();
         using var factory = new GameEngineTurnLifecycleTests();
         using var factoryOwned = new CleanupOwnedFixture(factory._rootPath, Console.WriteLine);
-        var files = new FileSystemManager(root, NullLogger<FileSystemManager>.Instance);
+        Action<TrustedLocalPublicationPhase, int>? repairObserver = null;
+        var repairPublications = new List<object>();
+        Exception? repairObserverFailure = null;
+        var files = new FileSystemManager(root, NullLogger<FileSystemManager>.Instance,
+            PhysicalLoadTransactionOperations.Instance, new FileSystemManagerHooks
+            {
+                LocalPublicationObserver = (phase, index) => repairObserver?.Invoke(phase, index)
+            });
         var input = new QueuedConsoleInputSource([Key(ConsoleKey.Escape)]);
         var accepted = false;
         var engine = factory.CreateGameEngine(input,
@@ -191,6 +198,7 @@ public sealed partial class GameEngineTurnLifecycleTests
                 FreshCacheEmpty = true, input.KeyAvailable, Artifacts = await CaptureGuaranteedNativeArtifactsAsync(files)
             } }));
             // No ExportCurrent, RestorePersistedTreatmentRequests, reducer or Compose call occurs before entry.
+            repairObserver = CaptureCommittedRepairRequest;
             actualCallerEntered = true;
             handled = await InvokePrivateAsync<bool>(engine, "ProcessLateTerminalAndIdleTransitionsForCurrentSessionAsync");
             Console.WriteLine(JsonSerializer.Serialize(new { Boundary = "fr063_guaranteed_native_after_actual_caller", Observation = new
@@ -198,6 +206,7 @@ public sealed partial class GameEngineTurnLifecycleTests
                 accepted, handled, ActualTurn = GetPrivateField<GameLoop>(engine, "_gameLoop").TurnNumber,
                 Artifacts = await CaptureGuaranteedNativeArtifactsAsync(files)
             } }));
+            Assert.Null(repairObserverFailure);
             Assert.True(GetPrivateField<GameLoop>(engine, "_gameLoop").TurnNumber == 42,
                 "The actual native ordinary caller did not complete the confirmed held guaranteed treatment turn42.");
             Assert.True(accepted);
@@ -214,6 +223,7 @@ public sealed partial class GameEngineTurnLifecycleTests
         catch (Exception error) { failure = error; throw; }
         finally
         {
+            repairObserver = null;
             await File.WriteAllTextAsync(output, JsonSerializer.Serialize(new
             {
                 processId = Environment.ProcessId, generation, scenario, prerequisitesValidated, actualCallerEntered,
@@ -221,9 +231,80 @@ public sealed partial class GameEngineTurnLifecycleTests
                 failure = failure?.ToString(), AuxiliaryFactoryRoot = factory._rootPath,
                 Source = original is null ? null : new { original.SessionId, original.RequestId, original.SnapshotToken, original.TurnNumber, original.Realm },
                 BinaryPins = MortalArchiveBinaryPins(), LoadedDependencies = MortalArchiveLoadedDependencyBindings(),
+                RepairPublications = repairPublications, RepairObserverFailure = repairObserverFailure?.ToString(),
                 Artifacts = await CaptureGuaranteedNativeArtifactsAsync(files)
             }));
         }
+
+        void CaptureCommittedRepairRequest(TrustedLocalPublicationPhase phase, int index)
+        {
+            if (phase != TrustedLocalPublicationPhase.Committed || repairObserverFailure is not null) return;
+            try
+            {
+                var journalPath = Path.Combine(files.RuntimeRootPath, "trusted-local-publication-v1", "active.json");
+                using var journal = CleanupPublicationCut.Metadata(File.ReadAllBytes(journalPath));
+                var requestPath = files.ResolvePath("game_state/control/validation_repair_request.json");
+                var members = journal.RootElement.GetProperty("Members").EnumerateArray()
+                    .Where(member => member.GetProperty("Path").GetString() == requestPath).ToArray();
+                if (members.Length == 0) return;
+                var member = Assert.Single(members);
+                var format = journal.RootElement.GetProperty("Format").GetInt32();
+                var committed = journal.RootElement.GetProperty("Committed").GetBoolean();
+                var transactionId = journal.RootElement.GetProperty("TransactionId").GetString();
+                Assert.Equal(1, format); // This existing control publication uses the byte-backed Format1 image.
+                var after = member.GetProperty("After");
+                var exists = after.GetProperty("Exists").GetBoolean();
+                var declaredBytes = after.GetProperty("Bytes").ValueKind == JsonValueKind.Null
+                    ? null : after.GetProperty("Bytes").GetBytesFromBase64();
+                var sha256 = after.GetProperty("Sha256").GetString();
+                var memberObservation = new
+                {
+                    Sequence = repairPublications.Count, Format = format, TransactionId = transactionId,
+                    Committed = committed, MemberPath = requestPath, DeclaredBytesLength = declaredBytes?.LongLength,
+                    After = new { Exists = exists, Sha256 = sha256 }
+                };
+                repairPublications.Add(memberObservation);
+                Console.WriteLine(JsonSerializer.Serialize(new { Boundary = "fr063_guaranteed_native_repair_member", Observation = memberObservation }));
+                Assert.True(committed);
+                if (!exists)
+                {
+                    Assert.Null(declaredBytes); Assert.Null(sha256);
+                    return; // A declared DELETE is evidence, not a newly published request to read.
+                }
+                Assert.NotNull(declaredBytes);
+                var actualBytes = File.ReadAllBytes(requestPath);
+                var bytesObservation = new
+                {
+                    Sequence = repairPublications.Count, TransactionId = transactionId,
+                    ActualBytesLength = actualBytes.LongLength, ActualSha256 = MortalArchiveHash(actualBytes),
+                    ActualBytes = Convert.ToBase64String(actualBytes), RawRequest = MortalArchiveText(actualBytes)
+                };
+                repairPublications.Add(bytesObservation);
+                Console.WriteLine(JsonSerializer.Serialize(new { Boundary = "fr063_guaranteed_native_repair_request_bytes", Observation = bytesObservation }));
+                Assert.Equal(declaredBytes!.LongLength, actualBytes.LongLength);
+                Assert.Equal(declaredBytes, actualBytes);
+                Assert.Equal(sha256, MortalArchiveHash(actualBytes));
+                var rawRequest = MortalArchiveText(actualBytes);
+                using var request = JsonDocument.Parse(rawRequest);
+                var requestObservation = new
+                {
+                    Sequence = repairPublications.Count, Format = format, TransactionId = transactionId,
+                    Committed = committed, MemberPath = requestPath, ActualBytesLength = actualBytes.LongLength,
+                    ActualSha256 = MortalArchiveHash(actualBytes), ActualBytes = Convert.ToBase64String(actualBytes),
+                    RawRequest = rawRequest, Request = request.RootElement.Clone()
+                };
+                repairPublications.Add(requestObservation);
+                Console.WriteLine(JsonSerializer.Serialize(new { Boundary = "fr063_guaranteed_native_repair_request", Observation = requestObservation }));
+            }
+            catch (Exception error)
+            {
+                // Keep the original caller/input behavior; the capture failure remains an explicit prerequisite failure.
+                repairObserverFailure = error;
+                var observation = new { Sequence = repairPublications.Count, Failure = error.ToString() };
+                repairPublications.Add(observation);
+                Console.WriteLine(JsonSerializer.Serialize(new { Boundary = "fr063_guaranteed_native_repair_capture_failure", Observation = observation }));
+            }
+        }
     }
 
     private static async Task WriteGuaranteedNativeOrdinaryOutputsAsync(
diff --git a/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md b/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md
index 3b54e3ca..a849f7ae 100644
--- a/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md
+++ b/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md
@@ -121,6 +121,15 @@ this native freeze; do not replace FR063 work, invent diagnosis mechanics or cla
 
 ## Task 1a: Evidence-only actual repair rejection capture
 
+**Task1a authoring checkpoint:** TEST-ONLY diagnostic SOURCE READY at base53aa4dd74fcc861e09587b169628cf6b41d04e90.
+Existing native child installs a read-only Format1 committed request-member observer immediately
+before actual entry; declares DELETE versus PRESENT, captures exact physical bytes and checks them
+against declared bytes/derived length/SHA, retaining ordered stdout/managed-result evidence. Finally
+resets the observer; failures remain explicit fixture prerequisites. Existing caller/input/assertions/
+selection/bounds are preserved. All corrected SOURCE/preparation/discovery/catalog/runtime checks
+remain UNRUN; first noncompletion EVIDENCE accepted7aa, exact cause still UNRESOLVED. No production,
+authority reconstruction/correction or immediate-guidance source was authored. No checkbox closure.
+
 - [ ] Add only a test-side observer in the first NativeCold probe: capture the actual committed
   validation_repair_request.json member bytes from the existing publication callback, using the
   accepted Format1 present-member pattern. Persist the captured sequence in native stdout and
diff --git a/specs/1536-complete-wound-materialization/plan.md b/specs/1536-complete-wound-materialization/plan.md
index 4b4f8268..5645e8f4 100644
--- a/specs/1536-complete-wound-materialization/plan.md
+++ b/specs/1536-complete-wound-materialization/plan.md
@@ -26,6 +26,21 @@ SOURCE, fresh selected preparation/exact plan/catalog, run only the affected nat
 verify PREPOST/cleanup, then freeze/publish and independently classify that diagnostic outcome.
 Production, new-root and finite controls remain unchanged/unwritten until causal evidence.
 
+Task1a TEST-ONLY diagnostic SOURCE READY on authoring base
+53aa4dd74fcc861e09587b169628cf6b41d04e90. Only the existing NativeCold child gains a
+read-only committed-publication observer immediately before ordinary entry. Exact request-member
+Format1 Exists/Bytes/Sha256 metadata and physical PRESENT bytes/digests are captured before queued
+Escape, checked against the declared committed image, parsed, and retained as an ordered native/
+managed-result sequence. Declared DELETE is recorded without a missing-file read; internal Length
+is never treated as a serialized field. The observer is reset in finally; capture failure is retained
+and asserted as a prerequisite failure, not hidden or used as accepted authority. Original Fact,
+Ready/input/caller/completion/history/spend/second-idle assertions,1/1/1 selection and45s/category5/
+default10 remain unchanged. No production or pre-entry validator/Export/Restore/reducer/Compose.
+SOURCE review and all corrected preparation/discovery/catalog/runtime checks are UNRUN. The first
+noncompletion EVIDENCE remains accepted7aaaf6dc; exact rejection cause remains UNRESOLVED until the
+new actual diagnostic outcome is frozen/reviewed. No treatment correction or guidance alignment
+source is authored in this block; fullFR063/T070/UI and parent boxes remain OPEN.
+
 ## Current FR-063 first native outcome — 2026-10-13 (OBSERVED FAIL; EVIDENCE PENDING)
 
 Test-only source31818f11c597b01409cfb12a9ba07322975c41f0 independently SOURCE/FIXTURE/SELECTION
diff --git a/specs/1536-complete-wound-materialization/tasks.md b/specs/1536-complete-wound-materialization/tasks.md
index 1c75318b..9e2eb40e 100644
--- a/specs/1536-complete-wound-materialization/tasks.md
+++ b/specs/1536-complete-wound-materialization/tasks.md
@@ -22,6 +22,21 @@ SOURCE, fresh selected preparation/exact plan/catalog, run only the affected nat
 verify PREPOST/cleanup, then freeze/publish and independently classify that diagnostic outcome.
 Production, new-root and finite controls remain unchanged/unwritten until causal evidence.
 
+Task1a TEST-ONLY diagnostic SOURCE READY on authoring base
+53aa4dd74fcc861e09587b169628cf6b41d04e90. Only the existing NativeCold child gains a
+read-only committed-publication observer immediately before ordinary entry. Exact request-member
+Format1 Exists/Bytes/Sha256 metadata and physical PRESENT bytes/digests are captured before queued
+Escape, checked against the declared committed image, parsed, and retained as an ordered native/
+managed-result sequence. Declared DELETE is recorded without a missing-file read; internal Length
+is never treated as a serialized field. The observer is reset in finally; capture failure is retained
+and asserted as a prerequisite failure, not hidden or used as accepted authority. Original Fact,
+Ready/input/caller/completion/history/spend/second-idle assertions,1/1/1 selection and45s/category5/
+default10 remain unchanged. No production or pre-entry validator/Export/Restore/reducer/Compose.
+SOURCE review and all corrected preparation/discovery/catalog/runtime checks are UNRUN. The first
+noncompletion EVIDENCE remains accepted7aaaf6dc; exact rejection cause remains UNRESOLVED until the
+new actual diagnostic outcome is frozen/reviewed. No treatment correction or guidance alignment
+source is authored in this block; fullFR063/T070/UI and parent boxes remain OPEN.
+
 ## Current FR-063 first native outcome — 2026-10-13 (OBSERVED FAIL; EVIDENCE PENDING)
 
 Test-only source31818f11c597b01409cfb12a9ba07322975c41f0 independently SOURCE/FIXTURE/SELECTION
```
