# FR063 first native noncompletion — read-only diagnosis and bounded alignment

2026-10-13. Pinned project checkpoint `7aaaf6dcadac5ebb6057d30a104412b1cfaa86b3`; actual runtime/compile/source `31818f11c597b01409cfb12a9ba07322975c41f0`.
No repository/source/metadata/Git/runtime mutation. This external report alone is authored. Independent EVIDENCE final classification remains ROOT-owned.

## Observed boundary

First actual: one executed,0PASS1FAIL,12.8736384s, complete descriptor/no timeout. Fresh child606362 versus parent606327, same generation/original42/command/Ready digests, official Reader, empty accepted-plan cache and current energy2 prerequisites were observed. Real late caller entered; loop remains41, accepted=false,handled=false. Energy remains2 and resource/wound state/history bytes equal baseline; no new spend/history. Second idle and positive treatment oracles were unreached. Both emitted strict roots are actually absent per ROOT readback.

Full preserved plain stdout consists of the ordinary `Мир ещё не готов продолжить ход...` wait0s, Escape cancellation and before-turn restoration. No exact validator issue/code was emitted. This is **ordinary noncompletion followed by repair cancellation**, not yet proven causal restoration RED or a fixture defect. Do not infer a production patch from the cache gap alone.

## Source-supported route and limits

- `Core/GameEngine/GameEngine.TurnLifecycle.cs:884–1010`: participating late-terminal entry reads the actual original/ready, requires ready42==loop41+1, then calls `ValidateAcceptedTurnOutcomeWithRepairLoopAsync`. After nonaccepted disposition,1122–1130 invokes rejected-turn rollback and original/control cleanup. The removed backup/snapshot paths in native after-images agree with this settlement.
- `Core/GameEngine/GameEngine.ValidationAndRepair.cs:411–520`: current completed-publication inspection precedes the ordinary core; the core runs finalized-treatment quarantine, upstream raw state/NPC/faction/location/item admission and resource/Mortal decision admission. Later general validation/normalization can also reject. None of their exact issue lists survived the original capture.
- Same file:1157–1268 `TryQuarantineFinalizedTreatmentReplayAsync` returnsnull when a strictly parsed catalog has held requests; it does not restore the held request. This is a verified source property, not the observed rejection code.
- `Services/Validation/ValidationService.ResourceMaterialization.cs:31–77`: retained treatment publication requires a successfully peeked cached plan with TreatmentResourcePublicationAuthority. Native empty cache cannot satisfy that special path. Ordinary cold admission continues instead.
- `Services/Validation/ValidationService.WoundMaterialization.cs:512–681`: ordinary treatment branch builds accepted events, recomposes command and creates general WoundAcceptedTurnInput. The independent fresh ExportCurrent/RestorePersistedRequests/guaranteed reduction/six-argument treatment-publication path from the warm explicit helper is not invoked here. This is the candidate orchestration gap, but no particular runtime error or causal priority is established.
- `Core/GameEngine/GameEngine.ValidationAndRepair.cs:3237–3326`: WaitForContractRepair writes the validation request before spawning the repair wait. Its unique printed wait/cancel strings match actual stdout. Queued Escape cancels and returns false; cleanup deletes the repair controls before our post-caller artifacts. Therefore a committed request capture can observe the actual errors at the missing boundary.

## Fixture alternatives checked from actual raw bytes

Raw Ready has exact original session/request/turn42,success,parseable UTC timestamp and the three physically authored public output paths. `SessionAndSnapshots.cs:1705–1718` success contract requires status/timestamp/present-valid filesModified; captured Ready satisfies that shape, and native actual repair wait rather than terminal mismatch is consistent with reaching validation. Narrative is closed response+timestamp with exact sealed finalSceneText; interface is dialogueOptions[]+timestamp. Debug is closed gm_thoughts_markdown+timestamp, Scene-local scope with relevant actors none, Field medic outside scope and reasons. These syntactic observations do not prove every NPC/actor/sibling/whole-output validation rule passed. Current transcript has no exact debug/NPC issue, so changing public outputs or declaring them the cause would be speculative.

Actual command is client-produced `game_state/wounds/wound_commands.json`: schemaVersion/session/request/snapshot and one accepted_transition/treat-family row with full authority/result/finalSceneText. Its kind spelling does not by itself mean unsupported generic diagnosis/alternative; the parser separates treatment commands. Do not replace the command with a caller-built family or precompose a plan to make the probe pass.

## Minimum next diagnostic (test-only, after ROOT release)

Modify only the existing native probe fixture and active checkpoint/status under a precise release. Existing Fact/category/selector/cases/budgets/caller/queuedEscape/assertions remain unchanged. No direct validator invocation or restoration/composition before entry.

Use existing `FileSystemManagerHooks.LocalPublicationObserver` at `TrustedLocalPublicationPhase.Committed`, exactly as accepted `QtePhysicalInjuryConsumerRepair.cs:134–177`. Read the current existing format1 journal `RuntimeRootPath/trusted-local-publication-v1/active.json`, select only the exact resolved validation_repair_request member, and capture transactionId/Format/Committed/memberPath/After.Exists/Bytes/Sha256. Skip only an explicitly declared DELETE (record it); for PRESENT decode public After.Bytes, derive length, require physical bytes identical and matching SHA before strict JSON parsing. Internal Length is not serialized. This authentic present-member witness precedes the queued Escape consumption because request publication completes before the wait starts.

Capture actual raw request and complete structured errors/source/session/request/turn/fullResubmission/metadata/harness context immediately to native stdout plus managed result. Retain observer failures as explicit prerequisite diagnostics and fail the fixture honestly; no catch-and-ignore/poll/timer/newhook or GM resubmission. Do not author any repair output, release/cancel extra input or alter authority. Keep full finally/result/log/artifact/strict cleanup handling. Existing45s/budget5/default10 stays.

After SOURCE gate and fresh matching preparation, rerun only the one native case. Freeze its first diagnostic outcome/EVIDENCE. Then correlate actual captured issues with the source route: fix an evidenced lawful fixture prerequisite if one exists, or authorize only the proven ordinary restoration bridge. Production is presently LOCKED; no minimum source correction is justified yet.

## Independent immediate wound guidance alignment (planning only)

Basis: `/workspace/boe-cloud-tools-20261013/immediate-wound-recommendations-readonly-map.md`, recorded13:03 user clarification. Player must immediately see the wound plus how/means/conditions; ordinary viewing cannot require paid/chance diagnosis. Actual treatment checks/reservation/cost/effects remain unchanged; FR063 stays the main runtime task.

Original diagnosis purpose in tracked design was discovering a hidden complication or an additional method from new evidence, while an already-known route could remain visible. Explain that narrower optional purpose before changing its codec/history or adding live diagnosis behavior. It never justifies hiding the initial wound/care recommendation. Preserve Spiritual Healingtier0 and private NPC facts; no diagnosis dice/cost/auto-success rule is invented.

Proposed limited documentation alignment: spec FR057/058/069/071 and clarification; design/research R008; `contracts/wound-player-commands-and-projection.md` immediate detail/discovery wording and `contracts/mortal-wound-treatment.md` disclosure versus actual action; active plan/tasks; GM `OtherGuides/Wound_Materialization_Contract.md`; the two existing complete route examples in `Examples/E_CLI_Wound_Materialization.txt` and their manifest/source-example guards. Keep all immutable packets and earlier accepted grammar/history/FR063 qualifications intact.

Meaningful finite expectations: accepted own Mortal wound immediately exposes name/rank/how/materials/conditions from a complete public/known route; missing material/helper explains the unmet condition without hiding instructions; merely reading emits no diagnosis attempt/command/resource reservation/spend/roll; safe console/browser meaning matches and private technical refs/NPC data do not leak. Existing actual-treatment energy2/spend authority expectations remain unchanged. Two distinct existing route examples prove no universal invented recipe.

Conditional source policy/UI work must be explicit, not silently folded into docs: current contract allows all-hidden-but-reachable routes, so requiring one initially accessible recommendation for NEW own wounds needs an owning creation/visibility rule and a targeted negative; do not globally expose hidden NPC/complication/history data. Current accepted notification only supplies name/rank/link; `/раны` navigation/shared WoundPlayerProjection and browser WoundNotifications consumer are incomplete. T113–T119 remain OPEN. New actual accepted-notification/guidance oracles may legitimately RED until a separately approved shared projection/render seam exists. `BrowserText` or narrative text alone is not browser runtime parity proof. Do not bundle full browser/UI implementation or claim completion from documentation tests.

## Stop

READ-ONLY STOPPED. No project execution, source correction, metadata edit, Git mutation or new agent. Next action is ROOT final EVIDENCE classification and a bounded published diagnostic plan/release. This report does not claim underlying issue or a successful restoration.
