from pathlib import Path
import json,gzip,hashlib,subprocess,os,xml.etree.ElementTree as ET,collections
r=Path('/workspace/The-Book-of-Eternity-Reborn');out=r/'specs/1536-complete-wound-materialization/recovery';t=Path('/workspace/boe-fr063-tools-20261015');sha=lambda b:hashlib.sha256(b).hexdigest()
def closed(pairs):
 d={}
 for k,v in pairs:
  assert k not in d,k;d[k]=v
 return d
def read(p):return json.loads(p.read_text(),object_pairs_hook=closed)
tags=read(t/'us5-ro2-current-corrected-packet-tags.json');pkts=[read(out/(tag+'-freeze.json')) for tag in tags];d=pkts[0];head=d['testedGit'];assert head=='da367883264e91fa438c65b60aa35ec340f7f206';count=0
for packet in pkts:
 assert packet['sourcePins']==d['sourcePins'] and packet['binaryPins']==d['binaryPins'] and packet['testedGit']==head and not packet['proofIssues']
 for ch in packet['chains']:
  z=(out/ch['tracked']).read_bytes();b=gzip.decompress(z);assert sha(z)==ch['compressedSha256'] and sha(b)==ch['rawSha256'];assert b==Path(ch['origin']).read_bytes();count+=1
 assert packet['summary']['Revision']['Head']==head and packet['summary']['Revision']['ChangedFiles']==0
 assert packet['summary']['ExitCode']==packet['nativeExit'] and not packet['summary']['TimedOut']
 assert packet['summary']['OwnedTreeCleanupSucceeded'] and packet['summary']['RuntimeCleanupSucceeded']
assert count==29 and len(d['sourcePins'])==2644 and len(d['binaryPins'])==10
p=subprocess.Popen(['git','-C',str(r),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for row in d['sourcePins']:
 p.stdin.write((head+':'+row['path']+'\n').encode());p.stdin.flush();h=p.stdout.readline().decode().split();assert h[1]=='blob';b=p.stdout.read(int(h[2]));assert p.stdout.read(1)==b'\n';assert sha(b)==row['sha256']==sha((r/row['path']).read_bytes()),row['path']
p.stdin.close();assert p.wait()==0
bp=read(t/'us5-ro2-da3678832-pre-catalog-runtime-ten-binary-pins.json');assert bp['git']==head and bp['binaryPins']==d['binaryPins']
for row in d['binaryPins']:assert sha((r/row['path']).read_bytes())==row['sha256']
a=pkts[-1];s=a['summary'];assert s['Tests']=={'Total':72,'Executed':72,'Passed':70,'Failed':2};assert s['Selection']=={'PlannedDescriptors':7,'CompletedDescriptors':3,'PlannedCases':96,'CompletedCases':72,'UnderfilledDescriptors':[x['Name'] for x in a['plan']['Descriptors'][3:]],'Complete':False};assert not s['DuplicateTests'];assert len(a['cases'])==72
N={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};parsed=[];errors=[]
for f in (r/'TestResults/test-categories/20261015-222009-560-191468-1a7d16dabdb1448ea5754973b415bd5a-categories').glob('*.trx'):
 root=ET.parse(f).getroot();defs={x.attrib['id']:x for x in root.findall('.//t:UnitTest',N)}
 for result in root.findall('.//t:UnitTestResult',N):
  m=defs[result.attrib['testId']].find('t:TestMethod',N);identity={**result.attrib,'className':m.attrib['className'],'methodName':m.attrib['name'],'codeBase':m.attrib['codeBase']};parsed.append(identity)
  if result.attrib['outcome']=='Failed':errors.append({'test':result.attrib['testName'],'message':result.findtext('t:Output/t:ErrorInfo/t:Message',namespaces=N),'stack':result.findtext('t:Output/t:ErrorInfo/t:StackTrace',namespaces=N)})
assert len(parsed)==72 and len({x['executionId'] for x in parsed})==72
for identity in parsed:
 match=[c for c in a['cases'] if c['executionId']==identity['executionId']];assert len(match)==1 and all(match[0][k]==v for k,v in identity.items())
counts=collections.Counter(c['className']+'.'+c['methodName'] for c in a['cases']);expected={x['Name']:x['Cases'] for desc in a['plan']['Descriptors'][:3] for x in desc['ExpectedMethodCounts']};assert counts==expected
roots=[]
for c in a['cases']:
 if 'IntegrationTests' in c['codeBase']:assert len(c['cleanup'])==1
 else:assert not c['cleanup']
 for receipt in c['cleanup']:
  assert set(receipt)=={'CleanupOwnedRoot','OwnedFixtureRemoved','LeaseInactive','CleanupFailure'} and receipt['OwnedFixtureRemoved'] is True and receipt['LeaseInactive'] is True and receipt['CleanupFailure'] is None
  f=receipt['CleanupOwnedRoot'];assert os.path.isabs(f) and not os.path.lexists(f);roots.append(f)
assert len(roots)==len(set(roots))==35
assert len(errors)==2 and all('System.IO.IOException' in e['message'] and 'canonical-write.lock' in e['message'] for e in errors)
proof={'task':'#1536 RO2 second GREEN failure ROOT qualification','testedCompiledGit':head,'packetHashes':{tag:sha((out/(tag+'-freeze.json')).read_bytes()) for tag in tags},'chains':count,'sourcePinsGitAndCurrent':2644,'binaryPinsPreAndPost':10,'preBinaryRecordSha256':sha((t/'us5-ro2-da3678832-pre-catalog-runtime-ten-binary-pins.json').read_bytes()),'nativeExit':1,'actual':s['Tests'],'selection':s['Selection'],'wallTime':s['WallTime'],'cases':a['cases'],'errors':errors,'strictDistinctAbsentOwnedRoots':roots,'limit':'70PASS2FAIL;24remaining cases UNRUN;public status UNRUN. Both new reader tests call full owned-tree Snapshot inside an active exclusive canonical lease and cannot read runtime lock bytes. Subsequent full-tree/captured-state assertions unreached. No application lock weakening authorized.','readbackCorrection':'First ephemeral ROOT readback asserted UnderfilledDescriptors=[] despite actual4unrun descriptors; no success claim or output was produced. This corrected recorded-data reader requires the exact4remaining descriptors; all other predicates retained. No C# rerun.'}
f=out/'us5-ro2-second-green-failure-root-readback-20261015T2222Z.json';assert not f.exists();f.write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n');print('ROOT',sha(f.read_bytes()),'29chains2644source10binary72TRX35roots')
