import pathlib,json,gzip,hashlib,subprocess,os,collections
r=pathlib.Path('/workspace/The-Book-of-Eternity-Reborn');o=r/'specs/1536-complete-wound-materialization/recovery'
def h(b):return hashlib.sha256(b).hexdigest()
def closed(pairs):
 d={}
 for k,v in pairs:
  assert k not in d,k
  d[k]=v
 return d
def read(p):return json.loads(p.read_text(),object_pairs_hook=closed)
names=['us5-ro1-refusal-binding-fresh-both-bc9b88dd7-20261015T211456Z','us5-ro1-correct-catalog-eae09c815-20261015T211943Z','us5-ro1-refusal-binding-exact-plan-eae09c815-20261015T211957Z','us5-ro1-refusal-binding-actual-eae09c815-20261015T212022Z']
packets=[read(o/(n+'-freeze.json')) for n in names]; chains=0
for p in packets:
 assert p['nativeExit']==0 and p['proofIssues']==[]
 for c in p['chains']:
  z=(o/c['tracked']).read_bytes();b=gzip.decompress(z)
  assert h(z)==c['compressedSha256'] and h(b)==c['rawSha256']
  assert pathlib.Path(c['origin']).read_bytes()==b,c['origin']
  chains+=1
 assert p['sourcePins']==packets[0]['sourcePins']
 assert p['binaryPins']==packets[0]['binaryPins']
 for pin in p['binaryPins']:assert h((r/pin['path']).read_bytes())==pin['sha256']
 pins=p['sourcePins'];data=('\n'.join(p['testedGit']+':'+x['path'] for x in pins)+'\n').encode()
 result=subprocess.run(['git','-C',str(r),'cat-file','--batch'],input=data,stdout=subprocess.PIPE,check=True).stdout; offset=0
 for pin in pins:
  end=result.index(b'\n',offset);header=result[offset:end].split();assert header[1]==b'blob';length=int(header[2]);b=result[end+1:end+1+length];offset=end+2+length
  assert h(b)==pin['sha256'] and (r/pin['path']).read_bytes()==b,pin['path']
 assert offset==len(result)
prep,catalog,plan,actual=packets
assert prep['testedGit']=='bc9b88dd7ef46b3413a7edbf75786f3c6a38824f'
assert all(p['testedGit']=='eae09c8156285ba1674940308ab88c8219cf94c9' for p in packets[1:])
for p in packets:
 s=p['summary'];assert s['ExitCode']==0 and not s['TimedOut'] and s['OwnedTreeCleanupSucceeded'] and s['RuntimeCleanupSucceeded'] and not s['DuplicateTests']
for p in (prep,plan):
 assert p['summary']['PlanOnly'] and p['summary']['Tests']['Executed']==0
 assert p['summary']['Selection']['PlannedDescriptors']==2 and p['summary']['Selection']['PlannedCases']==68
 assert p['plan']==prep['plan'] or p==plan
cat=catalog['summary']['CatalogAudit'];assert cat=={'Valid':True,'Methods':11641,'Categories':756,'Unmapped':[],'StaleSelectors':[]}
s=actual['summary'];assert s['Tests']=={'Total':68,'Executed':68,'Passed':68,'Failed':0};assert s['Selection']=={'PlannedDescriptors':2,'CompletedDescriptors':2,'PlannedCases':68,'CompletedCases':68,'UnderfilledDescriptors':[],'Complete':True}
cases=actual['cases'];assert len(cases)==68 and all(c['outcome']=='Passed' for c in cases)
assert len({c['testId'] for c in cases})==68 and len({c['executionId'] for c in cases})==68
reader=[c for c in cases if 'IntegrationTests' in c['codeBase']];pure=[c for c in cases if c not in reader]
assert len(reader)==33 and len(pure)==35 and all(not c['cleanup'] for c in pure)
roots=[]
for c in reader:
 receipt,=c['cleanup'];assert set(receipt)=={'CleanupOwnedRoot','OwnedFixtureRemoved','LeaseInactive','CleanupFailure'}
 assert receipt['OwnedFixtureRemoved'] is True and receipt['LeaseInactive'] is True and receipt['CleanupFailure'] is None
 root=receipt['CleanupOwnedRoot'];assert os.path.isabs(root) and not os.path.lexists(root);roots.append(root)
assert len(set(roots))==33
faults=[c for c in reader if c['methodName']=='Load_IncompleteOrMalformedAuthorityIsUnavailableAndPreserved'];assert len(faults)==17
bindings=[c for c in pure if c['methodName']=='Build_EffectRequiresExactOwnedDefinitionBinding'];assert len(bindings)==3
report={'task':'#1536 US5-RO1 corrected reader and exact binding ROOT recorded-data qualification','sourceReview':'us5-ro1-reader-failure-root-binding-correction-independent-20261015T211337Z-review','reviewedSource':'7c1db7294a1678a5f630cc67b0d3080cdd6e5dae','compiledGit':prep['testedGit'],'runtimeTestedGit':actual['testedGit'],'packetHashes':{n:h((o/(n+'-freeze.json')).read_bytes()) for n in names},'verifiedChains':chains,'testedGitAndCurrentPinsPerPacket':len(pins),'binaryPins':len(actual['binaryPins']),'catalog':cat,'nativeExit':0,'wallTime':s['WallTime'],'cases':68,'passed':68,'failed':0,'projectionCases':35,'readerCases':33,'strictDataFaultCases':17,'exactRootBindingRealmPairs':3,'strictDistinctAbsentOwnedRoots':roots,'qualification':'Runtime observations and ROOT readback complete. Final independent EVIDENCE pending. Foundation only; public RO2 unwired; full US5/FR063/T070/#1536/lawfulACTIVE open.'}
p=o/'us5-ro1-refusal-binding-root-readback-20261015T2122Z.json';assert not p.exists();p.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'report':str(p),'sha256':h(p.read_bytes()),'chains':chains,'cases':68,'roots':33}))
b=pathlib.Path(__file__).read_bytes();p=o/'us5-ro1-refusal-binding-root-readback-20261015T2122Z.py.gz';assert not p.exists();p.write_bytes(gzip.compress(b,mtime=0))
