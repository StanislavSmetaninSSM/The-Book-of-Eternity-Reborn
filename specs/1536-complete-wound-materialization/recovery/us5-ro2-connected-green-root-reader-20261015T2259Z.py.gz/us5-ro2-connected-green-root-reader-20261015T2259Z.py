from pathlib import Path
import json,gzip,hashlib,subprocess,os,xml.etree.ElementTree as ET,collections,re
R=Path('/workspace/The-Book-of-Eternity-Reborn');O=R/'specs/1536-complete-wound-materialization/recovery';T=Path('/workspace/boe-fr063-tools-20261015');sha=lambda b:hashlib.sha256(b).hexdigest()
def closed(pairs):
 d={}
 for k,v in pairs:
  assert k not in d,k;d[k]=v
 return d
def read(p):return json.loads(p.read_text(),object_pairs_hook=closed)
tags=read(T/'us5-ro2-current-history-packet-tags.json');packets=[read(O/(tag+'-freeze.json')) for tag in tags];base=packets[0];head='737092c39f9d87af1f588c96a22e7111570d36c2';chains=0
for packet in packets:
 assert packet['testedGit']==head and packet['nativeExit']==0 and not packet['proofIssues']
 assert packet['sourcePins']==base['sourcePins'] and packet['binaryPins']==base['binaryPins']
 for ch in packet['chains']:
  z=(O/ch['tracked']).read_bytes();b=gzip.decompress(z);assert sha(z)==ch['compressedSha256'] and sha(b)==ch['rawSha256'] and b==Path(ch['origin']).read_bytes();chains+=1
 s=packet['summary'];assert s['ExitCode']==0 and not s['TimedOut'] and not s['DuplicateTests'] and s['OwnedTreeCleanupSucceeded'] and s['RuntimeCleanupSucceeded']
 assert s['Revision']['Head']==head and s['Revision']['ChangedFiles']==0 and s['Revision']['WorkingTreeFingerprint']==sha(b'').upper()
assert chains==33 and len(base['sourcePins'])==2644 and len(base['binaryPins'])==10
p=subprocess.Popen(['git','-C',str(R),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for row in base['sourcePins']:
 p.stdin.write((head+':'+row['path']+'\n').encode());p.stdin.flush();h=p.stdout.readline().decode().split();assert h[1]=='blob';b=p.stdout.read(int(h[2]));assert p.stdout.read(1)==b'\n';assert sha(b)==row['sha256']==sha((R/row['path']).read_bytes())
p.stdin.close();assert p.wait()==0
pre=read(T/'us5-ro2-737092c39-pre-catalog-runtime-ten-binary-pins.json');assert pre['git']==head and pre['binaryPins']==base['binaryPins']
for row in base['binaryPins']:assert sha((R/row['path']).read_bytes())==row['sha256']
for packet in (packets[0],packets[2]):
 assert packet['summary']['Tests']['Executed']==0 and packet['summary']['PlanOnly']
 desc=packet['plan']['Descriptors'];methods=[x for d in desc for x in d['ExpectedMethodCounts']];assert (len(methods),len({x['Name'] for x in methods}),sum(x['Cases'] for x in methods),len(desc))==(53,53,96,7)
for name in ('Build-integration.log','Build-unit.log'):
 b=[Path(c['origin']).read_text() for c in base['chains'] if Path(c['origin']).name==name];assert len(b)==1 and 'Build succeeded.' in b[0] and re.search(r'\b0 Error\(s\)',b[0])
assert packets[1]['summary']['CatalogAudit']=={'Valid':True,'Methods':11653,'Categories':758,'Unmapped':[],'StaleSelectors':[]};assert packets[1]['summary']['Tests']['Executed']==0
actual=packets[-1];s=actual['summary'];assert s['Tests']=={'Total':96,'Executed':96,'Passed':96,'Failed':0};assert s['Selection']=={'PlannedDescriptors':7,'CompletedDescriptors':7,'PlannedCases':96,'CompletedCases':96,'UnderfilledDescriptors':[],'Complete':True}
assert all(c['Completed'] and c['Seconds']<=c['BudgetMinutes']*60 for c in s['CategoryResults'])
assert actual['plan']['Descriptors']==packets[2]['plan']['Descriptors']==packets[0]['plan']['Descriptors']
N={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};parsed=[];history=[]
run=Path(next(c['origin'] for c in actual['chains'] if Path(c['origin']).name=='summary.json')).parent
for f in run.glob('*.trx'):
 root=ET.parse(f).getroot();defs={x.attrib['id']:x for x in root.findall('.//t:UnitTest',N)}
 for result in root.findall('.//t:UnitTestResult',N):
  m=defs[result.attrib['testId']].find('t:TestMethod',N);case={**result.attrib,'className':m.attrib['className'],'methodName':m.attrib['name'],'codeBase':m.attrib['codeBase'],'cleanup':[]};assert case['outcome']=='Passed'
  for line in (result.findtext('t:Output/t:StdOut',namespaces=N) or '').splitlines():
   if line.startswith('{') and 'CleanupOwnedRoot' in line:case['cleanup'].append(json.loads(line,object_pairs_hook=closed))
   if line.startswith('{') and 'WoundHistoryRenderedConsole' in line:history.append(json.loads(line,object_pairs_hook=closed))
  parsed.append(case)
assert len(parsed)==len(actual['cases'])==96 and len({c['executionId'] for c in parsed})==96
for case in parsed:
 matches=[c for c in actual['cases'] if c['executionId']==case['executionId']];assert len(matches)==1 and all(matches[0][k]==v for k,v in case.items())
counts=collections.Counter(c['className']+'.'+c['methodName'] for c in parsed);expected={x['Name']:x['Cases'] for d in actual['plan']['Descriptors'] for x in d['ExpectedMethodCounts']};assert counts==expected and len(counts)==53
pure={('BookOfEternityClient.Tests.ExampleDocumentationValidationTests','JsonExamples_AreParseableOrExplicitlyExempted'),('BookOfEternityClient.Tests.ExampleDocumentationValidationTests','CompleteEffectMaterializationManifest_CoversEveryRequiredWorkedFamily')};roots=[];pureintegration=0;pureunit=0;status=0;reader=0
for c in parsed:
 if (c['className'],c['methodName']) in pure:assert not c['cleanup'];pureintegration+=1
 elif 'IntegrationTests' in c['codeBase']:assert len(c['cleanup'])==1
 else:assert not c['cleanup'];pureunit+=1
 if c['className'].endswith('.WoundPlayerStatusTests'):status+=1
 if c['className'].endswith('.WoundPlayerReadServiceTests'):reader+=1
 for receipt in c['cleanup']:
  assert set(receipt)=={'CleanupOwnedRoot','OwnedFixtureRemoved','LeaseInactive','CleanupFailure'} and receipt['OwnedFixtureRemoved'] is True and receipt['LeaseInactive'] is True and receipt['CleanupFailure'] is None
  path=receipt['CleanupOwnedRoot'];assert os.path.isabs(path) and not os.path.lexists(path);roots.append(path)
assert (len(roots),len(set(roots)),pureintegration,pureunit,status,reader)==(50,50,2,44,15,35)
assert len(history)==1;proof=history[0];console=proof['WoundHistoryRenderedConsole'];card=proof['WoundHistoryBrowserCard'];name='Известная зажившая рана'
assert 'История ран' in console and 'Название' in console and name in console and 'retained for replay' not in console and 'wound_healed_ui' not in console
assert card['Title']==name and card['Summary']=='Рана зажила' and card['Facts']==[{'Label':'Название','Value':name}] and card['PrimaryAction'] is None
root={'task':'#1536 bounded US5-RO2 final GREEN ROOT qualification','reviewedCorrectionGit':'b0158bf33144408d5858fea4b1566c638bbec5bb','testedCompiledGit':head,'packetHashes':{tag:sha((O/(tag+'-freeze.json')).read_bytes()) for tag in tags},'chains':chains,'sourceGitAndCurrentPins':2644,'freshBinaryPrePostPins':10,'preBinaryRecordSha256':sha((T/'us5-ro2-737092c39-pre-catalog-runtime-ten-binary-pins.json').read_bytes()),'freshPreparationWallTime':packets[0]['summary']['WallTime'],'nativeExit':0,'runtimeWallTime':s['WallTime'],'actual':s['Tests'],'selection':s['Selection'],'actualMethodCounts':dict(counts),'cases':actual['cases'],'strictDistinctAbsentOwnedRoots':roots,'pureIntegrationCases':2,'pureUnitCases':44,'historyActualRenderProof':proof,'qualificationLimit':'Bounded client-owned current-self readonly console and browser transport status/guidance only. Existing hidden/private/foreign/unavailable/literal semantics, complete unchanged-tree/no-mutation/no-repair native assertions reached. Existing frontend text path statically guarded; frontend DOM/visual runtime UNRUN. Full guided US5, lawfulACTIVE/FR063/T070/#1536 remain open; old failures unchanged. Parent proof is not independent EVIDENCE acceptance.'}
f=O/'us5-ro2-connected-green-root-readback-20261015T2259Z.json';assert not f.exists();f.write_text(json.dumps(root,indent=2,ensure_ascii=False)+'\n');print('ROOT',sha(f.read_bytes()),'33chains2644source10binary53methods96PASS50roots2pureintegration44pureunit')
