# FR-063 Task1 test-only SOURCE handoff — 2026-10-13

Authoring base: `417a9cf63c1273f95e2d4a0e3b37a4c8a28caa2e`. Branch: `1536-wound-b2-cloud-20261012`.
Status: **FINAL STOPPED READY for ROOT publication and independent SOURCE/FIXTURE/SELECTION**.
This is source authoring, not completed Task1 runtime qualification. All build/discovery/catalog/native execution remains **UNRUN**. No git mutation, project command, production change, package/provider/model call or new agent was performed. No runtime RED is claimed.

## Exact repository whitelist and SHA256

- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs` — `fd22da818458d1fb38d1865d196bbf77da26d2a1fbb21781e94a36295cdfb555`
- `BookOfEternityClient.TestSupport/NativeHostScenarioDriver.cs` — `3743c5bbb23cc9b5046503d03a3df599c44c08342bd3bfbf0d33ab10cc726b83`
- `tests/categories.json` — `c9db2dc56df97c567c364adca1bce694c928d0c3da07fadafb78cb686564dcfe`
- `tests/selections/1536-fr063-guaranteed-native-same-root.json` — `215190526104e3c2a51f0be461f671e254b89d1bb542f5a6a0f59c999d5af3aa`
- `specs/1536-complete-wound-materialization/plan.md` — `08ac68332935ff5f520b38828fa3b9ab7e71e49a31869bb6326c767585003f96`
- `specs/1536-complete-wound-materialization/tasks.md` — `14769e9a8113d9f8744d5d843796274ac675069d253f6525a3273ec84a242a62`
- `docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md` — `35b0d76e9413d69dd4911c094a086c390bd4ec5b5b6e43b73edcc4248cd3d91c`

The requested external report is this file; it is not a new repository artifact. Exactly seven repository paths are modified/new. Existing source helpers are read-only; no additional seam was necessary.

## Authored behavior and causal boundary

One Fact: `BookOfEternityClient.Tests.GameEngineTurnLifecycleTests.GuaranteedTreatment_NativeSameRootOrdinaryCompletionSpendsConfirmedEnergyOnce`.
One public native reflection entry: `Task WriteMortalGuaranteedTreatmentColdProbeAsync(string root,string output,int scenario,string contextPath)`, scenario0; exact mode `engine-mortal-guaranteed-treatment-cold`.

Parent consumes the existing `CreateHeldTreatmentPipelineContextAsync(fault:null,withRollbackAuthority:true,composePublication:false)` (source line3002). Its canonical wound/bootstrap is explicitly a precondition, not a new QTE creation proof. Existing real PrepareGuaranteedRequest/CreateGuaranteedAttempt/codec/StateDistributor stage the sealed full confirmed request and single target-player energy2 hold. The new Fact asserts guaranteed/held, exact claim2/energy2, no validated common plan, official original42 and real request/session/token/generation agreement, original create-only history/no prior spend and no story42.

Parent writes ordinary closed response+timestamp/interface dialogueOptions+timestamp/debug gm_thoughts_markdown+timestamp only, preserving the existing final scene text. Ready42 includes exact session/request/turn/status/timestamp and the exact three public authored filesModified. It validates the raw fields and physical outputs. `.rollback.*`, original manifest/authority/subtree/input bytes are observed from the real filesystem. No original is copied/re-signed. The parent fully releases its only lease before child launch and keeps the separately owned root alive.

Context is assertion-only scalar coordinates/request fingerprint/attempt ID, original/command/Ready digests and binary metadata. It carries no request object/Context/Resolution/accepted plan/full request payload to production. The child reads full request/command/pending and original persisted files itself; the context never supplies production authority.

Fresh child creates only its auxiliary GameEngine fixture root, borrows the same physical durable root and uses a fresh FileSystemManager/factory/input/cache/PID. Official Reader under the fresh lease checks original42; generation and all original/command/Ready digests agree, actual energy is2, and `AcceptedMechanicsPlanAuthority.HasValidated` is false. After that lease is disposed, StateManager refreshes and the real engine starts at loop41 with one queued Escape. No ExportCurrent/RestorePersistedTreatmentRequests/guaranteed reducer/Compose helper or carried accepted context is called before actual late-terminal engine entry.

The child invokes `ProcessLateTerminalAndIdleTransitionsForCurrentSessionAsync` through the existing private invocation helper. It captures returned/exception state and all available source/command/pending/Ready/repair/resources/wounds/effects/stories before the first causal loop42 assertion. Accepted-outcome hook and actual story42 must follow actual ordinary validation/publication. Strict publication assertions require energy2->0 and exactly one Applied spend2, exactly one additional typed treat row/receipt with original session/request/token/attempt/request fingerprint, declared stabilize, exact stabilized wound/turn/last-attempt, finalized durable catalog with zero held requests, consumed command/Ready/input/original manifest. Only then ordinary handled=false is asserted. Second actual idle must be false, loop42 and byte-inert for mechanics/stories.

The typed history/catalog parse occurs only after actual entry/publication, for assertions; it never primes the caller. No deferred integrity matrix or new-root case was authored.

## Transport, diagnostics and ownership

Reuses unchanged `RunMortalArchiveChildAsync` (Archive partial line586) and unchanged `RunBrowserColdChildAsync` (BrowserInputRecovery209): `dotnet exec --runtimeconfig <integration.runtimeconfig> --depsfile <integration.deps> <support DLL>`, integration resolver and unchanged45s child bound/kill/join/drain. Runtimeconfig/deps/Immutable/integration/support pins and loaded assembly/default-context identities are reused from the accepted archive pattern.

Native entry and pre-idle observations record PID/parentPID/borrowed root/auxiliary root/generation/original tuple/cache/input plus raw artifacts. Child finally always writes managed result/failure/current artifacts when reachable. Parent retains full drained stdout+stderr log, managed result/context and available artifacts before any failure assertions or root cleanup, including timeout. A missing managed result or failed original/cache/Ready prerequisite is not automatically a production RED.

Parent uses existing strict CleanupOwnedFixture on the unique held root, with its lease already released. Child uses strict CleanupOwnedFixture on its independent auxiliary root; it never disposes/deletes the borrowed durable root. Parent verifies the emitted child cleanup receipt and actual auxiliary absence. Input is existing queued source, which owns no disposable live input; all parent fixture leases are awaited/disposed before launch. Full cleanup/runtime evidence is still UNRUN.

## Static evidence and exact inventory

- `git diff --check` PASS; new source/selector whitespace PASS. Historical tasks.md trailing spaces remain unchanged.
- Exact seven-path status PASS; no production/old fixture/helper/global/packet changes.
- Catalog JSON parses; new category `fr063-guaranteed-native-same-root`, integration only, timeout5/default10, one exact Fact. Existing720 catalog nodes are both semantic and raw suffix byte-identical to base. No old selector or budget changed.
- Static sole owner match verified against all category method patterns. One new Fact/no theory, expected1method/1case/1descriptor; catalog721 and expected inventory11561 = previous11560 +one Fact. These are static expectations, not discovery.
- Native route is exactly two additions/substitutions; reversing the new literal and switch row restores old NativeHostScenarioDriver bytes exactly.
- Child prefix scanned through actual entry: no ExportCurrent/Restore/reducer/Compose invocation; official source and empty-plan-cache checks are explicit. API definitions checked from source: held fixture/release lease, official ReadCurrent/authority properties, claim/request coordinates, Core engine/GameLoop/StateManager hooks, queued input, resource/history parsers, WoundHistory TreatmentResult/receipt and operation.Kind, cleanup and host signatures. Compilation is UNRUN.
- Both active plan/tasks bodies agree exactly. Old history tails from `Final bounded acceptance` onward and every checkbox line in both specs and the bounded Superpowers plan are byte/line-preserved. Task1 authoring status added without marking runtime steps complete.

## Protected source SHA256 (all exact against base)

- `BookOfEternityClient.IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryFinalization.cs` — `ce955dcb177fd609c240cfe0705a45b5cb792cf4887ba6b6832494d72d543e6f`
- `BookOfEternityClient.IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryConsumerNone.cs` — `052193449c07189c45df67e95ced27d8fd0febe0ce2bcc1ba6d1792c5fda47df`
- `BookOfEternityClient.IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryConsumerCreate.cs` — `50b13695b728c4dc21e354b475ca5856f94e405cfa925686e5064ad178692864`
- `BookOfEternityClient.IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryConsumerProjection.cs` — `4a3f36abdf021a8f8dad1c0ab4439e43d7a6b577ee509a6540a240171a51db9a`
- `BookOfEternityClient.IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryConsumerArchive.cs` — `2ccdf58fedf0128b3ebfcfa8cf494de29669ffaf2fdb003f8f5cfb010c195d16`
- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.cs` — `06a3377ad0f0574e6d6bb501c446719b03998fda628082a54a90526534f6cee7`
- `scripts/test-csharp.ps1` — `beb29822a9b3760676766941d9d081cbd2be12835c91a5215adc8aefd48bfff4`
- `tests/selection.json` — `27006455535cc002e981dcffc40a9da07570279270dec10d587c138d906dc239`

All other existing source/fixture/helper/old selection/global CI files remain unchanged by the exact status whitelist. Original causal SHA stays `ce955dcb177fd609c240cfe0705a45b5cb792cf4887ba6b6832494d72d543e6f`.

## Review and execution handoff

ROOT publishes this candidate, verifies actual remote/GitHub-only recovery, then obtains mandatory actual retained Astra XHigh SOURCE/FIXTURE/SELECTION. Only after acceptance: fresh selected preparation/discovery1/1/1 (zero tests), source/binary pins and catalog audit, then only the first native case through `tests/selections/1536-fr063-guaranteed-native-same-root.json`. Freeze the first raw outcome/cleanup/pins and independent EVIDENCE before any conditional production restoration. Existing accepted archive4/durable4/proof20/finite68/baselines remain retained and unrerun.

No established API/fixture blocker remains from static source checks. Runtime may expose an ordinary-caller restoration gap or a prerequisite refusal; classify only from the actual frozen evidence. Existing current in-process cold fixture explicitly Restore/Composes, finalized quarantine excludes held requests and retained raw validation expects a validated cache, but this is source-only motivation, not observed RED.

GM docs/examples are unchanged deliberately: test-only transport evidence changes no production or public grammar and grants no new live capability. Afterlife contracts are untouched. Diagnosis policy question is pending independently; no diagnosis success/cost policy is inferred. Deferred controls/new-root/other FR063 modes/fullT070/#1536 stay open.

## Full bounded diff

```diff
diff --git a/BookOfEternityClient.TestSupport/NativeHostScenarioDriver.cs b/BookOfEternityClient.TestSupport/NativeHostScenarioDriver.cs
index 20ad72b3..631e8ba4 100644
--- a/BookOfEternityClient.TestSupport/NativeHostScenarioDriver.cs
+++ b/BookOfEternityClient.TestSupport/NativeHostScenarioDriver.cs
@@ -17,7 +17,7 @@ internal static class NativeHostScenarioDriver
         if (args.Length == 3 && args[0] == "engine-rollback-cold-read")
             return await EngineRollbackColdProbe.RunAsync(args[1], args[2]);
         if ((args.Length == 4 && args[0] is "engine-browser-recovery-cold" or "engine-qte-story-resume") ||
-            (args.Length == 6 && args[0] is "engine-qte-wound-archive" or "engine-qte-wound-durable" or "engine-browser-staging-cut" or "engine-browser-staging-publisher" or "engine-browser-quiescent-admission" or "engine-browser-status-phase" or "engine-browser-consumer-profile" or "engine-musings-repair" or "engine-musings-cut" or "engine-musings-original-cut" or "engine-musings-cold" or "engine-browser-active-poll-original"))
+            (args.Length == 6 && args[0] is "engine-mortal-guaranteed-treatment-cold" or "engine-qte-wound-archive" or "engine-qte-wound-durable" or "engine-browser-staging-cut" or "engine-browser-staging-publisher" or "engine-browser-quiescent-admission" or "engine-browser-status-phase" or "engine-browser-consumer-profile" or "engine-musings-repair" or "engine-musings-cut" or "engine-musings-original-cut" or "engine-musings-cold" or "engine-browser-active-poll-original"))
         {
             // The integration fixture supplies the real lifecycle service factory.
             // Resolve its test-only dependencies in this isolated child, without a project cycle.
@@ -30,6 +30,7 @@ internal static class NativeHostScenarioDriver
             var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(args[1]);
             var name = args[0] switch
             {
+                "engine-mortal-guaranteed-treatment-cold" => "WriteMortalGuaranteedTreatmentColdProbeAsync",
                 "engine-qte-story-resume" => "WriteQteStoryResumeProbeAsync",
                 "engine-qte-wound-archive" => "WriteMortalQteArchiveProbeAsync",
                 "engine-qte-wound-durable" => "WriteMortalQteDurableProbeAsync",
diff --git a/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md b/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md
index 286a230f..ce8dff7d 100644
--- a/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md
+++ b/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md
@@ -40,6 +40,16 @@
 - Update only active `specs/1536-complete-wound-materialization/plan.md` and `tasks.md` checkpoint; historical records/checkboxes remain exact.
 - Existing fixture/probe helper files are read-only unless a concrete necessary seam is reported and SOURCE-reviewed first.
 
+**Task1 authoring checkpoint — 2026-10-13:** TEST-ONLY SOURCE READY on
+`417a9cf63c1273f95e2d4a0e3b37a4c8a28caa2e`. One planned Fact/mode/category/selector,
+static1/1/1 and catalog721/11561; existing fixtures/production/old720 category nodes unchanged.
+Called APIs and literal native reflection signature checked from source. No new project execution:
+independent SOURCE/FIXTURE/SELECTION, fresh build/discovery/catalog and first actual remain UNRUN.
+The source-only restoration gap is not an observed RED. ROOT owns publication/recovery/review/runtime;
+first outcome is frozen before any conditional production change. Deferred controls/new-root case
+remain unwritten; all task checkboxes stay open. Full report is outside the repository at
+`/workspace/boe-cloud-tools-20261013/fr063-task1-source-report.md`.
+
 **Interfaces:**
 - Consume `CreateHeldTreatmentPipelineContextAsync(fault:null, withRollbackAuthority:true, composePublication:false)`, existing exact byte/readback helpers and existing native launch/dependency/cleanup pattern.
 - Produce one Fact `GuaranteedTreatment_NativeSameRootOrdinaryCompletionSpendsConfirmedEnergyOnce`.
diff --git a/specs/1536-complete-wound-materialization/plan.md b/specs/1536-complete-wound-materialization/plan.md
index 8c8455af..d62557dc 100644
--- a/specs/1536-complete-wound-materialization/plan.md
+++ b/specs/1536-complete-wound-materialization/plan.md
@@ -25,7 +25,29 @@ selects one existing guaranteed energy2 held request, real original42, freshPID
 causal ordinary-caller probe,then new-root qualification. Child cannot precompose/restore through
 a test helper or carry Context/request/Resolution/cache authority. Existing canonical wound bootstrap
 is labelled a precondition,not another QTE source proof. First source block is test-only1/1/1,
-category5/default10/child45s; planned initial catalog721/11561. No project checks run yet.
+category5/default10/child45s; static initial catalog721/11561 (+one owner/Fact), not runtime discovery.
+
+Task1 test-only SOURCE READY at published authoring base417a9cf63c1273f95e2d4a0e3b37a4c8a28caa2e:
+`MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs` authors exactly one Fact
+`GuaranteedTreatment_NativeSameRootOrdinaryCompletionSpendsConfirmedEnergyOnce` and one narrow
+`engine-mortal-guaranteed-treatment-cold` reflection route. Parent uses the existing real warm sealed
+held guaranteed request/claim2 with composePublication:false, labels canonical wound bootstrap as a
+precondition, proves energy2/no common plan and official original42, writes lawful public ordinary
+outputs plus correlated Ready42/filesModified, then releases its lease. Assertion-only metadata carries
+scalars/digests/binary pins; the child reads persisted bytes on the same physical root with fresh PID,
+generation agreement and empty plan cache, then enters actual late-terminal caller at loop41 without
+Export/Restore/reducer/Compose or carried authority. Strict completion/story42/energy2->0/one typed
+treatment receipt/history/stabilization/finalized durable hold precede ordinary false and byte-inert
+second idle. Existing integration dependency context and45s child drain/kill/join are reused; complete
+logs/result/context/available artifacts and strict source/auxiliary cleanup are retained before failure.
+
+[Exact one-case selection](../../tests/selections/1536-fr063-guaranteed-native-same-root.json) owns only
+this new Fact; existing720 category nodes/old selectors/globalCI/production/old fixtures stay unchanged.
+Independent SOURCE/FIXTURE/SELECTION review, fresh preparation/discovery/catalog and first actual are
+UNRUN. Source READY is not test acceptance or observed RED. Freeze/review first outcome before any
+production restoration; deferred finite controls and new-root qualification remain UNWRITTEN/UNRUN.
+No GM prompt/example change: production and the existing public guaranteed-treatment grammar are
+unchanged; this block adds test-only orchestration evidence, not a new game capability.
 Source-only gap: current cold test precomposes in-process; production finalized replay quarantine
 excludes held requests and retained validation requires a cached plan. Actual causal RED is UNRUN;
 no production fix until first frozen EVIDENCE and minimum source-reviewed correction plan.
diff --git a/specs/1536-complete-wound-materialization/tasks.md b/specs/1536-complete-wound-materialization/tasks.md
index da0f35aa..9be8141e 100644
--- a/specs/1536-complete-wound-materialization/tasks.md
+++ b/specs/1536-complete-wound-materialization/tasks.md
@@ -21,7 +21,29 @@ selects one existing guaranteed energy2 held request, real original42, freshPID
 causal ordinary-caller probe,then new-root qualification. Child cannot precompose/restore through
 a test helper or carry Context/request/Resolution/cache authority. Existing canonical wound bootstrap
 is labelled a precondition,not another QTE source proof. First source block is test-only1/1/1,
-category5/default10/child45s; planned initial catalog721/11561. No project checks run yet.
+category5/default10/child45s; static initial catalog721/11561 (+one owner/Fact), not runtime discovery.
+
+Task1 test-only SOURCE READY at published authoring base417a9cf63c1273f95e2d4a0e3b37a4c8a28caa2e:
+`MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs` authors exactly one Fact
+`GuaranteedTreatment_NativeSameRootOrdinaryCompletionSpendsConfirmedEnergyOnce` and one narrow
+`engine-mortal-guaranteed-treatment-cold` reflection route. Parent uses the existing real warm sealed
+held guaranteed request/claim2 with composePublication:false, labels canonical wound bootstrap as a
+precondition, proves energy2/no common plan and official original42, writes lawful public ordinary
+outputs plus correlated Ready42/filesModified, then releases its lease. Assertion-only metadata carries
+scalars/digests/binary pins; the child reads persisted bytes on the same physical root with fresh PID,
+generation agreement and empty plan cache, then enters actual late-terminal caller at loop41 without
+Export/Restore/reducer/Compose or carried authority. Strict completion/story42/energy2->0/one typed
+treatment receipt/history/stabilization/finalized durable hold precede ordinary false and byte-inert
+second idle. Existing integration dependency context and45s child drain/kill/join are reused; complete
+logs/result/context/available artifacts and strict source/auxiliary cleanup are retained before failure.
+
+[Exact one-case selection](../../tests/selections/1536-fr063-guaranteed-native-same-root.json) owns only
+this new Fact; existing720 category nodes/old selectors/globalCI/production/old fixtures stay unchanged.
+Independent SOURCE/FIXTURE/SELECTION review, fresh preparation/discovery/catalog and first actual are
+UNRUN. Source READY is not test acceptance or observed RED. Freeze/review first outcome before any
+production restoration; deferred finite controls and new-root qualification remain UNWRITTEN/UNRUN.
+No GM prompt/example change: production and the existing public guaranteed-treatment grammar are
+unchanged; this block adds test-only orchestration evidence, not a new game capability.
 Source-only gap: current cold test precomposes in-process; production finalized replay quarantine
 excludes held requests and retained validation requires a cached plan. Actual causal RED is UNRUN;
 no production fix until first frozen EVIDENCE and minimum source-reviewed correction plan.
diff --git a/tests/categories.json b/tests/categories.json
index ff034098..a582c36f 100644
--- a/tests/categories.json
+++ b/tests/categories.json
@@ -1,6 +1,32 @@
 {
     "schemaVersion": 1,
     "categories": [
+        {
+            "id": "fr063-guaranteed-native-same-root",
+            "responsibility": "#1536 FR-063 first test-only native ordinary-caller probe: one integration Fact, one case. Existing canonical wound bootstrap is explicitly a precondition. The real warm producer seals one confirmed held guaranteed target-player energy2 request under genuine original42 without a common plan. Fresh child PID on the same physical root/generation enters actual GameEngine late-terminal completion from loop41 with empty accepted-plan cache and only persisted command/source bytes. Exact completion/story42, energy2->0, one typed treatment receipt/history/stabilization, finalized durable hold and inert second idle are required. Full child logs, managed result, available artifacts, dependency pins and owned cleanup survive failure.",
+            "excludes": "No helper ExportCurrent/RestorePersistedTreatmentRequests/reducer/Compose or carried Context/request/Resolution/cache before child entry; no production change, fabricated/copied/re-signed original authority, QTE creation requalification, new-root/archive/control matrix, diagnosis policy, provider/model/Windows/CI/global runner change or accepted archive4/durable4/proof20/finite68/baseline repeat. Initial source/build/discovery/catalog/runtime remain UNRUN until published independent SOURCE/FIXTURE/SELECTION acceptance.",
+            "changeHints": [
+                "BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs",
+                "BookOfEternityClient.TestSupport/NativeHostScenarioDriver.cs",
+                "docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md"
+            ],
+            "related": [],
+            "requirements": {
+                "frontendBuild": false,
+                "exclusive": false,
+                "ciRunner": "ubuntu-24.04"
+            },
+            "timeoutMinutes": 5,
+            "expectedSeconds": null,
+            "selectors": [
+                {
+                    "project": "integration",
+                    "tests": [
+                        "BookOfEternityClient.Tests.GameEngineTurnLifecycleTests.GuaranteedTreatment_NativeSameRootOrdinaryCompletionSpendsConfirmedEnergyOnce"
+                    ]
+                }
+            ]
+        },
         {
             "id": "qte-physical-injury-consumer-completed-proof-generation",
             "responsibility": "#1536 failed-only fixture correction: one existing generation semantic row extracted into one integration Fact. Actual owner-produced CREATE completion precedes supported lifecycle plus replacement lease rotation. Real changed generation, unchanged original source and mechanical/receipt/marker bytes, fresh official original Reader correlation and stale marker-generation denial are observed. Genuine retained exact replay refuses without authority or mutation. This owner gates only the previously unqualified generation control.",
diff --git a/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs b/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs
new file mode 100644
--- /dev/null
+++ b/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs
@@ -0,0 +1,342 @@
+using System.Text.Json;
+using System.Text.Json.Nodes;
+using BookOfEternityClient.Core;
+using BookOfEternityClient.Services;
+using Microsoft.Extensions.Logging.Abstractions;
+using Xunit;
+
+namespace BookOfEternityClient.Tests;
+
+public sealed partial class GameEngineTurnLifecycleTests
+{
+    private static readonly string[] GuaranteedNativeSnapshotPaths =
+    [
+        "game_state/meta/soul_state.json",
+        ResourceMaterializationContract.DefinitionsPath,
+        ResourceMaterializationContract.StatePath,
+        ResourceMaterializationContract.HistoryPath,
+        CanonicalResourceOwnerAuthorityComposer.AuthorityPath,
+        WoundCarrierCatalog.PlayerPath,
+        WoundIdentityState.StatePath,
+        WoundHistoryState.HistoryPath
+    ];
+
+    private static readonly string[] GuaranteedNativeMechanicalPaths =
+    [
+        .. GuaranteedNativeSnapshotPaths,
+        EffectCarrierCatalog.PlayerPath,
+        EffectAcceptedTurnPlan.IdentityIndexPath,
+        WoundAcceptedTurnSnapshotContract.PendingResolutionPath
+    ];
+
+    [Fact]
+    public async Task GuaranteedTreatment_NativeSameRootOrdinaryCompletionSpendsConfirmedEnergyOnce()
+    {
+        // Existing canonical bootstrap is a precondition, not a new QTE creation proof.
+        await using var held = await CreateHeldTreatmentPipelineContextAsync(
+            fault: null, withRollbackAuthority: true, composePublication: false);
+        using var owned = new CleanupOwnedFixture(held.Root, line => _directGachaOutput?.WriteLine(line));
+        var files = held.FileSystem;
+        Assert.False(AcceptedMechanicsPlanAuthority.HasValidated(files, held.Lease));
+        Assert.Equal("guaranteed", held.Request.Mode);
+        Assert.Equal("held", held.Request.ResourceAuthority.ReservationDisposition);
+        AssertHeldTreatmentClaims(held.Request, itemScenario: null);
+        Assert.Equal(2, await ReadCurrentTreatmentEnergyAsync(held));
+        var originalRead = PendingTurnSnapshotReader.ReadCurrent(files, held.Lease, GuaranteedNativeSnapshotPaths);
+        Assert.True(originalRead.Success, DescribeValidationIssues(originalRead.Issues));
+        var original = Assert.IsType<PendingTurnSnapshotReadAuthority>(originalRead.Snapshot);
+        Assert.Equal(42, original.TurnNumber);
+        Assert.Equal(held.Request.Coordinates.SessionId, original.SessionId);
+        Assert.Equal(held.Request.Coordinates.RequestId, original.RequestId);
+        Assert.Equal(held.Request.Coordinates.SnapshotToken, original.SnapshotToken);
+        Assert.Equal("mortal_world", original.Realm);
+        var generation = files.GetOrCreateSessionGeneration(held.Lease);
+        Assert.Equal(held.Request.Coordinates.SessionGeneration, generation);
+        var beforeHistory = ReadCurrentTreatmentHistory(files);
+        Assert.Single(beforeHistory.State!.Transitions);
+        Assert.Equal(0, CountHeldTreatmentEnergySpends(await ReadTreatmentResourceHistoryAsync(files)));
+        var storyBefore = await CaptureGuaranteedNativeStoriesAsync(files);
+        Assert.DoesNotContain(storyBefore.Values.SelectMany(bytes => MortalArchiveText(bytes!).Split('\n', StringSplitOptions.RemoveEmptyEntries))
+            .Select(line => JsonNode.Parse(line)!.AsObject()), story => story["turn"]!.GetValue<int>() == 42);
+
+        await held.ReleaseLeaseAsync();
+        await WriteGuaranteedNativeOrdinaryOutputsAsync(files, original);
+        var originalImages = await CaptureGuaranteedNativeOriginalAsync(files);
+        var command = Assert.IsType<byte[]>(await files.ReadFileBytesAsync(AcceptedMechanicsPlan.WoundCommandPath));
+        var ready = Assert.IsType<byte[]>(await files.ReadFileBytesAsync("ready/turn_complete.json"));
+        var context = new JsonObject
+        {
+            ["parentProcessId"] = Environment.ProcessId, ["generation"] = generation,
+            ["sessionId"] = original.SessionId, ["requestId"] = original.RequestId,
+            ["snapshotToken"] = original.SnapshotToken, ["turn"] = original.TurnNumber,
+            ["realm"] = original.Realm, ["attemptId"] = held.Request.Coordinates.AttemptId,
+            ["requestFingerprint"] = held.Request.RequestFingerprint,
+            ["commandSha256"] = MortalArchiveHash(command), ["readySha256"] = MortalArchiveHash(ready),
+            ["originalDigests"] = JsonSerializer.SerializeToNode(MortalArchiveDigests(originalImages)),
+            ["binaryPins"] = JsonSerializer.SerializeToNode(MortalArchiveBinaryPins()),
+            ["dependencyContext"] = MortalArchiveDependencyContext()
+        };
+        var contextPath = Path.Combine(held.Root, "guaranteed-native-context.json");
+        var output = Path.Combine(held.Root, "guaranteed-native-result.json");
+        await File.WriteAllTextAsync(contextPath, context.ToJsonString());
+        WritePhysicalInjuryDiagnostic("fr063_guaranteed_native_parent_held", new
+        {
+            CanonicalBootstrapPrecondition = true, ParentProcessId = Environment.ProcessId, generation,
+            original.SessionId, original.RequestId, original.SnapshotToken, original.TurnNumber, original.Realm,
+            held.Request.Mode, held.Request.RequestFingerprint, held.Request.Coordinates.AttemptId,
+            held.Request.ResourceAuthority.ReservationDisposition, held.Request.ResourceAuthority.Claims,
+            EnergyBefore = 2, NoPrecomposedPlan = true, LeaseReleased = true,
+            RawCommand = MortalArchiveText(command), RawReady = MortalArchiveText(ready),
+            Original = MortalArchiveDigests(originalImages), StoryBefore = MortalArchiveDigests(storyBefore), Context = context
+        });
+        var failure = await Record.ExceptionAsync(() => RunMortalArchiveChildAsync(
+            "engine-mortal-guaranteed-treatment-cold", held.Root, output, 0, contextPath));
+        // Preserve all child and current-session evidence before any causal assertion or owned cleanup.
+        var log = File.Exists(output + ".log") ? await File.ReadAllTextAsync(output + ".log") : null;
+        var resultText = File.Exists(output) ? await File.ReadAllTextAsync(output) : null;
+        var artifacts = await CaptureGuaranteedNativeArtifactsAsync(files);
+        WritePhysicalInjuryDiagnostic("fr063_guaranteed_native_parent_after_child", new
+        {
+            Failure = failure?.ToString(), FullChildLog = log, ManagedResult = resultText,
+            Context = context, Artifacts = artifacts,
+            ChildCleanup = MortalArchiveChildCleanup(output + ".log")
+        });
+        Assert.NotNull(resultText);
+        var result = JsonNode.Parse(resultText!)!.AsObject();
+        Assert.True(result["prerequisitesValidated"]!.GetValue<bool>(), resultText);
+        Assert.True(result["actualCallerEntered"]!.GetValue<bool>(), resultText);
+        Assert.Null(failure);
+        Assert.Null(result["failure"]);
+        Assert.Equal(42, result["actualTurn"]!.GetValue<int>());
+        Assert.True(result["accepted"]!.GetValue<bool>());
+        await AssertGuaranteedNativePublicationAsync(files, context);
+        Assert.False(result["handled"]!.GetValue<bool>());
+        Assert.False(result["secondIdle"]!.GetValue<bool>());
+        var childCleanup = Assert.Single(MortalArchiveChildCleanup(output + ".log"));
+        Assert.True(childCleanup["OwnedFixtureRemoved"]!.GetValue<bool>());
+        Assert.Null(childCleanup["CleanupFailure"]);
+        Assert.False(Directory.Exists(childCleanup["CleanupOwnedRoot"]!.GetValue<string>()));
+    }
+
+    public static async Task WriteMortalGuaranteedTreatmentColdProbeAsync(
+        string root, string output, int scenario, string contextPath)
+    {
+        Assert.Equal(0, scenario);
+        var context = JsonNode.Parse(await File.ReadAllTextAsync(contextPath))!.AsObject();
+        using var factory = new GameEngineTurnLifecycleTests();
+        using var factoryOwned = new CleanupOwnedFixture(factory._rootPath, Console.WriteLine);
+        var files = new FileSystemManager(root, NullLogger<FileSystemManager>.Instance);
+        var input = new QueuedConsoleInputSource([Key(ConsoleKey.Escape)]);
+        var accepted = false;
+        var engine = factory.CreateGameEngine(input,
+            settings => { InertRealmSettings(settings); settings.AutosaveIntervalTurns = 0; },
+            fileSystem: files,
+            finalizationHooks: new GameEngineSessionFinalizationHooks
+            {
+                AtCheckpointAsync = checkpoint =>
+                {
+                    if (checkpoint == SessionFinalizationCheckpoint.AcceptedOutcomeValidatedBeforeMaterialization)
+                        accepted = true;
+                    return Task.CompletedTask;
+                }
+            });
+        Exception? failure = null;
+        bool prerequisitesValidated = false, actualCallerEntered = false;
+        bool? handled = null, secondIdle = null;
+        string? generation = null;
+        PendingTurnSnapshotReadAuthority? original = null;
+        Console.WriteLine(JsonSerializer.Serialize(new { Boundary = "fr063_guaranteed_native_child_entry", Observation = new
+        {
+            ProcessId = Environment.ProcessId, ParentProcessId = context["parentProcessId"]!.GetValue<int>(),
+            BorrowedRoot = root, AuxiliaryFactoryRoot = factory._rootPath, scenario,
+            ProcessArguments = Environment.GetCommandLineArgs(), DependencyContext = MortalArchiveDependencyContext(),
+            LoadedDependencies = MortalArchiveLoadedDependencyBindings(), InputType = input.GetType().FullName
+        } }));
+        try
+        {
+            Assert.NotEqual(Environment.ProcessId, context["parentProcessId"]!.GetValue<int>());
+            AssertMortalArchiveChildBinaries(context);
+            await using (var lease = await files.AcquireCanonicalWriteLeaseAsync())
+            {
+                generation = files.GetOrCreateSessionGeneration(lease);
+                Assert.Equal(context["generation"]!.GetValue<string>(), generation);
+                var read = PendingTurnSnapshotReader.ReadCurrent(files, lease, GuaranteedNativeSnapshotPaths);
+                Assert.True(read.Success, DescribeValidationIssues(read.Issues));
+                original = Assert.IsType<PendingTurnSnapshotReadAuthority>(read.Snapshot);
+                Assert.Equal(context["sessionId"]!.GetValue<string>(), original.SessionId);
+                Assert.Equal(context["requestId"]!.GetValue<string>(), original.RequestId);
+                Assert.Equal(context["snapshotToken"]!.GetValue<string>(), original.SnapshotToken);
+                Assert.Equal(42, original.TurnNumber);
+                Assert.Equal(context["realm"]!.GetValue<string>(), original.Realm);
+                Assert.False(AcceptedMechanicsPlanAuthority.HasValidated(files, lease));
+            }
+            foreach (var pair in context["originalDigests"]!.AsObject())
+            {
+                var bytes = await files.ReadFileBytesAsync(pair.Key);
+                Assert.Equal(pair.Value!["Exists"]!.GetValue<bool>(), bytes is not null);
+                Assert.Equal(pair.Value["Sha256"]?.GetValue<string>(), bytes is null ? null : MortalArchiveHash(bytes));
+            }
+            Assert.Equal(context["commandSha256"]!.GetValue<string>(), MortalArchiveHash(
+                Assert.IsType<byte[]>(await files.ReadFileBytesAsync(AcceptedMechanicsPlan.WoundCommandPath))));
+            Assert.Equal(context["readySha256"]!.GetValue<string>(), MortalArchiveHash(
+                Assert.IsType<byte[]>(await files.ReadFileBytesAsync("ready/turn_complete.json"))));
+            Assert.Equal(2m, await ReadGuaranteedNativeEnergyAsync(files));
+            await GetPrivateField<StateManager>(engine, "_stateManager").RefreshGameStateAsync();
+            GetPrivateField<GameLoop>(engine, "_gameLoop").SetSession(original!.SessionId, 41);
+            prerequisitesValidated = true;
+            Console.WriteLine(JsonSerializer.Serialize(new { Boundary = "fr063_guaranteed_native_before_actual_caller", Observation = new
+            {
+                ProcessId = Environment.ProcessId, generation, original.SessionId, original.RequestId,
+                original.SnapshotToken, original.TurnNumber, original.Realm, PreviousTurn = 41,
+                FreshCacheEmpty = true, input.KeyAvailable, Artifacts = await CaptureGuaranteedNativeArtifactsAsync(files)
+            } }));
+            // No ExportCurrent, RestorePersistedTreatmentRequests, reducer or Compose call occurs before entry.
+            actualCallerEntered = true;
+            handled = await InvokePrivateAsync<bool>(engine, "ProcessLateTerminalAndIdleTransitionsForCurrentSessionAsync");
+            Console.WriteLine(JsonSerializer.Serialize(new { Boundary = "fr063_guaranteed_native_after_actual_caller", Observation = new
+            {
+                accepted, handled, ActualTurn = GetPrivateField<GameLoop>(engine, "_gameLoop").TurnNumber,
+                Artifacts = await CaptureGuaranteedNativeArtifactsAsync(files)
+            } }));
+            Assert.True(GetPrivateField<GameLoop>(engine, "_gameLoop").TurnNumber == 42,
+                "The actual native ordinary caller did not complete the confirmed held guaranteed treatment turn42.");
+            Assert.True(accepted);
+            await AssertGuaranteedNativePublicationAsync(files, context);
+            Assert.False(handled);
+            var committed = await CaptureMortalArchiveImagesAsync(files, GuaranteedNativeMechanicalPaths);
+            var stories = await CaptureGuaranteedNativeStoriesAsync(files);
+            secondIdle = await InvokePrivateAsync<bool>(engine, "ProcessLateTerminalAndIdleTransitionsForCurrentSessionAsync");
+            Assert.False(secondIdle);
+            foreach (var pair in committed) Assert.Equal(pair.Value, await files.ReadFileBytesAsync(pair.Key));
+            foreach (var pair in stories) Assert.Equal(pair.Value, await files.ReadFileBytesAsync(pair.Key));
+            Assert.Equal(42, GetPrivateField<GameLoop>(engine, "_gameLoop").TurnNumber);
+        }
+        catch (Exception error) { failure = error; throw; }
+        finally
+        {
+            await File.WriteAllTextAsync(output, JsonSerializer.Serialize(new
+            {
+                processId = Environment.ProcessId, generation, scenario, prerequisitesValidated, actualCallerEntered,
+                accepted, handled, secondIdle, actualTurn = GetPrivateField<GameLoop>(engine, "_gameLoop").TurnNumber,
+                failure = failure?.ToString(), AuxiliaryFactoryRoot = factory._rootPath,
+                Source = original is null ? null : new { original.SessionId, original.RequestId, original.SnapshotToken, original.TurnNumber, original.Realm },
+                BinaryPins = MortalArchiveBinaryPins(), LoadedDependencies = MortalArchiveLoadedDependencyBindings(),
+                Artifacts = await CaptureGuaranteedNativeArtifactsAsync(files)
+            }));
+        }
+    }
+
+    private static async Task WriteGuaranteedNativeOrdinaryOutputsAsync(
+        FileSystemManager files, PendingTurnSnapshotReadAuthority original)
+    {
+        var timestamp = DateTime.UtcNow.ToString("O");
+        await files.WriteFileAtomicAsync("output/narrative_response.json", JsonSerializer.Serialize(new
+            { response = HeldTreatmentPipelineContext.FinalSceneText, timestamp }));
+        await files.WriteFileAtomicAsync("output/interface_updates.json", JsonSerializer.Serialize(new
+            { dialogueOptions = Array.Empty<object>(), timestamp }));
+        await files.WriteFileAtomicAsync("output/debug_logs.json", JsonSerializer.Serialize(new
+        {
+            timestamp, gm_thoughts_markdown = "## NPC Scope\n- Mode: Scene-local\n- Relevant actors: нет\n" +
+                "- Why relevant: Завершение уже запечатанного клиентом лечения без нового решения NPC.\n" +
+                "- Actors outside scope: Field medic\n- Why outside scope: Нет нового взаимодействия, реплик или изменений NPC.\n\n" +
+                "## Reasoning\n- Only the existing client-sealed guaranteed treatment is completed; no GM mechanical delta is authored."
+        }));
+        string[] modified = ["output/narrative_response.json", "output/interface_updates.json", "output/debug_logs.json"];
+        await files.WriteFileAtomicAsync("ready/turn_complete.json", JsonSerializer.Serialize(new
+        {
+            sessionId = original.SessionId, requestId = original.RequestId, turnNumber = original.TurnNumber,
+            status = "success", timestamp, filesModified = modified
+        }));
+        using var ready = JsonDocument.Parse(MortalArchiveText(Assert.IsType<byte[]>(
+            await files.ReadFileBytesAsync("ready/turn_complete.json"))));
+        Assert.Equal(original.RequestId, ready.RootElement.GetProperty("requestId").GetString());
+        Assert.Equal(original.SessionId, ready.RootElement.GetProperty("sessionId").GetString());
+        Assert.Equal(42, ready.RootElement.GetProperty("turnNumber").GetInt32());
+        Assert.Equal("success", ready.RootElement.GetProperty("status").GetString());
+        Assert.Equal(modified, ready.RootElement.GetProperty("filesModified").EnumerateArray().Select(value => value.GetString()).ToArray());
+        foreach (var path in modified) Assert.NotNull(await files.ReadFileBytesAsync(path));
+    }
+
+    private static async Task AssertGuaranteedNativePublicationAsync(FileSystemManager files, JsonObject expected)
+    {
+        Assert.Equal(0m, await ReadGuaranteedNativeEnergyAsync(files));
+        var resources = await ReadTreatmentResourceHistoryAsync(files);
+        Assert.Equal(1, CountHeldTreatmentEnergySpends(resources));
+        var spend = Assert.Single(resources.Transitions, row => row.Operation == ResourceTransitionOperation.Spend &&
+            row.Coordinate.ResourceKey == "energy" && row.Coordinate.ResourceOwnerId == "player_current");
+        Assert.Equal(2m, spend.AppliedAmount); Assert.Equal(2m, spend.BeforeState!.Current); Assert.Equal(0m, spend.AfterState!.Current);
+        Assert.Equal(42, spend.Turn); Assert.Equal(ResourceTransitionOutcome.Applied, spend.Outcome);
+        var history = ReadCurrentTreatmentHistory(files);
+        Assert.Equal(2, history.State!.Transitions.Count);
+        var treatment = Assert.Single(history.State.Transitions, row => row.Kind == "treat");
+        Assert.Equal(HeldTreatmentPipelineContext.OperationKey, treatment.OperationKey);
+        Assert.Equal(42, treatment.Turn); Assert.Equal(HeldTreatmentPipelineContext.WoundId, treatment.WoundId);
+        var result = Assert.IsType<MortalWoundTreatmentPersistedResult>(treatment.TreatmentResult);
+        Assert.Equal("guaranteed", result.Request.Mode);
+        Assert.Equal(expected["requestFingerprint"]!.GetValue<string>(), result.Request.RequestFingerprint);
+        Assert.Equal(expected["attemptId"]!.GetValue<string>(), result.Request.Coordinates.AttemptId);
+        Assert.Equal(expected["sessionId"]!.GetValue<string>(), result.Receipt.Coordinates.SessionId);
+        Assert.Equal(expected["requestId"]!.GetValue<string>(), result.Receipt.Coordinates.RequestId);
+        Assert.Equal(expected["snapshotToken"]!.GetValue<string>(), result.Receipt.Coordinates.SnapshotToken);
+        Assert.Equal("success", result.Receipt.ResultCategory);
+        Assert.Contains(result.Receipt.DeclaredResult, operation => operation.Kind == "stabilize");
+        JsonElement? pending = files.FileExists(WoundAcceptedTurnSnapshotContract.PendingResolutionPath)
+            ? JsonSerializer.SerializeToElement(JsonNode.Parse((await files.ReadFileAsync(WoundAcceptedTurnSnapshotContract.PendingResolutionPath))!)) : null;
+        var catalog = MortalWoundTreatmentPersistedRequestCatalog.Parse(null, pending, history);
+        Assert.True(catalog.IsValid, DescribeValidationIssues(catalog.Issues));
+        Assert.Empty(catalog.HeldRequests);
+        Assert.Equal(result.Request.RequestFingerprint, Assert.Single(catalog.FinalizedRequests).RequestFingerprint);
+        var wound = ReadCurrentTreatmentWound(files);
+        Assert.Equal(HeldTreatmentPipelineContext.WoundId, wound.WoundId);
+        Assert.Equal("stabilized", wound.Care.State);
+        Assert.Equal(42, wound.Care.StabilizedAtTurn);
+        Assert.Equal(result.Request.Coordinates.AttemptId, wound.Care.LastAttemptId);
+        var stories = await CaptureGuaranteedNativeStoriesAsync(files);
+        var row = Assert.Single(stories.Values.SelectMany(bytes => MortalArchiveText(bytes!).Split('\n', StringSplitOptions.RemoveEmptyEntries))
+            .Select(line => JsonNode.Parse(line)!.AsObject()), story => story["turn"]!.GetValue<int>() == 42);
+        Assert.Equal(HeldTreatmentPipelineContext.FinalSceneText, row["narrative"]!.GetValue<string>());
+        Assert.False(files.FileExists(AcceptedMechanicsPlan.WoundCommandPath));
+        Assert.False(files.FileExists("ready/turn_complete.json"));
+        Assert.False(files.FileExists("input/turn_request.json"));
+        Assert.False(files.FileExists(LiveTurnPreparationService.PendingTurnSnapshotManifestPath));
+    }
+
+    private static async Task<decimal> ReadGuaranteedNativeEnergyAsync(FileSystemManager files)
+    {
+        var definitions = ResourceDefinitionCatalog.ParseCanonical(await files.ReadFileAsync(ResourceMaterializationContract.DefinitionsPath), false);
+        Assert.True(definitions.IsValid, DescribeValidationIssues(definitions.Issues));
+        var state = ResourceStateContract.ParseCanonical(await files.ReadFileAsync(ResourceMaterializationContract.StatePath), definitions.Catalog!, false);
+        Assert.True(state.IsValid, DescribeValidationIssues(state.Issues));
+        Assert.True(state.Ledger!.TryResolveExact(new ResourceCoordinate("mortal_world", ResourceOwnerKind.Player, "player_current", "energy"), out var energy));
+        return Assert.IsType<ResourceStateEntry>(energy).Current;
+    }
+
+    private static Task<Dictionary<string, byte[]?>> CaptureGuaranteedNativeStoriesAsync(FileSystemManager files) =>
+        CaptureMortalArchiveImagesAsync(files, Directory.GetFiles(files.ResolvePath("stories"), "*.jsonl")
+            .Select(path => Path.GetRelativePath(files.GameSessionPath, path).Replace('\\', '/')));
+
+    private static Task<Dictionary<string, byte[]?>> CaptureGuaranteedNativeOriginalAsync(FileSystemManager files) =>
+        CaptureMortalArchiveImagesAsync(files, Directory.GetFiles(files.GameSessionPath, "*", SearchOption.AllDirectories)
+            .Select(path => Path.GetRelativePath(files.GameSessionPath, path).Replace('\\', '/'))
+            .Where(path => path.StartsWith("input/", StringComparison.Ordinal) || path.Contains(".rollback.", StringComparison.Ordinal) ||
+                path.StartsWith("game_state/control/pending_turn_snapshot", StringComparison.Ordinal)));
+
+    private static async Task<Dictionary<string, string?>> CaptureGuaranteedNativeArtifactsAsync(FileSystemManager files)
+    {
+        var paths = GuaranteedNativeMechanicalPaths.Concat(new[]
+        {
+            AcceptedMechanicsPlan.WoundCommandPath, ResourceMaterializationContract.CommandPath, EffectAcceptedTurnPlan.CommandPath,
+            "input/turn_request.json", "ready/turn_complete.json", "ready/turn_error.json", "output/narrative_response.json",
+            "output/interface_updates.json", "output/debug_logs.json", "game_state/control/validation_repair_request.json",
+            LiveTurnPreparationService.PendingTurnSnapshotManifestPath, PendingTurnSnapshotAuthority.AuthorityPath
+        }).Concat((await CaptureGuaranteedNativeOriginalAsync(files)).Keys).Concat((await CaptureGuaranteedNativeStoriesAsync(files)).Keys)
+            .Distinct(StringComparer.Ordinal);
+        var result = new Dictionary<string, string?>(StringComparer.Ordinal);
+        foreach (var path in paths)
+        {
+            var bytes = await files.ReadFileBytesAsync(path);
+            result.Add(path, bytes is null ? null : Convert.ToBase64String(bytes));
+        }
+        return result;
+    }
+}
diff --git a/tests/selections/1536-fr063-guaranteed-native-same-root.json b/tests/selections/1536-fr063-guaranteed-native-same-root.json
new file mode 100644
--- /dev/null
+++ b/tests/selections/1536-fr063-guaranteed-native-same-root.json
@@ -0,0 +1,15 @@
+{
+  "schemaVersion": 1,
+  "selections": [
+    {
+      "category": "fr063-guaranteed-native-same-root",
+      "reason": "First same-physical-root fresh-process causal probe only: one Fact/one case/one descriptor, budget5/default10, existing child45s. Existing specified guaranteed energy2 mechanics and genuine held request are preconditions; source gap is not yet an observed RED. Source review precedes fresh matching preparation/catalog and first actual; freeze/EVIDENCE before any production correction. No accepted cohort repeats or deferred controls/new-root case.",
+      "contracts": [
+        "FR-063 full production-sealed confirmed held request/claim2 and original42 survive a fresh PID/registry/cache; no caller-prepared plan or helper authority before real ordinary late-terminal entry.",
+        "Lawful scene/interface/debug/Ready with exact session/request42/filesModified, official snapshot and same generation are independently verified before causal completion assertions.",
+        "Actual loop42/story42, energy2->0 and exactly one typed treatment/history/receipt/stabilization finalize the durable hold; accurate ordinary false result follows those oracles and second idle is byte inert.",
+        "Existing integration runtimeconfig/depsfile/Immutable binding and45s kill/join/drained logs; full available result/context/artifacts and strict source/auxiliary-root cleanup retained even failure."
+      ]
+    }
+  ]
+}
```
