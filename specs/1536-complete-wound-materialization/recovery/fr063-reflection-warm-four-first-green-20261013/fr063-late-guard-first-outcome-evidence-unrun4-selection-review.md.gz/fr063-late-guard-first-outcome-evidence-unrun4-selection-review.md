# FR063 late-guard first preflight outcome and independent UNRUN4 selection

Reviewer: retained actual Astra XHigh. Published evidence/selection checkpoint `7c48fdbae764e3b0faec3a9d02f6c19d93501170`; runtime and compile source `14d037d82198659c509066759dcbb02e32b2b5f7`, previously SOURCE accepted. Read-only artifact/source/connected GitHub inspection; no repository edit, Git command/mutation, project execution, provider or new agent. This requested external report is the only write.

**EVIDENCE/status ACCEPTED. Narrow SOURCE/SELECTION for the independent four previously UNRUN cases ACCEPTED.** The late-guard case remains FAILED and unqualified: actual preflight refusal and physical-byte preservation passed, but the subsequent live-probe IsValid assertion failed. Neither resource-hold loss nor a production regression is established by the captured boolean. No aggregate13/15 GREEN or pending2 waiver follows.

## Frozen evidence and provenance

Independently verified all45 artifacts in `recovery/fr063-late-guard-preflight-first-outcome-20261013/manifest.json`: every compressed and decompressed length/SHA256 matches, and every decompressed payload equals its retained native run file or external original. Read the complete native TRX, all result attributes, error/stack and stdout, native plans/summaries, build summaries and root/diagnostic companions.

All244 source pins are accounted for:242 current files match directly; only plan/tasks differ after execution. Removing their new37-line active insert restores both pinned lengths/hashes exactly, with checkbox-containing lines unchanged. The connected GitHub commit contains only the two status edits,45-artifact packet/manifest and new task-local selection—no C#, project, catalog, existing selection or production change. All11 fresh14d binary pins still match current lengths/SHA256. The initial preparation root record counted10; later exact-plan/catalog/actual records and final pin file count11 including the Immutable dependency. No claim that the initial record already contained11 is necessary.

Native preparation is consistent:

- BOTH PlanOnly `20261013-190512-375-15899-669ba3997dc54ce3bfbe718155ab4eb6-categories`:140.6463936s,exit0,6methods8cases4descriptors; integration and unit builds completed with96/35 warnings and0 errors; ZERO tests executed. Three unit source guards were build/discovery only.
- Exact PlanOnly `20261013-190959-730-16331-22d9058a6600447fb90bf125dbb84745-categories`:2.5575261s,exit0,3methods5cases3descriptors,ZERO tests.
- Catalog `20261013-191053-560-16506-e9346ed6d76c4979a06c4e2d6ef18305-categories`:5.6190915s,exit0,Valid=true,726categories/11567methods, no unmapped/stale selectors,ZERO tests.

These successful checks do not change the historical UNKNOWN preparation or prior frozen failures.

## Actual boundary and truthful qualification

Actual `20261013-191200-939-16725-77daa990886440dca6a5716d57e268f8-categories`:11.4567491s,exit1,1executed/0PASS/1FAIL. The first one-case descriptor completed and fail-fast stopped the selection: INCOMPLETE1/3descriptors1/5cases. Reflection3 and warm1 did not run. Native TRX/summary agree; no timeout, skip, duplicate test ID or missing first-descriptor result. The failed category's Completed=false is not a timeout assertion.

The source ordering and exact native stack establish:

1. Genuine held setup, ordinary-owner admission, signed-absent npc_skills before-image, actual lease turnover, deliberate file introduction and raw mismatch assertion were reached.
2. `OrdinaryOwner.cs:283–285` passed the exact `InvalidDataException` assertion for coordinator preflight, including `Accepted mechanics authority at 'game_state/npcs/npc_skills.json' changed after validation.`
3. The complete physical-byte comparison at line286 returned successfully.
4. At line287, `AssertConfirmedHeldLiveRegistryProbeAsync` failed at `MortalWoundTreatmentResourcePublicationLifecycleTests.cs:3376`: the reflected probe result's IsValid was false.

Within that helper the typed Finalize validity checks had returned before the probe assertion. However, probe Issues, State, ChangedCount and exact identity assertions follow the failing IsValid check and were not reached. The outer dedicated current-request, energy2, create-only-history checks and final guard outcome observation also were not reached. The earlier complete byte assertion is real evidence of unchanged physical images; it must not be inflated into successful live registry/hold qualification.

There is one native boundary observation, the pre-original NPC shape witness. There is no native guard-result observation or detailed probe diagnostic. Reconstructed test stdout and that one observation exactly equal their frozen companions; native result/error/stack objects exactly equal the root and error-family records. Therefore the exact reason for the invalid probe and current live hold disposition remain unresolved. A later source-backed diagnosis may distinguish an unsuitable probe from a production issue; this packet alone does neither. Do not weaken IsValid, replace the probe with a generic exception, or label hold loss/production causal RED from this FAIL.

The native strict cleanup receipt names `/tmp/boe-held-treatment-pipeline-f9d545d1d982404d8ebc0b2a23496768`, Removed=true/Failure=null; that exact root is physically absent. Runner-owned/runtime cleanup is separately true. No missing receipt or blanket cleanup claim is needed.

## Independent UNRUN4 selection

The new `tests/selections/1536-fr063-guaranteed-ordinary-owner-reflection-warm-unrun.json` is895 bytes, SHA256 `3d5a827023c34566cf59dc38762847a81d3f02dd92783b8791659b4a9ac5cd36`. Its two complete selection objects equal the existing late-guard selection's final two entries exactly, including reasons/contracts:

- `fr063-guaranteed-ordinary-owner-reflection`: one existing method/three rows (pending,terminal,unknown),budget2.
- `fr063-guaranteed-ordinary-owner-warm-fence`: one existing held-publication/restart-replay Fact/one case,budget2.

Source attributes and the fresh native exact plan already establish their membership. The new subset is **2methods4cases2integrationdescriptors, default9**. Catalog, methods, fixtures, shared helpers and production remain unchanged. This subset excludes the unresolved late-guard, qualified6/native/postseal, blockedpending2 and all unit/C5 actual execution. Its cases own independent fixture state and do not depend on passing the late-guard test first.

The narrow selection is sufficient to progress these existing unrun obligations without pretending to fix or qualify the failed live-probe boundary. Matching fresh14d binaries may be reused: verify source/binary equivalence immediately before execution, run exact NoBuild PlanOnly for the subset (ZERO tests), then only the selected four actual cases, with a frozen first outcome and POST pins. There is no concrete dependency requiring another successful BOTH build/catalog audit or repetition of already qualified cases for this metadata-only selection. Any intervening source/binary change invalidates that reuse condition.

## Status and remaining work

The active plan/tasks inserts faithfully distinguish actual1/planned5, proven preflight/physical preservation, unknown probe details, one strict cleanup root, four UNRUN cases and pending diagnosis. Earlier sections retain historical labels; no old packet is changed. The accepted pending-contour advice is correctly recorded as conditional proposed authoring scope, not SOURCE/runtime approval.

Ordinary13 still has eight accepted positive cases and five unresolved (late-guard1 plus UNRUN4). Original15's mandatory genuine pending2 persistence obligation remains OPEN. Full FR063, new-root qualification, T070 and #1536 are not closed. No accepted case is newly qualified by this failed run.

**Final verdict: EVIDENCE/status ACCEPTED; independent UNRUN4 SOURCE/SELECTION ACCEPTED at7c48fdba, with reviewed NoBuild/source/binary conditions. Late-guard live-probe semantics and full case qualification remain BLOCKED on diagnosis; no source fix is approved here.**

FINAL STOPPED.
