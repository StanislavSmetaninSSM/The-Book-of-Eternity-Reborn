#!/usr/bin/env python3
"""Read-only US5 source pinning and immutable native artifact preservation. No native runner/controller."""
import argparse, pathlib, subprocess, json, hashlib, gzip, os, re, xml.etree.ElementTree as ET
R=pathlib.Path('/workspace/The-Book-of-Eternity-Reborn'); OUT=R/'specs/1536-complete-wound-materialization/recovery'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
def closed(pairs):
 d={}
 for k,v in pairs:
  if k in d:raise ValueError('Duplicate JSON key '+k)
  d[k]=v
 return d
def read(p):return json.loads(pathlib.Path(p).read_text(),object_pairs_hook=closed)
def write(p,d):
 p=pathlib.Path(p); assert not p.exists(),p;p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def pin(require_clean=True):
 status=git('status','--porcelain').decode().splitlines()
 assert not status or (not require_clean and all(line.startswith('?? specs/1536-complete-wound-materialization/recovery/') for line in status)), 'Source must be committed and clean; only newly frozen recovery evidence may be untracked' 
 paths=git('ls-files','-z').decode().strip('\0').split('\0')
 roots=('BookOfEternityClient/','BookOfEternityClient.Tests/','BookOfEternityClient.IntegrationTests/','BookOfEternityClient.TestSupport/','BookOfEternityClient.WebFrontend/','scripts/','tests/')
 return {'git':git('rev-parse','HEAD').decode().strip(),'sourcePins':[{'path':p,'sha256':sha((R/p).read_bytes())} for p in paths if p.startswith(roots) or p in ('global.json','NuGet.Config','Directory.Build.props','Directory.Build.targets')]}
p=argparse.ArgumentParser();p.add_argument('action',choices=['pin','freeze']);p.add_argument('--pin',required=True);p.add_argument('--run');p.add_argument('--stdout');p.add_argument('--tag');p.add_argument('--native-exit',type=int);p.add_argument('--classification');a=p.parse_args()
if a.action=='pin':write(a.pin,pin());print(a.pin);raise SystemExit()
d=read(a.pin);assert d==pin(require_clean=False), 'Current source differs from pre-native snapshot'
run=pathlib.Path(a.run); files=sorted(x for x in run.rglob('*') if x.is_file())+[pathlib.Path(a.stdout),pathlib.Path(a.pin),pathlib.Path(__file__)]
packet={'task':'#1536 US5 bounded selected evidence','testedGit':d['git'],'nativeExit':a.native_exit,'classification':a.classification,'sourcePins':d['sourcePins'],'binaryPins':[],'chains':[],'cases':[],'proofIssues':[]}
for i,f in enumerate(files):
 b=f.read_bytes();name=f'{a.tag}-{i:02d}-{f.name}.gz';dest=OUT/name; assert not dest.exists(),dest
 z=gzip.compress(b,mtime=0);dest.write_bytes(z);packet['chains'].append({'origin':str(f),'tracked':name,'rawSha256':sha(b),'compressedSha256':sha(z)})
for project in ('BookOfEternityClient.Tests','BookOfEternityClient.IntegrationTests'):
 b=R/project/'bin/Debug/net8.0'
 for name in ('BookOfEternityClient.dll',project+'.dll',project+'.deps.json',project+'.runtimeconfig.json'):
  f=b/name
  if f.exists():packet['binaryPins'].append({'path':str(f.relative_to(R)),'sha256':sha(f.read_bytes())})
for f in run.rglob('summary.json'):
 packet['summary']=read(f)
for f in run.rglob('plan.json'):packet['plan']=read(f)
N={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
for f in run.rglob('*.trx'):
 root=ET.parse(f).getroot();defs={x.attrib['id']:x for x in root.findall('.//t:UnitTest',N)}
 for result in root.findall('.//t:UnitTestResult',N):
  definition=defs[result.attrib['testId']];m=definition.find('t:TestMethod',N)
  case={**result.attrib,'className':m.attrib['className'],'methodName':m.attrib['name'],'codeBase':m.attrib['codeBase'],'trx':str(f),'cleanup':[]}
  stdout=result.find('t:Output/t:StdOut',N)
  for line in (stdout.text or '').splitlines() if stdout is not None else []:
   line=line.strip()
   if line.startswith('{') and 'CleanupOwnedRoot' in line:
    receipt=json.loads(line,object_pairs_hook=closed);case['cleanup'].append(receipt)
    path=receipt.get('CleanupOwnedRoot');valid=(set(receipt)=={'CleanupOwnedRoot','OwnedFixtureRemoved','LeaseInactive','CleanupFailure'} and receipt['OwnedFixtureRemoved'] is True and receipt['LeaseInactive'] is True and receipt['CleanupFailure'] is None and isinstance(path,str) and os.path.isabs(path) and not os.path.lexists(path))
    if not valid:packet['proofIssues'].append('Invalid/nonabsent receipt '+case['testName'])
  if 'IntegrationTests' in case['codeBase'] and not case['cleanup']:packet['proofIssues'].append('No owned receipt '+case['testName'])
  packet['cases'].append(case)
roots=[x['CleanupOwnedRoot'] for c in packet['cases'] for x in c['cleanup']]
if len(roots)!=len(set(roots)):packet['proofIssues'].append('Duplicate owned root')
pkt=OUT/(a.tag+'-freeze.json');write(pkt,packet)
print(json.dumps({'packet':str(pkt),'sha256':sha(pkt.read_bytes()),'chains':len(files),'sourcePins':len(d['sourcePins']),'binaryPins':len(packet['binaryPins']),'cases':len(packet['cases']),'receipts':len(roots),'proofIssues':packet['proofIssues']},ensure_ascii=False))
