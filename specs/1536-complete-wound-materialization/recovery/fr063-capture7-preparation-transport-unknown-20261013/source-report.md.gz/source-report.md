# FR-063 private capture7 correction source report — 2026-10-13

FINAL STOPPED READY; all corrected SOURCE/build/discovery/catalog/runtime checks UNRUN. Baseed0d1880e5f732c71a2a4929135391eb4565ae81. Read exact capture7 brief and accepted controls evidence before edits. No project/build/test/fault/catalog/discovery/diagnostic/runtime or Git mutation, new agent/provider occurred.

## Bounded change and API/ownership proof

Only OrdinaryOwner.cs private CaptureOrdinaryTreatmentOwnerBytesAsync and AssertOrdinaryTreatmentOwnerBytesAsync now take HeldTreatmentPipelineContext. The existing context ReadFileBytesAsync at old lifecycle partial5130-5133 explicitly uses FileSystem.ReadFileBytesAsync(Lease,path) while its owned lease exists and uses the public reader only after release. FileSystemManager.cs1417-1428 validates that participating lease and performs its explicit core read. No early lease release, extra acquisition, lock bypass, raw FS fallback or swallowed IO error.

Complete prior union GuaranteedNativeMechanicalPaths + TreatmentOrdinaryGuardPaths + wound command/NPC/original manifest/authority is preserved and Ordinal-Distinct before Dictionary.Add. This removes overlap without excluding any protected byte/presence root. Null/present bytes stay exact. All6 capture and5 equality caller arguments now pass held. Pending2 received these compile-required argument substitutions only; its row24 pending-file assumption remains unchanged/BLOCKED. The duplicate AFTER diagnostic capture still occurs before AcquireLease; context therefore chooses the released/unbound reader in that phase and explicit owned reader after acquisition. All underlying mutations/admission/cache/refusal/take/hold/source/state/turnover oracles and ordering are exact after reversal of these helper changes.

The passing post-seal case uses OLD CaptureExactTreatmentTransactionBytesAsync/AssertExactTreatmentTransactionBytesAsync, already context-aware+distinct. It does not call the corrected private helpers. Its entire body, shared Plan/Published helpers, old transaction helper file, qualified native and shared archive capture are byte-exact; no passing dependency repeat is needed.

## Pending2 blocker remains explicit

Guaranteed source legitimately stores its complete request in command, not an existing pending file. Pending submittedTreatmentRequests requires a genuine NONEMPTY same-binding repair packet/receipt wave: MortalWoundTreatmentPersistence.cs248-296 and2701-2788; PersistenceValidation.cs50-87. Empty writer intentionally omits request copies; adding a graph by hand is explicitly rejected by ResolverTests.Persistence.cs1420-1456/1699-1726. No fake packet/opportunity, empty-root initializer, unrelated helper cohort, request seal/claim or production parser change was authored. Pending2 remains unqualified and excluded until its own meaningful fixture contour is approved.

## Selection and outcomes

Accepted first component outcome10executed1PASS9fixtureFAIL (target14),24immutablechains/242source/11binary/10strictabsent roots remains historical. Qualified native1 and passing postseal1 are retained; reflection3+warm1 still UNRUN. New intentional-overlap owner fr063-guaranteed-ordinary-owner-capture7-retry selects ONLY four failed methods/seven cases: nested2, current capability1, concurrent3, turnover1. Budget5. New task-local selection adds exact existing reflection1/3 budget2 and warm1/1 budget2:6methods11cases3descriptors/default14. No new test method/case; catalog static725categories/expected11567methods, not discovery. Old724 nodes/raw suffix and old full/global selections stay exact; retry alias is not added to full selections. Original15 = qualified native1+postseal1, blocked pending2, corrected/unrun11. FullFR063/T070/#1536 and every parent checkbox remain OPEN.

ROOT publishes/recovery -> actual independent SOURCE/FIXTURE/SELECTION -> fresh matching BOTH preparation/catalog0tests -> bounded retry11, with first outcomes frozen/EVIDENCE. No runtime PASS or production regression claim comes from fixture exceptions or these static checks.

## Checks actually performed (source/static only)

- Whole fixture reversal: only two private helper bodies/signatures and all compile-required context argument calls — PASS
- Passing PostSeal complete body byte-exact — PASS
- Blocked pending2 body exact after ONLY helper argument reversal — PASS
- Shared Plan/Published helpers byte-exact — PASS
- Explicit held-context capture6/assert5 calls, unchanged diagnostic after-read order and complete unique inventory — PASS
- Old724 catalog nodes and literal raw suffix byte-exact — PASS
- Capture owner4methods7cases plus exact old unrun4 =>6/11/3/default14, old selections unchanged — PASS
- ActiveMD insertions identical; whole prior documents/history/checkboxes exact on reversal — PASS
- Exact5-path scope and git diff --check — PASS
- Protected14 paths incl native, passing old helper, shared archive, ce955, host, all old/global selectors and production byte-exact — PASS

## Exact changed paths and SHA256

- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs`: `fbefee0fb31684d347793c3c264ccc3ec007a9b09c13388e5480bcc128e60337`
- `tests/categories.json`: `4a54b8ebd3c923c700b8b2194766e510eba7efb32ffd5212c8555f0a704206b3`
- `tests/selections/1536-fr063-guaranteed-ordinary-owner-capture7-retry.json`: `3661494b4c43b787af69dfdcd8515895331613182ce74b55c971479794caa61a`
- `specs/1536-complete-wound-materialization/plan.md`: `8a8825b23934f4a4cf3e0cffaade206d4888733a1788761607be41605fcd051d`
- `specs/1536-complete-wound-materialization/tasks.md`: `625968b091d2ce9c8af048b7a0ccfbf47a6114a986e4d228b531a6848c2fabde`

## Protected source pins

- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs`: `8e98458265939f41e0d46317859bfc3729835263bcbc54d45a9b28fb5868e716`
- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.cs`: `06a3377ad0f0574e6d6bb501c446719b03998fda628082a54a90526534f6cee7`
- `BookOfEternityClient.IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryConsumerArchive.cs`: `2ccdf58fedf0128b3ebfcfa8cf494de29669ffaf2fdb003f8f5cfb010c195d16`
- `BookOfEternityClient.IntegrationTests/GameEngineTurnLifecycleTests.QtePhysicalInjuryFinalization.cs`: `ce955dcb177fd609c240cfe0705a45b5cb792cf4887ba6b6832494d72d543e6f`
- `BookOfEternityClient.TestSupport/NativeHostScenarioDriver.cs`: `3743c5bbb23cc9b5046503d03a3df599c44c08342bd3bfbf0d33ab10cc726b83`
- `tests/selection.json`: `27006455535cc002e981dcffc40a9da07570279270dec10d587c138d906dc239`
- `tests/selections/1536-fr063-guaranteed-native-same-root.json`: `215190526104e3c2a51f0be461f671e254b89d1bb542f5a6a0f59c999d5af3aa`
- `tests/selections/1536-fr063-guaranteed-ordinary-owner-controls.json`: `0a0064ca2f387062992f0feaffbd86684c4182189df574ce2ed3c0905434ab00`
- `tests/selections/1536-fr063-guaranteed-ordinary-owner-preparation.json`: `3eceaf0997f9232af1b4917a28531315319ec5ae495c0fb194e55fd1dd7874e3`
- `tests/selections/1536-fr063-guaranteed-ordinary-owner-remainder.json`: `4d902b102ee18c1678f12fa7a5ba450cff7897518d333f026d2c4c4c6486f898`
- `BookOfEternityClient/Core/GameEngine/GameEngine.MortalGuaranteedTreatment.cs`: `fdacf8c145a10b9be5f09f1fde28415969d740e6526c84ab4097d4e9093b4642`
- `BookOfEternityClient/Services/AcceptedMechanicsWoundCommonInputComposer.cs`: `aa8fbbe9e1765d7c3381e0f9e85ffa2e82be74a7864e1a460b32097599208751`
- `BookOfEternityClient/Services/Validation/ValidationService.ResourceMaterialization.cs`: `560f146d8210f8347f53f53196054c42ba9406f92cd6ef073b30aa17fb2c7b83`
- `BookOfEternityClient/Services/MortalWoundTreatmentPersistence.cs`: `ca7b36dd5904e02d42de25b365d0fea597e9c7eee3651960d0e32184682070ef`

## Full bounded fixture diff

```diff
diff --git a/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs b/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs
index 895c280e..bbdebe1e 100644
--- a/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs
+++ b/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs
@@ -35,19 +35,19 @@ public sealed partial class GameEngineTurnLifecycleTests
             await held.FileSystem.WriteFileAtomicAsync(held.Lease,
                 WoundAcceptedTurnSnapshotContract.PendingResolutionPath, pending.ToJsonString());
             Assert.False(AcceptedMechanicsPlanAuthority.HasValidated(held.FileSystem, held.Lease));
-            var before = await CaptureOrdinaryTreatmentOwnerBytesAsync(held.FileSystem);
+            var before = await CaptureOrdinaryTreatmentOwnerBytesAsync(held);
             await held.ReleaseLeaseAsync();
             var (engine, snapshot) = await CreateHeldTreatmentValidationEngineAsync(held);
             var issues = await InvokePrivateAsync<IReadOnlyList<ValidationIssue>>(engine,
                 "ValidateResourceAndMortalGuaranteedTreatmentAsync", true, snapshot, HeldTreatmentPipelineContext.Turn);
             WritePhysicalInjuryDiagnostic("fr063_component_ordinary_pending_duplicate", new
-                { changed, Issues = issues, Before = MortalArchiveDigests(before), After = MortalArchiveDigests(await CaptureOrdinaryTreatmentOwnerBytesAsync(held.FileSystem)) });
+                { changed, Issues = issues, Before = MortalArchiveDigests(before), After = MortalArchiveDigests(await CaptureOrdinaryTreatmentOwnerBytesAsync(held)) });
             await held.AcquireLeaseAsync();
             if (changed)
             {
                 Assert.Contains(issues, issue => issue.Severity == IssueSeverity.Error);
                 Assert.False(AcceptedMechanicsPlanAuthority.HasValidated(held.FileSystem, held.Lease));
-                await AssertOrdinaryTreatmentOwnerBytesAsync(held.FileSystem, before);
+                await AssertOrdinaryTreatmentOwnerBytesAsync(held, before);
             }
             else
             {
@@ -88,7 +88,7 @@ public sealed partial class GameEngineTurnLifecycleTests
                 // Keep every original fingerprint/seal: the resolved payload itself now disagrees.
             }
             await held.FileSystem.WriteFileAtomicAsync(held.Lease, AcceptedMechanicsPlan.WoundCommandPath, root.ToJsonString());
-            var before = await CaptureOrdinaryTreatmentOwnerBytesAsync(held.FileSystem);
+            var before = await CaptureOrdinaryTreatmentOwnerBytesAsync(held);
             await held.ReleaseLeaseAsync();
             var (engine, snapshot) = await CreateHeldTreatmentValidationEngineAsync(held);
             var issues = await InvokePrivateAsync<IReadOnlyList<ValidationIssue>>(engine,
@@ -97,7 +97,7 @@ public sealed partial class GameEngineTurnLifecycleTests
             Assert.Contains(issues, issue => issue.Severity == IssueSeverity.Error);
             await held.AcquireLeaseAsync();
             Assert.False(AcceptedMechanicsPlanAuthority.HasValidated(held.FileSystem, held.Lease));
-            await AssertOrdinaryTreatmentOwnerBytesAsync(held.FileSystem, before);
+            await AssertOrdinaryTreatmentOwnerBytesAsync(held, before);
         }
         finally { await held.ReleaseLeaseAsync(); }
     }
@@ -117,7 +117,7 @@ public sealed partial class GameEngineTurnLifecycleTests
             Assert.Single(skill["mortalWoundTreatmentCapabilities"]!.AsArray());
             skill["mortalWoundTreatmentCapabilities"] = new JsonArray();
             await held.FileSystem.WriteFileAtomicAsync(held.Lease, NpcCoreChangesContract.NpcCorePath, npc.ToJsonString());
-            var before = await CaptureOrdinaryTreatmentOwnerBytesAsync(held.FileSystem);
+            var before = await CaptureOrdinaryTreatmentOwnerBytesAsync(held);
             await held.ReleaseLeaseAsync();
             var (engine, snapshot) = await CreateHeldTreatmentValidationEngineAsync(held);
             var issues = await InvokePrivateAsync<IReadOnlyList<ValidationIssue>>(engine,
@@ -126,7 +126,7 @@ public sealed partial class GameEngineTurnLifecycleTests
             Assert.Contains(issues, issue => issue.Severity == IssueSeverity.Error);
             await held.AcquireLeaseAsync();
             Assert.False(AcceptedMechanicsPlanAuthority.HasValidated(held.FileSystem, held.Lease));
-            await AssertOrdinaryTreatmentOwnerBytesAsync(held.FileSystem, before);
+            await AssertOrdinaryTreatmentOwnerBytesAsync(held, before);
             Assert.Equal(2, await ReadCurrentTreatmentEnergyAsync(held));
         }
         finally { await held.ReleaseLeaseAsync(); }
@@ -234,7 +234,7 @@ public sealed partial class GameEngineTurnLifecycleTests
                 submitted = EffectMaterializationTestFixture.CreateCommandRoot(apply);
             }
             await held.FileSystem.WriteFileAtomicAsync(held.Lease, path, submitted.ToJsonString());
-            var before = await CaptureOrdinaryTreatmentOwnerBytesAsync(held.FileSystem);
+            var before = await CaptureOrdinaryTreatmentOwnerBytesAsync(held);
             await held.ReleaseLeaseAsync();
             var (engine, snapshot) = await CreateHeldTreatmentValidationEngineAsync(held);
             var issues = await InvokePrivateAsync<IReadOnlyList<ValidationIssue>>(engine,
@@ -244,7 +244,7 @@ public sealed partial class GameEngineTurnLifecycleTests
             Assert.Equal("mortal_wound_treatment_ordinary_concurrent_work_unsupported", refusal.Code);
             await held.AcquireLeaseAsync();
             Assert.False(AcceptedMechanicsPlanAuthority.HasValidated(held.FileSystem, held.Lease));
-            await AssertOrdinaryTreatmentOwnerBytesAsync(held.FileSystem, before);
+            await AssertOrdinaryTreatmentOwnerBytesAsync(held, before);
             Assert.True(await ContainsCurrentExactTreatmentRequestAsync(held));
             Assert.Equal(2, await ReadCurrentTreatmentEnergyAsync(held));
             Assert.Single(ReadCurrentTreatmentHistory(held.FileSystem).State!.Transitions);
@@ -275,14 +275,14 @@ public sealed partial class GameEngineTurnLifecycleTests
             await held.ReleaseLeaseAsync(); // The absence proof must survive this real owner lease turnover.
             await held.FileSystem.WriteFileAtomicAsync(path, new JsonObject
                 { ["NPCActiveSkillChanges"] = new JsonArray(), ["NPCPassiveSkillChanges"] = new JsonArray() }.ToJsonString());
-            var before = await CaptureOrdinaryTreatmentOwnerBytesAsync(held.FileSystem);
+            var before = await CaptureOrdinaryTreatmentOwnerBytesAsync(held);
             var validator = GetPrivateField<ValidationService>(engine, "_validator");
             var issues = await validator.ValidateAcceptedTurnRawResourceMaterializationAsync();
             Assert.Contains(issues, issue => issue.FilePath == path && issue.Code == "accepted_mechanics_wound_live_before_image_mismatch");
             await held.AcquireLeaseAsync();
             await Assert.ThrowsAsync<InvalidDataException>(() => GetPrivateField<CanonicalStateNormalizer>(engine, "_normalizer")
                 .BindTo(held.Lease).NormalizeAcceptedMechanicsAsync(backups: null));
-            await AssertOrdinaryTreatmentOwnerBytesAsync(held.FileSystem, before);
+            await AssertOrdinaryTreatmentOwnerBytesAsync(held, before);
             await AssertConfirmedHeldLiveRegistryProbeAsync(held);
             Assert.True(await ContainsCurrentExactTreatmentRequestAsync(held));
             Assert.Equal(2, await ReadCurrentTreatmentEnergyAsync(held));
@@ -326,15 +326,22 @@ public sealed partial class GameEngineTurnLifecycleTests
         Assert.Null(await held.FileSystem.ReadFileBytesAsync(AcceptedMechanicsPlan.WoundCommandPath));
     }
 
-    private static Task<Dictionary<string, byte[]?>> CaptureOrdinaryTreatmentOwnerBytesAsync(FileSystemManager files) =>
-        CaptureMortalArchiveImagesAsync(files, GuaranteedNativeMechanicalPaths.Concat(AcceptedMechanicsWoundCommonInputComposer.TreatmentOrdinaryGuardPaths).Concat(new[]
-        {
-            AcceptedMechanicsPlan.WoundCommandPath, NpcCoreChangesContract.NpcCorePath,
-            LiveTurnPreparationService.PendingTurnSnapshotManifestPath, PendingTurnSnapshotAuthority.AuthorityPath
-        }));
+    private static async Task<Dictionary<string, byte[]?>> CaptureOrdinaryTreatmentOwnerBytesAsync(HeldTreatmentPipelineContext held)
+    {
+        var paths = GuaranteedNativeMechanicalPaths
+            .Concat(AcceptedMechanicsWoundCommonInputComposer.TreatmentOrdinaryGuardPaths)
+            .Concat(new[]
+            {
+                AcceptedMechanicsPlan.WoundCommandPath, NpcCoreChangesContract.NpcCorePath,
+                LiveTurnPreparationService.PendingTurnSnapshotManifestPath, PendingTurnSnapshotAuthority.AuthorityPath
+            }).Distinct(StringComparer.Ordinal);
+        var result = new Dictionary<string, byte[]?>(StringComparer.Ordinal);
+        foreach (var path in paths) result.Add(path, await held.ReadFileBytesAsync(path));
+        return result;
+    }
 
-    private static async Task AssertOrdinaryTreatmentOwnerBytesAsync(FileSystemManager files, IReadOnlyDictionary<string, byte[]?> before)
+    private static async Task AssertOrdinaryTreatmentOwnerBytesAsync(HeldTreatmentPipelineContext held, IReadOnlyDictionary<string, byte[]?> before)
     {
-        foreach (var pair in before) Assert.Equal(pair.Value, await files.ReadFileBytesAsync(pair.Key));
+        foreach (var pair in before) Assert.Equal(pair.Value, await held.ReadFileBytesAsync(pair.Key));
     }
 }
```
