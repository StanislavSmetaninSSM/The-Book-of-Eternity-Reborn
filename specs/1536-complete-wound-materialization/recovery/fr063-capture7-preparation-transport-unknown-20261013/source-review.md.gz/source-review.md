# FR063 capture7 fixture correction: independent source review

Candidate: `b3bdd4af7547f5dc28ed03c3580e76f2eef14767`.
Source block baseline: `ed0d1880e5f732c71a2a4929135391eb4565ae81`; cumulative review package baseline: `2f670f4fd33c726520808c1dc0bb7269163c8338`.

**SOURCE / FIXTURE / SELECTION: ACCEPTED for the bounded capture7 correction and exact 11-case retry. No confirmed Critical or Important finding remains in this delta.** This does not accept the blocked pending pair or qualify the original 15-case cohort.

No repository edits, Git mutations, builds, discovery, tests, provider calls or new agents were performed. Read-only immutable object/file comparisons and static selection checks support this verdict; corrected build/runtime outcomes remain UNRUN.

## Exact correction and retained contracts

`MortalWoundTreatmentResourcePublicationLifecycleTests.OrdinaryOwner.cs:329–347` now captures and compares through `HeldTreatmentPipelineContext.ReadFileBytesAsync`. The existing implementation in the shared lifecycle partial at lines5130–5133 selects `FileSystem.ReadFileBytesAsync(_lease, path)` while its lease is active and the public reader only after release. The explicit overload validates that participating lease (`Core/FileSystemManager.cs:1417–1428`). This fixes the actual competing-main-owner capture failure without an extra acquisition, early release, lock bypass, raw filesystem read or swallowed error.

The complete prior union remains present: native mechanical roots, every treatment ordinary guard path, wound command, NPC core, original manifest and original authority. `Distinct(StringComparer.Ordinal)` precedes dictionary insertion with the same ordinal comparer. Each unique path is read once; absent null and present bytes remain unchanged representations. No authority or guard member is discarded to avoid the duplicate effect-identity path.

All six capture call sites and five equality call sites now pass `held`. Phase order is unchanged. In particular, the late-guard Fact still performs actual lease release and absent-to-present mutation before its capture and intended validator/take refusal; its later equality read uses the reacquired lease. The pending diagnostic's after-capture remains before reacquisition, so the existing context legitimately selects its released-lease read in that phase.

I independently reversed only those argument substitutions and the two helper changes and recovered the complete baseline fixture exactly. This preserves all underlying mutations, admission/cache/refusal/take/state/hold assertions and cleanup. The blocked pending rows retain their original setup and assertions apart from compile-required helper arguments; neither is selected for this retry.

The entire passing post-seal Fact is byte-identical and calls the separate existing transaction capture/assert helpers. Its shared plan/publication helpers are unchanged. The qualified native Fact, shared lifecycle fixture, shared archive capture, NativeHost driver, protected QTE Fact, production files and old selections are also unchanged. No dependency in this correction justifies repeating native1 or post-seal1.

Static API assessment: the private held-context type and its Task<byte[]?> reader already exist in the same partial class; each migrated call has that context in scope. The new async Task<Dictionary<string, byte[]?>> helper preserves all awaited operations and result types. There is no new project, external API, namespace dependency or runtime interface.

## Selection and preparation

The new intentional-overlap category `fr063-guaranteed-ordinary-owner-capture7-retry` selects exactly:

| Existing method responsibility | Cases |
|---|---:|
| Nested full request / resolved-result tamper | 2 |
| Current required capability drift | 1 |
| Actual concurrent resource / effect / party work | 3 |
| Absent guard across real lease turnover | 1 |

That is **4 methods / 7 cases / 1 integration descriptor**, budget 5 minutes. Its scope and exclusions explicitly omit the passing post-seal case, qualified native case and blocked pending pair.

The task-local retry adds only the existing reflected-Core theory (**1 method / 3 cases**, budget2) and named warm-fence Fact (**1 method / 1 case**, budget2), both unrun in the failed first remainder. Therefore the actual selection is **6 methods / 11 cases / 3 integration descriptors**, default overall14. The reflection and warm entries are byte-equivalent JSON values to the prior selected entries.

The external private preparation file adds the three existing unit source guards solely for fresh BOTH-project build/discovery: **9 methods / 14 cases / 4 descriptors**, zero execution. Its first three entries exactly equal the actual retry selection. This preparation does not authorize unit execution, C5 runtime checks or repetition of passing cohorts. Its SHA-256 is `f81a119ed73a64ddceb1370706ee825ddb97a9b1d6acfe9c86030693cd99c90d`.

All existing 724 catalog nodes and their literal old suffix are unchanged. One alias is prepended; no test declaration or case is added. Expected catalog725 / methods11567 remains a static expectation until official discovery. The new alias is not inserted into old full/global selections. Exact existing method declarations and their Fact/InlineData counts were checked from source.

## Metadata and preservation

The five-path source block consists only of the fixture, catalog, new selector and active plan/tasks. The eight-path cumulative package additionally preserves the already accepted evidence report and the coordinator's separately scoped GM planning follow-up/status. It contains no production implementation or GM file move.

The identical active plan/tasks insertion preserves all historical bytes and checkbox lines. Its accounting is honest: original15 = qualified native1 + passing post-seal1 + blocked pending2 + corrected/unrun11. It does not turn the nine prerequisite failures into production refusal proof. Full FR063/T070/#1536 and later new-root/UI work remain open. The GM follow-up records conditional planning disposition and actual-delivery UNRUN; this FR063 gate does not independently qualify GM implementation or runtime.

The separate pending-wave report is `/workspace/boe-cloud-tools-20261013/fr063-pending2-genuine-wave-readonly-seam.md` (SHA-256 `9289374780e1094cffe39747794ad8f8c86fcf516559b6866003f90b8e9aaf2a`). It leaves pending2 blocked as a responsibility mismatch: no synthetic or empty repair wave is authorized, and no removal or replacement coverage is approved here.

## Independent verification and release limits

- Candidate local HEAD and all changed working files match the specified immutable candidate.
- Whole fixture reversal, passing post-seal body and 14 named protected paths: exact.
- Of the preceding 242 pinned paths, only the fixture, catalog and two active metadata files changed; other pinned implementation/contract paths remain exact.
- Fixture SHA-256: `fbefee0fb31684d347793c3c264ccc3ec007a9b09c13388e5480bcc128e60337`.
- Catalog SHA-256: `4a54b8ebd3c923c700b8b2194766e510eba7efb32ffd5212c8555f0a704206b3`.
- New actual selector SHA-256: `3661494b4c43b787af69dfdcd8515895331613182ce74b55c971479794caa61a`.
- Author report hash matches the supplied `69790c0357a217f33616eeeace17bca565e9ce9eb3ddd0cec8feafc032ae52ee`; its claims were checked against source rather than used as proof.

**Release:** fresh matching BOTH-project zero-execution preparation, exact retry discovery and the catalog audit may proceed. After those succeed with matching source/binary pins, execute only the reviewed **11 integration cases**, freeze the first outcome and obtain EVIDENCE review. A prior binary from source9532 is not a corrected-fixture binary. No repeat of native1/post-seal1 or execution of blocked pending2 is warranted by this delta.

FINAL STOPPED.
