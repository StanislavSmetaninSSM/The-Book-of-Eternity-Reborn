# FR063 Task1b fixture-only SOURCE handoff — 2026-10-13

Authoring base `7fce4aa9fa00c191e76871dfff9b737f077a9362`. **FINAL STOPPED READY** for ROOT publication/recovery and mandatory independent SOURCE/FIXTURE/SELECTION. No project/build/discovery/runtime/Git mutation/new agent/provider/model operation. All corrected SOURCE/preparation/catalog/actual checks remain UNRUN; this is not completed runtime qualification.

First diagnostic EVIDENCE/status accepted5d8a26d8:46artifact chains/231source/11binary/two strict roots. One unique native case currently has2invocations2executions0PASS2FAIL. Actual three Test mentor issues are NPC fixture prerequisites, not proven treatment restoration RED. Old packets/history and accepted bounded8/proof20/finite68/baselines remain immutable/unrerun. Production remains LOCKED.

## Exact four-path whitelist/SHA256

- `BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs` — `21e05c326af3f29a8a81a6493dfb314af8e6995797cd7275b43eacc855c64179`
- `specs/1536-complete-wound-materialization/plan.md` — `a3825faad01370fd7ff7af405673f87a3b0510f1550ad7af1d366fd85710f6f5`
- `specs/1536-complete-wound-materialization/tasks.md` — `f1b79ddb19d1c03bd1d101da1cd25cb4587b5b59c7ea6aeea7c7f22ea21ea1b2`
- `docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md` — `67960ad7e0e79632dfc3a5865d6e0c23a0aeb999fe88e8316dd66c7c4aeef23e`

Only the requested external report is additional outside the repository. Existing warm helper/defaults, production/NPC validator/normalizer/authority sources, category/selectors/NativeHost/global runner/CI and frozen evidence are unchanged.

## Exact fixture correction and API/order proof

Native Fact now supplies existing configureBeforePreparation named argument pointing to one private callback. ResourcePublicationLifecycleTests.cs:3002 signature takes Func<FileSystemManager,Task>?;3042–3048 calls it after SeedHeldTreatmentAuthorityAsync/baseline bootstrap and before LiveTurnPreparationService.PrepareAsync, rollback/signed original, fresh ExportCurrent/PrepareGuaranteedRequest/resolved claims/StateDistributor. No helper refactor/new seam. Callback acts only on the per-test owned bootstrap NPC root before genuine authority is minted.

Callback requires the single exact NPCsInScene provider with NPCId field_medic_01, absent tradeInventoryReceipts and no root/row UpdateNpcTradeInventoryReceipts input. It calls existing NpcTradeRequestState.NormalizeNpcTradeReceiptsShape(JsonObject) (public static function278; public const ReceiptsProperty/UpdateReceiptsProperty in the same internal Services class, accessible to this existing friend test assembly). It asserts the result array is empty. Clone/remove that one added property must deeply equal the complete before root and serialize in the exact old property order; all name/identity/active skill/capabilities/location/stock/other actor/root values are thereby unchanged. The only write is the owned bootstrap NPC root; physical readback must deep-equal the candidate. Native witness records before/after hashes and the pre-original boundary.

No original/request/snapshot/backups/command are rewritten after creation, no source copied/re-signed, no private authority is passed to the child. The actual original42 is later created normally by the same existing helper from the settled canonical current schema. Raw held command/request/claim2/resource/cold-original oracles remain identical.

Source basis: CanonicalStateNormalizer.Npcs.cs:186+ -> MortalItemPublicationTailTransforms.NpcTrade:79–106 -> NpcTradeRequestState.NormalizeNpcTradeReceiptsShape:278 adds[] for the missing field. Existing whole-object unchanged signature comparison is NpcWorldAndMeta.cs:815–891. The old native signed provider lacked the field; old post-normalization current NPC bytes were not captured, so no retrospective measured-diff claim is made. This routine current-bootstrap correction avoids treating a shape-only tail change as newly authored actor work without waiving the actual NPC rules.

## Evidence-only current NPC witnesses

Adds exact current npc_core path to existing CaptureGuaranteedNativeArtifactsAsync. Original/rollback NPC files were already captured; next pre-caller/after-caller/finally now retain current root too. The existing successful Format1 PRESENT repair request observation additionally reads real current NPC bytes/length/SHA while committed request is visible, before Escape rollback. Its existing catch/explicit capture failure, declared image byte/SHA checks, sequence/stdout/result/reset lifetime stay unchanged. No data from these witnesses feeds accepted authority or repairs state. The current-root read is an expected-present fixture source; a missing/unreadable file remains explicit diagnostic failure, not ignored.

## Preservation/static proof

PASS git diff --check/exact four-path status. Exact reversal of the added call argument, private callback and two NPC diagnostic additions restores the ENTIRE old NativeCold.cs. Thus all existing caller/input/Escape/Ready/debug/journal/no-Export-Restore-reducer-Compose prelude/observer failure and Format1 guards/completion/energy2->0/one spend/history/receipt/stabilization/finalized hold/second-idle/cleanup oracles remain exact. The public-output and publication assertion/helper region is explicitly byte-equal.

PASS old warm helper/NativeHost/category/selection/runner/global selection/original causal source are exact. One Fact/no Theory, one1/1/1 selected owner/category5/default10 and child45s remain. Catalog stays721categories/expected11561methods; no new xUnit method/case/owner. The private callback is fixture plumbing only.

PASS active plan/tasks Task1b body agreement. Historical tails from FR063 actual repair diagnostic onward remain byte-exact; every checkbox in both specs and dated plan unchanged. Dated plan gains only an authoring note; none of the runtime steps are closed. User immediate-guidance alignment/GM modularization remain separate and untouched.

Protected original causal SHA256 remains `ce955dcb177fd609c240cfe0705a45b5cb792cf4887ba6b6832494d72d543e6f`. FullFR063/T070/parent/#1536 open; no new-root or deferred controls authored.

## Remaining gates

ROOT exact diff/readback -> WIP publication/actual remote/GitHub-only recovery -> actual independent retained Astra XHigh SOURCE/FIXTURE/SELECTION -> fresh matching BOTH preparation/exact1/1/1 plan/catalog0execution -> only this affected native case. Freeze raw outcome/current-vs-original NPC witnesses/source/binary/cleanup and EVIDENCE before any next fixture or production correction. No accepted cohort repeat requested. No GM docs/example update: test-only bootstrap normal form changes no production/public grammar/treatment policy.

No broader seam/API blocker established. Source/API/static checks are not compilation or runtime proof. Newly added NPC shape and before/after witnesses are UNRUN. STOPPED.

## Full bounded diff

```diff
diff --git a/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs b/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs
index d3449566..29911d15 100644
--- a/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs
+++ b/BookOfEternityClient.IntegrationTests/MortalWoundTreatmentResourcePublicationLifecycleTests.NativeCold.cs
@@ -34,7 +34,8 @@ public sealed partial class GameEngineTurnLifecycleTests
     {
         // Existing canonical bootstrap is a precondition, not a new QTE creation proof.
         await using var held = await CreateHeldTreatmentPipelineContextAsync(
-            fault: null, withRollbackAuthority: true, composePublication: false);
+            fault: null, withRollbackAuthority: true, composePublication: false,
+            configureBeforePreparation: PrepareGuaranteedNativeNpcReceiptShapeAsync);
         using var owned = new CleanupOwnedFixture(held.Root, line => _directGachaOutput?.WriteLine(line));
         var files = held.FileSystem;
         Assert.False(AcceptedMechanicsPlanAuthority.HasValidated(files, held.Lease));
@@ -286,12 +287,15 @@ public sealed partial class GameEngineTurnLifecycleTests
                 Assert.Equal(sha256, MortalArchiveHash(actualBytes));
                 var rawRequest = MortalArchiveText(actualBytes);
                 using var request = JsonDocument.Parse(rawRequest);
+                var currentNpcBytes = File.ReadAllBytes(files.ResolvePath(NpcCoreChangesContract.NpcCorePath));
                 var requestObservation = new
                 {
                     Sequence = repairPublications.Count, Format = format, TransactionId = transactionId,
                     Committed = committed, MemberPath = requestPath, ActualBytesLength = actualBytes.LongLength,
                     ActualSha256 = MortalArchiveHash(actualBytes), ActualBytes = Convert.ToBase64String(actualBytes),
-                    RawRequest = rawRequest, Request = request.RootElement.Clone()
+                    RawRequest = rawRequest, Request = request.RootElement.Clone(),
+                    CurrentNpcCore = new { Path = NpcCoreChangesContract.NpcCorePath, Bytes = Convert.ToBase64String(currentNpcBytes),
+                        Length = currentNpcBytes.LongLength, Sha256 = MortalArchiveHash(currentNpcBytes) }
                 };
                 repairPublications.Add(requestObservation);
                 Console.WriteLine(JsonSerializer.Serialize(new { Boundary = "fr063_guaranteed_native_repair_request", Observation = requestObservation }));
@@ -307,6 +311,36 @@ public sealed partial class GameEngineTurnLifecycleTests
         }
     }
 
+    private async Task PrepareGuaranteedNativeNpcReceiptShapeAsync(FileSystemManager files)
+    {
+        // The existing callback runs after canonical bootstrap and before original/request/claim creation.
+        var beforeBytes = Assert.IsType<byte[]>(await files.ReadFileBytesAsync(NpcCoreChangesContract.NpcCorePath));
+        var root = JsonNode.Parse(MortalArchiveText(beforeBytes))!.AsObject();
+        var beforeRoot = root.DeepClone().AsObject();
+        var provider = Assert.IsType<JsonObject>(Assert.Single(root[GuardianPolicyContracts.NpcCoreSceneSectionName]!.AsArray()));
+        Assert.Equal(HeldTreatmentPipelineContext.ProviderId, provider["NPCId"]!.GetValue<string>());
+        Assert.False(root.ContainsKey(NpcTradeRequestState.UpdateReceiptsProperty));
+        Assert.False(provider.ContainsKey(NpcTradeRequestState.UpdateReceiptsProperty));
+        Assert.False(provider.ContainsKey(NpcTradeRequestState.ReceiptsProperty));
+        NpcTradeRequestState.NormalizeNpcTradeReceiptsShape(provider);
+        Assert.Empty(provider[NpcTradeRequestState.ReceiptsProperty]!.AsArray());
+        var withoutReceiptShape = root.DeepClone().AsObject();
+        var unchangedProvider = Assert.IsType<JsonObject>(Assert.Single(withoutReceiptShape[GuardianPolicyContracts.NpcCoreSceneSectionName]!.AsArray()));
+        Assert.True(unchangedProvider.Remove(NpcTradeRequestState.ReceiptsProperty));
+        Assert.True(JsonNode.DeepEquals(beforeRoot, withoutReceiptShape));
+        Assert.Equal(beforeRoot.ToJsonString(), withoutReceiptShape.ToJsonString());
+        await files.WriteFileAtomicAsync(NpcCoreChangesContract.NpcCorePath, root.ToJsonString());
+        var afterBytes = Assert.IsType<byte[]>(await files.ReadFileBytesAsync(NpcCoreChangesContract.NpcCorePath));
+        Assert.True(JsonNode.DeepEquals(root, JsonNode.Parse(MortalArchiveText(afterBytes))));
+        WritePhysicalInjuryDiagnostic("fr063_guaranteed_native_pre_original_npc_shape", new
+        {
+            Path = NpcCoreChangesContract.NpcCorePath, ProviderId = HeldTreatmentPipelineContext.ProviderId,
+            BeforeSha256 = MortalArchiveHash(beforeBytes), AfterSha256 = MortalArchiveHash(afterBytes),
+            AddedOnlyEmptyCanonicalReceipts = true, AllOtherProviderAndRootPropertiesUnchanged = true,
+            BeforeOriginalRequestAndClaims = true
+        });
+    }
+
     private static async Task WriteGuaranteedNativeOrdinaryOutputsAsync(
         FileSystemManager files, PendingTurnSnapshotReadAuthority original)
     {
@@ -409,7 +443,8 @@ public sealed partial class GameEngineTurnLifecycleTests
             AcceptedMechanicsPlan.WoundCommandPath, ResourceMaterializationContract.CommandPath, EffectAcceptedTurnPlan.CommandPath,
             "input/turn_request.json", "ready/turn_complete.json", "ready/turn_error.json", "output/narrative_response.json",
             "output/interface_updates.json", "output/debug_logs.json", "game_state/control/validation_repair_request.json",
-            LiveTurnPreparationService.PendingTurnSnapshotManifestPath, PendingTurnSnapshotAuthority.AuthorityPath
+            LiveTurnPreparationService.PendingTurnSnapshotManifestPath, PendingTurnSnapshotAuthority.AuthorityPath,
+            NpcCoreChangesContract.NpcCorePath
         }).Concat((await CaptureGuaranteedNativeOriginalAsync(files)).Keys).Concat((await CaptureGuaranteedNativeStoriesAsync(files)).Keys)
             .Distinct(StringComparer.Ordinal);
         var result = new Dictionary<string, string?>(StringComparer.Ordinal);
diff --git a/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md b/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md
index 3740cbf0..855a39e4 100644
--- a/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md
+++ b/docs/superpowers/plans/2026-10-13-fr063-guaranteed-native-cold-orchestration.md
@@ -198,6 +198,14 @@ authority reconstruction/correction or immediate-guidance source was authored. N
 
 ## Task 1b: Canonical NPC receipt precondition before genuine original
 
+**Task1b authoring checkpoint:** FIXTURE-ONLY SOURCE READY at base7fce4aa9fa00c191e76871dfff9b737f077a9362.
+Existing callback settles only the exact provider's absent empty tradeInventoryReceipts before real
+original/request/claims; all other properties are deep/order invariant. Current NPC artifact and
+PRESENT repair-time byte/hash witnesses are evidence only, still UNRUN. Existing helper/defaults,
+production, Fact/oracles/input/Ready/observer/selection/bounds/catalog remain unchanged. Independent
+SOURCE review and corrected preparation/runtime remain UNRUN; no restoration RED or fix claimed.
+All historical outcomes/checkboxes remain unchanged; guidance alignment is outside this source block.
+
 - [ ] Reuse only the existing configureBeforePreparation callback in the native parent to initialize
   field_medic_01's empty canonical tradeInventoryReceipts before the genuine original is minted.
   Preserve existing provider identity/capability/stock/currency/state and original/command/held authority.
diff --git a/specs/1536-complete-wound-materialization/plan.md b/specs/1536-complete-wound-materialization/plan.md
index c4ed804d..f3f50996 100644
--- a/specs/1536-complete-wound-materialization/plan.md
+++ b/specs/1536-complete-wound-materialization/plan.md
@@ -35,6 +35,20 @@ catalog0execution,onlyaffectednativeactual; freeze/publish/EVIDENCE its firstout
 GMdocmodularization staysread-onlyproposal; nofilemovesbeforestructureagreement. Immediatewound
 recommendations policy/docs alignment remains separate; no diagnosis mechanics invented.
 
+Task1b FIXTURE-ONLY SOURCE READY on authoring base7fce4aa9fa00c191e76871dfff9b737f077a9362.
+The existing configureBeforePreparation seam invokes a private native-fixture callback after provider
+bootstrap but BEFORE PrepareAsync/original/backups/request/claims. It requires the single exact
+field_medic_01 provider, absent canonical receipts and no receipt-update input; the existing pure
+NormalizeNpcTradeReceiptsShape adds only[]. Deep/order equality after removing that one property
+proves all root/provider/name/skill/location/stock/capability values unchanged, with physical readback.
+No old warm helper/default or production changes. Currentnpc_core joins the existing artifact capture
+and the committed PRESENT repair witness records its real bytes/hash before rollback. These are
+newly authored UNRUN witnesses; historical currentNPCafterimage remains unobserved. Original/cold
+caller/input/Ready/debug/journal/observer checks and all strict treatment/second-idle assertions remain
+unchanged,one1/1/1 selection/category5/default10/child45s/catalog72111561. SOURCE review and all
+corrected build/discovery/catalog/runtime are UNRUN. Production restoration remains LOCKED until
+actual lawful NPC admission and treatment oracles are observed; old2FAIL history/packets stay exact.
+
 ## FR-063 actual repair diagnostic — 2026-10-13 (NPC ERRORS OBSERVED; EVIDENCE PENDING)
 
 Task1a test-only sourceb08d7750e543d39a1dddbad4ee3cbab9b2a8b1a5 independently SOURCE/FIXTURE/
diff --git a/specs/1536-complete-wound-materialization/tasks.md b/specs/1536-complete-wound-materialization/tasks.md
index 6267d450..3ece9a22 100644
--- a/specs/1536-complete-wound-materialization/tasks.md
+++ b/specs/1536-complete-wound-materialization/tasks.md
@@ -31,6 +31,20 @@ catalog0execution,onlyaffectednativeactual; freeze/publish/EVIDENCE its firstout
 GMdocmodularization staysread-onlyproposal; nofilemovesbeforestructureagreement. Immediatewound
 recommendations policy/docs alignment remains separate; no diagnosis mechanics invented.
 
+Task1b FIXTURE-ONLY SOURCE READY on authoring base7fce4aa9fa00c191e76871dfff9b737f077a9362.
+The existing configureBeforePreparation seam invokes a private native-fixture callback after provider
+bootstrap but BEFORE PrepareAsync/original/backups/request/claims. It requires the single exact
+field_medic_01 provider, absent canonical receipts and no receipt-update input; the existing pure
+NormalizeNpcTradeReceiptsShape adds only[]. Deep/order equality after removing that one property
+proves all root/provider/name/skill/location/stock/capability values unchanged, with physical readback.
+No old warm helper/default or production changes. Currentnpc_core joins the existing artifact capture
+and the committed PRESENT repair witness records its real bytes/hash before rollback. These are
+newly authored UNRUN witnesses; historical currentNPCafterimage remains unobserved. Original/cold
+caller/input/Ready/debug/journal/observer checks and all strict treatment/second-idle assertions remain
+unchanged,one1/1/1 selection/category5/default10/child45s/catalog72111561. SOURCE review and all
+corrected build/discovery/catalog/runtime are UNRUN. Production restoration remains LOCKED until
+actual lawful NPC admission and treatment oracles are observed; old2FAIL history/packets stay exact.
+
 ## FR-063 actual repair diagnostic — 2026-10-13 (NPC ERRORS OBSERVED; EVIDENCE PENDING)
 
 Task1a test-only sourceb08d7750e543d39a1dddbad4ee3cbab9b2a8b1a5 independently SOURCE/FIXTURE/
```
